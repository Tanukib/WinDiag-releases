﻿<#
.SYNOPSIS
    Telomera - interface gráfica para pessoas leigas.

.DESCRIPTION
    Janela simples em etapas: verificar, ver o que foi encontrado (em linguagem comum) e corrigir
    com confirmação. O motor de diagnóstico é o mesmo do Telomera.ps1 e roda em segundo plano,
    para a janela não travar.

    Abra com o arquivo Abrir-Telomera.bat (duplo clique).
    Licença: MIT.
#>

$ErrorActionPreference = 'Continue'

# ----------------------------------------------------------------------------
# Início seguro: qualquer falha antes da janela aparece em uma caixa de mensagem
# ----------------------------------------------------------------------------
try { . (Join-Path $PSScriptRoot 'Telomera-Monitor.ps1') } catch { }
$script:PastaDados = ''
try { $script:PastaDados = Join-Path $env:LOCALAPPDATA 'Telomera' } catch { }
if (-not $script:PastaDados) { $script:PastaDados = Join-Path ([IO.Path]::GetTempPath()) 'Telomera' }
$script:ArquivoErros = Join-Path $script:PastaDados 'erros.log'

function Write-LogErro {
    # Grava o erro (com versão, Windows e pilha de chamadas) em %LOCALAPPDATA%\Telomera\erros.log e devolve o texto gravado.
    param($Erro, [string]$Origem = '')
    $msg = "$Erro"
    $linhas = New-Object System.Collections.Generic.List[string]
    $linhas.Add(("[{0}] {1} {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Origem, $msg).Trim())
    $linhas.Add(("    Telomera {0} | PowerShell {1} | {2}" -f $script:Versao, $PSVersionTable.PSVersion, [Environment]::OSVersion.VersionString))
    try {
        $ex = $null
        if ($Erro -is [System.Management.Automation.ErrorRecord]) { $ex = $Erro.Exception } elseif ($Erro -is [Exception]) { $ex = $Erro }
        if ($Erro.ScriptStackTrace) { $linhas.Add($Erro.ScriptStackTrace) }
        if ($ex -and $ex.StackTrace) { $linhas.Add($ex.StackTrace) }
        if ($ex -and $ex.InnerException) { $linhas.Add('Causa: ' + $ex.InnerException.Message) }
    } catch { }
    $texto = ($linhas -join "`r`n")
    try {
        New-Item -ItemType Directory -Force -Path $script:PastaDados -ErrorAction SilentlyContinue | Out-Null
        # Evita um arquivo gigante: acima de 512 KB, guarda só o final
        if ((Test-Path -LiteralPath $script:ArquivoErros) -and ((Get-Item -LiteralPath $script:ArquivoErros).Length -gt 524288)) {
            $resto = Get-Content -LiteralPath $script:ArquivoErros -Tail 400 -ErrorAction Stop
            Set-Content -LiteralPath $script:ArquivoErros -Value $resto -Encoding UTF8
        }
        Add-Content -LiteralPath $script:ArquivoErros -Value ($texto + "`r`n") -Encoding UTF8 -ErrorAction Stop
    } catch { }
    return $texto
}

function Registrar-Erro {
    param($Erro, [switch]$Silencioso)
    $texto = Write-LogErro $Erro
    if (-not $Silencioso) {
        try {
            $r = [System.Windows.Forms.MessageBox]::Show(
                "Ocorreu um erro inesperado:`r`n`r`n$Erro`r`n`r`nOs detalhes foram salvos em:`r`n$($script:ArquivoErros)`r`n`r`nDeseja copiar os detalhes para a área de transferência (para enviar a quem mantém o programa)?",
                'Telomera', 'YesNo', 'Error')
            if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { [System.Windows.Forms.Clipboard]::SetText($texto) }
        } catch { }
    }
}

try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
} catch {
    Write-Host 'Não foi possível carregar a interface gráfica do Windows (WinForms).'
    exit 1
}

if ($env:OS -ne 'Windows_NT') {
    [void][System.Windows.Forms.MessageBox]::Show('O Telomera funciona apenas no Windows.', 'Telomera', 'OK', 'Error')
    exit 1
}
if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    [void][System.Windows.Forms.MessageBox]::Show(
        'O PowerShell está em modo restrito (normalmente por política da empresa ou escola). O Telomera não consegue rodar assim.',
        'Telomera', 'OK', 'Error')
    exit 1
}
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Telomera.ps1')) -or
    -not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Telomera-Worker.ps1'))) {
    [void][System.Windows.Forms.MessageBox]::Show(
        'Não encontrei os arquivos Telomera.ps1 e Telomera-Worker.ps1 na mesma pasta. Extraia o ZIP inteiro antes de abrir.',
        'Telomera', 'OK', 'Error')
    exit 1
}

# Imagem nítida em telas com escala (125%, 150%...)
try {
    Add-Type -Namespace TelomeraNative -Name Dpi -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'
    [void][TelomeraNative.Dpi]::SetProcessDPIAware()
} catch { }
try {
    # Identidade própria na barra de tarefas: sem isso o Windows agrupa a janela com o PowerShell e mostra o ícone dele.
    Add-Type -Namespace TelomeraNative -Name Shell -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);'
    [void][TelomeraNative.Shell]::SetCurrentProcessExplicitAppUserModelID('Telomera.Diagnostico.GUI')
} catch { }
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch { }

# Corrige um bug conhecido do WinForms (.NET Framework): o buffer de redesenho dos botões (BufferedGraphics,
# usado internamente pelo Button/CheckBox) fica com tamanho preso ao monitor de quando o app abriu. Se a
# resolução muda, um monitor é removido/trocado, ou a sessão é controlada remotamente (RDP, compartilhamento
# de tela), o próximo redesenho de um botão pode cair num buffer inválido e lançar NullReferenceException em
# BufferedGraphics.Render() — o app continua funcionando, mas aparecia a caixa de "erro inesperado" à toa.
function Reparar-BufferGraficos {
    try {
        $tela = [System.Windows.Forms.SystemInformation]::VirtualScreen
        $ctx = [System.Drawing.BufferedGraphicsManager]::Current
        $ctx.MaximumBuffer = New-Object System.Drawing.Size(($tela.Width + 1), ($tela.Height + 1))
        $ctx.Invalidate()
    } catch { }
}
Reparar-BufferGraficos
try {
    Add-Type -AssemblyName System.Windows.Forms, Microsoft.VisualBasic -ErrorAction SilentlyContinue
    [Microsoft.Win32.SystemEvents]::add_DisplaySettingsChanged({ Reparar-BufferGraficos })
} catch { }

try {
    # Erros não tratados da interface: registram no log e mostram uma caixa clara, em vez da caixa padrão do .NET.
    [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
    [System.Windows.Forms.Application]::add_ThreadException({
        param($remetente, $ev)
        try {
            $ex = $ev.Exception
            $ehRedesenho = ($ex -is [System.NullReferenceException]) -and ($ex.StackTrace -match 'BufferedGraphics\.Render|Control\.WmPaint')
            if ($ehRedesenho) {
                # Falha de redesenho conhecida e inofensiva: corrige o buffer, registra em silêncio, sem assustar o usuário.
                Reparar-BufferGraficos
                try { [void](Write-LogErro $ex) } catch { }
                return
            }
            Registrar-Erro $ex
        } catch { }
    })
} catch { }
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }

$script:Esc = 1.0
$script:Relogio = $null
try {
    $g0 = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    $script:Esc = [double]$g0.DpiX / 96.0
    $g0.Dispose()
} catch { }

# Ícone do Telomera (arquivo telomera.ico ao lado dos scripts); se não existir, usa o escudo do Windows.
function Get-IconeTelomera {
    try { $p = Join-Path $PSScriptRoot 'telomera.ico'; if (Test-Path -LiteralPath $p) { return (New-Object System.Drawing.Icon($p)) } } catch { }
    return [System.Drawing.SystemIcons]::Shield
}
function Get-LogoTelomera {
    try { $p = Join-Path $PSScriptRoot 'telomera-logo.png'; if (Test-Path -LiteralPath $p) { return (New-Object System.Drawing.Bitmap($p)) } } catch { }
    return [System.Drawing.SystemIcons]::Shield.ToBitmap()
}

function PX { param([double]$n) return [int][Math]::Round($n * $script:Esc) }
function Cor { param([string]$hex) return [System.Drawing.ColorTranslator]::FromHtml($hex) }
function Fonte {
    param([double]$Tam = 10, [bool]$Negrito = $false)
    $nome = 'Segoe UI'
    if ($Negrito) { $nome = 'Segoe UI Semibold' }
    return (New-Object System.Drawing.Font($nome, [single]$Tam, [System.Drawing.FontStyle]::Regular))
}

# ----------------------------------------------------------------------------
# Estado
# ----------------------------------------------------------------------------
$script:Versao = '2.1'
try {
    $m = Select-String -LiteralPath (Join-Path $PSScriptRoot 'Telomera.ps1') -Pattern "^\`$script:Versao\s*=\s*'([^']+)'" | Select-Object -First 1
    if ($m) { $script:Versao = $m.Matches[0].Groups[1].Value }
} catch { }

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$script:IsAdmin = (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$script:Sync = [hashtable]::Synchronized(@{ Fila = (New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'); Cancelar = $false })
$script:Opc = @{
    PastaScripts     = $PSScriptRoot
    PastaRelatorio   = ''
    SomenteLeitura   = (-not $script:IsAdmin)
    SemWindowsUpdate = $false
    PularScanVolumes = $false
    VerificacaoProfunda = $false
    AceitarTudo      = $false
    DiasEventos      = 30
}
$script:ModoAuto = $false
$script:RS = $null
$script:Ps = $null
$script:Async = $null
$script:WorkerCarregado = $false
$script:FimRecebido = $false
$script:Cancelando = $false
$script:FaseAtual = ''
$script:EmDialogo = $false
$script:Res = $null
$script:LarguraCards = 0

function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

# ----------------------------------------------------------------------------
# Pedido de permissão de administrador
# ----------------------------------------------------------------------------
# TELOMERA_UAC_JA_PERGUNTADO=1: o Telomera.exe já pediu o UAC (com o nome e ícone certos) e o usuário
# recusou. Não pergunta de novo aqui — senão o PowerShell pediria UAC uma segunda vez, logo em seguida.
if (-not $script:IsAdmin -and $PSCommandPath -and $env:WINDIAG_GUI_FUMACA -ne '1' -and $env:TELOMERA_UAC_JA_PERGUNTADO -ne '1') {
    # Pede direto a permissão do Windows (UAC), sem pergunta extra. Se o usuário recusar, abre só para verificação.
    try {
        $h2 = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $PSCommandPath)
        Start-Process -FilePath $h2.Exe -ArgumentList $h2.Args -Verb RunAs -ErrorAction Stop
        exit
    } catch {
        [void][System.Windows.Forms.MessageBox]::Show(
            "A permissão de administrador não foi concedida. O Telomera vai abrir apenas para verificação (não será possível corrigir).`r`n`r`nPara corrigir, feche e abra o Telomera de novo e aceite o pedido do Windows.", 'Telomera', 'OK', 'Information')
    }
}

# ----------------------------------------------------------------------------
# Janela de confirmação (substitui as perguntas do console)
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Idioma: inglês (parcial). Traduz os textos fixos da interface; os achados do diagnóstico continuam em português.
# Ativado quando o Windows está em inglês, ou com a variável de ambiente WINDIAG_IDIOMA=en.
# ----------------------------------------------------------------------------
$script:Ingles = $false
try {
    if ($env:WINDIAG_IDIOMA -eq 'en') { $script:Ingles = $true }
    elseif ($env:WINDIAG_IDIOMA -eq 'pt') { $script:Ingles = $false }
    elseif ((Get-UICulture).TwoLetterISOLanguageName -eq 'en') { $script:Ingles = $true }
} catch { }
$script:TradEN = @{
    'Vamos verificar o seu computador?' = 'Shall we check your computer?'
    'O Telomera procura problemas em drivers, discos, memória, placa de vídeo e no histórico de erros do Windows, como telas azuis e travamentos. Ele só lê as informações: nada é alterado sem a sua permissão.' = 'Telomera looks for problems in drivers, disks, memory, graphics card and the Windows error history, such as blue screens and freezes. It only reads information: nothing is changed without your permission.'
    'Leva de 2 a 10 minutos   ·   Você pode continuar usando o computador' = 'Takes 2 to 10 minutes   ·   You can keep using the computer'
    'Aberto sem permissão de administrador: dá para verificar, mas não para corrigir. Para corrigir, feche e abra de novo aceitando o pedido de permissão.' = 'Opened without administrator permission: you can scan, but not fix. To fix, close and reopen it and accept the permission prompt.'
    'Verificar meu computador' = 'Scan my computer'
    'Testar desempenho (processador, memória e vídeo)' = 'Test performance (CPU, memory and video)'
    'Ferramentas de reparo e restauração' = 'Repair and restore tools'
    'Mostrar opções avançadas' = 'Show advanced options'
    'Ocultar opções avançadas' = 'Hide advanced options'
    'Usar a internet na verificação: Windows Update (drivers pendentes) e teste de rede (pode demorar alguns minutos)' = 'Use the internet during the scan: Windows Update (pending drivers) and network test (may take a few minutes)'
    'Procurar erros nas unidades de disco (mais completo, porém mais lento)' = 'Look for errors on disk drives (more thorough, but slower)'
    'Verificação profunda do Windows (SFC e DISM): bem mais lenta; só se há telas azuis ou arquivos corrompidos' = 'Deep Windows check (SFC and DISM): much slower; only if there are blue screens or corrupted files'
    'Desfazer bloqueios de driver do Telomera' = 'Undo Telomera driver blocks'
    'Desfazer correções (restaurar drivers salvos)' = 'Undo fixes (restore saved drivers)'
    'Recriar o atalho do Telomera (Área de Trabalho e Menu Iniciar)' = 'Recreate the Telomera shortcut (Desktop and Start Menu)'
    'Abrir a pasta das verificações anteriores' = 'Open the folder of previous scans'
    'Procurar atualização do Telomera' = 'Check for a Telomera update'
    'Cada verificação é salva em uma pasta própria dentro de "Telomera", na Área de Trabalho. Revise os relatórios antes de compartilhar: podem conter o nome do computador e IDs de hardware.' = 'Each scan is saved in its own folder inside "Telomera" on the Desktop. Review the reports before sharing: they may contain the computer name and hardware IDs.'
    'Diagnóstico de drivers, discos e hardware' = 'Drivers, disks and hardware diagnostics'
    'Corrigir automaticamente' = 'Fix automatically'
    'Corrigir (requer administrador)' = 'Fix (requires administrator)'
    'Nada a corrigir' = 'Nothing to fix'
    'Relatório completo' = 'Full report'
    'Salvar em PDF' = 'Save as PDF'
    'Abrir pasta' = 'Open folder'
    'Copiar resumo' = 'Copy summary'
    'Copiado!' = 'Copied!'
    'Verificar de novo' = 'Scan again'
    'Exportar ▾' = 'Export ▾'
    'Sair' = 'Exit'
    'Fechar' = 'Close'
    'Cancelar' = 'Cancel'
    'Voltar ao início' = 'Back to start'
    '← Voltar ao início' = '← Back to start'
    'Testar de novo' = 'Test again'
    'Abrir o relatório' = 'Open the report'
    'Desfazer alterações' = 'Undo changes'
    'Reiniciar o computador agora' = 'Restart the computer now'
    'Reiniciar mesmo assim (opcional)' = 'Restart anyway (optional)'
    'Mostrar detalhes técnicos' = 'Show technical details'
    'Meu computador' = 'My computer'
    'Detalhes técnicos' = 'Technical details'
    'Incluir avisos apenas informativos' = 'Include informational notices'
    'Mostrar' = 'Show'
    'Ver mais: o que é isso e preciso me preocupar?' = 'See more: what is this and should I worry?'
    'Ver menos' = 'See less'
    'O QUE FAZER' = 'WHAT TO DO'
    'Preparando...' = 'Preparing...'
    'Cancelando...' = 'Cancelling...'
    'Tempo decorrido: 00:00' = 'Elapsed time: 00:00'
    'Tudo certo! Nenhum problema relevante' = 'All good! No relevant problems'
    'Nenhuma correção foi aplicada' = 'No fix was applied'
    'Correções concluídas' = 'Fixes completed'
    'Correções interrompidas' = 'Fixes interrupted'
    'Teste de desempenho concluído' = 'Performance test completed'
    'Teste de desempenho: há um problema' = 'Performance test: there is a problem'
    'Teste de desempenho: pontos de atenção' = 'Performance test: points of attention'
    'Ferramentas de reparo e restauração ' = 'Repair and restore tools'
    'Cada ferramenta pede a sua confirmação antes de mexer em alguma coisa. As que corrigem o Windows exigem abrir o Telomera como administrador.' = 'Each tool asks for your confirmation before changing anything. Those that fix Windows require opening Telomera as administrator.'
    'Ver os pontos de restauração' = 'View restore points'
    'Criar um ponto de restauração agora' = 'Create a restore point now'
    'Abrir a Restauração do Sistema do Windows' = 'Open Windows System Restore'
    'Reparar a rede e a internet' = 'Repair the network and internet'
    'Reparar o Windows Update' = 'Repair Windows Update'
    'Reparar a Microsoft Store' = 'Repair the Microsoft Store'
    'Verificar o disco com o CHKDSK (na reinicialização)' = 'Check the disk with CHKDSK (on restart)'
    'Limpar arquivos temporários' = 'Clear temporary files'
    'Copiar meus arquivos pessoais (backup)' = 'Copy my personal files (backup)'
    'Ver o que o Telomera já mudou neste computador' = 'See what Telomera has already changed on this computer'
    'Mostra os pontos de volta que o Windows tem guardados (inclusive os criados pelo Telomera).' = 'Shows the restore points Windows has stored (including those created by Telomera).'
    'Guarda o estado atual do Windows para poder voltar a ele se algo der errado.' = 'Saves the current state of Windows so you can go back to it if something goes wrong.'
    'Abre a tela do Windows para voltar o computador a um ponto de restauração anterior.' = 'Opens the Windows screen to roll the computer back to an earlier restore point.'
    'Limpa o DNS e reinicia o Winsock e o IP. Resolve sites que não abrem com a rede conectada.' = 'Flushes DNS and resets Winsock and IP. Fixes websites that will not open while the network is connected.'
    'Corrige atualizações que travam, falham ou não aparecem (renomeia as pastas temporárias do Windows Update).' = 'Fixes updates that hang, fail or do not show up (renames the Windows Update temporary folders).'
    'Registra a loja novamente. Útil quando ela não abre ou não baixa aplicativos.' = 'Registers the store again. Useful when it does not open or does not download apps.'
    'Agenda a verificação completa do disco do Windows. Pode demorar de minutos a horas.' = 'Schedules a full check of the Windows disk. It can take from minutes to hours.'
    'Apaga arquivos temporários com mais de 2 dias para liberar espaço.' = 'Deletes temporary files older than 2 days to free up space.'
    'Copia Documentos, Imagens e Área de Trabalho para uma pasta ou pen drive que você escolher. Nada é apagado.' = 'Copies Documents, Pictures and Desktop to a folder or USB drive of your choice. Nothing is deleted.'
    'Lista todas as alterações feitas pelo Telomera, com a data e como desfazer cada uma.' = 'Lists every change made by Telomera, with the date and how to undo each one.'
    'ATENÇÃO: existem 2 formas de fazer as correções. Escolha uma:' = 'ATTENTION: there are 2 ways to apply the fixes. Choose one:'
    'Telomera - ESCOLHA COMO CORRIGIR' = 'Telomera - CHOOSE HOW TO FIX'
    '1) Corrigir tudo automaticamente' = '1) Fix everything automatically'
    '2) Escolher uma a uma' = '2) Choose one by one'
    'Clique no botão da forma que você quer. Se tiver dúvida, escolha "Escolher uma a uma".' = 'Click the button for the way you want. If in doubt, choose "Choose one by one".'
    'Telomera - confirmar' = 'Telomera - confirm'
    'Iniciar as correções' = 'Start the fixes'
    'Voltar sem corrigir' = 'Go back without fixing'
    'Iniciar o teste' = 'Start the test'
    'Agora não' = 'Not now'
    'Sim' = 'Yes'
    'Não' = 'No'
    'Sim, fazer' = 'Yes, do it'
    'Agora não ' = 'Not now'
    'Sim, cancelar' = 'Yes, cancel'
    'Continuar' = 'Continue'
    'Telomera - confirmação' = 'Telomera - confirmation'
    'Telomera - confirmar correção' = 'Telomera - confirm fix'
    'Não feche esta janela e não desligue o computador enquanto as correções estiverem em andamento.' = 'Do not close this window or turn off the computer while the fixes are in progress.'
    'Se aparecer uma pergunta, responda na caixa que abrir. Não feche esta janela até terminar.' = 'If a question appears, answer in the box that opens. Do not close this window until it finishes.'
}
# Textos da versão 2.22
$script:TradEN['Seu computador'] = 'Your computer'
$script:TradEN['SEU COMPUTADOR'] = 'YOUR COMPUTER'
$script:TradEN['ARMAZENAMENTO'] = 'STORAGE'
$script:TradEN['Lendo os componentes...'] = 'Reading components...'
$script:TradEN['Não foi possível ler os componentes agora.'] = 'Could not read the components right now.'
$script:TradEN['Sem informações do computador.'] = 'No computer information.'
$script:TradEN['Processador'] = 'Processor'
$script:TradEN['Memória'] = 'Memory'
$script:TradEN['Vídeo'] = 'Graphics'
$script:TradEN['Placa-mãe'] = 'Motherboard'
# Textos da versão 2.21
$script:TradEN['Baixar drivers novos com segurança'] = 'Download new drivers safely'
$script:TradEN['Baixar drivers novos: abrir as páginas oficiais'] = 'New drivers: open the official pages'
$script:TradEN['Conferir e instalar um driver baixado'] = 'Check and install a downloaded driver'
$script:TradEN['Drivers'] = 'Drivers'
$script:TradEN['Entender'] = 'Understand'
$script:TradEN['Corrigir'] = 'Fix'
$script:TradEN['Driver de vídeo: instalação limpa'] = 'Video driver: clean install'
$script:TradEN['Energia que derruba dispositivos'] = 'Power settings that drop devices'
$script:TradEN['Ver todos os drivers e o que cada um faz'] = 'Show all drivers and what each one does'
$script:TradEN['Reparar dispositivos com erro'] = 'Repair devices with errors'
$script:TradEN['Reiniciar o driver de vídeo'] = 'Restart the video driver'
$script:TradEN['Instalar drivers pelo Windows Update'] = 'Install drivers through Windows Update'
$script:TradEN['Limpar versões antigas de driver'] = 'Clean up old driver versions'
$script:TradEN['Limpeza do driver de vídeo (para instalação limpa)'] = 'Video driver cleanup (for a clean install)'
$script:TradEN['Guia: instalar o driver de vídeo do zero'] = 'Guide: install the video driver from scratch'
$script:TradEN['Desligar a economia de energia do USB'] = 'Turn off USB power saving'
# Textos da versão 2.20
$script:TradEN['O PC trava ou desliga'] = 'PC freezes or shuts down'
$script:TradEN['Monitor e sensores'] = 'Monitor and sensors'
$script:TradEN['Reparos e restauração'] = 'Repairs and restore'
$script:TradEN['Ajuda e autoteste'] = 'Help and self-test'
$script:TradEN['Reparos do Windows'] = 'Windows repairs'
$script:TradEN['Testes e estresse'] = 'Tests and stress'
$script:TradEN['Restaurar e desfazer'] = 'Restore and undo'
$script:TradEN['Descobrir o que aconteceu'] = 'Find out what happened'
$script:TradEN['Corrigir configurações que causam travamento (todas com desfazer)'] = 'Fix settings that cause freezes (all can be undone)'
$script:TradEN['Testar hipóteses de hardware'] = 'Test hardware hypotheses'
$script:TradEN['BIOS e drivers'] = 'BIOS and drivers'
$script:TradEN['Programas de sensores'] = 'Sensor programs'
$script:TradEN['Registro durante o jogo'] = 'Recording while you play'
$script:TradEN['Dentro do Telomera'] = 'Inside Telomera'
$script:TradEN['Ver o estado dos sensores'] = 'Show the sensor status'
$script:TradEN['Configurar e abrir o HWiNFO para o Telomera'] = 'Configure and open HWiNFO for Telomera'
$script:TradEN['Baixar a LibreHardwareMonitor (alternativa ao HWiNFO)'] = 'Download LibreHardwareMonitor (alternative to HWiNFO)'
$script:TradEN['Abrir a LibreHardwareMonitor'] = 'Open LibreHardwareMonitor'
$script:TradEN['Testar desempenho (processador, memória, disco, vídeo e estresse)'] = 'Run performance test (CPU, memory, disk, video and stress)'
$script:TradEN['Escolha pelo assunto: cada bloco abre só o que é dele. O PC trava? Comece por "O PC trava ou desliga". Problema com driver? Vá em "Drivers".'] = 'Pick by topic: each block opens only what belongs to it. PC freezing? Start with "PC freezes or shuts down". Driver problem? Go to "Drivers".'
# Textos da versão 2.19
$script:TradEN['Teste de memória RAM com padrões (cerca de 10 minutos)'] = 'RAM test with patterns (about 10 minutes)'
$script:TradEN['Grava e confere vários padrões de dados em quase toda a memória livre, com mais de um núcleo. Um erro aqui indica pente defeituoso, instável ou mal configurado (XMP/DOCP). Para uma checagem completa, use depois o teste de memória do Windows ou o MemTest86.'] = 'Writes and checks several data patterns across most of the free memory, using more than one core. An error here means a faulty, unstable or badly configured (XMP/DOCP) module. For a full check, also use the Windows memory test or MemTest86 afterwards.'
$script:TradEN['Estresse do disco com verificação (cerca de 10 minutos)'] = 'Disk stress with verification (about 10 minutes)'
$script:TradEN['Grava no disco um arquivo temporário grande e confere cada bloco ao ler, medindo a velocidade e o tempo de acesso. Mostra se o disco (principalmente HD) ou o cabo SATA corrompe dados sob uso contínuo. O arquivo é apagado no fim.'] = 'Writes a large temporary file to the disk and checks every block when reading it back, measuring speed and access time. Shows whether the disk (especially an HDD) or the SATA cable corrupts data under continuous use. The file is deleted at the end.'
$script:TradEN['Incluir também o teste longo do processador e da memória'] = 'Also include the long CPU and memory test'
$script:TradEN['Soma cerca de 4 minutos.'] = 'Adds about 4 minutes.'
$script:TradEN['Prolongar o estresse da placa de vídeo para 20 minutos'] = 'Extend the video card stress test to 20 minutes'
$script:TradEN['Para reproduzir travamentos que só aparecem depois de vários minutos de carga. Soma cerca de 17 minutos.'] = 'Reproduces freezes that only show up after several minutes under load. Adds about 17 minutes.'
$script:TradEN['Mais pesado: 60 aberturas, carga maior e mais lenta'] = 'Heavier: 60 cycles, bigger and slower load'
$script:TradEN['Cerca de 15 minutos. Use se o teste normal não travou.'] = "About 15 minutes. Use if the normal test didn't cause a freeze."
$script:TradEN['Prolongar o teste de memória ou de disco para 30 minutos'] = 'Extend the memory or disk test to 30 minutes'
$script:TradEN['Acha erros que só aparecem com o aquecimento.'] = 'Finds errors that only show up as things warm up.'
$script:TradEN['Desligar o agendamento de GPU por hardware'] = 'Turn off hardware-accelerated GPU scheduling'
$script:TradEN['Opção do Windows que em alguns computadores causa travamento de imagem em jogos. Pede confirmação, guarda o valor atual e precisa reiniciar. Dá para desfazer.'] = 'A Windows option that on some computers causes the picture to freeze in games. Asks for confirmation, saves the current value and needs a restart. Can be undone.'
$script:TradEN['Desligar a economia de energia do PCIe'] = 'Turn off PCIe power saving'
$script:TradEN['Impede que a placa de vídeo entre em repouso profundo quando o PC está na tomada. Pede confirmação e dá para desfazer.'] = 'Stops the graphics card from entering deep sleep while the PC is plugged in. Asks for confirmation and can be undone.'
$script:TradEN['Desligar a inicialização rápida do Windows'] = 'Turn off Windows Fast Startup'
$script:TradEN['Faz o Windows carregar os drivers do zero a cada ligada. Pede confirmação, precisa reiniciar e dá para desfazer.'] = 'Makes Windows load the drivers from scratch on every boot. Asks for confirmation, needs a restart and can be undone.'
$script:TradEN['Desfazer as mudanças de configuração'] = 'Undo the configuration changes'
$script:TradEN['Volta o agendamento de GPU, a economia do PCIe e a inicialização rápida ao valor que tinham antes do Telomera.'] = 'Puts GPU scheduling, PCIe power saving and Fast Startup back to the values they had before Telomera.'
$script:TradEN['Guia: testar com outra fonte de alimentação'] = 'Guide: test with another power supply'
$script:TradEN['Passo a passo para trocar a fonte por uma emprestada e descobrir se ela é a causa de travamentos sob carga.'] = 'Step by step to swap in a borrowed power supply and find out whether it causes freezes under load.'
$script:TradEN['Guia: limitar a energia da placa de vídeo'] = 'Guide: limit the graphics card power'
$script:TradEN['Passo a passo para reduzir o consumo da placa (Afterburner ou nvidia-smi) e testar se os picos de energia causam o travamento.'] = 'Step by step to reduce the card power draw (Afterburner or nvidia-smi) and test whether power spikes cause the freeze.'
$script:TradEN['BIOS e drivers: abrir a página da placa-mãe'] = 'BIOS and drivers: open the motherboard page'
$script:TradEN['Mostra a BIOS instalada e abre a página de suporte do fabricante da sua placa-mãe para conferir se existe versão mais nova.'] = 'Shows the installed BIOS and opens your motherboard maker support page so you can check for a newer version.'
$script:TradEN['Driver de chipset: abrir a página oficial'] = 'Chipset driver: open the official page'
$script:TradEN['Abre a página oficial do driver de chipset do fabricante do seu processador (AMD ou Intel).'] = 'Opens the official chipset driver page from your processor maker (AMD or Intel).'
$script:TradEN['Autoteste do Telomera (conferir se tudo funciona)'] = 'Telomera self-test (check that everything works)'
$script:TradEN['Confere, neste Windows, se cada recurso do Telomera funciona (sensores, testes, vídeo, SMART). Gera um texto para enviar ao desenvolvedor se algo falhar.'] = 'Checks, on this Windows, whether each Telomera feature works (sensors, tests, video, SMART). Produces a text to send to the developer if something fails.'
$script:TradEN['Correções de configuração (com desfazer)'] = 'Configuration fixes (with undo)'
$script:TradEN['Guias passo a passo para travamentos'] = 'Step-by-step guides for freezes'
$script:TradEN['Conferir o próprio Telomera'] = 'Check Telomera itself'
function Tr {
    param([string]$Texto)
    if ($script:Ingles -and $Texto -and $script:TradEN.ContainsKey($Texto)) { return $script:TradEN[$Texto] }
    return $Texto
}
function Traduzir-Controles {
    param($Pai)
    if (-not $script:Ingles) { return }
    foreach ($c in $Pai.Controls) {
        try {
            $t = [string]$c.Text
            if ($t -and $script:TradEN.ContainsKey($t)) {
                $c.Text = $script:TradEN[$t]
                if ($c -is [System.Windows.Forms.Button]) { Ajustar-LarguraBotao $c $c.Text ([int]($c.Width / [Math]::Max(1, [double](PX 1)))) }
            }
        } catch { }
        if ($c.Controls.Count -gt 0) { Traduzir-Controles $c }
    }
}

function Show-Dialogo {
    param(
        [string]$Titulo = 'Telomera',
        [string]$Texto,
        [string]$Aviso = '',
        [string]$Exige = '',
        [string]$TextoSim = 'Sim',
        [string]$TextoNao = 'Não',
        [bool]$PadraoSim = $true,
        [bool]$Perigo = $false
    )
    $Titulo = Tr $Titulo; $Texto = Tr $Texto; $Aviso = Tr $Aviso; $TextoSim = Tr $TextoSim; $TextoNao = Tr $TextoNao
    $largura = PX 540
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $Titulo
    $f.StartPosition = 'CenterParent'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    $f.BackColor = (Pal 'Superficie')
    $f.ForeColor = Pal 'Texto'
    $f.Font = Fonte 10
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'

    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding((PX 22))
    $f.Controls.Add($flow)

    $lt = New-Object System.Windows.Forms.Label
    $lt.AutoSize = $true
    $lt.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $lt.Text = $Texto
    $lt.ForeColor = Pal 'Texto'
    $lt.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $flow.Controls.Add($lt)

    if ($Aviso) {
        $la = New-Object System.Windows.Forms.Label
        $la.AutoSize = $true
        $la.MaximumSize = New-Object System.Drawing.Size($largura, 0)
        $la.Padding = New-Object System.Windows.Forms.Padding((PX 8))
        $la.Text = $Aviso
        if ($Perigo) { $la.BackColor = Pal 'PerigoFundo'; $la.ForeColor = Pal 'PerigoTextoForte' } else { $la.BackColor = Pal 'AvisoFundo'; $la.ForeColor = Pal 'AvisoTextoForte' }
        $la.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
        $flow.Controls.Add($la)
    }

    $tb = $null
    if ($Exige) {
        $lx = New-Object System.Windows.Forms.Label
        $lx.AutoSize = $true
        $lx.MaximumSize = New-Object System.Drawing.Size($largura, 0)
        $lx.Text = "Para autorizar, digite $Exige na caixa abaixo:"
        $lx.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
        $flow.Controls.Add($lx)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.BackColor = Pal 'Superficie'; $tb.ForeColor = Pal 'Texto'
        $tb.Width = PX 220
        $tb.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
        $flow.Controls.Add($tb)
    }

    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.FlowDirection = 'LeftToRight'
    $bar.AutoSize = $true
    $bar.AutoSizeMode = 'GrowAndShrink'
    $bar.WrapContents = $false
    $flow.Controls.Add($bar)

    $estiloSim = 'primario'
    if ($Perigo) { $estiloSim = 'perigo' }
    $btnSim = Nova-BotaoGrande $TextoSim $estiloSim 130 40
    $btnSim.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $btnNao = Nova-BotaoGrande $TextoNao 'secundario' 130 40
    $btnNao.DialogResult = [System.Windows.Forms.DialogResult]::No
    foreach ($bt in @($btnSim, $btnNao)) {
        $bt.AutoSize = $true
        $bt.AutoSizeMode = 'GrowAndShrink'
        $bt.MinimumSize = New-Object System.Drawing.Size((PX 130), (PX 40))
        $bt.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    }
    $bar.Controls.Add($btnSim)
    $bar.Controls.Add($btnNao)

    $f.CancelButton = $btnNao
    if ($PadraoSim -and -not $Exige) { $f.AcceptButton = $btnSim } else { $f.AcceptButton = $btnNao }

    if ($Exige) {
        $btnSim.Enabled = $false
        $tb.Add_TextChanged({ $btnSim.Enabled = ($tb.Text.Trim() -ceq $Exige) }.GetNewClosure())
    }

    $dono = $null
    if ($script:Form -and $script:Form.Visible) { $dono = $script:Form }
    try {
        if ($dono) { $r = $f.ShowDialog($dono) } else { $r = $f.ShowDialog() }
    } finally {
        $f.Dispose()
    }
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

# Janela de escolha do tipo de teste de desempenho. Devolve $true se o usuário iniciou; define $script:TesteLongo e $script:TesteEstresse.
$script:TesteLongo = $false
$script:TesteEstresse = $false
$script:TesteTransicao = $false
$script:TransPesado = $false
$script:EstresseProlongado = $false
$script:TesteMemoria = $false
$script:TesteDiscoEstresse = $false
$script:DuracaoLonga = $false
$script:TipoTeste = 'normal'
$script:VerifProfunda = $false
function Show-EscolhaVerificacao {
    # Pergunta qual verificação fazer. Devolve 'normal', 'profunda' ou $null (cancelou).
    $largura = PX 520
    $f = New-Object System.Windows.Forms.Form
    $f.Text = (Tr 'Telomera - tipo de verificação')
    $f.StartPosition = 'CenterParent'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    $f.BackColor = (Pal 'Superficie')
    $f.ForeColor = Pal 'Texto'
    $f.Font = Fonte 10
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding((PX 22))
    $f.Controls.Add($flow)
    $intro = New-Object System.Windows.Forms.Label
    $intro.AutoSize = $true
    $intro.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $intro.ForeColor = Pal 'Texto'
    $intro.Text = (Tr 'Como você quer verificar o computador? As duas só leem as informações: nada é alterado sem a sua permissão.')
    $intro.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $flow.Controls.Add($intro)
    $opcoes = @(
        @{ Id = 'normal'; T = 'Verificação normal (de 2 a 10 minutos)'; D = 'Drivers, discos, memória, placa de vídeo e o histórico recente de erros. É a melhor para o dia a dia.' },
        @{ Id = 'profunda'; T = 'Verificação profunda (soma de 10 a 30 minutos)'; D = 'Além da normal: confere os arquivos do Windows (SFC e DISM), 90 dias de histórico, travamentos de programas, a inicialização, a energia e os arquivos dos programas instalados (corrompidos ou alterados). Use se o computador trava, reinicia sozinho ou a normal não achou a causa.' }
    )
    $radios = @{}
    foreach ($o in $opcoes) {
        $rb = New-Object System.Windows.Forms.RadioButton
        $rb.Text = (Tr $o.T)
        $rb.AutoSize = $true
        $rb.Font = Fonte 10.5 $true
        $rb.ForeColor = Pal 'Texto'
        $rb.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, 0)
        $rb.Checked = ($o.Id -eq $(if ($script:VerifProfunda) { 'profunda' } else { 'normal' }))
        $flow.Controls.Add($rb)
        $radios[$o.Id] = $rb
        $ld = New-Object System.Windows.Forms.Label
        $ld.AutoSize = $true
        $ld.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
        $ld.ForeColor = Pal 'Texto2'
        $ld.Text = (Tr $o.D)
        $ld.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
        $flow.Controls.Add($ld)
    }
    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.FlowDirection = 'LeftToRight'
    $bar.AutoSize = $true
    $bar.AutoSizeMode = 'GrowAndShrink'
    $bar.WrapContents = $false
    $bar.Margin = New-Object System.Windows.Forms.Padding(0, (PX 8), 0, 0)
    $flow.Controls.Add($bar)
    $btnSim = Nova-BotaoGrande (Tr 'Iniciar') 'primario' 150 40
    $btnSim.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $btnNao = Nova-BotaoGrande (Tr 'Cancelar') 'secundario' 130 40
    $btnNao.DialogResult = [System.Windows.Forms.DialogResult]::No
    $bar.Controls.Add($btnSim); $bar.Controls.Add($btnNao)
    $f.AcceptButton = $btnSim
    $f.CancelButton = $btnNao
    $res = $null
    try {
        $r = $f.ShowDialog($form)
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
            $script:VerifProfunda = [bool]$radios['profunda'].Checked
            if ($script:VerifProfunda) { $res = 'profunda' } else { $res = 'normal' }
        }
    } finally { $f.Dispose() }
    return $res
}

function Show-EscolhaTeste {
    $largura = PX 560
    $f = New-Object System.Windows.Forms.Form
    $f.Text = (Tr 'Telomera - teste de desempenho')
    $f.StartPosition = 'CenterParent'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    $f.BackColor = (Pal 'Superficie')
    $f.ForeColor = Pal 'Texto'
    $f.Font = Fonte 10
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding((PX 22))
    $f.Controls.Add($flow)

    $intro = New-Object System.Windows.Forms.Label
    $intro.AutoSize = $true
    $intro.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $intro.ForeColor = Pal 'Texto'
    $intro.Text = (Tr 'Qual teste você quer fazer? Os testes usam o computador com força: o processador fica em 100%, parte da memória livre é preenchida, o disco recebe um arquivo temporário (apagado no fim) e uma janela com animação abre sozinha (o teste de transição só abre e fecha uma tela cheia). Antes de começar, o Telomera lê o computador e ajusta a intensidade para não travar computadores mais fracos.')
    $intro.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $flow.Controls.Add($intro)

    $opcoes = @(
        @{ Id = 'normal'; T = 'Teste normal (de 3 a 4 minutos)'; D = 'Processador, memória RAM, disco e placa de vídeo, com uma animação 3D em janela. É o ideal para conferir o estado geral e comparar com testes futuros.' },
        @{ Id = 'longo'; T = 'Teste longo (cerca de 7 minutos)'; D = 'O processador fica 3 minutos a 100% e a memória RAM é verificada 4 vezes. Mostra se o desempenho e a frequência caem com o aquecimento. Use se o computador esquenta, trava ou desliga sozinho.' },
        @{ Id = 'estresse'; T = 'Estresse de jogo pesado (de 6 a 10 minutos)'; D = 'Além dos testes normais, abre uma janela em tela cheia que leva a placa de vídeo ao limite, com o processador em carga parcial como num jogo. Liga a gravação do monitor sozinha. Use se o computador trava ou desliga ao jogar.' },
        @{ Id = 'transicao'; T = 'Teste de transição (cerca de 10 minutos)'; D = 'Abre e fecha uma tela cheia 40 vezes, trocando a resolução da tela a cada abertura (a tela pisca, como ao abrir um jogo em tela cheia) e deixando a placa de vídeo descansar entre as aberturas. A carga sobe aos poucos. Reproduz a troca de repouso para carga que acontece ao apertar Play num jogo. Use se a imagem trava justamente ao abrir um jogo. Liga a gravação do monitor sozinha.' },
        @{ Id = 'memoria'; T = 'Teste de memória RAM com padrões (cerca de 10 minutos)'; D = 'Grava e confere vários padrões de dados em quase toda a memória livre, com mais de um núcleo. Um erro aqui indica pente defeituoso, instável ou mal configurado (XMP/DOCP). Para uma checagem completa, use depois o teste de memória do Windows ou o MemTest86.' },
        @{ Id = 'disco'; T = 'Estresse do disco com verificação (cerca de 10 minutos)'; D = 'Grava no disco um arquivo temporário grande e confere cada bloco ao ler, medindo a velocidade e o tempo de acesso. Mostra se o disco (principalmente HD) ou o cabo SATA corrompe dados sob uso contínuo. O arquivo é apagado no fim.' }
    )
    $radios = @{}
    foreach ($o in $opcoes) {
        $rb = New-Object System.Windows.Forms.RadioButton
        $rb.Text = (Tr $o.T)
        $rb.AutoSize = $true
        $rb.Font = Fonte 10.5 $true
        $rb.ForeColor = Pal 'Texto'
        $rb.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, 0)
        $rb.Checked = ($o.Id -eq $script:TipoTeste)
        $rb.Tag = $o.Id
        $flow.Controls.Add($rb)
        $radios[$o.Id] = $rb
        $ld = New-Object System.Windows.Forms.Label
        $ld.AutoSize = $true
        $ld.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
        $ld.ForeColor = Pal 'Texto2'
        $ld.Text = (Tr $o.D)
        $ld.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 6))
        $flow.Controls.Add($ld)
    }
    # Cada opção extra segue o mesmo padrão título+detalhe dos testes acima (em vez de um único texto
    # longo dentro da caixinha): o texto da CheckBox por si só não tem como quebrar linha com segurança
    # dentro da largura do diálogo, e um texto único comprido acabava sendo cortado na borda da janela.
    $chkJunto = New-Object System.Windows.Forms.CheckBox
    $chkJunto.Text = (Tr 'Incluir também o teste longo do processador e da memória')
    $chkJunto.AutoSize = $true
    $chkJunto.Font = Fonte 10.5 $true
    $chkJunto.ForeColor = Pal 'Texto'
    $chkJunto.Margin = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), 0, 0)
    $chkJunto.Checked = [bool]($script:TesteLongo -and $script:TesteEstresse)
    $chkJunto.Enabled = [bool]$radios['estresse'].Checked
    $flow.Controls.Add($chkJunto)
    $radios['estresse'].Add_CheckedChanged({ $chkJunto.Enabled = [bool]$radios['estresse'].Checked; if (-not $chkJunto.Enabled) { $chkJunto.Checked = $false } }.GetNewClosure())
    $ldJunto = New-Object System.Windows.Forms.Label
    $ldJunto.AutoSize = $true
    $ldJunto.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
    $ldJunto.ForeColor = Pal 'Texto2'
    $ldJunto.Text = (Tr 'Soma cerca de 4 minutos.')
    $ldJunto.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $flow.Controls.Add($ldJunto)

    $chkProlong = New-Object System.Windows.Forms.CheckBox
    $chkProlong.Text = (Tr 'Prolongar o estresse da placa de vídeo para 20 minutos')
    $chkProlong.AutoSize = $true
    $chkProlong.Font = Fonte 10.5 $true
    $chkProlong.ForeColor = Pal 'Texto'
    $chkProlong.Margin = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), 0, 0)
    $chkProlong.Checked = [bool]($script:EstresseProlongado -and $script:TesteEstresse)
    $chkProlong.Enabled = [bool]$radios['estresse'].Checked
    $flow.Controls.Add($chkProlong)
    $radios['estresse'].Add_CheckedChanged({ $chkProlong.Enabled = [bool]$radios['estresse'].Checked; if (-not $chkProlong.Enabled) { $chkProlong.Checked = $false } }.GetNewClosure())
    $ldProlong = New-Object System.Windows.Forms.Label
    $ldProlong.AutoSize = $true
    $ldProlong.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
    $ldProlong.ForeColor = Pal 'Texto2'
    $ldProlong.Text = (Tr 'Para reproduzir travamentos que só aparecem depois de vários minutos de carga. Soma cerca de 17 minutos.')
    $ldProlong.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $flow.Controls.Add($ldProlong)

    $chkPesado = New-Object System.Windows.Forms.CheckBox
    $chkPesado.Text = (Tr 'Mais pesado: 60 aberturas, carga maior e mais lenta')
    $chkPesado.AutoSize = $true
    $chkPesado.Font = Fonte 10.5 $true
    $chkPesado.ForeColor = Pal 'Texto'
    $chkPesado.Margin = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), 0, 0)
    $chkPesado.Checked = [bool]($script:TransPesado -and $script:TesteTransicao)
    $chkPesado.Enabled = [bool]$radios['transicao'].Checked
    $flow.Controls.Add($chkPesado)
    $radios['transicao'].Add_CheckedChanged({ $chkPesado.Enabled = [bool]$radios['transicao'].Checked; if (-not $chkPesado.Enabled) { $chkPesado.Checked = $false } }.GetNewClosure())
    $ldPesado = New-Object System.Windows.Forms.Label
    $ldPesado.AutoSize = $true
    $ldPesado.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
    $ldPesado.ForeColor = Pal 'Texto2'
    $ldPesado.Text = (Tr "Cerca de 15 minutos. Use se o teste normal não travou.")
    $ldPesado.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $flow.Controls.Add($ldPesado)

    $chkLonga = New-Object System.Windows.Forms.CheckBox
    $chkLonga.Text = (Tr 'Prolongar o teste de memória ou de disco para 30 minutos')
    $chkLonga.AutoSize = $true
    $chkLonga.Font = Fonte 10.5 $true
    $chkLonga.ForeColor = Pal 'Texto'
    $chkLonga.Margin = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), 0, 0)
    $chkLonga.Checked = [bool]($script:DuracaoLonga -and ($script:TesteMemoria -or $script:TesteDiscoEstresse))
    $chkLonga.Enabled = [bool]($radios['memoria'].Checked -or $radios['disco'].Checked)
    $flow.Controls.Add($chkLonga)
    foreach ($kk in @('memoria', 'disco')) { $radios[$kk].Add_CheckedChanged({ $chkLonga.Enabled = [bool]($radios['memoria'].Checked -or $radios['disco'].Checked); if (-not $chkLonga.Enabled) { $chkLonga.Checked = $false } }.GetNewClosure()) }
    $ldLonga = New-Object System.Windows.Forms.Label
    $ldLonga.AutoSize = $true
    $ldLonga.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
    $ldLonga.ForeColor = Pal 'Texto2'
    $ldLonga.Text = (Tr 'Acha erros que só aparecem com o aquecimento.')
    $ldLonga.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $flow.Controls.Add($ldLonga)

    $la = New-Object System.Windows.Forms.Label
    $la.AutoSize = $true
    $la.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $la.Padding = New-Object System.Windows.Forms.Padding((PX 8))
    $la.BackColor = Pal 'AvisoFundo'; $la.ForeColor = Pal 'AvisoTextoForte'
    $la.Text = (Tr 'Salve seus trabalhos e feche jogos e vídeos antes. Se o seu computador já trava, reinicia sozinho ou esquenta muito, faça o teste com cuidado: ele exige bastante do hardware. Para ver as temperaturas, deixe o HWiNFO aberto (opcional). Nada é alterado no seu computador.')
    $la.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 12))
    $flow.Controls.Add($la)

    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.FlowDirection = 'LeftToRight'
    $bar.AutoSize = $true
    $bar.AutoSizeMode = 'GrowAndShrink'
    $bar.WrapContents = $false
    $flow.Controls.Add($bar)
    $btnSim = Nova-BotaoGrande (Tr 'Iniciar o teste') 'primario' 150 40
    $btnSim.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $btnNao = Nova-BotaoGrande (Tr 'Agora não') 'secundario' 130 40
    $btnNao.DialogResult = [System.Windows.Forms.DialogResult]::No
    foreach ($bt in @($btnSim, $btnNao)) {
        $bt.AutoSize = $true; $bt.AutoSizeMode = 'GrowAndShrink'
        $bt.MinimumSize = New-Object System.Drawing.Size((PX 130), (PX 40))
        $bt.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    }
    $bar.Controls.Add($btnSim); $bar.Controls.Add($btnNao)
    $f.AcceptButton = $btnSim; $f.CancelButton = $btnNao

    $dono = $null
    if ($script:Form -and $script:Form.Visible) { $dono = $script:Form }
    try { if ($dono) { $r = $f.ShowDialog($dono) } else { $r = $f.ShowDialog() } }
    finally {
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
            $tipo = 'normal'
            foreach ($k in $radios.Keys) { if ($radios[$k].Checked) { $tipo = $k } }
            $script:TipoTeste = $tipo
            $script:TesteEstresse = ($tipo -eq 'estresse')
            $script:TesteTransicao = ($tipo -eq 'transicao')
            $script:TesteMemoria = ($tipo -eq 'memoria')
            $script:TesteDiscoEstresse = ($tipo -eq 'disco')
            $script:DuracaoLonga = (($tipo -eq 'memoria' -or $tipo -eq 'disco') -and $chkLonga.Checked)
            $script:TransPesado = ($tipo -eq 'transicao' -and $chkPesado.Checked)
            $script:EstresseProlongado = ($tipo -eq 'estresse' -and $chkProlong.Checked)
            $script:TesteLongo = (($tipo -eq 'longo') -or ($tipo -eq 'estresse' -and $chkJunto.Checked))
        }
        $f.Dispose()
    }
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Abrir-Url {
    param([string]$Url)
    if ($Url -match '^https?://') {
        try { Start-Process $Url } catch { }
    }
}

# ----------------------------------------------------------------------------
# Estilo: paleta e componentes
# ----------------------------------------------------------------------------
# Tema escuro (proposta aprovada): cores tiradas por amostragem de pixel da própria proposta
# aprovada pelo usuário. Contraste de cada par texto/fundo conferido contra o WCAG 2.2 AA
# (>=4,5:1 em texto normal, >=3:1 em elementos gráficos) antes de entrar aqui.
$script:Pal = @{
    Fundo = '#15171D'; Superficie = '#1A1D24'; Borda = '#2A2E38'; BordaForte = '#636C7A'; BordaHover = '#7A8491'
    Texto = '#F2F4F8'; Texto2 = '#9AA3B2'; Texto3 = '#828B99'
    Acento = '#2563EB'; AcentoHover = '#1D4ED8'; AcentoDown = '#1E40AF'; AcentoTexto = '#60A5FA'
    Perigo = '#DC2626'; PerigoHover = '#B91C1C'; PerigoDown = '#991B1B'; PerigoFundo = '#3A1414'; PerigoTextoForte = '#FCA5A5'
    Aviso = '#D97706'; AvisoFundo = '#3A2A0E'; AvisoTextoForte = '#FBBF24'
    Ok = '#16A34A'; OkFundo = '#10301D'; OkTextoForte = '#86EFAC'
    Info = '#94A0AF'; InfoFundo = '#13233D'
    Sutil = '#20242D'; SutilForte = '#2A2F3A'
    Desabilitado = '#262A33'; DesabilitadoTexto = '#5B6472'
    Trilha = '#333A47'
}
function Pal { param([string]$Nome) return (Cor $script:Pal[$Nome]) }

function Aplicar-EstiloBotao {
    param($B)
    $est = "$($B.Name)"
    $B.FlatStyle = 'Flat'
    try { $B.Invalidate() } catch { }
    if (-not $B.Enabled) {
        $B.BackColor = Pal 'Desabilitado'
        $B.ForeColor = Pal 'DesabilitadoTexto'
        $B.FlatAppearance.BorderSize = 0
        return
    }
    switch ($est) {
        'primario' {
            $B.BackColor = Pal 'Acento'; $B.ForeColor = [System.Drawing.Color]::White
            $B.FlatAppearance.BorderSize = 0
            $B.FlatAppearance.MouseOverBackColor = Pal 'AcentoHover'
            $B.FlatAppearance.MouseDownBackColor = Pal 'AcentoDown'
        }
        'perigo' {
            $B.BackColor = Pal 'Perigo'; $B.ForeColor = [System.Drawing.Color]::White
            $B.FlatAppearance.BorderSize = 0
            $B.FlatAppearance.MouseOverBackColor = Pal 'PerigoHover'
            $B.FlatAppearance.MouseDownBackColor = Pal 'PerigoDown'
        }
        'fantasma' {
            # Sem borda nem preenchimento em repouso: para ações de pouco peso (ex. "Sair"), que não devem
            # competir visualmente com a ação principal da tela.
            $B.BackColor = Pal 'Fundo'; $B.ForeColor = Pal 'Texto2'
            $B.FlatAppearance.BorderSize = 0
            $B.FlatAppearance.MouseOverBackColor = Pal 'Sutil'
            $B.FlatAppearance.MouseDownBackColor = Pal 'SutilForte'
        }
        default {
            $B.BackColor = (Pal 'Superficie'); $B.ForeColor = Pal 'Texto'
            $B.FlatAppearance.BorderSize = 1
            $B.FlatAppearance.BorderColor = Pal 'BordaForte'
            $B.FlatAppearance.MouseOverBackColor = Pal 'Sutil'
            $B.FlatAppearance.MouseDownBackColor = Pal 'SutilForte'
        }
    }
}

function Nova-CaminhoArredondado {
    param([single]$X, [single]$Y, [single]$W, [single]$H, [single]$R)
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = [single]($R * 2)
    $p.AddArc($X, $Y, $d, $d, 180, 90)
    $p.AddArc(($X + $W - $d), $Y, $d, $d, 270, 90)
    $p.AddArc(($X + $W - $d), ($Y + $H - $d), $d, $d, 0, 90)
    $p.AddArc($X, ($Y + $H - $d), $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

function Ajustar-LarguraBotao {
    # Define o texto e garante que ele caiba no botão (largura mínima + respiro dos lados).
    param($B, [string]$Texto, [double]$LarguraMin = 0)
    $B.Text = $Texto
    $tw = [System.Windows.Forms.TextRenderer]::MeasureText($Texto, $B.Font).Width
    $B.Width = [int][Math]::Max((PX $LarguraMin), ($tw + (PX 44)))
    $B.Invalidate()
}

function Nova-BotaoGrande {
    # Estilo: primario (azul), perigo (vermelho) ou secundario (branco com borda fina). Cantos arredondados.
    # -Icone é opcional: um caractere/glifo desenhado à esquerda do texto (ex. barra lateral de Ferramentas
    # de reparo). Fica só no desenho (Tag), nunca dentro de .Text - assim a tradução automática (que
    # procura o texto exato no dicionário) continua funcionando normalmente.
    param([string]$Texto, [string]$Estilo = 'secundario', [double]$Largura = 200, [double]$Altura = 40, [string]$Icone = '')
    $b = New-Object System.Windows.Forms.Button
    $b.Name = $Estilo
    $b.Text = $Texto
    if ($Estilo -eq 'secundario') { $b.Font = Fonte 10 } else { $b.Font = Fonte 10.5 $true }
    $tw = [System.Windows.Forms.TextRenderer]::MeasureText($Texto, $b.Font).Width
    $larg = [int][Math]::Max((PX $Largura), ($tw + (PX 44)))
    $b.Size = New-Object System.Drawing.Size($larg, (PX $Altura))
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 12), 0)
    $b.UseVisualStyleBackColor = $false
    $b.Tag = @{ Hover = $false; Down = $false; Teclado = $false; Icone = $Icone }
    Aplicar-EstiloBotao $b
    $b.Add_EnabledChanged({ param($remetente, $ev) Aplicar-EstiloBotao $remetente })
    $b.Add_MouseEnter({ param($r, $ev) $r.Tag.Hover = $true; $r.Invalidate() })
    $b.Add_MouseLeave({ param($r, $ev) $r.Tag.Hover = $false; $r.Tag.Down = $false; $r.Invalidate() })
    $b.Add_MouseDown({ param($r, $ev) $r.Tag.Down = $true; $r.Tag.Teclado = $false; $r.Invalidate() })
    $b.Add_KeyUp({ param($r, $ev) $r.Tag.Teclado = $true; $r.Invalidate() })
    $b.Add_Enter({ param($r, $ev) $r.Invalidate() })
    $b.Add_MouseUp({ param($r, $ev) $r.Tag.Down = $false; $r.Invalidate() })
    $b.Add_GotFocus({ param($r, $ev) $r.Invalidate() })
    $b.Add_LostFocus({ param($r, $ev) $r.Invalidate() })
    $b.Add_Paint({
        param($r, $ev)
        try {
            $g = $ev.Graphics
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $hover = $false; $down = $false
            if ($r.Tag -is [hashtable]) { $hover = [bool]$r.Tag.Hover; $down = [bool]$r.Tag.Down }
            $borda = $null
            if (-not $r.Enabled) {
                $fill = Pal 'Desabilitado'; $fore = Pal 'DesabilitadoTexto'
            } elseif ("$($r.Name)" -eq 'primario') {
                $fill = if ($down) { Pal 'AcentoDown' } elseif ($hover) { Pal 'AcentoHover' } else { Pal 'Acento' }
                $fore = [System.Drawing.Color]::White
            } elseif ("$($r.Name)" -eq 'perigo') {
                $fill = if ($down) { Pal 'PerigoDown' } elseif ($hover) { Pal 'PerigoHover' } else { Pal 'Perigo' }
                $fore = [System.Drawing.Color]::White
            } elseif ("$($r.Name)" -eq 'fantasma') {
                # Some com o fundo em repouso; só aparece ao passar o mouse ou focar.
                $fundoPai = (Pal 'Superficie')
                if ($r.Parent -and $r.Parent.BackColor.A -gt 0) { $fundoPai = $r.Parent.BackColor }
                $fill = if ($down) { Pal 'SutilForte' } elseif ($hover) { Pal 'Sutil' } else { $fundoPai }
                $fore = Pal 'Texto2'
            } else {
                $fill = if ($down) { Pal 'SutilForte' } elseif ($hover) { Pal 'Sutil' } else { (Pal 'Superficie') }
                $fore = Pal 'Texto'
                $borda = if ($hover) { Pal 'BordaHover' } else { Pal 'BordaForte' }
            }
            $fundo = (Pal 'Superficie')
            if ($r.Parent -and $r.Parent.BackColor.A -gt 0) { $fundo = $r.Parent.BackColor }
            $g.Clear($fundo)
            $rad = PX 8
            $caminho = Nova-CaminhoArredondado 0.5 0.5 ($r.Width - 2) ($r.Height - 2) $rad
            $pb = New-Object System.Drawing.SolidBrush($fill)
            $g.FillPath($pb, $caminho)
            $pb.Dispose()
            if ($borda) {
                $pen = New-Object System.Drawing.Pen($borda, 1)
                $g.DrawPath($pen, $caminho)
                $pen.Dispose()
            }
            $caminho.Dispose()
            if ($r.Focused -and $r.Tag.Teclado -and $r.Enabled) {
                $c2 = Nova-CaminhoArredondado 3 3 ($r.Width - 7) ($r.Height - 7) ($rad - 2)
                $pf = New-Object System.Drawing.Pen((Pal 'Acento'), 2)
                if ("$($r.Name)" -ne 'secundario') { $pf.Color = [System.Drawing.Color]::White }
                $g.DrawPath($pf, $c2)
                $pf.Dispose(); $c2.Dispose()
            }
            $iconeTxt = ''
            if ($r.Tag -is [hashtable] -and $r.Tag.Icone) { $iconeTxt = [string]$r.Tag.Icone }
            $xTexto = 0
            if ($iconeTxt) {
                $reservaIcone = PX 26
                $fonteIcone = New-Object System.Drawing.Font('Segoe UI Symbol', $r.Font.Size)
                $retIcone = New-Object System.Drawing.Rectangle((PX 12), 0, $reservaIcone, $r.Height)
                $flagsIcone = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::SingleLine -bor [System.Windows.Forms.TextFormatFlags]::NoPrefix
                [System.Windows.Forms.TextRenderer]::DrawText($g, $iconeTxt, $fonteIcone, $retIcone, $fore, $flagsIcone)
                $fonteIcone.Dispose()
                $xTexto = (PX 12) + $reservaIcone
            }
            $flags = $(if ($iconeTxt) { [System.Windows.Forms.TextFormatFlags]::Left } else { [System.Windows.Forms.TextFormatFlags]::HorizontalCenter }) -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::SingleLine -bor [System.Windows.Forms.TextFormatFlags]::EndEllipsis -bor [System.Windows.Forms.TextFormatFlags]::NoPrefix
            $ret = New-Object System.Drawing.Rectangle($xTexto, 0, ($r.Width - $xTexto), $r.Height)
            [System.Windows.Forms.TextRenderer]::DrawText($g, $r.Text, $r.Font, $ret, $fore, $flags)
        } catch { }
    })
    return $b
}

function Nova-Etiqueta {
    param([string]$Texto, [double]$Tam = 10, [bool]$Negrito = $false, [string]$CorNome = 'Texto', [double]$Altura = 30, [double]$Largura = 620)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Texto
    $l.AutoSize = $false
    $l.Height = PX $Altura
    $l.Width = PX $Largura
    $l.Font = Fonte $Tam $Negrito
    $l.ForeColor = Pal $CorNome
    $l.BackColor = [System.Drawing.Color]::Transparent
    $l.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
    return $l
}

function Centralizar {
    # Centraliza um filho dentro do pai; sem -Topo, centraliza também na vertical.
    param($Pai, $Filho, [double]$Topo = -1)
    $x = [int][Math]::Max((PX 24), ($Pai.ClientSize.Width - $Filho.Width) / 2)
    if ($Topo -ge 0) {
        $y = PX $Topo
    } else {
        $y = [int][Math]::Max((PX 24), ($Pai.ClientSize.Height - $Filho.Height) / 2 - (PX 30))
    }
    $Filho.Location = New-Object System.Drawing.Point($x, $y)
}

function Ajustar-Barra {
    # Quando os botões não cabem numa linha, a barra cresce e eles passam para a linha de baixo.
    # Mede pela largura da própria barra (a do painel interno pode estar desatualizada durante o redimensionamento).
    param($Barra)
    $fl = $Barra.Controls['fluxo']
    if (-not $fl) { return }
    $disp = [int]($Barra.ClientSize.Width - $fl.Padding.Horizontal)
    if ($disp -le 0) { return }
    $linhas = 1; $x = 0
    foreach ($c in $fl.Controls) {
        if (-not $c.Visible) { continue }
        $c.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 12), (PX 8))
        $w = $c.Width + $c.Margin.Horizontal
        if (($x + $w) -gt $disp -and $x -gt 0) { $linhas++; $x = 0 }
        $x += $w
    }
    $alvo = [int]((PX 16) + $linhas * (PX 52) + (PX 8))
    if ($alvo -lt (PX 76)) { $alvo = PX 76 }
    if ($Barra.Height -ne $alvo) { $Barra.Height = $alvo }
    # Força o encaixe do restante da página e o redesenho (evita botões cortados ou "fantasmas" ao maximizar).
    try { $fl.PerformLayout(); if ($Barra.Parent) { $Barra.Parent.PerformLayout() }; $Barra.Invalidate($true) } catch { }
}

function Nova-BarraAcoes {
    # Barra inferior branca com linha fina em cima; os botões entram em .Controls['fluxo'].
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Bottom'
    $p.Height = PX 76
    $p.BackColor = (Pal 'Superficie')
    $fl = New-Object System.Windows.Forms.FlowLayoutPanel
    $fl.Name = 'fluxo'
    $fl.Dock = 'Fill'
    $fl.WrapContents = $true
    $fl.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 16), (PX 24), 0)
    $p.Controls.Add($fl)
    $p.Add_Resize({ try { Ajustar-Barra $this } catch { } })
    $linha = New-Object System.Windows.Forms.Panel
    $linha.Dock = 'Top'
    $linha.Height = 1
    $linha.BackColor = Pal 'Borda'
    $p.Controls.Add($linha)
    return $p
}

# ----------------------------------------------------------------------------
# Janela principal
# ----------------------------------------------------------------------------
$script:Form = New-Object System.Windows.Forms.Form
$form = $script:Form
$form.Text = "Telomera $($script:Versao)"
$form.StartPosition = 'CenterScreen'
# Tamanho inicial proporcional à tela: em notebook com escala 150% um tamanho fixo ocuparia a tela inteira ou passaria dela.
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.MinimumSize = New-Object System.Drawing.Size([int][Math]::Min((PX 840), $wa.Width * 0.9), [int][Math]::Min((PX 620), $wa.Height * 0.9))
$form.ClientSize = New-Object System.Drawing.Size([int][Math]::Min((PX 1180), $wa.Width * 0.92), [int][Math]::Min((PX 780), $wa.Height * 0.88))
# ClientSize acima é o tamanho de quando o usuário restaurar a janela (botão de restaurar da barra de título);
# o Telomera já abre maximizado.
$form.WindowState = 'Maximized'
$form.Font = Fonte 10
$form.BackColor = Pal 'Fundo'
$form.ForeColor = Pal 'Texto'
try { $form.Icon = Get-IconeTelomera } catch { }

# Área central (vai primeiro: o painel "Fill" precisa ser o último a ser encaixado)
$conteudo = New-Object System.Windows.Forms.Panel
$conteudo.Dock = 'Fill'
$form.Controls.Add($conteudo)

# Cabeçalho branco, discreto
$cab = New-Object System.Windows.Forms.Panel
$cab.Dock = 'Top'
$cab.Height = PX 64
$cab.BackColor = (Pal 'Superficie')
$logo = New-Object System.Windows.Forms.PictureBox
$logo.SizeMode = 'Zoom'
$logo.BackColor = (Pal 'Superficie')
try { $logo.Image = Get-LogoTelomera } catch { }
$logo.Size = New-Object System.Drawing.Size((PX 34), (PX 34))
$logo.Location = New-Object System.Drawing.Point((PX 26), (PX 15))
$lblTitulo = New-Object System.Windows.Forms.Label
$lblTitulo.Text = 'Telomera'
$lblTitulo.Font = Fonte 14 $true
$lblTitulo.ForeColor = Pal 'Texto'
$lblTitulo.AutoSize = $true
$lblTitulo.Location = New-Object System.Drawing.Point((PX 70), (PX 9))
$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = (Tr 'Diagnóstico de drivers, discos e hardware')
$lblSub.Font = Fonte 9
$lblSub.ForeColor = Pal 'Texto3'
$lblSub.AutoSize = $true
$lblSub.Location = New-Object System.Drawing.Point((PX 71), (PX 35))
$btnInicio = Nova-BotaoGrande (Tr '← Voltar ao início') 'secundario' 190 40
$btnInicio.AccessibleName = 'Voltar ao início'
$btnInicio.Anchor = 'Top, Right'
$btnInicio.Visible = $false
$cab.Controls.Add($btnInicio)

# Engrenagem de Configurações no cabeçalho (substitui o bloco "Configurações" que ficava na grade da
# tela inicial): sempre à vista, em vez de competir com os blocos de assunto.
$btnCfgEngrenagem = New-Object System.Windows.Forms.Button
$btnCfgEngrenagem.Text = [string]([char]0x2699)
$btnCfgEngrenagem.AccessibleName = 'Configurações'
$btnCfgEngrenagem.FlatStyle = 'Flat'
$btnCfgEngrenagem.FlatAppearance.BorderSize = 0
$btnCfgEngrenagem.FlatAppearance.MouseOverBackColor = Pal 'Sutil'
$btnCfgEngrenagem.FlatAppearance.MouseDownBackColor = Pal 'SutilForte'
$btnCfgEngrenagem.BackColor = (Pal 'Superficie')
$btnCfgEngrenagem.ForeColor = Pal 'Texto'
$btnCfgEngrenagem.Font = New-Object System.Drawing.Font('Segoe UI Symbol', [single](20 * $script:Esc))
$btnCfgEngrenagem.UseVisualStyleBackColor = $false
$btnCfgEngrenagem.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnCfgEngrenagem.Size = New-Object System.Drawing.Size((PX 48), (PX 48))
$btnCfgEngrenagem.Anchor = 'Top, Right'
$script:DicaEngrenagem = New-Object System.Windows.Forms.ToolTip
$script:DicaEngrenagem.SetToolTip($btnCfgEngrenagem, (Tr 'Configurações'))
$cab.Controls.Add($btnCfgEngrenagem)

function Posicionar-BtnInicio {
    $xEngrenagem = $cab.ClientSize.Width - $btnCfgEngrenagem.Width - (PX 24)
    $btnCfgEngrenagem.Location = New-Object System.Drawing.Point($xEngrenagem, (PX 8))
    $btnInicio.Location = New-Object System.Drawing.Point(($xEngrenagem - $btnInicio.Width - (PX 12)), (PX 12))
}
Posicionar-BtnInicio
$cab.Add_Resize({ try { Posicionar-BtnInicio } catch { } })
$cab.Controls.Add($logo)
$cab.Controls.Add($lblTitulo)
$cab.Controls.Add($lblSub)
$linhaCab = New-Object System.Windows.Forms.Panel
$linhaCab.Dock = 'Bottom'
$linhaCab.Height = 1
$linhaCab.BackColor = Pal 'Borda'
$cab.Controls.Add($linhaCab)
$form.Controls.Add($cab)

# Rodapé sem faixa: só um texto discreto
$rodape = New-Object System.Windows.Forms.Panel
$rodape.Dock = 'Bottom'
$rodape.Height = PX 28
$rodape.BackColor = Pal 'Fundo'
$lblRodape = New-Object System.Windows.Forms.Label
$lblRodape.AutoSize = $true
$lblRodape.Font = Fonte 8.5
$lblRodape.ForeColor = Pal 'Texto3'
$lblRodape.Location = New-Object System.Drawing.Point((PX 26), (PX 6))
if ($script:IsAdmin) { $modo = 'administrador' } else { $modo = 'somente verificação' }
$lblRodape.Text = "v$($script:Versao)   ·   $modo   ·   nada é enviado para a internet"
$rodape.Controls.Add($lblRodape)
$form.Controls.Add($rodape)

function Nova-Pagina {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.Visible = $false
    $p.BackColor = Pal 'Fundo'
    $conteudo.Controls.Add($p)
    return $p
}
$pgInicio = Nova-Pagina
$pgProg   = Nova-Pagina
$pgRes    = Nova-Pagina
$pgFim    = Nova-Pagina
$pgFerr   = Nova-Pagina
$pgCfg    = Nova-Pagina

function Reposicionar {
    try {
        if ($pgInicio.Visible) {
            # Janela larga: apresentação à esquerda e resumo do PC à direita. Estreita: um embaixo do outro.
            # Se for alta demais, a página rola (barra de rolagem) em vez de cortar o conteúdo.
            $mostrarLado = ($pgInicio.ClientSize.Width -ge (PX 980))
            $pnlLado.Visible = $mostrarLado
            $ladoW = $(if ($mostrarLado) { $pnlLado.Width } else { 0 })
            $pw = $pgInicio.ClientSize.Width - $ladoW
            $mg = PX 28
            $xi = [int]($ladoW + [Math]::Max($mg, ($pw - $colIni.Width) / 2))
            $yAlto = ($colIni.Height + (2 * (PX 24))) -gt $pgInicio.ClientSize.Height
            if ($yAlto) {
                $yi = [int]((PX 24) + $pgInicio.AutoScrollPosition.Y)
            } else {
                $pgInicio.AutoScrollPosition = New-Object System.Drawing.Point(0, 0)
                $yi = [int][Math]::Max((PX 24), ($pgInicio.ClientSize.Height - $colIni.Height) / 2 - (PX 20))
            }
            $colIni.Location = New-Object System.Drawing.Point($xi, $yi)
        }
        if ($pgProg.Visible) {
            Ajustar-ColunaProg
            if ($script:Log.Visible) { Centralizar $topoProg $colProg 28 } else { Centralizar $topoProg $colProg }
        }
    } catch { }
}

$script:Margem = 24
function Ajustar-Margens {
    # Em janelas largas o conteúdo fica numa coluna central (até ~1180 px) em vez de colado à esquerda.
    $total = [int]$conteudo.ClientSize.Width
    if ($total -le 0) { return }
    $m = [int][Math]::Max((PX 24), [Math]::Floor(($total - (PX 1180)) / 2))
    $wb0 = [int][Math]::Max((PX 300), ($banner.ClientSize.Width - (2 * $m) - (PX 8)))
    if ($lblBanT.Width -ne $wb0) { $lblBanT.Width = $wb0; $lblBanS.Width = $wb0 }
    if ($m -eq $script:Margem) { return }
    $script:Margem = $m
    $flowCards.Padding = New-Object System.Windows.Forms.Padding($m, (PX 6), $m, (PX 16))
    $pnlFiltro.Padding = New-Object System.Windows.Forms.Padding($m, (PX 14), 0, 0)
    $pnlPC.Padding = New-Object System.Windows.Forms.Padding($m, (PX 10), $m, (PX 16))
    $barraRes.Controls['fluxo'].Padding = New-Object System.Windows.Forms.Padding($m, (PX 16), (PX 24), 0)
    $barraFim.Controls['fluxo'].Padding = New-Object System.Windows.Forms.Padding($m, (PX 16), (PX 24), 0)
    $flowAbas.Padding = New-Object System.Windows.Forms.Padding([int][Math]::Max((PX 18), ($m - (PX 12))), 0, 0, 0)
    $lblBanT.Left = $m + (PX 4)
    $lblBanS.Left = $m + (PX 5)
    $pnlFimCorpo.Padding = New-Object System.Windows.Forms.Padding($m, (PX 8), $m, (PX 16))
    $lblFimT.Padding = New-Object System.Windows.Forms.Padding($m, (PX 22), 0, 0)
    try { Ajustar-Barra $barraRes; Ajustar-Barra $barraFim } catch { }
}

function Show-Pagina {
    param($Pagina)
    foreach ($p in @($pgInicio, $pgProg, $pgRes, $pgFim, $pgFerr, $pgCfg)) { $p.Visible = $false }
    $Pagina.Visible = $true
    $Pagina.BringToFront()
    try { $btnInicio.Visible = (($Pagina -ne $pgInicio) -and ($Pagina -ne $pgProg)); $btnInicio.BringToFront() } catch { }
    try { if ($Pagina -eq $pgInicio) { Atualizar-InfoInicio } } catch { }
    try { if ($Pagina -eq $pgCfg) { Atualizar-Cfg } } catch { }
    try { if ($Pagina -eq $pgFerr) { Atualizar-Monitor } } catch { }
    try { if ($Pagina -eq $pgInicio) { Atualizar-Sensores } } catch { }
    Reposicionar
}

# ----------------------------------------------------------------------------
# Página 1 - Início (conteúdo centralizado)
# ----------------------------------------------------------------------------
$colIni = New-Object System.Windows.Forms.FlowLayoutPanel
$colIni.FlowDirection = 'TopDown'
$colIni.WrapContents = $false
$colIni.AutoSize = $true
$colIni.AutoSizeMode = 'GrowAndShrink'
$colIni.BackColor = Pal 'Fundo'
$pgInicio.AutoScroll = $true
$pgInicio.AutoScrollMargin = New-Object System.Drawing.Size(0, (PX 24))
$pgInicio.Controls.Add($colIni)

$script:LargIni = PX 620
$picIni = New-Object System.Windows.Forms.PictureBox
$picIni.SizeMode = 'Zoom'; $picIni.BackColor = Pal 'Fundo'
$picIni.Size = New-Object System.Drawing.Size((PX 84), (PX 84))
$picIni.Margin = New-Object System.Windows.Forms.Padding((PX (($script:LargIni / $script:Esc - 84) / 2)), 0, 0, (PX 10))
try { $picIni.Image = Get-LogoTelomera } catch { }
$colIni.Controls.Add($picIni)
$lblIniT = Nova-Etiqueta 'Vamos verificar o seu computador?' 24 $true 'Texto' 56
$lblIniT.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
$colIni.Controls.Add($lblIniT)
$lblIniD = Nova-Etiqueta 'O Telomera procura problemas em drivers, discos, memória, placa de vídeo e no histórico de erros do Windows, como telas azuis e travamentos. Ele só lê as informações: nada é alterado sem a sua permissão.' 11.5 $false 'Texto2' 84
$lblIniD.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 14))
$colIni.Controls.Add($lblIniD)
$lblTempoEst = Nova-Etiqueta 'Leva de 2 a 10 minutos   ·   Você pode continuar usando o computador' 9.5 $false 'Texto3' 28
$lblTempoEst.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 22))
$lblTempoEst.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
$colIni.Controls.Add($lblTempoEst)
function Nova-Anel {
    # Anel de progresso (0 a 100): trilha cinza clara + arco colorido proporcional ao percentual, igual
    # à proposta de design. Usado pequeno ao lado da nota de saúde (Início) e grande na tela de Progresso.
    # A cor do arco segue a mesma lógica de "Ok/Aviso/Perigo" já usada no resto da interface. -ComTexto
    # desenha um texto centralizado dentro do anel (usado no anel grande de Progresso; o pequeno do Início
    # não precisa, o texto fica do lado de fora). $Anel.Tag guarda um hashtable com o estado atual
    # (Pct/Texto/Indet/Angulo); Set-Anel troca os valores e manda redesenhar.
    param([double]$DiametroLogico = 40, [double]$EspessuraLogica = 5, [switch]$ComTexto)
    $anel = New-Object System.Windows.Forms.Panel
    $d = PX $DiametroLogico
    $anel.Size = New-Object System.Drawing.Size($d, $d)
    $anel.BackColor = Pal 'Fundo'
    $anel.Tag = @{ Pct = [double]0; Texto = ''; Indet = $false; Angulo = [double]0 }
    $esp = [Math]::Max(2, [int](PX $EspessuraLogica))
    $comTextoLocal = [bool]$ComTexto
    $fonteCentro = Fonte ([Math]::Max(10, $DiametroLogico * 0.16)) $true
    $Desenhar = {
        param($s, $e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $r = $s.ClientRectangle
        $r.Inflate(-[int]($esp / 2), -[int]($esp / 2))
        $pTrilha = New-Object System.Drawing.Pen((Pal 'Trilha'), $esp)
        $g.DrawEllipse($pTrilha, $r)
        $pTrilha.Dispose()
        $info = $s.Tag
        $pct = 0.0; $txt = ''; $indet = $false; $ang = 0.0
        if ($info -is [hashtable]) {
            $pct = [double]$info.Pct; $txt = [string]$info.Texto
            $indet = [bool]$info.Indet; $ang = [double]$info.Angulo
        }
        if ($indet) {
            $pArco = New-Object System.Drawing.Pen((Pal 'Acento'), $esp)
            $pArco.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
            $pArco.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
            $g.DrawArc($pArco, $r, $ang, 110)
            $pArco.Dispose()
        } elseif ($pct -gt 0) {
            $corArco = if ($pct -ge 70) { Pal 'Ok' } elseif ($pct -ge 40) { Pal 'Aviso' } else { Pal 'Perigo' }
            $pArco = New-Object System.Drawing.Pen($corArco, $esp)
            $pArco.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
            $pArco.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
            $varredura = [double]360 * ([Math]::Min(100, [Math]::Max(0, $pct)) / 100.0)
            $g.DrawArc($pArco, $r, -90, $varredura)
            $pArco.Dispose()
        }
        if ($comTextoLocal -and $txt) {
            $fmt = New-Object System.Drawing.StringFormat
            $fmt.Alignment = [System.Drawing.StringAlignment]::Center
            $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
            $bTxt = New-Object System.Drawing.SolidBrush((Pal 'Texto'))
            $retTxt = New-Object System.Drawing.RectangleF(0, 0, $s.Width, $s.Height)
            $g.DrawString($txt, $fonteCentro, $bTxt, $retTxt, $fmt)
            $bTxt.Dispose(); $fmt.Dispose()
        }
    }.GetNewClosure()
    $anel.Add_Paint($Desenhar)
    return $anel
}
function Set-Anel {
    param($Anel, [double]$Percentual = 0, [string]$Texto = $null, [switch]$Indeterminada)
    $info = $Anel.Tag
    if (-not ($info -is [hashtable])) { $info = @{ Pct = [double]0; Texto = ''; Indet = $false; Angulo = [double]0 } }
    if ($Indeterminada) { $info.Indet = $true } else { $info.Indet = $false; $info.Pct = [double]$Percentual }
    if ($null -ne $Texto) { $info.Texto = $Texto }
    $Anel.Tag = $info
    try { $Anel.Invalidate() } catch { }
}
function Girar-Anel {
    # Avança o ângulo do arco "indeterminado" (sem corrigir nada em andamento, só o giro visual).
    param($Anel, [double]$Passo = 7)
    $info = $Anel.Tag
    if (-not ($info -is [hashtable]) -or -not $info.Indet) { return }
    $info.Angulo = ([double]$info.Angulo + $Passo) % 360
    $Anel.Tag = $info
    try { $Anel.Invalidate() } catch { }
}

# Nota de saúde da última verificação: anel pequeno + texto, lado a lado (em vez de só texto).
$linhaNota = New-Object System.Windows.Forms.Panel
$linhaNota.Size = New-Object System.Drawing.Size($script:LargIni, (PX 44))
$linhaNota.BackColor = Pal 'Fundo'
$linhaNota.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
$linhaNota.Visible = $false
$grupoNota = New-Object System.Windows.Forms.FlowLayoutPanel
$grupoNota.FlowDirection = 'LeftToRight'
$grupoNota.WrapContents = $false
$grupoNota.AutoSize = $true
$grupoNota.AutoSizeMode = 'GrowAndShrink'
$grupoNota.BackColor = Pal 'Fundo'
$script:AnelNota = Nova-Anel 34 4.5
$script:AnelNota.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 10), 0)
$grupoNota.Controls.Add($script:AnelNota)
$lblNotaIni = Nova-Etiqueta '' 10 $true 'Texto' 34 420
$lblNotaIni.TextAlign = 'MiddleLeft'
$lblNotaIni.Margin = New-Object System.Windows.Forms.Padding(0)
$grupoNota.Controls.Add($lblNotaIni)
$linhaNota.Controls.Add($grupoNota)
Centralizar $linhaNota $grupoNota 5
$colIni.Controls.Add($linhaNota)
$lblAvisoAg = Nova-Etiqueta '' 9.5 $false 'Texto' 70
$lblAvisoAg.BackColor = Pal 'AvisoFundo'
$lblAvisoAg.ForeColor = Pal 'AvisoTextoForte'
$lblAvisoAg.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
$lblAvisoAg.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
$lblAvisoAg.Visible = $false
$colIni.Controls.Add($lblAvisoAg)
$lnkAvisoOk = New-Object System.Windows.Forms.LinkLabel
$lnkAvisoOk.Text = (Tr 'Dispensar este aviso')
$lnkAvisoOk.AutoSize = $false
$lnkAvisoOk.Width = $script:LargIni
$lnkAvisoOk.Height = PX 24
$lnkAvisoOk.TextAlign = 'TopCenter'
$lnkAvisoOk.Font = Fonte 9
$lnkAvisoOk.LinkColor = Pal 'Texto2'
$lnkAvisoOk.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
$lnkAvisoOk.Visible = $false
$colIni.Controls.Add($lnkAvisoOk)

$lblSemAdmin = Nova-Etiqueta 'Aberto sem permissão de administrador: dá para verificar, mas não para corrigir. Para corrigir, feche e abra de novo aceitando o pedido de permissão.' 9.5 $false 'Texto' 54
$lblSemAdmin.BackColor = Pal 'AvisoFundo'
$lblSemAdmin.ForeColor = Pal 'AvisoTextoForte'
$lblSemAdmin.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
$lblSemAdmin.Visible = (-not $script:IsAdmin)
$colIni.Controls.Add($lblSemAdmin)

$btnIniciar = Nova-BotaoGrande 'Verificar meu computador' 'primario' 700 60
$btnIniciar.Font = Fonte 13 $true
$btnIniciar.Width = $script:LargIni
$btnIniciar.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 14))
$colIni.Controls.Add($btnIniciar)
# Verificação profunda: opção na tela inicial (mais lenta; só leitura). Volta desmarcada toda vez que o app abre.
$form.AcceptButton = $btnIniciar

# Seis blocos por assunto (cada um abre só o que é daquele assunto)
$btnBench = Nova-BotaoGrande 'Testar desempenho' 'secundario' 200 56
$btnAreaTravou = Nova-BotaoGrande 'O PC trava ou desliga' 'secundario' 200 56
$btnAreaMonitor = Nova-BotaoGrande 'Monitor e sensores' 'secundario' 200 56
$btnAreaDrivers = Nova-BotaoGrande 'Drivers' 'secundario' 200 56
$btnFerr = Nova-BotaoGrande 'Reparos e restauração' 'secundario' 200 56
$btnAreaAjuda = Nova-BotaoGrande 'Ajuda e autoteste' 'secundario' 200 56
$btnCfg = Nova-BotaoGrande 'Configurações' 'secundario' 200 56
# Blocos por assunto em grade fixa (alinhada): três grandes em cima, quatro menores embaixo.
$linhaSec = New-Object System.Windows.Forms.Panel
$linhaSec.Size = New-Object System.Drawing.Size($script:LargIni, (PX 124))
$linhaSec.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
$linhaSec.BackColor = Pal 'Fundo'
$gapT = PX 12
$w3 = [int][Math]::Floor(($script:LargIni - (2 * $gapT)) / 3)
$w4 = [int][Math]::Floor(($script:LargIni - (2 * $gapT)) / 3)
$k = 0
foreach ($bt in @($btnAreaTravou, $btnAreaDrivers, $btnAreaMonitor)) {
    $bt.Size = New-Object System.Drawing.Size($w3, (PX 56)); $bt.Margin = New-Object System.Windows.Forms.Padding(0)
    $bt.Location = New-Object System.Drawing.Point(($k * ($w3 + $gapT)), 0)
    $linhaSec.Controls.Add($bt); $k++
}
$k = 0
# "Configurações" saiu daqui: agora é a engrenagem no cabeçalho (perto do título), para sobrar só os
# blocos de assunto nesta grade. $btnCfg continua existindo e com o mesmo clique de sempre, só não fica
# mais na grade; a engrenagem aciona o clique dele (PerformClick), sem duplicar a lógica de navegação.
foreach ($bt in @($btnBench, $btnFerr, $btnAreaAjuda)) {
    $bt.Size = New-Object System.Drawing.Size($w4, (PX 44)); $bt.Margin = New-Object System.Windows.Forms.Padding(0); $bt.Font = Fonte 9.5
    $bt.Location = New-Object System.Drawing.Point(($k * ($w4 + $gapT)), (PX 68))
    $linhaSec.Controls.Add($bt); $k++
}
$colIni.Controls.Add($linhaSec)
$lblLegSec = Nova-Etiqueta 'Escolha pelo assunto: cada bloco abre só o que é dele. O PC trava? Comece por "O PC trava ou desliga". Problema com driver? Vá em "Drivers".' 9 $false 'Texto3' 24
$lblLegSec.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblLegSec.Visible = $false   # legenda removida: os nomes dos blocos já dizem o assunto
$colIni.Controls.Add($lblLegSec)
$lblSensIni = Nova-Etiqueta '' 9 $false 'Texto2' 40
$lblSensIni.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
$colIni.Controls.Add($lblSensIni)

$lnkSeguro = New-Object System.Windows.Forms.LinkLabel
$lnkSeguro.Text = (Tr 'O que o Telomera faz e o que nunca faz sozinho')
$lnkSeguro.AutoSize = $false
$lnkSeguro.Width = $script:LargIni
$lnkSeguro.Height = PX 26
$lnkSeguro.TextAlign = 'TopCenter'
$lnkSeguro.Font = Fonte 9.5
$lnkSeguro.LinkColor = Pal 'AcentoTexto'
$lnkSeguro.LinkBehavior = 'HoverUnderline'
$lnkSeguro.Margin = New-Object System.Windows.Forms.Padding(0, (PX 22), 0, 0)
$colIni.Controls.Add($lnkSeguro)
$lblPriv = Nova-Etiqueta 'Cada verificação é salva em uma pasta própria dentro de "Telomera", na Área de Trabalho. Revise os relatórios antes de compartilhar: podem conter o nome do computador e IDs de hardware.' 9 $false 'Texto3' 44
$lblPriv.Margin = New-Object System.Windows.Forms.Padding(0, (PX 8), 0, 0)
$colIni.Controls.Add($lblPriv)

# Tudo centralizado na coluna: textos, aviso e rodapé
foreach ($lc in @($lblIniT, $lblIniD, $lblTempoEst, $lblAvisoAg, $lblSemAdmin, $lblLegSec, $lblSensIni, $lblPriv)) {
    $lc.Width = $script:LargIni
    $lc.TextAlign = 'TopCenter'
}
# Resumo do computador (lido em segundo plano; aparece ao lado, ou embaixo em janelas estreitas)
$script:DadosPcIni = $null
# Barra lateral esquerda: componentes do computador (lidos logo que o app abre)
$pnlLado = New-Object System.Windows.Forms.Panel
$pnlLado.Dock = 'Left'
$pnlLado.Width = PX 300
$pnlLado.BackColor = (Pal 'Superficie')
$bordaLado = New-Object System.Windows.Forms.Panel
$bordaLado.Dock = 'Right'; $bordaLado.Width = 1; $bordaLado.BackColor = Pal 'Borda'
$pnlLado.Controls.Add($bordaLado)
$fluxoLado = New-Object System.Windows.Forms.FlowLayoutPanel
$fluxoLado.Dock = 'Fill'
$fluxoLado.FlowDirection = 'TopDown'
$fluxoLado.WrapContents = $false
$fluxoLado.AutoScroll = $true
$fluxoLado.BackColor = (Pal 'Superficie')
$fluxoLado.Padding = New-Object System.Windows.Forms.Padding((PX 22), (PX 24), (PX 14), (PX 16))
$pnlLado.Controls.Add($fluxoLado)
$fluxoLado.BringToFront()
$pgInicio.Controls.Add($pnlLado)
$pgInicio.Add_SizeChanged({ Reposicionar })
$colIni.Add_SizeChanged({ Reposicionar })
function Get-DirDadosGui {
    $b = $env:WD_DADOS_DIR
    if (-not $b) { $b = Join-Path $env:LOCALAPPDATA 'Telomera' }
    return $b
}
function Atualizar-InfoInicio {
    # Última nota de saúde e aviso da verificação automática (se houver) na tela inicial.
    try {
        $linhaNota.Visible = $false
        $f = Join-Path (Get-DirDadosGui) 'saude.jsonl'
        if (Test-Path -LiteralPath $f) {
            $ult = @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction Stop | Where-Object { "$_".Trim() }) | Select-Object -Last 1
            if ($ult) {
                $o = $ult | ConvertFrom-Json
                $lblNotaIni.Text = "Última verificação ($($o.Data)): nota de saúde $($o.Nota)/100 ($($o.Rotulo))"
                try { Set-Anel $script:AnelNota ([double]$o.Nota) } catch { }
                $linhaNota.Visible = $true
                Centralizar $linhaNota $grupoNota 5
            }
        }
    } catch { }
    try {
        $lblAvisoAg.Visible = $false; $lnkAvisoOk.Visible = $false
        $fa = Join-Path (Get-DirDadosGui) 'aviso.json'
        if (Test-Path -LiteralPath $fa) {
            $av = Get-Content -LiteralPath $fa -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
            if ($av.Texto) {
                $lblAvisoAg.Text = [string]$av.Texto
                $lblAvisoAg.Visible = $true; $lnkAvisoOk.Visible = $true
            }
        }
    } catch { }
}
$lnkAvisoOk.Add_LinkClicked({
    try {
        $fa = Join-Path (Get-DirDadosGui) 'aviso.json'
        if (Test-Path -LiteralPath $fa) { Remove-Item -LiteralPath $fa -Force -ErrorAction SilentlyContinue }
        Atualizar-InfoInicio
        Reposicionar
    } catch { }
})
$script:TextoSeguro = @"
O QUE O TELOMERA FAZ

- Lê informações do computador (discos, drivers, memória, placa de vídeo, histórico de erros e travamentos do Windows) e gera um relatório.
- Na verificação profunda, também confere os arquivos dos programas instalados: avisa se algum estiver corrompido ou alterado (assinatura digital não bate).
- Mostra o que encontrou e, quando existe uma correção, explica o que ela faz.
- Monitora temperaturas e tensões (lendo o HWiNFO, se estiver aberto) e mostra o estado dos sensores.

O QUE ELE SÓ FAZ DEPOIS DO SEU "SIM"

- Qualquer correção: reparar o disco, reativar ou reinstalar um driver, restaurar um driver guardado, proteger o driver de vídeo contra trocas, apagar arquivos temporários antigos, reiniciar a configuração de rede, agendar o CHKDSK.
- Testar o desempenho (processador, memória, disco ou vídeo): só roda quando você escolhe "Testar desempenho" e confirma o tipo de teste. Esses testes exigem bastante do hardware de propósito (é para isso que servem).
- No modo "Corrigir automaticamente" você aprova uma vez só as correções comuns. As ações mais delicadas e as proteções opcionais continuam pedindo uma confirmação separada.
- Antes de corrigir, o Telomera oferece criar um ponto de restauração e guardar uma cópia dos drivers.

O QUE O TELOMERA NUNCA FAZ

- Apagar os seus arquivos pessoais (documentos, fotos, vídeos). A limpeza só mexe em arquivos temporários com mais de 2 dias, e o backup apenas copia.
- Formatar discos, mexer em partições, na BIOS ou no firmware.
- Desativar o antivírus ou o firewall, nem trocar senhas ou contas de usuário.
- Instalar ou desinstalar programas. Os drivers pendentes só podem ser instalados pelo Windows Update, e só se você aprovar.
- Enviar informações do seu computador para alguém. Não há conta, nem coleta de dados, nem envio de relatórios.

QUANDO ELE USA A INTERNET

- Na verificação, se a opção estiver marcada: para consultar drivers pendentes no Windows Update e testar a conexão.
- No botão "Procurar atualização": só para ler qual é a versão mais recente do Telomera.
- Os relatórios ficam na pasta "Telomera" da Área de Trabalho. Revise-os antes de compartilhar: podem conter o nome do computador.

VERIFICAÇÃO SEMANAL AUTOMÁTICA (OPCIONAL)

- Só existe se você ativar em "Configurações". Ela apenas lê informações, sem corrigir nada, e só avisa se a saúde do computador piorar (se marcada para usar a internet, também consulta drivers pendentes, como na verificação manual). Dá para desativar quando quiser.
"@
$lnkSeguro.Add_LinkClicked({
    try { [void][System.Windows.Forms.MessageBox]::Show((Tr $script:TextoSeguro), 'Telomera', 'OK', 'Information') } catch { Registrar-Erro $_ -Silencioso }
})

# ----------------------------------------------------------------------------
# Página 2 - Progresso (centralizado; barra fina)
# ----------------------------------------------------------------------------
$script:Log = New-Object System.Windows.Forms.RichTextBox
$log = $script:Log
$log.Dock = 'Fill'
$log.ReadOnly = $true
$log.BorderStyle = 'None'
$log.BackColor = [System.Drawing.Color]::FromArgb(24, 26, 31)
$log.ForeColor = [System.Drawing.Color]::LightGray
$log.Font = New-Object System.Drawing.Font('Consolas', [single]9)
$log.WordWrap = $true
$log.DetectUrls = $false
$log.Visible = $false
$pgProg.Controls.Add($log)

$topoProg = New-Object System.Windows.Forms.Panel
$topoProg.Dock = 'Fill'
$topoProg.BackColor = Pal 'Fundo'
$pgProg.Controls.Add($topoProg)

$colProg = New-Object System.Windows.Forms.FlowLayoutPanel
$colProg.FlowDirection = 'TopDown'
$colProg.WrapContents = $false
$colProg.AutoSize = $true
$colProg.AutoSizeMode = 'GrowAndShrink'
$colProg.BackColor = Pal 'Fundo'
$topoProg.Controls.Add($colProg)

$script:PontosTotal = 0
$DesenharPonto = {
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $cor = if ($s.Tag) { $s.Tag } else { Pal 'Trilha' }
    $b = New-Object System.Drawing.SolidBrush($cor)
    $g.FillEllipse($b, 0, 0, [Math]::Max(1, $s.Width - 1), [Math]::Max(1, $s.Height - 1))
    $b.Dispose()
}
function Atualizar-Pontos {
    # Uma bolinha por etapa, abaixo do anel grande: cheias (cor de destaque) até a etapa atual, que
    # fica um pouco maior; o resto em cinza claro. Com mais de 24 etapas (ex.: DISM) os pontos deixam de
    # ajudar e ficam escondidos — só a porcentagem no meio do anel já basta nesse caso.
    param([int]$N, [int]$Total)
    if ($Total -le 0 -or $Total -gt 24) { $painelPontos.Visible = $false; return }
    if ($script:PontosTotal -ne $Total) {
        $painelPontos.Controls.Clear()
        for ($i = 1; $i -le $Total; $i++) {
            $p = New-Object System.Windows.Forms.Panel
            $p.Margin = New-Object System.Windows.Forms.Padding((PX 3), (PX 5), (PX 3), 0)
            $p.BackColor = Pal 'Fundo'
            $p.Add_Paint($DesenharPonto)
            $painelPontos.Controls.Add($p)
        }
        $script:PontosTotal = $Total
    }
    for ($i = 0; $i -lt $painelPontos.Controls.Count; $i++) {
        $p = $painelPontos.Controls[$i]
        $atual = ($i -eq ($N - 1))
        $feito = ($i -lt $N)
        $diam = if ($atual) { PX 10 } else { PX 7 }
        if ($p.Width -ne $diam) { $p.Size = New-Object System.Drawing.Size($diam, $diam) }
        $p.Tag = if ($feito) { Pal 'Acento' } else { Pal 'Trilha' }
        $p.Invalidate()
    }
    $painelPontos.Visible = $true
    try { Centralizar $linhaPontos $painelPontos 0 } catch { }
}

# Anel grande de progresso (substitui a barra linear) + pontos de etapa, centralizados na coluna.
$linhaAnelProg = New-Object System.Windows.Forms.Panel
$linhaAnelProg.Size = New-Object System.Drawing.Size((PX 620), (PX 200))
$linhaAnelProg.BackColor = Pal 'Fundo'
$linhaAnelProg.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
$anelProg = Nova-Anel 176 14 -ComTexto
$linhaAnelProg.Controls.Add($anelProg)
Centralizar $linhaAnelProg $anelProg 0
$colProg.Controls.Add($linhaAnelProg)

$painelPontos = New-Object System.Windows.Forms.FlowLayoutPanel
$painelPontos.FlowDirection = 'LeftToRight'
$painelPontos.WrapContents = $true
$painelPontos.AutoSize = $true
$painelPontos.AutoSizeMode = 'GrowAndShrink'
$painelPontos.BackColor = Pal 'Fundo'
$painelPontos.Visible = $false
$linhaPontos = New-Object System.Windows.Forms.Panel
$linhaPontos.Size = New-Object System.Drawing.Size((PX 620), (PX 20))
$linhaPontos.BackColor = Pal 'Fundo'
$linhaPontos.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 16))
$linhaPontos.Controls.Add($painelPontos)
$colProg.Controls.Add($linhaPontos)

$lblEtapa = New-Object System.Windows.Forms.Label
$lblEtapa.Font = Fonte 17 $true
$lblEtapa.ForeColor = Pal 'Texto'
$lblEtapa.AutoSize = $false
$lblEtapa.Size = New-Object System.Drawing.Size((PX 620), (PX 72))
$lblEtapa.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblEtapa.TextAlign = 'BottomLeft'
$lblEtapa.Text = (Tr 'Preparando...')
$colProg.Controls.Add($lblEtapa)

$barraFundo = New-Object System.Windows.Forms.Panel
$barraFundo.Size = New-Object System.Drawing.Size((PX 620), (PX 8))
$barraFundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 16))
$barraFundo.BackColor = Pal 'Borda'
$barraFundo.AccessibleName = 'Progresso'
$barraFundo.AccessibleRole = 'ProgressBar'
$barraPreench = New-Object System.Windows.Forms.Panel
$barraPreench.Location = New-Object System.Drawing.Point(0, 0)
$barraPreench.Size = New-Object System.Drawing.Size(0, (PX 8))
$barraPreench.BackColor = Pal 'Acento'
$barraFundo.Controls.Add($barraPreench)
$colProg.Controls.Add($barraFundo)
# A barra linear vira o anel grande (visual); ela continua existindo e sendo calculada normalmente,
# só não aparece mais - assim Set-Barra e toda a lógica de fração/estimativa de tempo que já dependia
# dela não precisou mudar.
$barraFundo.Visible = $false

$lblTempo = New-Object System.Windows.Forms.Label
$lblTempo.Font = Fonte 10.5
$lblTempo.ForeColor = Pal 'Texto2'
$lblTempo.AutoSize = $false
$lblTempo.Size = New-Object System.Drawing.Size((PX 620), (PX 26))
$lblTempo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$colProg.Controls.Add($lblTempo)

$lblDica = New-Object System.Windows.Forms.Label
$lblDica.Font = Fonte 10
$lblDica.ForeColor = Pal 'Texto2'
$lblDica.AutoSize = $true
$lblDica.MaximumSize = New-Object System.Drawing.Size((PX 620), 0)
$lblDica.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 22))
$colProg.Controls.Add($lblDica)

$filaBtnProg = New-Object System.Windows.Forms.FlowLayoutPanel
$filaBtnProg.FlowDirection = 'LeftToRight'
$filaBtnProg.WrapContents = $false
$filaBtnProg.AutoSize = $true
$filaBtnProg.AutoSizeMode = 'GrowAndShrink'
$filaBtnProg.BackColor = Pal 'Fundo'
$filaBtnProg.Margin = New-Object System.Windows.Forms.Padding(0)
$btnDet = Nova-BotaoGrande 'Mostrar detalhes técnicos' 'secundario' 230 40
$btnCancel = Nova-BotaoGrande 'Cancelar' 'secundario' 120 40
$filaBtnProg.Controls.Add($btnDet)
$filaBtnProg.Controls.Add($btnCancel)
$colProg.Controls.Add($filaBtnProg)

function Ajustar-ColunaProg {
    # A coluna central cresce com a janela (620 px no mínimo, 880 px no máximo).
    $w = [int][Math]::Max((PX 620), [Math]::Min((PX 880), $topoProg.ClientSize.Width * 0.5))
    foreach ($c in @($lblEtapa, $barraFundo, $lblTempo, $linhaAnelProg, $linhaPontos)) { if ($c.Width -ne $w) { $c.Width = $w } }
    $lblDica.MaximumSize = New-Object System.Drawing.Size($w, 0)
    try { Centralizar $linhaAnelProg $anelProg 0; Centralizar $linhaPontos $painelPontos 0 } catch { }
}

$topoProg.Add_SizeChanged({ Reposicionar })

$script:BarraModo = 'fixo'
$script:BarraFrac = 0.0
$script:BarraPos = 0
function Set-Barra {
    # Único ponto que todo o resto do arquivo já chamava para relatar o progresso (fração 0-1 ou
    # indeterminado); passou a também desenhar o anel grande, sem mudar a assinatura nem precisar tocar
    # em quem já chamava isso.
    param([double]$Fracao = 0, [switch]$Indeterminada)
    if ($Indeterminada) {
        $script:BarraModo = 'indet'
        try { Set-Anel $anelProg -Indeterminada } catch { }
        return
    }
    $script:BarraModo = 'fixo'
    $script:BarraFrac = [Math]::Max(0.0, [Math]::Min(1.0, $Fracao))
    $barraPreench.Left = 0
    $barraPreench.Width = [int]($barraFundo.Width * $script:BarraFrac)
    try { Set-Anel $anelProg -Percentual ($script:BarraFrac * 100.0) } catch { }
}
$barraFundo.Add_SizeChanged({ if ($script:BarraModo -eq 'fixo') { Set-Barra -Fracao $script:BarraFrac } })
$script:TimerBarra = New-Object System.Windows.Forms.Timer
$script:TimerBarra.Interval = 30
$script:TimerBarra.Add_Tick({
    if ($script:BarraModo -ne 'indet' -or -not $pgProg.Visible) { return }
    $w = [int]($barraFundo.Width * 0.28)
    $script:BarraPos += (PX 9)
    if ($script:BarraPos -gt $barraFundo.Width) { $script:BarraPos = -$w }
    $barraPreench.Width = $w
    $barraPreench.Left = $script:BarraPos
    try { Girar-Anel $anelProg 7 } catch { }
})
$script:TimerBarra.Start()

function Alternar-Detalhes {
    param([bool]$Mostrar)
    $script:Log.Visible = $Mostrar
    if ($Mostrar) {
        $topoProg.Dock = 'Top'
        $topoProg.Height = PX 340
        Ajustar-LarguraBotao $btnDet 'Ocultar detalhes técnicos' 230
    } else {
        $topoProg.Dock = 'Fill'
        Ajustar-LarguraBotao $btnDet 'Mostrar detalhes técnicos' 230
    }
    Reposicionar
}

# ----------------------------------------------------------------------------
# Página 3 - Resultados
# ----------------------------------------------------------------------------
# Área das abas (vai primeiro: Fill)
$areaAbas = New-Object System.Windows.Forms.Panel
$areaAbas.Dock = 'Fill'
$pgRes.Controls.Add($areaAbas)

function Nova-PainelAba {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.BackColor = Pal 'Fundo'
    $areaAbas.Controls.Add($p)
    return $p
}
$tpProb = Nova-PainelAba
$tpPC   = Nova-PainelAba
$tpDet  = Nova-PainelAba

# Cabeçalho das abas (estilo "sublinhado")
$cabAbas = New-Object System.Windows.Forms.Panel
$cabAbas.Dock = 'Top'
$cabAbas.Height = PX 48
$cabAbas.BackColor = (Pal 'Superficie')
$flowAbas = New-Object System.Windows.Forms.FlowLayoutPanel
$flowAbas.Dock = 'Fill'
$flowAbas.WrapContents = $false
$flowAbas.Padding = New-Object System.Windows.Forms.Padding((PX 18), 0, 0, 0)
$cabAbas.Controls.Add($flowAbas)
$linhaAbas = New-Object System.Windows.Forms.Panel
$linhaAbas.Dock = 'Bottom'
$linhaAbas.Height = 1
$linhaAbas.BackColor = Pal 'Borda'
$cabAbas.Controls.Add($linhaAbas)
$pgRes.Controls.Add($cabAbas)

$script:AbaAtual = 0
function Nova-Aba {
    param([string]$Texto, [int]$Indice)
    $b = New-Object System.Windows.Forms.Button
    $b.Name = "aba$Indice"
    $b.Text = $Texto
    $b.AccessibleName = "Aba $Texto"
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.FlatAppearance.MouseOverBackColor = Pal 'Sutil'
    $b.FlatAppearance.MouseDownBackColor = Pal 'SutilForte'
    $b.BackColor = (Pal 'Superficie')
    $b.UseVisualStyleBackColor = $false
    $b.AutoSize = $true
    $b.AutoSizeMode = 'GrowAndShrink'
    $b.MinimumSize = New-Object System.Drawing.Size(0, (PX 47))
    $b.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    $b.Margin = New-Object System.Windows.Forms.Padding(0)
    $b.Font = Fonte 10
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Add_Click({ param($remetente, $ev) Show-Aba ([int]("$($remetente.Name)" -replace '\D', '')) })
    $b.Add_Paint({
        param($remetente, $ev)
        if ("$($remetente.Name)" -eq "aba$($script:AbaAtual)") {
            $br = New-Object System.Drawing.SolidBrush((Cor $script:Pal['Acento']))
            $ev.Graphics.FillRectangle($br, 0, $remetente.Height - (PX 3), $remetente.Width, (PX 3))
            $br.Dispose()
        }
    })
    return $b
}
$abaProb = Nova-Aba 'Problemas encontrados' 0
$abaPC   = Nova-Aba 'Meu computador' 1
$abaDet  = Nova-Aba 'Detalhes técnicos' 2
foreach ($b in @($abaProb, $abaPC, $abaDet)) { $flowAbas.Controls.Add($b) }

function Show-Aba {
    param([int]$I)
    $script:AbaAtual = $I
    $paineis = @($tpProb, $tpPC, $tpDet)
    for ($k = 0; $k -lt $paineis.Count; $k++) { $paineis[$k].Visible = ($k -eq $I) }
    $paineis[$I].BringToFront()
    if ($I -eq 1 -and $null -ne $script:DadosPC) { Montar-PC -SePrecisar }
    $botoes = @($abaProb, $abaPC, $abaDet)
    for ($k = 0; $k -lt $botoes.Count; $k++) {
        if ($k -eq $I) { $botoes[$k].ForeColor = Pal 'AcentoTexto'; $botoes[$k].Font = Fonte 10 $true }
        else { $botoes[$k].ForeColor = Pal 'Texto2'; $botoes[$k].Font = Fonte 10 }
        $botoes[$k].Invalidate()
    }
}

# Faixa de status (cor suave + barra lateral)
$banner = New-Object System.Windows.Forms.Panel
$banner.Dock = 'Top'
$banner.Height = PX 108
$faixa = New-Object System.Windows.Forms.Panel
$faixa.Dock = 'Left'
$faixa.Width = PX 6
$lblBanT = New-Object System.Windows.Forms.Label
$lblBanT.Font = Fonte 16 $true
$lblBanT.AutoSize = $false
$lblBanT.Location = New-Object System.Drawing.Point((PX 28), (PX 14))
$lblBanT.Size = New-Object System.Drawing.Size((PX 900), (PX 36))
$lblBanT.Anchor = 'Top, Left, Right'
$lblBanS = New-Object System.Windows.Forms.Label
$lblBanS.Font = Fonte 10
$lblBanS.ForeColor = Pal 'Texto2'
$lblBanS.AutoSize = $false
$lblBanS.Location = New-Object System.Drawing.Point((PX 29), (PX 52))
$lblBanS.Size = New-Object System.Drawing.Size((PX 900), (PX 52))
$lblBanS.Anchor = 'Top, Left, Right'
$banner.Controls.Add($lblBanT)
$banner.Controls.Add($lblBanS)
$banner.Controls.Add($faixa)
$pgRes.Controls.Add($banner)

# Barra de ações
# Relatório completo / Salvar em PDF / Copiar resumo / Abrir pasta são as 4 formas de "me dê os dados de
# algum jeito": viviam soltas na barra (7 botões ao todo) e competiam com Corrigir/Verificar de novo, a
# ação que a pessoa realmente veio fazer. Agora ficam atrás de um botão "Exportar" só; os 4 continuam
# existindo como botões de verdade (só não ficam visíveis), com a mesma lógica de sempre em Add_Click.
$barraRes = Nova-BarraAcoes
$btnCorrigir  = Nova-BotaoGrande 'Corrigir automaticamente' 'primario' 250 44
$btnRelatorio = Nova-BotaoGrande 'Relatório completo' 'secundario' 170 44
$btnPasta     = Nova-BotaoGrande 'Abrir pasta' 'secundario' 120 44
$btnCopiar    = Nova-BotaoGrande 'Copiar resumo' 'secundario' 140 44
$btnNova      = Nova-BotaoGrande 'Verificar de novo' 'secundario' 160 44
$btnSair      = Nova-BotaoGrande 'Sair' 'fantasma' 90 44
$btnPdf       = Nova-BotaoGrande 'Salvar em PDF' 'secundario' 140 44
$btnReiniciar = Nova-BotaoGrande 'Reiniciar o PC agora' 'secundario' 190 44
$btnReiniciar.Visible = $false
$btnExportar = Nova-BotaoGrande (Tr 'Exportar ▾') 'secundario' 130 44
$mnuExportar = New-Object System.Windows.Forms.ContextMenuStrip
$mnuExportar.Font = Fonte 9.5
foreach ($par in @(
    @{ Texto = 'Relatório completo'; Botao = $btnRelatorio },
    @{ Texto = 'Salvar em PDF'; Botao = $btnPdf },
    @{ Texto = 'Copiar resumo'; Botao = $btnCopiar },
    @{ Texto = 'Abrir pasta'; Botao = $btnPasta }
)) {
    $item = New-Object System.Windows.Forms.ToolStripMenuItem((Tr $par.Texto))
    $botaoOrigem = $par.Botao
    $item.Add_Click({ try { $botaoOrigem.PerformClick() } catch { Registrar-Erro $_ -Silencioso } }.GetNewClosure())
    [void]$mnuExportar.Items.Add($item)
}
$btnExportar.Add_Click({ try { $mnuExportar.Show($btnExportar, (New-Object System.Drawing.Point(0, $btnExportar.Height))) } catch { Registrar-Erro $_ -Silencioso } })
foreach ($b in @($btnCorrigir, $btnReiniciar, $btnExportar, $btnNova, $btnSair)) { $barraRes.Controls['fluxo'].Controls.Add($b) }
$pgRes.Controls.Add($barraRes)

# Aba "Problemas encontrados"
$flowCards = New-Object System.Windows.Forms.FlowLayoutPanel
$flowCards.Dock = 'Fill'
$flowCards.FlowDirection = 'TopDown'
$flowCards.WrapContents = $false
$flowCards.AutoScroll = $true
$flowCards.BackColor = Pal 'Fundo'
$flowCards.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), (PX 24), (PX 16))
$tpProb.Controls.Add($flowCards)

$pnlFiltro = New-Object System.Windows.Forms.FlowLayoutPanel
$pnlFiltro.Dock = 'Top'
$pnlFiltro.Height = PX 52
$pnlFiltro.WrapContents = $false
$pnlFiltro.BackColor = Pal 'Fundo'
$pnlFiltro.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 14), 0, 0)
$lblFiltro = New-Object System.Windows.Forms.Label
$lblFiltro.Text = (Tr 'Mostrar')
$lblFiltro.AutoSize = $true
$lblFiltro.ForeColor = Pal 'Texto2'
$lblFiltro.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), (PX 8), 0)
$cmbCat = New-Object System.Windows.Forms.ComboBox
$cmbCat.DropDownStyle = 'DropDownList'
$cmbCat.FlatStyle = 'Flat'
$cmbCat.BackColor = Pal 'Superficie'; $cmbCat.ForeColor = Pal 'Texto'
$cmbCat.Width = PX 340
$cmbCat.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 24), 0)
$chkInfo = New-Object System.Windows.Forms.CheckBox
$chkInfo.Text = (Tr 'Incluir avisos apenas informativos')
$chkInfo.AutoSize = $true
$chkInfo.ForeColor = Pal 'Texto2'
$chkInfo.Margin = New-Object System.Windows.Forms.Padding(0, (PX 3), 0, 0)
$pnlFiltro.Controls.Add($lblFiltro)
$pnlFiltro.Controls.Add($cmbCat)
$pnlFiltro.Controls.Add($chkInfo)
$tpProb.Controls.Add($pnlFiltro)
$script:CatChaves = @('')
$script:AtualizandoFiltro = $false
$script:Expandidos = @{}

# Aba "Meu computador"
$pnlPC = New-Object System.Windows.Forms.Panel
$pnlPC.Dock = 'Fill'
$pnlPC.AutoScroll = $true
$pnlPC.BackColor = Pal 'Fundo'
$pnlPC.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 10), (PX 24), (PX 16))
$tpPC.Controls.Add($pnlPC)
$script:DadosPC = $null
$script:LarguraPC = 0

# Aba "Detalhes técnicos": o painel de log é encaixado aqui quando a verificação termina. Antes ficava
# colado nas quatro bordas (preenchimento zero); agora sobra uma margem clara ao redor, para o log
# escuro parecer um cartão dentro da aba em vez de preencher a aba inteira.
$tpDet.Padding = New-Object System.Windows.Forms.Padding((PX 20), (PX 16), (PX 20), (PX 16))
$tpDet.BackColor = Pal 'Fundo'

# ----------------------------------------------------------------------------
# Página 4 - Fim das correções
# ----------------------------------------------------------------------------
$txtFim = New-Object System.Windows.Forms.TextBox
$txtFim.Multiline = $true
$txtFim.ReadOnly = $true
$txtFim.BorderStyle = 'None'
$txtFim.ScrollBars = 'Vertical'
$txtFim.Dock = 'Fill'
$txtFim.Font = Fonte 10.5
$txtFim.BackColor = (Pal 'Superficie')
$txtFim.ForeColor = Pal 'Texto'
$pnlFimCorpo = New-Object System.Windows.Forms.Panel
$pnlFimCorpo.Dock = 'Fill'
$pnlFimCorpo.Padding = New-Object System.Windows.Forms.Padding((PX 28), (PX 8), (PX 28), (PX 16))
$pnlFimCorpo.BackColor = Pal 'Fundo'
$pnlTxtFim = New-Object System.Windows.Forms.Panel
$pnlTxtFim.Dock = 'Fill'
$pnlTxtFim.BackColor = (Pal 'Superficie')
$pnlTxtFim.Padding = New-Object System.Windows.Forms.Padding((PX 20), (PX 16), (PX 20), (PX 16))
$pnlTxtFim.Controls.Add($txtFim)
$pnlFimCorpo.Controls.Add($pnlTxtFim)

# Lista com marcas de verificação (substitui o texto corrido só para o resultado de correções -
# Mostrar-Fim; o resumo de desempenho - Mostrar-Bench - é texto livre e continua usando $txtFim).
$flowFim = New-Object System.Windows.Forms.FlowLayoutPanel
$flowFim.FlowDirection = 'TopDown'
$flowFim.WrapContents = $false
$flowFim.AutoScroll = $true
$flowFim.Dock = 'Fill'
$flowFim.BackColor = (Pal 'Superficie')
$flowFim.Visible = $false
$pnlTxtFim.Controls.Add($flowFim)

function Nova-LinhaChecada {
    # Uma linha de "o que foi feito": marca de verificação + texto, largura limitada para quebrar linha.
    param([string]$Texto, [string]$CorMarca = 'Ok')
    $linha = New-Object System.Windows.Forms.Panel
    $linha.AutoSize = $true
    $linha.AutoSizeMode = 'GrowAndShrink'
    $linha.BackColor = (Pal 'Superficie')
    $linha.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
    $marca = New-Object System.Windows.Forms.Label
    $marca.Text = [string]([char]0x2713)
    $marca.AutoSize = $true
    $marca.Font = Fonte 12 $true
    $marca.ForeColor = Pal $CorMarca
    $marca.Location = New-Object System.Drawing.Point(0, (PX 1))
    $linha.Controls.Add($marca)
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.AutoSize = $true
    $lbl.MaximumSize = New-Object System.Drawing.Size((PX 600), 0)
    $lbl.Font = Fonte 10.5
    $lbl.ForeColor = Pal 'Texto'
    $lbl.Location = New-Object System.Drawing.Point((PX 28), 0)
    $lbl.Text = $Texto
    $linha.Controls.Add($lbl)
    return $linha
}
function Nova-Aviso {
    # Aviso de destaque (fundo âmbar), igual ao já usado para outros avisos na tela inicial - reservado
    # para o estado "precisa reiniciar" e para o cancelamento, que pedem atenção de verdade.
    param([string]$Texto)
    $l = New-Object System.Windows.Forms.Label
    $l.AutoSize = $true
    $l.MaximumSize = New-Object System.Drawing.Size((PX 628), 0)
    $l.Font = Fonte 9.5
    $l.BackColor = Pal 'AvisoFundo'
    $l.ForeColor = Pal 'AvisoTextoForte'
    $l.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
    $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 14))
    $l.Text = $Texto
    return $l
}
function Nova-NotaTexto {
    # Texto informativo neutro (sem fundo colorido), para os avisos que não exigem atenção imediata.
    param([string]$Texto)
    $l = New-Object System.Windows.Forms.Label
    $l.AutoSize = $true
    $l.MaximumSize = New-Object System.Drawing.Size((PX 640), 0)
    $l.Font = Fonte 9.5
    $l.ForeColor = Pal 'Texto2'
    $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 10))
    $l.Text = $Texto
    return $l
}
$lblFimT = New-Object System.Windows.Forms.Label
$lblFimT.Font = Fonte 18 $true
$lblFimT.Dock = 'Top'
$lblFimT.Height = PX 78
$lblFimT.Padding = New-Object System.Windows.Forms.Padding((PX 28), (PX 22), 0, 0)
$barraFim = Nova-BarraAcoes
$btnReiniciar = Nova-BotaoGrande 'Reiniciar o computador agora' 'primario' 250 44
$btnDesfazer  = Nova-BotaoGrande 'Desfazer alterações' 'secundario' 190 44
$btnVerif2    = Nova-BotaoGrande 'Verificar de novo' 'secundario' 160 44
$btnSair2     = Nova-BotaoGrande 'Fechar' 'fantasma' 100 44
$btnBenchAbrir  = Nova-BotaoGrande 'Abrir o relatório' 'primario' 190 44
$btnBenchDeNovo = Nova-BotaoGrande 'Testar de novo' 'secundario' 160 44
$btnBenchVoltar = Nova-BotaoGrande 'Voltar ao início' 'secundario' 170 44
foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2, $btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar, $btnSair2)) { $barraFim.Controls['fluxo'].Controls.Add($b) }
foreach ($b in @($btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar)) { $b.Visible = $false }
$pgFim.Controls.Add($pnlFimCorpo)
$pgFim.Controls.Add($lblFimT)
$pgFim.Controls.Add($barraFim)

# ----------------------------------------------------------------------------
# Página - Ferramentas de reparo e restauração
# ----------------------------------------------------------------------------
$script:ListaFerramentas = @(
    @{ Id = 'pontos-listar'; Titulo = 'Ver os pontos de restauração'; Desc = 'Mostra os pontos de volta que o Windows tem guardados (inclusive os criados pelo Telomera).'; Admin = $false },
    @{ Id = 'pontos-criar'; Titulo = 'Criar um ponto de restauração agora'; Desc = 'Guarda o estado atual do Windows para poder voltar a ele se algo der errado.'; Admin = $true },
    @{ Id = 'pontos-abrir'; Titulo = 'Abrir a Restauração do Sistema do Windows'; Desc = 'Abre a tela do Windows para voltar o computador a um ponto de restauração anterior.'; Admin = $false },
    @{ Id = 'rede'; Titulo = 'Reparar a rede e a internet'; Desc = 'Limpa o DNS e reinicia o Winsock e o IP. Resolve sites que não abrem com a rede conectada.'; Admin = $true },
    @{ Id = 'wu'; Titulo = 'Reparar o Windows Update'; Desc = 'Corrige atualizações que travam, falham ou não aparecem (renomeia as pastas temporárias do Windows Update).'; Admin = $true },
    @{ Id = 'store'; Titulo = 'Reparar a Microsoft Store'; Desc = 'Registra a loja novamente. Útil quando ela não abre ou não baixa aplicativos.'; Admin = $true },
    @{ Id = 'chkdsk'; Titulo = 'Verificar o disco com o CHKDSK (na reinicialização)'; Desc = 'Agenda a verificação completa do disco do Windows. Pode demorar de minutos a horas.'; Admin = $true },
    @{ Id = 'temp'; Titulo = 'Limpar arquivos temporários'; Desc = 'Apaga arquivos temporários com mais de 2 dias para liberar espaço.'; Admin = $true },
    @{ Id = 'backup'; Titulo = 'Copiar meus arquivos pessoais (backup)'; Desc = 'Copia Documentos, Imagens e Área de Trabalho para uma pasta ou pen drive que você escolher. Nada é apagado.'; Admin = $false },
    @{ Id = 'historico'; Titulo = 'Ver o que o Telomera já mudou neste computador'; Desc = 'Lista todas as alterações feitas pelo Telomera, com a data e como desfazer cada uma.'; Admin = $false },
    @{ Id = 'saude-historico'; Titulo = 'Ver a nota de saúde ao longo do tempo'; Desc = 'Mostra a nota de saúde (0 a 100) de cada verificação, para você ver se o computador está melhorando ou piorando.'; Admin = $false },
    @{ Id = 'cfg-hags'; Titulo = 'Desligar o agendamento de GPU por hardware'; Desc = 'Opção do Windows que em alguns computadores causa travamento de imagem em jogos. Pede confirmação, guarda o valor atual e precisa reiniciar. Dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-pcie'; Titulo = 'Desligar a economia de energia do PCIe'; Desc = 'Impede que a placa de vídeo entre em repouso profundo quando o PC está na tomada. Pede confirmação e dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-fast'; Titulo = 'Desligar a inicialização rápida do Windows'; Desc = 'Faz o Windows carregar os drivers do zero a cada ligada. Pede confirmação, precisa reiniciar e dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-desfazer'; Titulo = 'Desfazer as mudanças de configuração'; Desc = 'Volta o agendamento de GPU, a economia do PCIe e a inicialização rápida ao valor que tinham antes do Telomera.'; Admin = $true },
    @{ Id = 'guia-fonte'; Titulo = 'Guia: testar com outra fonte de alimentação'; Desc = 'Passo a passo para trocar a fonte por uma emprestada e descobrir se ela é a causa de travamentos sob carga.'; Admin = $false },
    @{ Id = 'guia-energia'; Titulo = 'Guia: limitar a energia da placa de vídeo'; Desc = 'Passo a passo para reduzir o consumo da placa (Afterburner ou nvidia-smi) e testar se os picos de energia causam o travamento.'; Admin = $false },
    @{ Id = 'reiniciar-pc'; Titulo = 'Reiniciar o computador agora'; Desc = 'Muitos reparos e drivers só terminam depois de reiniciar. Avisa e espera 30 segundos; dá para cancelar com shutdown /a.'; Admin = $true },
    @{ Id = 'drv-lista'; Titulo = 'Ver todos os drivers e o que cada um faz'; Desc = 'Lista os drivers do computador por tipo (vídeo, rede, som, chipset, disco, USB), explica o que cada um faz e marca os com erro, antigos ou sem assinatura.'; Admin = $false },
    @{ Id = 'drv-sites'; Titulo = 'Baixar drivers novos: abrir as páginas oficiais'; Desc = 'Mostra o driver instalado de cada fabricante (NVIDIA, AMD, Intel, Realtek) e abre a página oficial de download para você escolher a versão.'; Admin = $false },
    @{ Id = 'drv-verificar'; Titulo = 'Conferir e instalar um driver baixado'; Desc = 'Você escolhe o instalador que baixou. O Telomera só deixa executar se a assinatura digital for válida e de um fabricante conhecido, e cria um ponto de restauração antes.'; Admin = $true },
    @{ Id = 'drv-reparar'; Titulo = 'Reparar dispositivos com erro'; Desc = 'Reativa o que está desativado e reinstala (remove e procura de novo) os dispositivos com erro no Gerenciador de Dispositivos. Não mexe em disco, processador e sistema.'; Admin = $true },
    @{ Id = 'drv-video-reiniciar'; Titulo = 'Reiniciar o driver de vídeo'; Desc = 'Desliga e liga de novo o driver da placa de vídeo, sem reiniciar o PC. Útil quando a imagem congela ou a tela fica estranha. A tela pisca por alguns segundos.'; Admin = $true },
    @{ Id = 'drv-wu'; Titulo = 'Instalar drivers pelo Windows Update'; Desc = 'Procura e instala os drivers que o Windows Update tem para o seu hardware (cria um ponto de restauração antes).'; Admin = $true },
    @{ Id = 'drv-limpar'; Titulo = 'Limpar versões antigas de driver'; Desc = 'Remove do sistema os pacotes de driver substituídos por versões mais novas e que não estão em uso. Guarda uma cópia de cada um e dá para voltar.'; Admin = $true },
    @{ Id = 'drv-video-limpo'; Titulo = 'Limpeza do driver de vídeo (para instalação limpa)'; Desc = 'Remove o driver de vídeo do fabricante para você instalar um do zero. Cria ponto de restauração e guarda cópia. Tenha o instalador novo já baixado.'; Admin = $true },
    @{ Id = 'guia-driver-video'; Titulo = 'Guia: instalar o driver de vídeo do zero'; Desc = 'Passo a passo completo: escolher a versão, limpar, reiniciar e instalar sem o Windows Update atrapalhar.'; Admin = $false },
    @{ Id = 'cfg-usb'; Titulo = 'Desligar a economia de energia do USB'; Desc = 'Evita que o Windows corte a energia de portas USB paradas (teclado, mouse e headset desconectando no jogo). Pede confirmação e dá para desfazer.'; Admin = $true },
    @{ Id = 'sensores-estado'; Titulo = 'Ver o estado dos sensores'; Desc = 'Mostra se o HWiNFO ou a LibreHardwareMonitor estão instalados, abertos e configurados para o Telomera ler.'; Admin = $false },
    @{ Id = 'hwinfo-config'; Titulo = 'Configurar e abrir o HWiNFO para o Telomera'; Desc = 'Liga a memória compartilhada, deixa só os sensores e a atualização em 500 ms (guarda uma cópia do arquivo antigo) e abre o HWiNFO.'; Admin = $true },
    @{ Id = 'lhm-baixar'; Titulo = 'Baixar a LibreHardwareMonitor (alternativa ao HWiNFO)'; Desc = 'Baixa a versão oficial do GitHub, confere o hash e guarda numa pasta do Telomera. Ela carrega um driver para ler o processador; antivírus e anticheat podem reclamar.'; Admin = $false },
    @{ Id = 'lhm-abrir'; Titulo = 'Abrir a LibreHardwareMonitor'; Desc = 'Abre como administrador para o Telomera ler a temperatura do processador por ela quando o HWiNFO não estiver aberto.'; Admin = $false },
    @{ Id = 'bios-site'; Titulo = 'BIOS e drivers: abrir a página da placa-mãe'; Desc = 'Mostra a BIOS instalada e abre a página de suporte do fabricante da sua placa-mãe para conferir se existe versão mais nova.'; Admin = $false },
    @{ Id = 'chipset-site'; Titulo = 'Driver de chipset: abrir a página oficial'; Desc = 'Abre a página oficial do driver de chipset do fabricante do seu processador (AMD ou Intel).'; Admin = $false },
    @{ Id = 'autoteste'; Titulo = 'Autoteste do Telomera (conferir se tudo funciona)'; Desc = 'Confere, neste Windows, se cada recurso do Telomera funciona (sensores, testes, vídeo, SMART). Gera um texto para enviar ao desenvolvedor se algo falhar.'; Admin = $false },
    @{ Id = 'agendar-ativar'; Titulo = 'Ativar a verificação semanal'; Desc = ''; Admin = $true },
    @{ Id = 'agendar-desativar'; Titulo = 'Desativar a verificação semanal'; Desc = ''; Admin = $true }
)
$script:LargFerr = PX 640

function Nova-ColunaPagina {
    # Coluna central (largura fixa) dentro de uma página com rolagem.
    param($Pagina)
    $col = New-Object System.Windows.Forms.FlowLayoutPanel
    $col.FlowDirection = 'TopDown'
    $col.WrapContents = $false
    $col.AutoSize = $true
    $col.AutoSizeMode = 'GrowAndShrink'
    $col.BackColor = Pal 'Fundo'
    $col.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 24), (PX 24), (PX 24))
    $Pagina.AutoScroll = $true
    $Pagina.Controls.Add($col)
    return $col
}
function Nova-SecaoPagina {
    param($Col, [string]$Titulo)
    $l = Nova-Etiqueta $Titulo 11.5 $true 'Texto' 30 640
    $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 18), 0, (PX 4))
    $Col.Controls.Add($l)
}
function Nova-LinhaBotao {
    # Botão largo com a explicação embaixo.
    param($Col, $Botao, [string]$Desc, [double]$AlturaDesc = 34)
    $Botao.Width = $script:LargFerr
    $Botao.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), 0, 0)
    $Col.Controls.Add($Botao)
    if ($Desc) {
        $ld = Nova-Etiqueta $Desc 9 $false 'Texto3' $AlturaDesc 640
        $ld.Margin = New-Object System.Windows.Forms.Padding((PX 6), 0, 0, (PX 4))
        $Col.Controls.Add($ld)
    }
}

# ----------------------------------------------------------------------------
# Página - Ferramentas de reparo e restauração (só o que corrige, restaura ou desfaz)
# ----------------------------------------------------------------------------
# Menu lateral com as áreas; à direita, só o conteúdo da área escolhida
$pgFerrCorpo = New-Object System.Windows.Forms.Panel
$pgFerrCorpo.Dock = 'Fill'
$pgFerrCorpo.BackColor = Pal 'Fundo'
$pgFerr.Controls.Add($pgFerrCorpo)
$pnlLateral = New-Object System.Windows.Forms.FlowLayoutPanel
$pnlLateral.Dock = 'Left'
$pnlLateral.Width = PX 230
$pnlLateral.FlowDirection = 'TopDown'
$pnlLateral.WrapContents = $false
$pnlLateral.AutoScroll = $true
$pnlLateral.BackColor = Pal 'Superficie'
$pnlLateral.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 18), (PX 12), (PX 12))
$pgFerr.Controls.Add($pnlLateral)
$pgFerrCorpo.BringToFront()
$script:ColAreas = @{}
$script:BotoesAreas = @{}
$script:BotoesFerr = @()
$script:BotoesVoltar = @()
$script:AreaAtual = 'travou'
$btnDesbloq = Nova-BotaoGrande 'Desfazer bloqueios de driver do Telomera' 'secundario' 640 40
$btnDesfazer2 = Nova-BotaoGrande 'Desfazer correções (restaurar drivers salvos)' 'secundario' 640 40
$btnMonIni = Nova-BotaoGrande 'Ligar o monitor (registrar temperaturas durante o jogo)' 'secundario' 640 40
$btnMonParar = Nova-BotaoGrande 'Desligar o monitor' 'secundario' 640 40
$btnMonVer = Nova-BotaoGrande 'Ver o último registro (por que o PC desligou?)' 'secundario' 640 40
$btnMonInv = Nova-BotaoGrande 'Investigar o último travamento (relatório completo)' 'secundario' 640 40
$btnMemWin = Nova-BotaoGrande 'Testar a memória RAM pelo Windows (no próximo reinício)' 'secundario' 640 40
$btnExtOcct = Nova-BotaoGrande 'OCCT (estresse de processador, placa de vídeo, memória e fonte)' 'secundario' 640 40
$btnExtFur = Nova-BotaoGrande 'FurMark (estresse da placa de vídeo)' 'secundario' 640 40
$btnExtMem = Nova-BotaoGrande 'MemTest86 (teste completo da memória RAM, fora do Windows)' 'secundario' 640 40
$descPseudo = @{
    'ext-occt' = 'Abre o site oficial. O OCCT faz estresse combinado e gráficos de tensão e temperatura; o Telomera não baixa nem instala nada sozinho.'
    'ext-fur' = 'Abre o site oficial do FurMark, o teste de estresse mais usado para placas de vídeo.'
    'ext-mem' = 'Abre o site oficial do MemTest86. Ele roda a partir de um pendrive, antes do Windows, e é o teste de memória mais confiável.'
    'desbloq' = 'Remove a proteção que impede o Windows Update de trocar o driver de vídeo (e os outros bloqueios criados pelo Telomera).'
    'drivers' = 'Volta aos drivers que o Telomera guardou antes de corrigir.'
    'mon-ini' = 'Grava temperaturas, tensões e consumo a cada meio segundo enquanto você joga (lê o HWiNFO, o MSI Afterburner ou o LibreHardwareMonitor abertos). Se o computador desligar, o último registro mostra o que estava acontecendo.'
    'mon-parar' = 'Encerra o registro e fecha a sessão. Os arquivos ficam guardados para consulta.'
    'mon-ver' = 'Mostra as últimas temperaturas e tensões gravadas antes de o monitor parar e a provável causa.'
    'mon-inv' = 'Junta o último registro do monitor, os erros que o Windows anotou nessa hora, as configurações que costumam causar travamento e os próximos passos. Use depois de reiniciar o PC que travou.'
    'mem-win' = 'Abre o Diagnóstico de Memória do Windows, que testa a memória RAM antes de o Windows iniciar. O computador reinicia (salve seus trabalhos); o resultado aparece na próxima verificação do Telomera.'
}
$btnBenchFerr = Nova-BotaoGrande 'Testar desempenho (processador, memória, disco, vídeo e estresse)' 'secundario' 640 40
$descPseudo['testar-desempenho'] = 'Abre a janela de escolha: teste normal, longo, estresse de jogo, transição, memória RAM e disco. Mostra o que cada um faz antes de começar.'
$script:AreasFerr = @(
    @{ Id = 'travou'; Nome = 'O PC trava ou desliga'; Sub = 'Descubra a causa e teste as hipóteses mais comuns: fonte, placa de vídeo, memória e configurações do Windows.'
       Grupos = @(
        @{ T = 'Descobrir o que aconteceu'; Ids = @('mon-inv') },
        @{ T = 'Corrigir configurações que causam travamento (todas com desfazer)'; Ids = @('cfg-hags', 'cfg-pcie', 'cfg-fast') },
        @{ T = 'Testar hipóteses de hardware'; Ids = @('guia-fonte', 'guia-energia', 'mem-win') },
        @{ T = 'BIOS e drivers'; Ids = @('bios-site', 'chipset-site') }) },
    @{ Id = 'drivers'; Nome = 'Drivers'; Sub = 'Entenda o que cada driver faz e corrija de verdade: reinstale, atualize, limpe versões velhas ou refaça o driver de vídeo.'
       Grupos = @(
        @{ T = 'Entender'; Ids = @('drv-lista') },
        @{ T = 'Baixar drivers novos com segurança'; Ids = @('drv-wu', 'drv-sites', 'drv-verificar') },
        @{ T = 'Corrigir'; Ids = @('drv-reparar', 'drv-video-reiniciar', 'drv-limpar') },
        @{ T = 'Driver de vídeo: instalação limpa'; Ids = @('guia-driver-video', 'drv-video-limpo') },
        @{ T = 'Energia que derruba dispositivos'; Ids = @('cfg-usb') }) },
    @{ Id = 'monitor'; Nome = 'Monitor e sensores'; Sub = 'Registra temperaturas, tensões e consumo enquanto você joga. Se o PC desligar, o último registro mostra o que estava acontecendo.'
       Grupos = @(
        @{ T = 'Programas de sensores'; Ids = @('sensores-estado', 'hwinfo-config', 'lhm-baixar', 'lhm-abrir') },
        @{ T = 'Registro durante o jogo'; Ids = @('mon-ini', 'mon-parar', 'mon-ver') }) },
    @{ Id = 'testes'; Nome = 'Testes e estresse'; Sub = 'Leve o computador ao limite de forma controlada para reproduzir o problema.'
       Grupos = @(
        @{ T = 'Dentro do Telomera'; Ids = @('testar-desempenho') },
        @{ T = 'Programas externos (sites oficiais; o Telomera não baixa nada)'; Ids = @('ext-occt', 'ext-fur', 'ext-mem') }) },
    @{ Id = 'reparos'; Nome = 'Reparos do Windows'; Sub = 'Cada ferramenta pede a sua confirmação antes de mexer em alguma coisa. As que corrigem o Windows exigem o Telomera como administrador.'
       Grupos = @(
        @{ T = 'Reparos'; Ids = @('rede', 'wu', 'store', 'chkdsk', 'reiniciar-pc') },
        @{ T = 'Limpeza e cópia de segurança'; Ids = @('temp', 'backup') }) },
    @{ Id = 'restaurar'; Nome = 'Restaurar e desfazer'; Sub = 'Volte atrás: pontos de restauração e tudo o que o Telomera já alterou.'
       Grupos = @(
        @{ T = 'Pontos de restauração'; Ids = @('pontos-listar', 'pontos-criar', 'pontos-abrir') },
        @{ T = 'Desfazer o que o Telomera fez'; Ids = @('historico', 'desbloq', 'drivers', 'cfg-desfazer') }) },
    @{ Id = 'ajuda'; Nome = 'Ajuda e autoteste'; Sub = 'Confira se o Telomera funciona neste Windows e gere um texto para enviar ao desenvolvedor.'
       Grupos = @(
        @{ T = 'Conferir o próprio Telomera'; Ids = @('autoteste') }) }
)
# Um glifo por área na barra lateral (desenhado por Nova-BotaoGrande, fora do texto - ver -Icone).
$script:IconesArea = @{
    'travou'    = [string]([char]0x26A0)  # ⚠ aviso
    'drivers'   = [string]([char]0x2699)  # ⚙ engrenagem
    'monitor'   = [string]([char]0x2103)  # ℃ temperatura
    'testes'    = [string]([char]0x25B6)  # ▶ executar
    'reparos'   = [string]([char]0x2692)  # ⚒ ferramentas
    'restaurar' = [string]([char]0x21BA)  # ↺ desfazer
    'ajuda'     = [string]([char]0x24D8)  # ⓘ informação
}
function Show-Area {
    param([string]$Id)
    if (-not $script:ColAreas.ContainsKey($Id)) { $Id = 'travou' }
    foreach ($k in $script:ColAreas.Keys) { $script:ColAreas[$k].Visible = ($k -eq $Id) }
    foreach ($k in $script:BotoesAreas.Keys) { $bt = $script:BotoesAreas[$k]; $bt.Name = $(if ($k -eq $Id) { 'primario' } else { 'secundario' }); Aplicar-EstiloBotao $bt }
    $script:AreaAtual = $Id
    try { $pgFerrCorpo.AutoScrollPosition = New-Object System.Drawing.Point(0, 0) } catch { }
    try { Ajustar-PaginaFerr } catch { }
}
foreach ($ar in $script:AreasFerr) {
    $colFerr = Nova-ColunaPagina $pgFerrCorpo
    $colFerr.Visible = $false
    $script:ColAreas[$ar.Id] = $colFerr
    $colFerr.Controls.Add((Nova-Etiqueta $ar.Nome 20 $true 'Texto' 44 640))
    $colFerr.Controls.Add((Nova-Etiqueta $ar.Sub 10 $false 'Texto2' 44 640))
    $icArea = $(if ($script:IconesArea.ContainsKey($ar.Id)) { $script:IconesArea[$ar.Id] } else { '' })
    $bar = Nova-BotaoGrande $ar.Nome 'secundario' 200 44 -Icone $icArea
    $bar.Width = PX 204
    $bar.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
    $bar.AccessibleName = 'area:' + $ar.Id
    $pnlLateral.Controls.Add($bar)
    $script:BotoesAreas[$ar.Id] = $bar
    foreach ($gr in $ar.Grupos) {
        Nova-SecaoPagina $colFerr $gr.T
        if ($gr.Ids -contains 'mon-ini') {
            $script:lblMonEstado = Nova-Etiqueta 'Monitor desligado.' 10 $true 'Texto' 24 640
            $colFerr.Controls.Add($script:lblMonEstado)
        }
        if ($gr.Ids -contains 'sensores-estado') {
            $script:lblSensEstado = Nova-Etiqueta '' 9.5 $false 'Texto' 46 640
            $script:lblSensEstado.BackColor = Pal 'InfoFundo'
            $script:lblSensEstado.Padding = New-Object System.Windows.Forms.Padding((PX 10), (PX 6), (PX 10), (PX 6))
            $colFerr.Controls.Add($script:lblSensEstado)
        }
        foreach ($id in $gr.Ids) {
            if ($id -eq 'desbloq') { Nova-LinhaBotao $colFerr $btnDesbloq $descPseudo['desbloq']; continue }
            if ($id -eq 'drivers') { Nova-LinhaBotao $colFerr $btnDesfazer2 $descPseudo['drivers']; continue }
            if ($id -eq 'mon-ini') { Nova-LinhaBotao $colFerr $btnMonIni $descPseudo['mon-ini'] 52; continue }
            if ($id -eq 'testar-desempenho') { Nova-LinhaBotao $colFerr $btnBenchFerr $descPseudo['testar-desempenho']; continue }
            if ($id -eq 'ext-occt') { Nova-LinhaBotao $colFerr $btnExtOcct $descPseudo['ext-occt']; continue }
            if ($id -eq 'ext-fur') { Nova-LinhaBotao $colFerr $btnExtFur $descPseudo['ext-fur']; continue }
            if ($id -eq 'ext-mem') { Nova-LinhaBotao $colFerr $btnExtMem $descPseudo['ext-mem']; continue }
            if ($id -eq 'mon-parar') { Nova-LinhaBotao $colFerr $btnMonParar $descPseudo['mon-parar']; continue }
            if ($id -eq 'mon-ver') { Nova-LinhaBotao $colFerr $btnMonVer $descPseudo['mon-ver']; continue }
            if ($id -eq 'mon-inv') { Nova-LinhaBotao $colFerr $btnMonInv $descPseudo['mon-inv']; continue }
            if ($id -eq 'mem-win') { Nova-LinhaBotao $colFerr $btnMemWin $descPseudo['mem-win']; continue }
            $f = $script:ListaFerramentas | Where-Object { $_.Id -eq $id } | Select-Object -First 1
            $b = Nova-BotaoGrande $f.Titulo 'secundario' 640 40
            $b.AccessibleName = $f.Id
            Nova-LinhaBotao $colFerr $b $f.Desc
            $f.Botao = $b
            $script:BotoesFerr += $b
        }
    }
    $bv = Nova-BotaoGrande 'Voltar ao início' 'secundario' 200 44
    $bv.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, (PX 20))
    $bv.AccessibleName = 'voltar-inicio'
    $colFerr.Controls.Add($bv)
    $script:BotoesVoltar += $bv
}
foreach ($bt in @($script:BotoesAreas.Values)) { $bt.Add_Click({ try { Show-Area (([string]$this.AccessibleName) -replace '^area:', '') } catch { Registrar-Erro $_ } }) }
function Abrir-Area {
    param([string]$Id)
    Ajustar-PaginaFerr
    Show-Pagina $pgFerr
    Show-Area $Id
}
Show-Area 'travou\'

# ----------------------------------------------------------------------------
# Página - Configurações (opções, verificação automática, histórico e manutenção do Telomera)
# ----------------------------------------------------------------------------
$script:DiasPt = @('Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado')
$script:DiasEn = @('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
$script:CarregandoCfg = $true
$colCfg = Nova-ColunaPagina $pgCfg
$colCfg.Controls.Add((Nova-Etiqueta 'Configurações' 20 $true 'Texto' 44 640))
$colCfg.Controls.Add((Nova-Etiqueta 'Opções da verificação, verificação automática, histórico e manutenção do Telomera.' 10 $false 'Texto2' 30 640))

function Nova-Toggle {
    # Opção liga/desliga desenhada como trilha + bolinha (em vez da caixinha quadrada padrão do Windows),
    # no estilo das Configurações do Windows 11. A lógica (Checked, CheckedChanged, leitura/gravação em
    # Salvar-Config e Carregar-Config) continua 100% no CheckBox de sempre: ele só fica invisível; quem
    # aparece é o painel ao lado, que só espelha o estado dele. $LargLogica é em unidades lógicas (antes
    # da escala de DPI), igual ao parâmetro Largura de Nova-Etiqueta — não usar $script:LargFerr aqui
    # (ele já vem escalado) para não aplicar a escala em dobro.
    param($Col, [string]$Texto, [bool]$Marcado, [double]$Altura = 44)
    $LargLogica = 640; $TrilhaLLogica = 40; $TrilhaALogica = 22; $FolgaLogica = 14

    $chk = New-Object System.Windows.Forms.CheckBox
    $chk.Checked = $Marcado
    $chk.Visible = $false

    $alturaPx = PX $Altura
    $linha = New-Object System.Windows.Forms.Panel
    $linha.Size = New-Object System.Drawing.Size($script:LargFerr, $alturaPx)
    $linha.BackColor = Pal 'Fundo'
    $linha.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 6))
    $linha.Controls.Add($chk)

    $lbl = Nova-Etiqueta $Texto 9.5 $false 'Texto2' $Altura ($LargLogica - $TrilhaLLogica - $FolgaLogica)
    $lbl.Location = New-Object System.Drawing.Point(0, 0)
    $lbl.Margin = New-Object System.Windows.Forms.Padding(0)
    $lbl.Cursor = [System.Windows.Forms.Cursors]::Hand
    $linha.Controls.Add($lbl)

    $trilhaLPx = PX $TrilhaLLogica; $trilhaAPx = PX $TrilhaALogica
    $trilha = New-Object System.Windows.Forms.Panel
    $trilha.Size = New-Object System.Drawing.Size($trilhaLPx, $trilhaAPx)
    $trilha.Location = New-Object System.Drawing.Point(($script:LargFerr - $trilhaLPx), [int](($alturaPx - $trilhaAPx) / 2))
    $trilha.BackColor = Pal 'Fundo'
    $trilha.Cursor = [System.Windows.Forms.Cursors]::Hand
    $linha.Controls.Add($trilha)

    $Desenhar = {
        param($s, $e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $r = $s.ClientRectangle
        $d = $r.Height
        $cam = New-Object System.Drawing.Drawing2D.GraphicsPath
        $cam.AddArc($r.X, $r.Y, $d, $d, 90, 180)
        $cam.AddArc($r.Right - $d, $r.Y, $d, $d, 270, 180)
        $cam.CloseFigure()
        $corFundo = if ($chk.Checked) { Pal 'Acento' } else { Pal 'Trilha' }
        $pin = New-Object System.Drawing.SolidBrush($corFundo)
        $g.FillPath($pin, $cam)
        $pin.Dispose(); $cam.Dispose()
        $diam = $r.Height - (PX 4)
        $x = if ($chk.Checked) { $r.Width - $diam - (PX 2) } else { PX 2 }
        $bola = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
        $g.FillEllipse($bola, $x, (PX 2), $diam, $diam)
        $bola.Dispose()
    }.GetNewClosure()
    $trilha.Add_Paint($Desenhar)

    $Alternar = { $chk.Checked = -not $chk.Checked }.GetNewClosure()
    $trilha.Add_Click($Alternar)
    $lbl.Add_Click($Alternar)
    $chk.Add_CheckedChanged({ try { $trilha.Invalidate() } catch { } }.GetNewClosure())

    $Col.Controls.Add($linha)
    return $chk
}
Nova-SecaoPagina $colCfg 'Ao verificar'
$chkWU   = Nova-Toggle $colCfg 'Usar a internet na verificação: Windows Update (drivers pendentes) e teste de rede (pode demorar alguns minutos)' $true 48
$chkVol  = Nova-Toggle $colCfg 'Procurar erros nas unidades de disco (mais completo, porém mais lento)' $true 32

Nova-SecaoPagina $colCfg 'Verificação semanal automática'
$lblAgStatus = Nova-Etiqueta '' 10 $false 'Texto2' 44 640
$colCfg.Controls.Add($lblAgStatus)
$linhaAg = New-Object System.Windows.Forms.FlowLayoutPanel
$linhaAg.FlowDirection = 'LeftToRight'
$linhaAg.WrapContents = $false
$linhaAg.AutoSize = $false
$linhaAg.Size = New-Object System.Drawing.Size($script:LargFerr, (PX 36))
$linhaAg.BackColor = Pal 'Fundo'
$linhaAg.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblDia = New-Object System.Windows.Forms.Label
$lblDia.Text = (Tr 'Dia:'); $lblDia.AutoSize = $true; $lblDia.ForeColor = Pal 'Texto2'
$lblDia.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), (PX 6), 0)
$cmbDia = New-Object System.Windows.Forms.ComboBox
$cmbDia.DropDownStyle = 'DropDownList'; $cmbDia.FlatStyle = 'Flat'; $cmbDia.Width = PX 160
$cmbDia.BackColor = Pal 'Superficie'; $cmbDia.ForeColor = Pal 'Texto'
foreach ($d0 in $script:DiasPt) { [void]$cmbDia.Items.Add($d0) }
$cmbDia.SelectedIndex = 0
$cmbDia.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), (PX 24), 0)
$lblHora = New-Object System.Windows.Forms.Label
$lblHora.Text = (Tr 'Horário:'); $lblHora.AutoSize = $true; $lblHora.ForeColor = Pal 'Texto2'
$lblHora.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), (PX 6), 0)
$cmbHora = New-Object System.Windows.Forms.ComboBox
$cmbHora.DropDownStyle = 'DropDownList'; $cmbHora.FlatStyle = 'Flat'; $cmbHora.Width = PX 90
$cmbHora.BackColor = Pal 'Superficie'; $cmbHora.ForeColor = Pal 'Texto'
foreach ($h0 in 0..23) { [void]$cmbHora.Items.Add(('{0:00}:00' -f $h0)) }
$cmbHora.SelectedItem = '10:00'
$cmbHora.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, 0)
foreach ($c0 in @($lblDia, $cmbDia, $lblHora, $cmbHora)) { $linhaAg.Controls.Add($c0) }
$colCfg.Controls.Add($linhaAg)
$linhaBtnAg = New-Object System.Windows.Forms.FlowLayoutPanel
$linhaBtnAg.FlowDirection = 'LeftToRight'
$linhaBtnAg.WrapContents = $false
$linhaBtnAg.AutoSize = $false
$linhaBtnAg.Size = New-Object System.Drawing.Size($script:LargFerr, (PX 50))
$linhaBtnAg.BackColor = Pal 'Fundo'
$wMetade = [int](($script:LargFerr - (PX 14)) / 2)
$btnAgAtivar = Nova-BotaoGrande 'Ativar a verificação semanal' 'secundario' 300 40
$btnAgAtivar.AccessibleName = 'agendar-ativar'
$btnAgAtivar.Width = $wMetade
$btnAgAtivar.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 14), 0)
$btnAgDesativar = Nova-BotaoGrande 'Desativar' 'secundario' 300 40
$btnAgDesativar.AccessibleName = 'agendar-desativar'
$btnAgDesativar.Width = $script:LargFerr - $wMetade - (PX 14)
$btnAgDesativar.Margin = New-Object System.Windows.Forms.Padding(0)
$linhaBtnAg.Controls.Add($btnAgAtivar); $linhaBtnAg.Controls.Add($btnAgDesativar)
$colCfg.Controls.Add($linhaBtnAg)
$colCfg.Controls.Add((Nova-Etiqueta 'Uma vez por semana o Telomera faz uma verificação rápida só de leitura (não corrige nada e não usa a internet) e avisa se a nota de saúde cair 5 pontos ou mais, ou se aparecer um problema crítico novo. Ativar e desativar exigem abrir o Telomera como administrador.' 9 $false 'Texto3' 54 640))

Nova-SecaoPagina $colCfg 'Histórico'
$btnCfgNota = Nova-BotaoGrande 'Ver a nota de saúde ao longo do tempo' 'secundario' 640 40
$btnCfgNota.AccessibleName = 'saude-historico'
Nova-LinhaBotao $colCfg $btnCfgNota 'Mostra a nota de saúde (0 a 100) de cada verificação, para você ver se o computador está melhorando ou piorando.'
$btnPastaBase = Nova-BotaoGrande 'Abrir a pasta das verificações anteriores' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnPastaBase 'Abre a pasta "Telomera" da Área de Trabalho, onde ficam os relatórios de cada verificação.' 24

Nova-SecaoPagina $colCfg 'Sobre o Telomera'
$colCfg.Controls.Add((Nova-Etiqueta ("Versão " + $script:Versao) 10 $false 'Texto2' 24 640))
$btnAtualizar = Nova-BotaoGrande 'Procurar atualização do Telomera' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnAtualizar 'Consulta o canal oficial de versões; se houver versão nova, baixa e instala depois da sua confirmação. Nada sobre o seu computador é enviado.'
$btnAtalho = Nova-BotaoGrande 'Recriar o atalho do Telomera (Área de Trabalho e Menu Iniciar)' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnAtalho '' 
$script:BotoesCfg = @($btnAgAtivar, $btnAgDesativar, $btnCfgNota)
$btnCfgVoltar = Nova-BotaoGrande 'Voltar ao início' 'primario' 200 44
$btnCfgVoltar.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, (PX 20))
$colCfg.Controls.Add($btnCfgVoltar)

function Get-ArquivoConfigGui { return (Join-Path (Get-DirDadosGui) 'config.json') }
function Salvar-Config {
    if ($script:CarregandoCfg) { return }
    try {
        $f = Get-ArquivoConfigGui
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $o = @{ UsarInternet = [bool]$chkWU.Checked; ProcurarDiscos = [bool]$chkVol.Checked; AgendaDia = [int]$cmbDia.SelectedIndex; AgendaHora = [string]$cmbHora.SelectedItem }
        [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}
function Carregar-Config {
    $script:CarregandoCfg = $true
    try {
        $f = Get-ArquivoConfigGui
        if (Test-Path -LiteralPath $f) {
            $o = Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
            if ($null -ne $o.UsarInternet) { $chkWU.Checked = [bool]$o.UsarInternet }
            if ($null -ne $o.ProcurarDiscos) { $chkVol.Checked = [bool]$o.ProcurarDiscos }
            if ($null -ne $o.AgendaDia -and [int]$o.AgendaDia -ge 0 -and [int]$o.AgendaDia -le 6) { $cmbDia.SelectedIndex = [int]$o.AgendaDia }
            if ($o.AgendaHora -and $cmbHora.Items.Contains([string]$o.AgendaHora)) { $cmbHora.SelectedItem = [string]$o.AgendaHora }
        }
    } catch { }
    $script:CarregandoCfg = $false
}
$chkWU.Add_CheckedChanged({ Salvar-Config })
$chkVol.Add_CheckedChanged({ Salvar-Config })
$cmbDia.Add_SelectedIndexChanged({ Salvar-Config })
$cmbHora.Add_SelectedIndexChanged({ Salvar-Config })

function Atualizar-Cfg {
    # Mostra se a verificação semanal está ativa (e quando) e ajusta os botões.
    $ativa = $false
    $texto = 'A verificação semanal automática está desativada.'
    try {
        $t = Get-ScheduledTask -TaskName 'Telomera - verificação semanal' -ErrorAction Stop
        $ativa = $true
        $texto = 'A verificação semanal automática está ativada.'
        try {
            $tr = @($t.Triggers)[0]
            if ($tr -and $tr.StartBoundary) {
                $hora = ([datetime]$tr.StartBoundary).ToString('HH:mm')
                if ($cmbHora.Items.Contains($hora)) { $script:CarregandoCfg = $true; $cmbHora.SelectedItem = $hora; $script:CarregandoCfg = $false }
            }
            if ($tr -and $null -ne $tr.DaysOfWeek -and [int]$tr.DaysOfWeek -gt 0) {
                $idx = [int][Math]::Log([double][int]$tr.DaysOfWeek, 2)
                if ($idx -ge 0 -and $idx -le 6) { $script:CarregandoCfg = $true; $cmbDia.SelectedIndex = $idx; $script:CarregandoCfg = $false }
            }
        } catch { $script:CarregandoCfg = $false }
        try {
            $i = Get-ScheduledTaskInfo -TaskName 'Telomera - verificação semanal' -ErrorAction Stop
            if ($i.NextRunTime -and $i.NextRunTime.Year -gt 2000) { $texto += ' Próxima execução: ' + $i.NextRunTime.ToString('dd/MM/yyyy HH:mm') + '.' }
        } catch { }
    } catch { }
    $lblAgStatus.Text = $texto
    if ($ativa) { $btnAgAtivar.Text = (Tr 'Salvar o novo dia e horário') } else { $btnAgAtivar.Text = (Tr 'Ativar a verificação semanal') }
    $btnAgDesativar.Enabled = $ativa
    try { $btnAgAtivar.Invalidate(); $btnAgDesativar.Invalidate() } catch { }
}
Carregar-Config
try { Atualizar-Cfg } catch { }

function Ajustar-PaginaFerr {
    $pares = New-Object System.Collections.ArrayList
    [void]$pares.Add(@($pgCfg, $colCfg))
    foreach ($k in @($script:ColAreas.Keys)) { [void]$pares.Add(@($pgFerrCorpo, $script:ColAreas[$k])) }
    foreach ($par in $pares) {
        $esq = [int][Math]::Max((PX 24), ($par[0].ClientSize.Width - $script:LargFerr) / 2)
        $par[1].Padding = New-Object System.Windows.Forms.Padding($esq, (PX 24), (PX 24), (PX 24))
    }
}
$pgFerrCorpo.Add_SizeChanged({ try { Ajustar-PaginaFerr } catch { } })
$pgCfg.Add_SizeChanged({ try { Ajustar-PaginaFerr } catch { } })

# ----------------------------------------------------------------------------
# Resultados: cartões, filtro, faixa de status e resumo do computador
# ----------------------------------------------------------------------------
function Nova-Card {
    param($Achado, [int]$Largura)
    $cores = @{ Critico = $script:Pal['Perigo']; Atencao = $script:Pal['Aviso']; Info = $script:Pal['Info'] }
    $rotulo = @{ Critico = 'GRAVE'; Atencao = 'ATENÇÃO'; Info = 'INFORMAÇÃO' }
    $interna = $Largura - (PX 44)
    $sev = "$($Achado.Gravidade)"
    if (-not $cores.ContainsKey($sev)) { $sev = 'Info' }

    $card = New-Object System.Windows.Forms.FlowLayoutPanel
    $card.FlowDirection = 'TopDown'
    $card.WrapContents = $false
    $card.AutoSize = $true
    $card.AutoSizeMode = 'GrowAndShrink'
    $card.BackColor = (Pal 'Superficie')
    $card.Tag = $cores[$sev]
    $card.AccessibleName = ('{0}: {1}' -f $rotulo[$sev], $Achado.Titulo)
    $card.AccessibleRole = 'Grouping'
    $card.Padding = New-Object System.Windows.Forms.Padding((PX 22), (PX 14), (PX 16), (PX 14))
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $card.MinimumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    # Borda fina + barra lateral na cor da gravidade
    $card.Add_Paint({
        param($remetente, $ev)
        $pen = New-Object System.Drawing.Pen((Cor $script:Pal['Borda']))
        $ev.Graphics.DrawRectangle($pen, 0, 0, $remetente.Width - 1, $remetente.Height - 1)
        $pen.Dispose()
        $br = New-Object System.Drawing.SolidBrush((Cor "$($remetente.Tag)"))
        $ev.Graphics.FillRectangle($br, 0, 0, (PX 5), $remetente.Height)
        $br.Dispose()
    })

    $linha = New-Object System.Windows.Forms.FlowLayoutPanel
    $linha.FlowDirection = 'LeftToRight'
    $linha.WrapContents = $false
    $linha.AutoSize = $true
    $linha.AutoSizeMode = 'GrowAndShrink'
    $linha.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
    $ls = New-Object System.Windows.Forms.Label
    $ls.AutoSize = $true
    $ls.Text = $rotulo[$sev]
    $ls.Font = Fonte 8.5 $true
    $ls.ForeColor = Cor $cores[$sev]
    $ls.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 8), 0)
    $lc = New-Object System.Windows.Forms.Label
    $lc.AutoSize = $true
    $lc.Text = (Get-NomeCategoria "$($Achado.Categoria)")
    $lc.Font = Fonte 8.5
    $lc.ForeColor = Pal 'Texto3'
    $lc.Margin = New-Object System.Windows.Forms.Padding(0)
    $linha.Controls.Add($ls)
    $linha.Controls.Add($lc)
    if ($Achado.Veredito) {
        $coresV = @{ Normal = $script:Pal['Ok']; Depende = $script:Pal['Aviso']; Corrigir = $script:Pal['Perigo']; Opcional = $script:Pal['Info'] }
        $corV = $coresV["$($Achado.Veredito)"]
        if ($corV) {
            $lv = New-Object System.Windows.Forms.Label
            $lv.AutoSize = $true
            $lv.Text = '·  ' + (Get-RotuloVeredito "$($Achado.Veredito)")
            $lv.Font = Fonte 8.5 $true
            $lv.ForeColor = Cor $corV
            $lv.Margin = New-Object System.Windows.Forms.Padding((PX 8), 0, 0, 0)
            $linha.Controls.Add($lv)
        }
    }
    # Selo de reparo: o Telomera consegue corrigir este item ou não?
    $lr = New-Object System.Windows.Forms.Label
    $lr.AutoSize = $true
    $lr.Font = Fonte 8.5 $true
    $lr.Margin = New-Object System.Windows.Forms.Padding((PX 8), 0, 0, 0)
    if ("$($Achado.Reparo)" -eq 'Auto') {
        $lr.Text = '·  Corrigível pelo Telomera'
        $lr.ForeColor = Pal 'AcentoTexto'
    } elseif ("$($Achado.Titulo)" -like 'Há uma reinicialização pendente*') {
        $lr.Text = '·  Resolve com o botão Reiniciar'
        $lr.ForeColor = Pal 'AcentoTexto'
    } else {
        $lr.Text = '·  Não corrigível pelo Telomera'
        $lr.ForeColor = Pal 'Texto3'
    }
    $linha.Controls.Add($lr)
    $card.Controls.Add($linha)

    $t = New-Object System.Windows.Forms.Label
    $t.AutoSize = $true
    $t.MaximumSize = New-Object System.Drawing.Size($interna, 0)
    $t.Font = Fonte 11.5 $true
    $t.ForeColor = Pal 'Texto'
    $t.Text = "$($Achado.Titulo)"
    $t.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
    $card.Controls.Add($t)

    if ($Achado.Detalhe) {
        $d = New-Object System.Windows.Forms.Label
        $d.AutoSize = $true
        $d.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $d.Font = Fonte 9.5
        $d.ForeColor = Pal 'Texto2'
        $d.Text = "$($Achado.Detalhe)"
        $d.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
        $card.Controls.Add($d)
    }
    if ($Achado.Solucao) {
        $sh = New-Object System.Windows.Forms.Label
        $sh.AutoSize = $true
        $sh.Text = (Tr 'O QUE FAZER')
        $sh.Font = Fonte 8 $true
        $sh.ForeColor = Pal 'Texto3'
        $sh.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 1))
        $card.Controls.Add($sh)
        $s = New-Object System.Windows.Forms.Label
        $s.AutoSize = $true
        $s.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $s.Font = Fonte 10
        $s.ForeColor = Pal 'Texto'
        $s.Text = "$($Achado.Solucao)"
        $s.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
        $card.Controls.Add($s)
    }
    if ($Achado.Explicacao) {
        $pex = New-Object System.Windows.Forms.FlowLayoutPanel
        $pex.Name = "$($Achado.Titulo)"
        $pex.FlowDirection = 'TopDown'
        $pex.WrapContents = $false
        $pex.AutoSize = $true
        $pex.AutoSizeMode = 'GrowAndShrink'
        $pex.BackColor = Pal 'Fundo'
        $pex.Padding = New-Object System.Windows.Forms.Padding((PX 12))
        $pex.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 8))
        $lex = New-Object System.Windows.Forms.Label
        $lex.AutoSize = $true
        $lex.MaximumSize = New-Object System.Drawing.Size(($interna - (PX 28)), 0)
        $lex.Font = Fonte 9.5
        $lex.ForeColor = Pal 'Texto'
        $lex.Text = "$($Achado.Explicacao)"
        $pex.Controls.Add($lex)
        $aberto = [bool]$script:Expandidos["$($Achado.Titulo)"]
        $pex.Visible = $aberto
        $mais = New-Object System.Windows.Forms.LinkLabel
        $mais.AutoSize = $true
        $mais.Font = Fonte 9.5 $true
        $mais.LinkColor = Pal 'AcentoTexto'
        $mais.ActiveLinkColor = Pal 'AcentoDown'
        $mais.LinkBehavior = 'HoverUnderline'
        if ($aberto) { $mais.Text = (Tr 'Ver menos') } else { $mais.Text = (Tr 'Ver mais: o que é isso e preciso me preocupar?') }
        $mais.Tag = $pex
        $mais.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 4))
        $mais.Add_LinkClicked({
            param($remetente, $ev)
            $pn = $remetente.Tag
            $pn.Visible = (-not $pn.Visible)
            $script:Expandidos[$pn.Name] = $pn.Visible
            if ($pn.Visible) { $remetente.Text = (Tr 'Ver menos') } else { $remetente.Text = (Tr 'Ver mais: o que é isso e preciso me preocupar?') }
        })
        $card.Controls.Add($mais)
        $card.Controls.Add($pex)
    }
    foreach ($l in @($Achado.Links)) {
        if (-not $l -or -not $l.Url) { continue }
        $ll = New-Object System.Windows.Forms.LinkLabel
        $ll.AutoSize = $true
        $ll.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $ll.Font = Fonte 9.5
        $ll.LinkColor = Pal 'AcentoTexto'
        $ll.ActiveLinkColor = Pal 'AcentoDown'
        $ll.LinkBehavior = 'HoverUnderline'
        $ll.Text = "$($l.Texto)"
        $ll.Tag = "$($l.Url)"
        $ll.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 2))
        $ll.Add_LinkClicked({ param($remetente, $ev) Abrir-Url ([string]$remetente.Tag) })
        $card.Controls.Add($ll)
    }
    return $card
}

function Get-TextoGrupoReparo {
    # Mesmos textos do motor (a interface não carrega o motor): separa o que o Telomera corrige do que depende do usuário.
    param([string]$Grupo)
    if ($Grupo -eq 'Auto') {
        return @{
            Titulo = 'O Telomera consegue corrigir'
            Texto  = 'Para estes itens existe uma correção automática. Clique em "Corrigir automaticamente" (como administrador): o Telomera cria um ponto de restauração antes de mexer.'
        }
    }
    return @{
        Titulo = 'Precisa de você: o Telomera não conserta sozinho'
        Texto  = 'Aqui estão eventos que já aconteceram (o Windows guarda o histórico por 30 dias, então eles continuam aparecendo depois de corrigir), programas de terceiros como jogos e anti-cheat, peças de hardware e avisos informativos. Siga o "O que fazer" de cada item.'
    }
}

function Get-RotuloVeredito {
    # (A janela e o motor rodam em processos separados; por isso esta função existe nos dois lados.)
    param([string]$Veredito)
    switch ($Veredito) {
        'Normal'   { return 'Provavelmente normal' }
        'Depende'  { return 'Depende' }
        'Corrigir' { return 'Vale corrigir' }
        'Opcional' { return 'Opcional' }
        default    { return '' }
    }
}

function Get-NomeCategoria {
    param([string]$Chave)
    switch ($Chave) {
        'Driver'         { return 'Drivers' }
        'Eventos'        { return 'Eventos do Windows (erros e travamentos)' }
        'Disco'          { return 'Discos' }
        'Volume'         { return 'Unidades (volumes)' }
        'Hardware'       { return 'Hardware' }
        'Sistema'        { return 'Sistema' }
        'Windows Update' { return 'Windows Update' }
        'Telomera'        { return 'Avisos do próprio Telomera' }
        default          { return $Chave }
    }
}

function Get-AchadosVisiveis {
    # Achados que passam pelo filtro atual (categoria + avisos informativos).
    param([switch]$IgnorarCategoria)
    if (-not $script:Res) { return @() }
    $catSel = ''
    if (-not $IgnorarCategoria -and $cmbCat.SelectedIndex -ge 0 -and $cmbCat.SelectedIndex -lt $script:CatChaves.Count) { $catSel = $script:CatChaves[$cmbCat.SelectedIndex] }
    $ordem = @{ Critico = 0; Atencao = 1; Info = 2 }
    return @($script:Res.Achados | Where-Object { $_ -and ($chkInfo.Checked -or $_.Gravidade -ne 'Info') -and (-not $catSel -or "$($_.Categoria)" -eq $catSel) } | Sort-Object { if ($_.Reparo -eq 'Auto') { 0 } else { 1 } }, { $ordem["$($_.Gravidade)"] })
}

function Atualizar-Filtro {
    # Recria a lista de categorias (só as que têm itens a mostrar) mantendo a escolha atual.
    if (-not $script:Res) { return }
    $script:AtualizandoFiltro = $true
    try {
        $atual = ''
        if ($cmbCat.SelectedIndex -ge 0 -and $cmbCat.SelectedIndex -lt $script:CatChaves.Count) { $atual = $script:CatChaves[$cmbCat.SelectedIndex] }
        $visiveis = @(Get-AchadosVisiveis -IgnorarCategoria)
        $grupos = @($visiveis | Group-Object Categoria | Sort-Object Name)
        $cmbCat.Items.Clear()
        $script:CatChaves = @('')
        [void]$cmbCat.Items.Add("Todas as categorias ($($visiveis.Count))")
        foreach ($g in $grupos) {
            $script:CatChaves += "$($g.Name)"
            [void]$cmbCat.Items.Add("$(Get-NomeCategoria "$($g.Name)") ($($g.Count))")
        }
        $idx = [Array]::IndexOf($script:CatChaves, $atual)
        if ($idx -lt 0) { $idx = 0 }
        $cmbCat.SelectedIndex = $idx
    } finally {
        $script:AtualizandoFiltro = $false
    }
}

function Montar-Cards {
    if (-not $script:Res) { return }
    $flowCards.SuspendLayout()
    try {
        $flowCards.Controls.Clear()
        $largura = $flowCards.ClientSize.Width - $flowCards.Padding.Horizontal - [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
        $largura = [Math]::Max((PX 360), [Math]::Min((PX 1100), $largura))
        $script:LarguraCards = $flowCards.ClientSize.Width
        $lista = @(Get-AchadosVisiveis)
        if ($lista.Count -eq 0) {
            $l = Nova-Etiqueta 'Nada por aqui.' 12 $false 'Texto3' 36 400
            $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, 0)
            $flowCards.Controls.Add($l)
        }
        $grupoAtual = ''
        foreach ($a in $lista) {
            $gr = if ($a.Reparo -eq 'Auto') { 'Auto' } else { 'Manual' }
            if ($gr -ne $grupoAtual) {
                $grupoAtual = $gr
                $tg = Get-TextoGrupoReparo $gr
                $corG = if ($gr -eq 'Auto') { 'Ok' } else { 'Texto2' }
                $lt = Nova-Etiqueta $tg.Titulo 12.5 $true $corG 28 $largura
                $lt.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), 0, (PX 2))
                $flowCards.Controls.Add($lt)
                $ld = New-Object System.Windows.Forms.Label
                $ld.AutoSize = $true
                $ld.MaximumSize = New-Object System.Drawing.Size($largura, 0)
                $ld.Text = $tg.Texto
                $ld.Font = Fonte 9.5
                $ld.ForeColor = Pal 'Texto2'
                $ld.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
                $flowCards.Controls.Add($ld)
            }
            $flowCards.Controls.Add((Nova-Card $a $largura))
        }
    } finally {
        $flowCards.ResumeLayout()
    }
}

function Get-CorNivel {
    param([string]$Nivel)
    switch ($Nivel) {
        'ok'     { return (Pal 'Ok') }
        'aviso'  { return (Pal 'Aviso') }
        'perigo' { return (Pal 'Perigo') }
        default  { return (Pal 'Texto3') }
    }
}

function Nova-LinhaPC {
    param([string]$Texto, [double]$Tam, [bool]$Negrito, [string]$CorNome, [int]$Largura, [int]$MargemBaixo = 0)
    $l = New-Object System.Windows.Forms.Label
    $l.AutoSize = $true
    $l.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    $l.Text = $Texto
    $l.Font = Fonte $Tam $Negrito
    $l.ForeColor = Pal $CorNome
    $l.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, $MargemBaixo)
    return $l
}

function Nova-CardPC {
    param($Sec, [int]$Largura)
    $interna = $Largura - (PX 38)
    $card = New-Object System.Windows.Forms.FlowLayoutPanel
    $card.FlowDirection = 'TopDown'
    $card.WrapContents = $false
    $card.AutoSize = $true
    $card.AutoSizeMode = 'GrowAndShrink'
    $card.BackColor = (Pal 'Superficie')
    $card.Padding = New-Object System.Windows.Forms.Padding((PX 18), (PX 14), (PX 18), (PX 14))
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 14))
    $card.MinimumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.AccessibleName = ('{0}: {1}' -f $Sec.Titulo, $Sec.Destaque).Trim(' ', ':')
    $card.AccessibleRole = 'Grouping'
    $card.Add_Paint({
        param($remetente, $ev)
        $pen = New-Object System.Drawing.Pen((Cor $script:Pal['Borda']))
        $ev.Graphics.DrawRectangle($pen, 0, 0, $remetente.Width - 1, $remetente.Height - 1)
        $pen.Dispose()
        $br = New-Object System.Drawing.SolidBrush((Cor $script:Pal['Acento']))
        $ev.Graphics.FillRectangle($br, 0, 0, $remetente.Width, (PX 3))
        $br.Dispose()
    })

    $card.Controls.Add((Nova-LinhaPC (("$($Sec.Titulo)").ToUpper()) 8.5 $true 'Acento' $interna (PX 6)))
    if ($Sec.Destaque) {
        $mb = 0; if (-not $Sec.Sub) { $mb = PX 6 }
        $card.Controls.Add((Nova-LinhaPC "$($Sec.Destaque)" 13 $true 'Texto' $interna $mb))
    }
    if ($Sec.Sub) { $card.Controls.Add((Nova-LinhaPC "$($Sec.Sub)" 9.5 $false 'Texto2' $interna (PX 8))) }

    $empilhado = (@('disk', 'net') -contains "$($Sec.Chave)")
    $colR = PX 104
    foreach ($it in (Get-VetorLista $Sec.Itens)) {
        $linha = New-Object System.Windows.Forms.FlowLayoutPanel
        $linha.AutoSize = $true
        $linha.AutoSizeMode = 'GrowAndShrink'
        $linha.WrapContents = $false
        $linha.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 5))
        $nivel = "$($it.Nivel)"
        if ($empilhado) {
            $linha.FlowDirection = 'TopDown'
            $linha.Controls.Add((Nova-LinhaPC "$($it.R)" 10 $true 'Texto' $interna 0))
            $sub = New-Object System.Windows.Forms.FlowLayoutPanel
            $sub.AutoSize = $true; $sub.AutoSizeMode = 'GrowAndShrink'; $sub.WrapContents = $false
            $sub.Margin = New-Object System.Windows.Forms.Padding(0)
            if ($nivel) {
                $d = Nova-LinhaPC ([string][char]0x25CF) 9 $false 'Texto3' (PX 20) 0
                $d.ForeColor = Get-CorNivel $nivel
                $d.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 4), 0)
                $sub.Controls.Add($d)
            }
            $sub.Controls.Add((Nova-LinhaPC "$($it.V)" 9.5 $false 'Texto2' ($interna - (PX 24)) 0))
            $linha.Controls.Add($sub)
        } else {
            $linha.FlowDirection = 'LeftToRight'
            $r = New-Object System.Windows.Forms.Label
            $r.AutoSize = $false
            $r.Width = $colR
            $r.Height = PX 20
            $r.Text = "$($it.R)"
            $r.Font = Fonte 9.5
            $r.ForeColor = Pal 'Texto3'
            $r.Margin = New-Object System.Windows.Forms.Padding(0)
            $linha.Controls.Add($r)
            $linha.Controls.Add((Nova-LinhaPC "$($it.V)" 9.5 $false 'Texto' ($interna - $colR - (PX 6)) 0))
        }
        $card.Controls.Add($linha)
    }

    foreach ($br in (Get-VetorLista $Sec.Barras)) {
        $cab = New-Object System.Windows.Forms.FlowLayoutPanel
        $cab.AutoSize = $true; $cab.AutoSizeMode = 'GrowAndShrink'; $cab.WrapContents = $false
        $cab.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 4))
        $rot = Nova-LinhaPC "$($br.Rotulo)" 10 $true 'Texto' (PX 90) 0
        $rot.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 8), 0)
        $cab.Controls.Add($rot)
        $cab.Controls.Add((Nova-LinhaPC "$($br.Texto)" 9.5 $false 'Texto2' ($interna - (PX 100)) 0))
        $card.Controls.Add($cab)
        $fundo = New-Object System.Windows.Forms.Panel
        $fundo.Width = $interna
        $fundo.Height = PX 6
        $fundo.BackColor = Pal 'Borda'
        $fundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
        $fr = [Math]::Max(0.0, [Math]::Min(1.0, [double]$br.Fracao))
        $cheio = New-Object System.Windows.Forms.Panel
        $cheio.Height = $fundo.Height
        $cheio.Width = [int][Math]::Round($interna * $fr)
        $cheio.Left = 0; $cheio.Top = 0
        $cheio.BackColor = Get-CorNivel "$($br.Nivel)"
        $fundo.Controls.Add($cheio)
        $card.Controls.Add($fundo)
    }
    return $card
}

function Montar-PC {
    param([switch]$SePrecisar)
    if ($null -eq $script:DadosPC) { return }
    $avail = $pnlPC.ClientSize.Width - $pnlPC.Padding.Horizontal - [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
    if ($avail -lt (PX 200)) { return }
    if ($SePrecisar -and [Math]::Abs($avail - $script:LarguraPC) -le (PX 20) -and $pnlPC.Controls.Count -gt 0) { return }
    $script:LarguraPC = $avail
    $pnlPC.SuspendLayout()
    try {
        foreach ($c in @($pnlPC.Controls)) { $c.Dispose() }
        $pnlPC.Controls.Clear()
        $secoes = @($script:DadosPC | Where-Object { $_ -is [hashtable] })
        if ($secoes.Count -eq 0) {
            $pnlPC.Controls.Add((Nova-LinhaPC 'Sem informações do computador.' 11 $false 'Texto3' (PX 500) 0))
            return
        }
        $gap = PX 16
        $ncols = 1
        if ($avail -ge (PX 780)) { $ncols = 2 }
        $larg = [int][Math]::Floor(($avail - ($gap * ($ncols - 1))) / $ncols)
        $larg = [Math]::Min($larg, (PX 600))
        $linhaCols = New-Object System.Windows.Forms.FlowLayoutPanel
        $linhaCols.FlowDirection = 'LeftToRight'
        $linhaCols.WrapContents = $false
        $linhaCols.AutoSize = $true
        $linhaCols.AutoSizeMode = 'GrowAndShrink'
        $linhaCols.Location = New-Object System.Drawing.Point($pnlPC.Padding.Left, $pnlPC.Padding.Top)
        $cols = @(); $pesos = @()
        for ($i = 0; $i -lt $ncols; $i++) {
            $c = New-Object System.Windows.Forms.FlowLayoutPanel
            $c.FlowDirection = 'TopDown'
            $c.WrapContents = $false
            $c.AutoSize = $true
            $c.AutoSizeMode = 'GrowAndShrink'
            $c.Margin = New-Object System.Windows.Forms.Padding(0, 0, $gap, 0)
            $linhaCols.Controls.Add($c)
            $cols += $c; $pesos += 0.0
        }
        foreach ($sec in $secoes) {
            $nIt = [double]([int]$sec.Itens.Count)
            $nBr = [double]([int]$sec.Barras.Count)
            $w = 3.0 + $nIt + (1.6 * $nBr)
            if ($sec.Destaque) { $w += 2.0 }
            $k = 0
            for ($i = 1; $i -lt $ncols; $i++) { if ($pesos[$i] -lt $pesos[$k]) { $k = $i } }
            try { $cartao = Nova-CardPC $sec $larg }
            catch {
                try { Registrar-Erro $_ -Silencioso } catch { }
                $cartao = Nova-LinhaPC ("$($sec.Titulo): não foi possível mostrar este bloco. Detalhes em erros.log.") 9.5 $false 'Texto3' $larg 6
            }
            $cols[$k].Controls.Add($cartao)
            $pesos[$k] += $w
        }
        $pnlPC.Controls.Add($linhaCols)
    } finally {
        $pnlPC.ResumeLayout()
    }
}

function Add-LinhaLado {
    param([string]$Texto, [double]$Tam, [bool]$Neg, [string]$Cor, [int]$Acima = 0, [int]$Abaixo = 0)
    $larg = [int]($pnlLado.Width - (PX 22) - (PX 14) - (PX 20))
    $l = Nova-LinhaPC $Texto $Tam $Neg $Cor $larg $Abaixo
    $l.Margin = New-Object System.Windows.Forms.Padding(0, $Acima, 0, $Abaixo)
    $fluxoLado.Controls.Add($l)
}

function Montar-PcInicio {
    # $Estado: 'dados' (usa $script:DadosPcIni), 'lendo' ou 'erro' (com $Mensagem)
    param([string]$Estado = 'dados', [string]$Mensagem = '')
    $fluxoLado.SuspendLayout()
    try {
        foreach ($c in @($fluxoLado.Controls)) { $c.Dispose() }
        $fluxoLado.Controls.Clear()
        Add-LinhaLado (Tr 'SEU COMPUTADOR') 8.5 $true 'Acento' 0 10
        if ($Estado -eq 'lendo') { Add-LinhaLado (Tr 'Lendo os componentes...') 10 $false 'Texto3' 0 0; return }
        if ($Estado -eq 'erro') {
            Add-LinhaLado (Tr 'Não foi possível ler os componentes agora.') 10 $false 'Texto2' 0 6
            if ($Mensagem) { Add-LinhaLado $Mensagem 8.5 $false 'Texto3' 0 0 }
            return
        }
        $sec = @($script:DadosPcIni | Where-Object { $_ -is [hashtable] }) | Select-Object -First 1
        if (-not $sec) { Add-LinhaLado (Tr 'Sem informações do computador.') 10 $false 'Texto3' 0 0; return }
        if ($sec.Destaque) { Add-LinhaLado "$($sec.Destaque)" 13 $true 'Texto' 0 2 }
        if ($sec.Sub) { Add-LinhaLado "$($sec.Sub)" 9.5 $false 'Texto2' 0 14 }
        foreach ($it in (Get-VetorLista $sec.Itens)) {
            Add-LinhaLado (Tr "$($it.R)") 8.5 $false 'Texto3' 6 0
            Add-LinhaLado "$($it.V)" 10 $false 'Texto' 0 4
        }
        if ((Get-VetorLista $sec.Barras).Count -gt 0) { Add-LinhaLado (Tr 'ARMAZENAMENTO') 8.5 $true 'Acento' 14 6 }
        $interna = [int]($pnlLado.Width - (PX 22) - (PX 14) - (PX 20))
        foreach ($br in (Get-VetorLista $sec.Barras)) {
            Add-LinhaLado ("$($br.Rotulo)  $($br.Texto)") 9.5 $false 'Texto' 0 3
            $fundo = New-Object System.Windows.Forms.Panel
            $fundo.Width = $interna; $fundo.Height = PX 6; $fundo.BackColor = Pal 'Borda'
            $fundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
            $fr = [Math]::Max(0.0, [Math]::Min(1.0, [double]$br.Fracao))
            $cheio = New-Object System.Windows.Forms.Panel
            $cheio.Height = $fundo.Height; $cheio.Width = [int][Math]::Round($interna * $fr); $cheio.Left = 0; $cheio.Top = 0
            $cheio.BackColor = Get-CorNivel "$($br.Nivel)"
            $fundo.Controls.Add($cheio)
            $fluxoLado.Controls.Add($fundo)
        }
    } finally { $fluxoLado.ResumeLayout() }
}

function Start-LeituraPcInicio {
    # Lê os componentes logo depois de a janela aparecer (1 a 2 segundos). Se falhar, a barra lateral mostra o motivo e o erro vai ao erros.log.
    if ($script:PcIniFeito) { return }
    $script:PcIniFeito = $true
    try { Montar-PcInicio 'lendo' } catch { }
    $script:TimerPcIni = New-Object System.Windows.Forms.Timer
    $script:TimerPcIni.Interval = 150
    $script:TimerPcIni.Add_Tick({
        $script:TimerPcIni.Stop()
        try {
            $res = @(Get-ResumoPcRapido)
            if ($res.Count -gt 0) { $script:DadosPcIni = $res; Montar-PcInicio 'dados' }
            else { Montar-PcInicio 'erro' 'A leitura não devolveu dados.' }
        } catch {
            try { Registrar-Erro $_ -Silencioso } catch { }
            try { Montar-PcInicio 'erro' ("$($_.Exception.Message) [linha $($_.InvocationInfo.ScriptLineNumber): $(("$($_.InvocationInfo.Line)").Trim())]") } catch { }
        }
    })
    $script:TimerPcIni.Start()
}

function Update-IconeAtalhos {
    # Atalhos criados por versões antigas apontam para o escudo; troca para o ícone do Telomera (sem apagar nem recriar o atalho).
    try {
        $origem = Join-Path $PSScriptRoot 'telomera.ico'
        if (-not (Test-Path -LiteralPath $origem)) { return }
        $dadosDir = Join-Path $env:LOCALAPPDATA 'Telomera'
        New-Item -ItemType Directory -Force -Path $dadosDir | Out-Null
        $ico = Join-Path $dadosDir 'telomera-app.ico'
        Copy-Item -LiteralPath $origem -Destination $ico -Force
        $ws = New-Object -ComObject WScript.Shell
        $mudou = $false
        foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
            foreach ($nomeLnk in @('Telomera.lnk', 'WinDiag.lnk')) {   # Telomera.lnk é o novo nome; WinDiag.lnk é mantido por quem instalou antes da marca
                $lnk = Join-Path $pasta $nomeLnk
                if (-not (Test-Path -LiteralPath $lnk)) { continue }
                $l = $ws.CreateShortcut($lnk)
                if ("$($l.IconLocation)" -ne "$ico,0") {
                    $b = [IO.File]::ReadAllBytes($lnk)   # preserva a opção "Executar como administrador" do atalho
                    $l.IconLocation = "$ico,0"; $l.Save()
                    try { if ($b[0x15] -band 0x20) { $n = [IO.File]::ReadAllBytes($lnk); $n[0x15] = $n[0x15] -bor 0x20; [IO.File]::WriteAllBytes($lnk, $n) } } catch { }
                    $mudou = $true
                }
            }
        }
        try { $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Telomera'; if (Test-Path -LiteralPath $k) { Set-ItemProperty -LiteralPath $k -Name DisplayIcon -Value $ico } } catch { }
        if ($mudou) { try { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden } catch { } }
    } catch { }
}

function Get-TextoResumo {
    $L = New-Object System.Collections.Generic.List[string]
    $rot = @{ Critico = 'GRAVE'; Atencao = 'ATENÇÃO'; Info = 'INFO' }
    $L.Add("Telomera v$($script:Versao) - resumo da verificação")
    $L.Add('')
    $grupoAtual = ''
    foreach ($a in @(Get-AchadosVisiveis)) {
        $gr = if ($a.Reparo -eq 'Auto') { 'Auto' } else { 'Manual' }
        if ($gr -ne $grupoAtual) {
            $grupoAtual = $gr
            $tg = Get-TextoGrupoReparo $gr
            $L.Add(('=== ' + $tg.Titulo + ' ==='))
            $L.Add($tg.Texto)
            $L.Add('')
        }
        $L.Add(("[{0}] {1}" -f $rot["$($a.Gravidade)"], $a.Titulo))
        if ($a.Detalhe) { $L.Add("    $($a.Detalhe)") }
        if ($a.Solucao) { $L.Add("    O que fazer: $($a.Solucao)") }
        if ($a.Veredito) { $L.Add("    Avaliação: $(Get-RotuloVeredito "$($a.Veredito)")") }
        if ($a.Reparo -eq 'Auto') { $L.Add('    Reparo: corrigível pelo Telomera') } else { $L.Add('    Reparo: não corrigível pelo Telomera') }
        $L.Add('')
    }
    if ($script:Res -and $script:Res.ResumoPC) { $L.Add('--- Meu computador ---'); $L.Add("$($script:Res.ResumoPC)") }
    return ($L -join "`r`n")
}

function Mostrar-Resultados {
    param($R)
    $script:Res = $R
    $script:Expandidos = @{}
    try { Ajustar-Margens } catch { }
    $achados = @($R.Achados)
    $nc = @($achados | Where-Object { $_.Gravidade -eq 'Critico' }).Count
    $na = @($achados | Where-Object { $_.Gravidade -eq 'Atencao' }).Count
    $ni = @($achados | Where-Object { $_.Gravidade -eq 'Info' }).Count

    if ($nc -gt 0) {
        $banner.BackColor = Pal 'PerigoFundo'; $faixa.BackColor = Pal 'Perigo'; $lblBanT.ForeColor = Pal 'PerigoTextoForte'
        $lblBanT.Text = "Encontramos $nc problema(s) grave(s)"
        $sub = 'Veja abaixo o que significam e o que fazer.'
    } elseif ($na -gt 0) {
        $banner.BackColor = Pal 'AvisoFundo'; $faixa.BackColor = Pal 'Aviso'; $lblBanT.ForeColor = Pal 'AvisoTextoForte'
        $lblBanT.Text = "Encontramos $na ponto(s) que merecem atenção"
        $sub = 'Nada crítico, mas vale a pena dar uma olhada.'
    } else {
        $banner.BackColor = Pal 'OkFundo'; $faixa.BackColor = Pal 'Ok'; $lblBanT.ForeColor = Pal 'OkTextoForte'
        $lblBanT.Text = (Tr 'Tudo certo! Nenhum problema relevante')
        $sub = 'Seu computador passou na verificação.'
    }
    $nAuto = @($achados | Where-Object { $_.Reparo -eq 'Auto' -and $_.Gravidade -ne 'Info' }).Count
    $nReb  = @($achados | Where-Object { $_.Reparo -ne 'Auto' -and $_.Gravidade -ne 'Info' -and "$($_.Titulo)" -like 'Há uma reinicialização pendente*' }).Count
    $nMan  = @($achados | Where-Object { $_.Reparo -ne 'Auto' -and $_.Gravidade -ne 'Info' }).Count - $nReb
    if (($nAuto + $nMan + $nReb) -gt 0) {
        $sub += " O Telomera consegue corrigir $nAuto"
        if ($nReb -gt 0) { $sub += " (e $nReb com o botão Reiniciar)" }
        $sub += "; $nMan precisa(m) de você."
    }
    if ($R.NAcoes -gt 0 -and -not $script:IsAdmin) {
        $sub += ' Para corrigir, feche e reabra o Telomera como administrador.'
    } elseif ($R.NAcoes -gt 0 -and $nAuto -gt 0) {
        $sub += " Há $($R.NAcoes) correção(ões) disponível(is)."
    } elseif ($R.NAcoes -gt 0) {
        $sub += " Há $($R.NAcoes) proteção(ões) opcional(is) disponível(is) (ex.: impedir o Windows Update de trocar o driver de vídeo)."
    }
    if ([int]$R.NDesfaz -gt 0) { $sub += ' O Telomera já protegeu o driver de vídeo contra trocas; para remover essa proteção, use "Desfazer bloqueios" em Ferramentas de reparo.' }
    if ($ni -gt 0) { $sub += " Há também $ni aviso(s) informativo(s)." }
    if ($R.NotaTexto) { $sub += ' ' + [string]$R.NotaTexto }
    if ($R.Comparacao) { $sub += ' ' + [string]$R.Comparacao }
    $lblBanS.Text = $sub
    try { Ajustar-Barra $barraRes } catch { }

    $abaProb.Text = "Problemas encontrados ($($nc + $na))"

    $chkInfo.Checked = $false
    $cmbCat.SelectedIndex = -1
    Atualizar-Filtro
    $script:DadosPC = @($R.PC)
    $script:LarguraPC = 0
    Montar-PC

    # O painel de log passa a viver na aba "Detalhes técnicos"
    $tpDet.Controls.Add($script:Log)
    $script:Log.Dock = 'Fill'
    $script:Log.Visible = $true

    $btnReiniciar.Visible = [bool](@($R.Achados | Where-Object { "$($_.Titulo)" -eq 'Há uma reinicialização pendente' }).Count -gt 0)
    $btnCorrigir.Enabled = ($script:IsAdmin -and $R.NAcoes -gt 0)
    if ($R.NAcoes -gt 0 -and $script:IsAdmin) { $btnCorrigir.Text = "Corrigir automaticamente ($($R.NAcoes))" }
    elseif ($R.NAcoes -gt 0) { $btnCorrigir.Text = (Tr 'Corrigir (requer administrador)') }
    else { $btnCorrigir.Text = (Tr 'Nada a corrigir') }
    $btnRelatorio.Enabled = [bool]($R.Html -and (Test-Path -LiteralPath $R.Html))

    Show-Aba 0
    Show-Pagina $pgRes
    Montar-Cards
}

function Confirmar-Reinicio {
    $ok = Show-Dialogo -Titulo 'Telomera' -Texto 'O computador será reiniciado em 20 segundos. Salve seus trabalhos agora. Para cancelar depois de confirmar, abra um prompt e digite: shutdown /a' -TextoSim 'Reiniciar agora' -TextoNao 'Mais tarde' -PadraoSim $false
    if ($ok) { Start-Process -FilePath 'shutdown.exe' -ArgumentList '/r', '/t', '20', '/c', '"Telomera: reiniciando para concluir as correções"' -WindowStyle Hidden }
}

function Mostrar-Bench {
    param($R)
    try { Ajustar-Margens } catch { }
    $script:UltBenchHtml = [string]$R.Html
    $ehBench = ("$($R.Fase)" -eq 'bench')
    foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2)) { $b.Visible = $false }
    $btnBenchAbrir.Visible = [bool]$R.Html; $btnBenchDeNovo.Visible = $ehBench; $btnBenchVoltar.Visible = $true
    $btnBenchAbrir.Enabled = [bool]($R.Html -and (Test-Path -LiteralPath ([string]$R.Html)))
    if ($R.Titulo) {
        $lblFimT.ForeColor = Pal 'Ok'; $lblFimT.Text = [string]$R.Titulo
    } else {
        switch ("$($R.Pior)") {
            'problema' { $lblFimT.ForeColor = Pal 'Perigo'; $lblFimT.Text = (Tr 'Teste de desempenho: há um problema') }
            'atencao'  { $lblFimT.ForeColor = Pal 'Aviso';  $lblFimT.Text = (Tr 'Teste de desempenho: pontos de atenção') }
            default    { $lblFimT.ForeColor = Pal 'Ok';     $lblFimT.Text = (Tr 'Teste de desempenho concluído') }
        }
    }
    try { Ajustar-Barra $barraFim } catch { }
    $t = [string]$R.Texto
    if ($R.Cancelado) { $t = "O teste foi interrompido; só os testes concluídos aparecem abaixo.`r`n`r`n" + $t }
    $flowFim.Visible = $false
    $txtFim.Visible = $true
    $txtFim.Text = $t
    $txtFim.SelectionStart = 0
    $txtFim.SelectionLength = 0
    Show-Pagina $pgFim
}

function Mostrar-Fim {
    param($R)
    try { Ajustar-Margens } catch { }
    foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2)) { $b.Visible = $true }
    foreach ($b in @($btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar)) { $b.Visible = $false }
    try { Ajustar-Barra $barraFim } catch { }
    $itens = @($R.Alteracoes)
    $precisaReiniciar = [bool]$R.Reiniciar
    $btnDesfazer.Enabled = ($itens.Count -gt 0)

    $txtFim.Visible = $false
    $flowFim.Controls.Clear()
    $flowFim.Visible = $true

    if ($itens.Count -eq 0) {
        $lblFimT.ForeColor = Pal 'Aviso'
        $lblFimT.Text = (Tr 'Nenhuma correção foi aplicada')
        $flowFim.Controls.Add((Nova-NotaTexto 'Você não autorizou nenhuma correção (ou nenhuma foi necessária). Se quiser, volte e clique em "Verificar de novo".'))
        $btnReiniciar.Enabled = $false
        $btnReiniciar.Text = (Tr 'Reiniciar o computador agora')
    } else {
        if ($R.Cancelado) {
            $lblFimT.ForeColor = Pal 'Aviso'
            $lblFimT.Text = (Tr 'Correções interrompidas')
        } else {
            $lblFimT.ForeColor = Pal 'Ok'
            $lblFimT.Text = (Tr 'Correções concluídas')
        }
        foreach ($i in $itens) { $flowFim.Controls.Add((Nova-LinhaChecada "$($i.Acao) — Resultado: $($i.Resultado)")) }
        if ($R.Cancelado) { $flowFim.Controls.Add((Nova-Aviso 'Você pediu para parar: as correções que ainda não tinham começado foram puladas.')) }
        if ($precisaReiniciar) {
            $flowFim.Controls.Add((Nova-Aviso 'O Windows indicou que precisa reiniciar para concluir as correções. Depois, clique em "Verificar de novo" para conferir o resultado.'))
        } else {
            $flowFim.Controls.Add((Nova-NotaTexto 'Não é preciso reiniciar agora. Se algum problema persistir, reinicie e clique em "Verificar de novo".'))
        }
        $flowFim.Controls.Add((Nova-NotaTexto 'Um relatório atualizado, com todas as alterações feitas, foi salvo na pasta da verificação.'))
        $flowFim.Controls.Add((Nova-NotaTexto 'Importante: depois de corrigir, a nova verificação ainda pode mostrar alguns avisos. Isso é esperado para: (1) o histórico de eventos, como desligamentos inesperados e travamentos de driver já ocorridos, que continuam registrados por 30 dias; e (2) drivers e serviços de programas, como jogos e anti-cheat (ex.: Riot Vanguard), que o Telomera não conserta sozinho: abra "Ver mais" no aviso e reinstale o programa citado.'))
        if ($R.TemCopia) { $flowFim.Controls.Add((Nova-NotaTexto 'Se algo piorar, o botão "Desfazer alterações" restaura a cópia dos drivers feita antes das correções.')) }
        $btnReiniciar.Enabled = $true
        if ($precisaReiniciar) { $btnReiniciar.Text = (Tr 'Reiniciar o computador agora') } else { $btnReiniciar.Text = (Tr 'Reiniciar mesmo assim (opcional)') }
    }
    try { $flowFim.AutoScrollPosition = New-Object System.Drawing.Point(0, 0) } catch { }
    Show-Pagina $pgFim
    if ($precisaReiniciar -and $itens.Count -gt 0) { Confirmar-Reinicio }
}

function Iniciar-Desfazer {
    if (-not $script:IsAdmin) {
        [void][System.Windows.Forms.MessageBox]::Show('É preciso abrir o Telomera como administrador para desfazer alterações.', 'Telomera', 'OK', 'Information')
        return
    }
    $r = Show-Dialogo -Titulo 'Telomera - desfazer' -Texto "Se você aceitou criar a cópia dos drivers antes das correções, o Telomera pode reinstalar essa cópia (útil quando um driver atualizado causou problemas).`r`n`r`nPara voltar o Windows inteiro a um ponto anterior, use a Restauração do Sistema (próxima opção)." -TextoSim 'Restaurar drivers salvos' -TextoNao 'Outras opções' -PadraoSim $false
    if ($r) { Start-Fase 'restore'; return }
    $r2 = Show-Dialogo -Titulo 'Telomera - desfazer' -Texto 'Abrir a Restauração do Sistema do Windows? Ela permite escolher o ponto de restauração criado pelo Telomera antes das correções.' -TextoSim 'Abrir' -TextoNao 'Cancelar' -PadraoSim $false
    if ($r2) { Start-Process -FilePath 'rstrui.exe' }
}

# Ações novas desta versão
$script:DicaExportar = New-Object System.Windows.Forms.ToolTip
$script:DicaExportar.AutomaticDelay = 0
$script:DicaExportar.ShowAlways = $true
$btnCopiar.Add_Click({
    try {
        [System.Windows.Forms.Clipboard]::SetText((Get-TextoResumo))
        $btnCopiar.Text = (Tr 'Copiado!')
        # "Copiar resumo" agora mora dentro do menu "Exportar" (não aparece sozinho na barra); a confirmação
        # aparece como dica flutuante sobre o botão "Exportar", já que o botão original fica escondido.
        if ($btnExportar) { $script:DicaExportar.Show((Tr 'Copiado!'), $btnExportar, 0, -26, 1600) }
        $script:TimerCopiar.Stop()
        $script:TimerCopiar.Start()
    } catch { Registrar-Erro $_ -Silencioso }
})
$script:TimerCopiar = New-Object System.Windows.Forms.Timer
$script:TimerCopiar.Interval = 1600
$script:TimerCopiar.Add_Tick({ $script:TimerCopiar.Stop(); $btnCopiar.Text = (Tr 'Copiar resumo') })

$btnPastaBase.Add_Click({
    try {
        $base = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Telomera'
        if (Test-Path -LiteralPath $base) {
            Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $base)
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Ainda não há verificações salvas.', 'Telomera', 'OK', 'Information')
        }
    } catch { Registrar-Erro $_ -Silencioso }
})

# ----------------------------------------------------------------------------
# Execução em segundo plano
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Tempo decorrido e estimativa de término
# ----------------------------------------------------------------------------
# Duração esperada de cada etapa (segundos) antes de o Telomera aprender com o seu computador.
$script:PesosPadrao = @{ 1 = 5; 2 = 20; 3 = 15; 4 = 60; 5 = 40; 6 = 90; 7 = 20; 8 = 5 }
$script:ArquivoTempos = Join-Path $env:LOCALAPPDATA 'Telomera\tempos.json'
$script:Historico = @{}
$script:TempoObs = @{}
$script:EtapaN = 0
$script:EtapaTotal = 0
$script:EtapaInicio = 0.0
$script:ProgPct = 0.0
$script:ProgP0 = 0.0
$script:ProgT0 = 0.0
$script:ProgUlt = -1.0

function Get-ChaveEtapa {
    # A duração depende das opções (Windows Update e varredura de discos), então elas entram na chave.
    param([int]$N)
    $wu = 1; if ($script:Opc.SemWindowsUpdate) { $wu = 0 }
    $vol = 1; if ($script:Opc.PularScanVolumes) { $vol = 0 }
    $pf = 0; if ($script:Opc.VerificacaoProfunda) { $pf = 1 }
    return "$N|$wu|$vol|$pf"
}

function Get-BaseEtapa {
    param([int]$N)
    $k = Get-ChaveEtapa $N
    if ($script:Historico.ContainsKey($k)) { return [double]$script:Historico[$k] }
    $b = 10.0
    # Na verificação profunda há uma etapa extra (8) antes do relatório: o relatório passa a ser a 9 e usa o peso que seria da 8.
    $nPeso = $N
    if ($script:Opc.VerificacaoProfunda -and $N -gt 8) { $nPeso = $N - 1 }
    if ($script:PesosPadrao.ContainsKey($nPeso)) { $b = [double]$script:PesosPadrao[$nPeso] }
    if ($script:Opc.VerificacaoProfunda -and $N -eq 8) { $b = 900.0 }
    if ($N -eq 4 -and $script:Opc.PularScanVolumes) { $b = 5.0 }
    if ($N -eq 6 -and $script:Opc.SemWindowsUpdate) { $b = 45.0 }
    return $b
}

function Get-EstimativaTempo {
    # Fração concluída (0 a 0,97) e segundos que faltam, a partir do passo atual e do tempo gasto nele.
    param([int]$N, [int]$Total, [double]$NaEtapa, [hashtable]$Obs)
    $feitoObs = 0.0; $feitoEsp = 0.0
    for ($k = 1; $k -lt $N; $k++) {
        $ch = Get-ChaveEtapa $k
        if ($Obs.ContainsKey($ch)) { $feitoObs += [double]$Obs[$ch]; $feitoEsp += (Get-BaseEtapa $k) }
    }
    # Ajuste de velocidade deste computador, conforme as etapas já concluídas
    $fator = 1.0
    if ($feitoEsp -gt 5) { $fator = [Math]::Max(0.5, [Math]::Min(3.0, $feitoObs / $feitoEsp)) }
    $soma = 0.0; $feito = 0.0; $falta = 0.0
    for ($k = 1; $k -le $Total; $k++) {
        $b = (Get-BaseEtapa $k) * $fator
        $soma += $b
        if ($k -lt $N) { $feito += $b }
        elseif ($k -eq $N) {
            $feito += [Math]::Min($NaEtapa, $b * 0.95)
            $falta += [Math]::Max($b - $NaEtapa, $b * 0.15)
        } else { $falta += $b }
    }
    $fr = 0.0
    if ($soma -gt 0) { $fr = [Math]::Min(0.97, $feito / $soma) }
    return @{ Fracao = $fr; Falta = $falta }
}

function Get-EstimativaProgresso {
    # Tempo restante (s) de uma tarefa com percentual (DISM/SFC), pela velocidade observada até agora.
    param([double]$Pct, [double]$Pct0, [double]$Dt)
    $avancou = $Pct - $Pct0
    if ($avancou -lt 2 -or $Dt -lt 5) { return $null }
    $taxa = $avancou / $Dt
    if ($taxa -le 0) { return $null }
    return [double]((100 - $Pct) / $taxa)
}

function Format-Duracao {
    param([double]$Seg)
    $t = [int][Math]::Round($Seg)
    return ('{0:00}:{1:00}' -f [int][Math]::Floor($t / 60), ($t % 60))
}

function Format-Restante {
    param([double]$Seg)
    if ($Seg -lt 45) { return 'menos de 1 minuto' }
    $m = [int][Math]::Ceiling($Seg / 60)
    if ($m -eq 1) { return 'cerca de 1 minuto' }
    return "cerca de $m minutos"
}

function Carregar-Historico {
    $script:Historico = @{}
    try {
        if (Test-Path -LiteralPath $script:ArquivoTempos) {
            $o = Get-Content -LiteralPath $script:ArquivoTempos -Raw -ErrorAction Stop | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) {
                $v = [double]$p.Value
                if ($v -gt 0 -and $v -lt 7200) { $script:Historico["$($p.Name)"] = $v }
            }
        }
    } catch { $script:Historico = @{} }
}

function Salvar-Historico {
    # Guarda quanto cada etapa levou (média móvel) para a próxima estimativa ser mais precisa.
    try {
        foreach ($k in @($script:TempoObs.Keys)) {
            $obs = [double]$script:TempoObs[$k]
            if ($obs -le 0) { continue }
            if ($script:Historico.ContainsKey($k)) { $script:Historico[$k] = [Math]::Round(0.5 * [double]$script:Historico[$k] + 0.5 * $obs, 1) }
            else { $script:Historico[$k] = [Math]::Round($obs, 1) }
        }
        $dir = Split-Path -Parent $script:ArquivoTempos
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        ($script:Historico | ConvertTo-Json) | Set-Content -LiteralPath $script:ArquivoTempos -Encoding UTF8
    } catch { }
}
Carregar-Historico

function Atualizar-Tempos {
    if (-not $script:Relogio) { return }
    $dec = $script:Relogio.Elapsed.TotalSeconds
    $txt = 'Tempo decorrido: ' + (Format-Duracao $dec)
    if ($script:FaseAtual -eq 'scan') {
        if ($script:EtapaN -gt 0 -and $script:EtapaTotal -gt 0) {
            $est = Get-EstimativaTempo -N $script:EtapaN -Total $script:EtapaTotal -NaEtapa ($dec - $script:EtapaInicio) -Obs $script:TempoObs
            $txt += '   ·   Tempo restante estimado: ' + (Format-Restante $est.Falta)
            Set-Barra -Fracao $est.Fracao
            try { Set-Anel $anelProg -Percentual ($est.Fracao * 100.0) -Texto "$($script:EtapaN)/$($script:EtapaTotal)"; Atualizar-Pontos $script:EtapaN $script:EtapaTotal } catch { }
        } else {
            $txt += '   ·   Tempo restante estimado: calculando...'
        }
    } elseif ($script:FaseAtual -eq 'tool') {
        Set-Barra -Indeterminada
        try { Set-Anel $anelProg -Indeterminada -Texto ''; $painelPontos.Visible = $false } catch { }
    } elseif ($script:FaseAtual -eq 'bench') {
        if ($script:EtapaN -gt 0 -and $script:EtapaTotal -gt 0) {
            $txt += '   ·   Teste ' + $script:EtapaN + ' de ' + $script:EtapaTotal
            $fracaoBench = [Math]::Min(0.97, ($script:EtapaN - 0.5) / $script:EtapaTotal)
            Set-Barra -Fracao $fracaoBench
            try { Set-Anel $anelProg -Percentual ($fracaoBench * 100.0) -Texto "$($script:EtapaN)/$($script:EtapaTotal)"; Atualizar-Pontos $script:EtapaN $script:EtapaTotal } catch { }
        } else {
            Set-Barra -Indeterminada
            try { Set-Anel $anelProg -Indeterminada -Texto ''; $painelPontos.Visible = $false } catch { }
        }
    } else {
        # Reparos: DISM e SFC informam o percentual; a estimativa vale para a tarefa em andamento.
        $ativo = ($script:ProgUlt -ge 0 -and ($dec - $script:ProgUlt) -le 30)
        if ($ativo) {
            $txt += '   ·   Tarefa atual: ' + [int][Math]::Floor($script:ProgPct) + '%'
            $falta = Get-EstimativaProgresso -Pct $script:ProgPct -Pct0 $script:ProgP0 -Dt ($script:ProgUlt - $script:ProgT0)
            if ($null -ne $falta) { $txt += '   ·   Tempo restante estimado desta tarefa: ' + (Format-Restante $falta) }
            else { $txt += '   ·   Tempo restante estimado: calculando...' }
            Set-Barra -Fracao ($script:ProgPct / 100.0)
            try { Set-Anel $anelProg -Percentual $script:ProgPct -Texto ([string]([int][Math]::Floor($script:ProgPct)) + '%'); $painelPontos.Visible = $false } catch { }
        } else {
            Set-Barra -Indeterminada
            try { Set-Anel $anelProg -Indeterminada -Texto ''; $painelPontos.Visible = $false } catch { }
        }
    }
    $lblTempo.Text = $txt
}

function Add-Log {
    param([string]$Texto, [string]$CorNome)
    $l = $script:Log
    if ($l.TextLength -gt 600000) { $l.Clear() }
    $c = [System.Drawing.Color]::LightGray
    if ($CorNome) {
        try {
            $tmp = [System.Drawing.Color]::FromName($CorNome)
            if ($tmp.IsKnownColor) { $c = $tmp }
        } catch { }
    }
    $l.SelectionStart = $l.TextLength
    $l.SelectionLength = 0
    $l.SelectionColor = $c
    $l.AppendText($Texto + "`r`n")
}

function Start-Fase {
    param([ValidateSet('scan', 'repair', 'unblock', 'restore', 'bench', 'tool')][string]$Fase)
    if ($script:Async -and -not $script:Async.IsCompleted) { return }

    $script:FaseAtual = $Fase
    $script:FimRecebido = $false
    $script:Cancelando = $false
    $script:Sync.Cancelar = $false

    $script:Opc.SomenteLeitura   = (-not $script:IsAdmin)
    $script:Opc.SemWindowsUpdate = (-not $chkWU.Checked)
    $script:Opc.PularScanVolumes = (-not $chkVol.Checked)
    if ($Fase -eq 'scan') { $script:Opc.VerificacaoProfunda = [bool]$script:VerifProfunda }
    $script:Opc.BenchLongo = [bool]$script:TesteLongo
    $script:Opc.BenchEstresse = [bool]$script:TesteEstresse
    $script:Opc.BenchTransicao = [bool]$script:TesteTransicao
    $script:Opc.BenchTransicaoPesado = [bool]$script:TransPesado
    $script:Opc.BenchEstresseProlongado = [bool]$script:EstresseProlongado
    $script:Opc.BenchMemoria = [bool]$script:TesteMemoria
    $script:Opc.BenchDiscoEstresse = [bool]$script:TesteDiscoEstresse
    $script:Opc.BenchDuracaoLonga = [bool]$script:DuracaoLonga
    $script:Opc.AceitarTudo      = ($Fase -eq 'repair' -and $script:ModoAuto)
    if ($Fase -eq 'tool') { $script:Opc.SomenteLeitura = $false }

    # Prepara a página de progresso
    $pgProg.Controls.Add($script:Log)
    $script:Log.Dock = 'Fill'
    $script:Log.BringToFront()   # o painel "Fill" precisa ser encaixado por último
    $script:Log.Visible = $false
    $script:Log.Clear()
    Alternar-Detalhes $false
    $btnCancel.Visible = ($Fase -eq 'scan' -or $Fase -eq 'repair' -or $Fase -eq 'bench' -or $Fase -eq 'tool')
    $btnCancel.Enabled = $true
    if ($Fase -eq 'repair') {
        Ajustar-LarguraBotao $btnCancel 'Parar depois desta correção' 120
    } else {
        Ajustar-LarguraBotao $btnCancel 'Cancelar' 120
    }
    Set-Barra -Indeterminada
    $lblTempo.Text = (Tr 'Tempo decorrido: 00:00')
    $script:Relogio = [System.Diagnostics.Stopwatch]::StartNew()
    $script:EtapaN = 0
    $script:EtapaTotal = 0
    $script:EtapaInicio = 0.0
    $script:TempoObs = @{}
    $script:ProgPct = 0.0
    $script:ProgP0 = 0.0
    $script:ProgT0 = 0.0
    $script:ProgUlt = -1.0
    Atualizar-Tempos
    $lblEtapa.Text = (Tr 'Preparando...')
    if ($Fase -eq 'scan') {
        $lblDica.Text = 'Pode continuar usando o computador. A estimativa melhora a cada verificação, porque o Telomera aprende quanto tempo cada etapa leva no seu computador. Se a janela pedir algo, responda na caixa que aparecer.'
    } elseif ($Fase -eq 'tool') {
        $lblDica.Text = (Tr 'Se aparecer uma pergunta, responda na caixa que abrir. Não feche esta janela até terminar.')
    } elseif ($Fase -eq 'bench') {
        $lblDica.Text = 'O computador pode ficar lento por alguns minutos (de 3 a 14 minutos, conforme o tipo de teste escolhido). Janelas com animação vão abrir e fechar sozinhas, no estresse de jogo pesado em tela cheia (Esc para parar): não mexa nelas. Nada é alterado no seu computador.'
    } else {
        $lblDica.Text = (Tr 'Não feche esta janela e não desligue o computador enquanto as correções estiverem em andamento.')
    }
    Show-Pagina $pgProg

    try {
        if (-not $script:RS) {
            $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
            try { $iss.ExecutionPolicy = [Microsoft.PowerShell.ExecutionPolicy]::Bypass } catch { }
            $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
            $rs.ApartmentState = 'MTA'
            $rs.ThreadOptions = 'ReuseThread'
            $rs.Open()
            $rs.SessionStateProxy.SetVariable('WD_Sync', $script:Sync)
            $rs.SessionStateProxy.SetVariable('WD_Opc', $script:Opc)
            $script:RS = $rs
        }
        $ps = [System.Management.Automation.PowerShell]::Create()
        $ps.Runspace = $script:RS
        $codigo = ''
        if (-not $script:WorkerCarregado) {
            $caminho = (Join-Path $PSScriptRoot 'Telomera-Worker.ps1').Replace("'", "''")
            $codigo += ". '$caminho'`r`n"
        }
        $codigo += "Invoke-FaseGUI -Fase '$Fase'"
        [void]$ps.AddScript($codigo, $false)
        $script:Ps = $ps
        $script:Async = $ps.BeginInvoke()
    } catch {
        Registrar-Erro $_
        Show-Pagina $pgInicio
    }
}

function Tratar-Ask {
    param($M)
    $p = [string]$M.Prompt
    $resp = ''
    if ($p -match 'Pressione Enter') {
        $resp = ''
    } elseif ($p -match '\[S/n\]\s*$') {
        $txt = ($p -replace '\s*\[[sSnN]/[sSnN]\]\s*$', '').Trim()
        if (Show-Dialogo -Titulo 'Telomera - confirmação' -Texto $txt -TextoSim 'Sim' -TextoNao 'Não' -PadraoSim $true) { $resp = 's' } else { $resp = 'n' }
    } elseif ($p -match '\[s/N\]\s*$') {
        $txt = ($p -replace '\s*\[[sSnN]/[sSnN]\]\s*$', '').Trim()
        if (Show-Dialogo -Titulo 'Telomera - confirmação' -Texto $txt -TextoSim 'Sim' -TextoNao 'Não' -PadraoSim $false) { $resp = 's' } else { $resp = 'n' }
    }
    $M.Req.Resp = $resp
    [void]$M.Req.Evt.Set()
}

function Tratar-Confirm {
    param($M)
    $ok = $false
    if ($M.Sensivel) {
        $aviso = 'Este é um driver INTERNO do sistema (chipset, armazenamento, processador ou barramento). Uma troca errada pode impedir o Windows de iniciar. Só continue se tiver certeza. O Telomera cria um ponto de volta antes.'
        if ($M.Aviso) { $aviso += "`r`n`r`n$($M.Aviso)" }
        $ok = Show-Dialogo -Titulo 'Telomera - ação sensível' -Texto ([string]$M.Mensagem) -Aviso $aviso -Exige 'RESTAURAR' -TextoSim 'Restaurar' -TextoNao 'Não restaurar' -PadraoSim $false -Perigo $true
    } else {
        $ok = Show-Dialogo -Titulo 'Telomera - confirmar correção' -Texto ([string]$M.Mensagem) -Aviso ([string]$M.Aviso) -TextoSim 'Sim, fazer' -TextoNao 'Agora não' -PadraoSim $false
    }
    $M.Req.Resp = [bool]$ok
    [void]$M.Req.Evt.Set()
}

function Tratar-Fim {
    param($M)
    $script:FimRecebido = $true
    $script:WorkerCarregado = $true
    Set-Barra -Fracao 1
    if (-not $M.Ok -and "$($M.Fase)" -ne 'scan') {
        # Reparo, restauração ou desbloqueio que falhou: mostra o motivo em vez de uma tela vazia.
        [void][System.Windows.Forms.MessageBox]::Show("A operação não pôde ser concluída.`r`n`r`n$($M.Erro)", 'Telomera', 'OK', 'Warning')
        if ($script:Res) { Show-Pagina $pgRes } else { Show-Pagina $pgInicio }
        return
    }
    switch ("$($M.Fase)") {
        'scan' {
            if ($M.Ok) {
                if ($script:EtapaN -gt 0 -and -not $script:Cancelando -and $script:Relogio) {
                    $script:TempoObs[(Get-ChaveEtapa $script:EtapaN)] = ($script:Relogio.Elapsed.TotalSeconds - $script:EtapaInicio)
                    Salvar-Historico
                }
                Mostrar-Resultados $M
            } else {
                [void][System.Windows.Forms.MessageBox]::Show("A verificação não pôde ser concluída.`r`n`r`n$($M.Erro)", 'Telomera', 'OK', 'Warning')
                Show-Pagina $pgInicio
            }
        }
        'repair' { Mostrar-Fim $M }
        'bench' { Mostrar-Bench $M }
        'tool' { Mostrar-Bench $M }
        'restore' {
            if ($M.Restaurado) {
                [void][System.Windows.Forms.MessageBox]::Show('Os drivers da cópia foram restaurados. Reinicie o computador para concluir.', 'Telomera', 'OK', 'Information')
            } elseif ($M.Aviso) {
                [void][System.Windows.Forms.MessageBox]::Show([string]$M.Aviso, 'Telomera', 'OK', 'Information')
            } else {
                [void][System.Windows.Forms.MessageBox]::Show('Nada foi restaurado.', 'Telomera', 'OK', 'Information')
            }
            Show-Pagina $pgInicio
        }
        'unblock' {
            [void][System.Windows.Forms.MessageBox]::Show('Pronto. Reinicie o computador para concluir.', 'Telomera', 'OK', 'Information')
            Show-Pagina $pgInicio
        }
    }
}

function Tratar-Mensagem {
    param($M)
    switch ("$($M.T)") {
        'log'     { Add-Log ([string]$M.Texto) ([string]$M.Cor) }
        'etapa'   {
            if ([int]$M.Total -gt 0) {
                $agora = 0.0
                if ($script:Relogio) { $agora = $script:Relogio.Elapsed.TotalSeconds }
                if ($script:EtapaN -gt 0 -and $script:FaseAtual -eq 'scan') { $script:TempoObs[(Get-ChaveEtapa $script:EtapaN)] = ($agora - $script:EtapaInicio) }
                $script:EtapaN = [int]$M.N
                $script:EtapaTotal = [int]$M.Total
                $script:EtapaInicio = $agora
                $lblEtapa.Text = "Passo $($M.N) de $($M.Total): $($M.Texto)"
            } else {
                $lblEtapa.Text = [string]$M.Texto
                Set-Barra -Indeterminada
                $script:ProgUlt = -1.0
            }
        }
        'prog'    {
            $agora = 0.0
            if ($script:Relogio) { $agora = $script:Relogio.Elapsed.TotalSeconds }
            $pct = [double]$M.Pct
            # Nova tarefa (percentual voltou a cair ou ficou muito tempo sem atualizar): recomeça a medição
            if ($script:ProgUlt -lt 0 -or $pct -lt ($script:ProgPct - 10) -or ($agora - $script:ProgUlt) -gt 30) {
                $script:ProgP0 = $pct
                $script:ProgT0 = $agora
            }
            $script:ProgPct = $pct
            $script:ProgUlt = $agora
        }
        'ask'     { Tratar-Ask $M }
        'confirm' { Tratar-Confirm $M }
        'fim'     { Tratar-Fim $M }
    }
}

function Finalizar-Fase {
    try { [void]$script:Ps.EndInvoke($script:Async) } catch { }
    try {
        if ($script:Ps.Streams.Error.Count -gt 0) {
            foreach ($e in $script:Ps.Streams.Error) { Registrar-Erro ("[worker] " + $e.ToString()) -Silencioso }
        }
    } catch { }
    try { $script:Ps.Dispose() } catch { }
    $script:Ps = $null
    $script:Async = $null
    if (-not $script:FimRecebido) {
        if (-not $script:Cancelando) {
            [void][System.Windows.Forms.MessageBox]::Show(
                "A etapa terminou de forma inesperada.`r`n`r`nOs detalhes foram salvos em:`r`n$($script:ArquivoErros)",
                'Telomera', 'OK', 'Warning')
        }
        Set-Barra -Fracao 0
        Show-Pagina $pgInicio
    }
}

$script:Timer = New-Object System.Windows.Forms.Timer
$script:Timer.Interval = 100
$script:Timer.Add_Tick({
    if ($script:EmDialogo) { return }
    $script:EmDialogo = $true
    try {
        $concluido = ($script:Async -ne $null -and $script:Async.IsCompleted)
        $m = $null
        $n = 0
        while ($n -lt 400 -and $script:Sync.Fila.TryDequeue([ref]$m)) {
            $n++
            try { Tratar-Mensagem $m } catch { Registrar-Erro $_ -Silencioso }
            $m = $null
        }
        if ($script:Log.Visible -and $n -gt 0) { $script:Log.ScrollToCaret() }
        if ($script:Async -ne $null) { Atualizar-Tempos }
        if ($concluido -and $script:Sync.Fila.IsEmpty) { Finalizar-Fase }
    } catch {
        Registrar-Erro $_ -Silencioso
    } finally {
        $script:EmDialogo = $false
    }
})

# ----------------------------------------------------------------------------
# Eventos dos botões
# ----------------------------------------------------------------------------
$btnIniciar.Add_Click({
    try { if (Show-EscolhaVerificacao) { Start-Fase 'scan' } } catch { Registrar-Erro $_ }
})

function Iniciar-Desempenho { if (Show-EscolhaTeste) { Start-Fase 'bench' } }
$btnBench.Add_Click({ try { Iniciar-Desempenho } catch { Registrar-Erro $_ } })
$btnBenchFerr.Add_Click({ try { Iniciar-Desempenho } catch { Registrar-Erro $_ } })
function Iniciar-Ferramenta {
    param([string]$Id)
    $f = $script:ListaFerramentas | Where-Object { $_.Id -eq $Id } | Select-Object -First 1
    if (-not $f) { return }
    if ($f.Admin -and -not $script:IsAdmin) {
        [void][System.Windows.Forms.MessageBox]::Show('Esta ferramenta altera o Windows e precisa do Telomera aberto como administrador. Feche e abra de novo aceitando o pedido de permissão.', 'Telomera', 'OK', 'Information')
        return
    }
    if ($Id -eq 'pontos-abrir') { try { Start-Process -FilePath 'rstrui.exe' } catch { Registrar-Erro $_ -Silencioso }; return }
    $script:Opc.Ferramenta = $Id
    $script:Opc.DestinoBackup = ''
    if ($Id -eq 'agendar-ativar') {
        $script:Opc.AgendaDia = [string]$script:DiasEn[[Math]::Max(0, $cmbDia.SelectedIndex)]
        $script:Opc.AgendaHora = [string]$cmbHora.SelectedItem
    }
    if ($Id -eq 'drv-verificar') {
        $dlgA = New-Object System.Windows.Forms.OpenFileDialog
        $dlgA.Title = 'Escolha o instalador de driver que você baixou do site do fabricante'
        $dlgA.Filter = 'Instaladores (*.exe;*.msi)|*.exe;*.msi'
        try { $dlgA.InitialDirectory = (Join-Path $env:USERPROFILE 'Downloads') } catch { }
        if ($dlgA.ShowDialog() -ne 'OK') { return }
        $script:Opc.DestinoBackup = $dlgA.FileName
    }
    if ($Id -eq 'backup') {
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Escolha a pasta (ou o pen drive) onde guardar a cópia dos seus arquivos'
        if ($dlg.ShowDialog() -ne 'OK') { return }
        $script:Opc.DestinoBackup = $dlg.SelectedPath
    }
    Start-Fase 'tool'
}
foreach ($bf in @($script:BotoesFerr) + @($script:BotoesCfg)) { $bf.Add_Click({ try { Iniciar-Ferramenta ([string]$this.AccessibleName) } catch { Registrar-Erro $_ } }) }
function Atualizar-Sensores {
    # Estado dos programas de sensores (barato: só lê processos e o INI do HWiNFO).
    $es = Get-EstadoSensores
    $av = Get-AvaliacaoSensores $es
    $txt = $av.Resumo
    if ($av.Passos.Count -gt 0) { $txt += '  Próximo passo: ' + $av.Passos[0] }
    if ($script:lblSensEstado) { $script:lblSensEstado.Text = (Tr $txt); $script:lblSensEstado.BackColor = $(if ($av.Pronto) { Pal 'OkFundo' } else { Pal 'AvisoFundo' }) }
    if ($script:lblSensIni) { $script:lblSensIni.Text = $(if ($av.Pronto) { 'Sensores: ' + $av.Resumo } else { 'Sensores: ' + $av.Resumo + ' (Monitor e sensores)' }) }
}
function Atualizar-Monitor {
    $e = $null
    try { $e = Get-EstadoMonitor } catch { }
    if ($e) {
        $desde = ''
        try { $desde = ([datetime]::Parse([string]$e.Inicio, [Globalization.CultureInfo]::InvariantCulture)).ToString('dd/MM HH:mm') } catch { }
        $script:lblMonEstado.Text = (Tr ("Monitor ligado desde $desde. Pode jogar: o registro é gravado a cada $(([string]$e.Intervalo) -replace '\.', ',') s."))
    } else {
        $script:lblMonEstado.Text = (Tr 'Monitor desligado.')
    }
    try { Atualizar-Sensores } catch { }
    $btnMonIni.Enabled = (-not $e)
    $btnMonParar.Enabled = [bool]$e
    $btnMonVer.Enabled = [bool]($e -or (Get-UltimaSessaoMonitor))
}
$btnMonIni.Add_Click({
    try {
        $achou = @()
        foreach ($n in 'HWiNFO64', 'HWiNFO32', 'MSIAfterburner', 'LibreHardwareMonitor', 'OpenHardwareMonitor') { if (Get-Process -Name $n -ErrorAction SilentlyContinue) { $achou += $n } }
        $aviso = ''
        if ($achou.Count -eq 0) { $aviso = 'Nenhum programa de sensores está aberto. Abra o HWiNFO (modo "Sensors only", com "Shared Memory Support" ligado nas configurações) ou o MSI Afterburner antes de jogar; sem eles o monitor grava só o uso do processador e da memória e a temperatura da placa de vídeo (NVIDIA/AMD).' }
        $txt = "O monitor roda escondido, em segundo plano, até você desligá-lo aqui mesmo. Ele lê a cada meio segundo (0,5 s) o que o HWiNFO, o MSI Afterburner ou o LibreHardwareMonitor estiverem publicando (temperaturas, tensões da fonte, consumo, uso) e grava em um arquivo, forçando cada linha para o disco. Para o HWiNFO acompanhar esse ritmo, nas configurações dele (engrenagem da janela de sensores) deixe o intervalo de atualização em 500 ms.`r`n`r`nSe o computador desligar durante o jogo, abra o Telomera depois e use 'Ver o último registro': ele mostra as últimas temperaturas e tensões e a provável causa. Não é instalado nada, nada vai para a internet e ele não liga sozinho junto com o Windows."
        $ok = Show-Dialogo -Titulo 'Telomera - monitor em tempo real' -Texto $txt -Aviso $aviso -TextoSim 'Ligar o monitor' -TextoNao 'Agora não' -PadraoSim $true
        if ($ok) {
            $okIni = Start-Monitor -Pasta $PSScriptRoot -Intervalo 0.5
            if (-not $okIni) { [void][System.Windows.Forms.MessageBox]::Show((Tr 'Não consegui ligar o monitor. Tente de novo.'), 'Telomera', 'OK', 'Warning') }
            Atualizar-Monitor
        }
    } catch { Registrar-Erro $_ }
})
$btnMonParar.Add_Click({
    try {
        [void](Stop-Monitor)
        Atualizar-Monitor
    } catch { Registrar-Erro $_ }
})
$btnMonVer.Add_Click({
    try {
        $e = Get-EstadoMonitor
        $f = if ($e) { [string]$e.Arquivo } else { Get-UltimaSessaoMonitor }
        $an = $null
        if ($f) { $an = Get-AnaliseSessao -Arquivo $f }
        $txt = Format-TextoSessao $an
        $saida = Join-Path (Get-PastaMonitor) 'ultima-sessao.txt'
        New-Item -ItemType Directory -Force -Path (Get-PastaMonitor) | Out-Null
        [IO.File]::WriteAllText($saida, $txt, (New-Object System.Text.UTF8Encoding($true)))
        Start-Process -FilePath $saida
    } catch { Registrar-Erro $_ }
})
$btnMonInv.Add_Click({
    try {
        $txt = Invoke-InvestigarTravamento
        $saida = Join-Path (Get-PastaMonitor) 'ultimo-travamento.txt'
        New-Item -ItemType Directory -Force -Path (Get-PastaMonitor) | Out-Null
        [IO.File]::WriteAllText($saida, $txt, (New-Object System.Text.UTF8Encoding($true)))
        Start-Process -FilePath $saida
    } catch { Registrar-Erro $_ }
})
$btnMemWin.Add_Click({
    try {
        $r = [System.Windows.Forms.MessageBox]::Show('O Diagnóstico de Memória do Windows vai abrir. Se você escolher reiniciar agora, o computador reinicia, testa a memória por alguns minutos (até cerca de uma hora no teste completo) e volta ao Windows. Salve seus trabalhos antes. Abrir agora?', 'Telomera', 'YesNo', 'Question')
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\MdSched.exe') }
    } catch { Registrar-Erro $_ }
})
$btnExtOcct.Add_Click({ try { Start-Process 'https://www.ocbase.com/' } catch { Registrar-Erro $_ } })
$btnExtFur.Add_Click({ try { Start-Process 'https://geeks3d.com/furmark/' } catch { Registrar-Erro $_ } })
$btnExtMem.Add_Click({ try { Start-Process 'https://www.memtest86.com/' } catch { Registrar-Erro $_ } })
$btnFerr.Add_Click({ try { Abrir-Area 'reparos' } catch { Registrar-Erro $_ } })
$btnAreaTravou.Add_Click({ try { Abrir-Area 'travou' } catch { Registrar-Erro $_ } })
$btnAreaMonitor.Add_Click({ try { Abrir-Area 'monitor' } catch { Registrar-Erro $_ } })
$btnAreaDrivers.Add_Click({ try { Abrir-Area 'drivers' } catch { Registrar-Erro $_ } })
$btnAreaAjuda.Add_Click({ try { Abrir-Area 'ajuda' } catch { Registrar-Erro $_ } })
$btnInicio.Add_Click({
    try {
        if ($script:Async -and -not $script:Async.IsCompleted) { return }
        Show-Pagina $pgInicio
    } catch { Registrar-Erro $_ }
})
foreach ($bv in $script:BotoesVoltar) { $bv.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } }) }
$btnCfg.Add_Click({ try { Ajustar-PaginaFerr; Show-Pagina $pgCfg } catch { Registrar-Erro $_ } })
$btnCfgEngrenagem.Add_Click({ try { $btnCfg.PerformClick() } catch { Registrar-Erro $_ -Silencioso } })
$btnCfgVoltar.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } })
$btnPdf.Add_Click({
    try {
        if (-not ($script:Res -and $script:Res.Html -and (Test-Path -LiteralPath $script:Res.Html))) { return }
        $nav = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
        if (-not $nav) { [void][System.Windows.Forms.MessageBox]::Show('Para salvar em PDF é preciso ter o Microsoft Edge ou o Google Chrome. Alternativa: abra o relatório e use Imprimir > Salvar como PDF.', 'Telomera', 'OK', 'Information'); return }
        $pdf = [IO.Path]::ChangeExtension([string]$script:Res.Html, '.pdf')
        $url = ([Uri]([IO.Path]::GetFullPath([string]$script:Res.Html))).AbsoluteUri
        $perfil = Join-Path ([IO.Path]::GetTempPath()) 'Telomera-pdf'
        $arg = @('--headless', '--disable-gpu', '--no-pdf-header-footer', "--user-data-dir=`"$perfil`"", "--print-to-pdf=`"$pdf`"", "`"$url`"")
        $btnPdf.Enabled = $false; $btnPdf.Text = 'Gerando...'
        $pr = Start-Process -FilePath $nav -ArgumentList $arg -PassThru -WindowStyle Hidden
        [void]$pr.WaitForExit(60000)
        try { if (-not $pr.HasExited) { $pr.Kill() } } catch { }
        $btnPdf.Enabled = $true; $btnPdf.Text = (Tr 'Salvar em PDF')
        if (Test-Path -LiteralPath $pdf) { Start-Process -FilePath $pdf } else { [void][System.Windows.Forms.MessageBox]::Show('Não consegui gerar o PDF. Abra o relatório e use Imprimir > Salvar como PDF.', 'Telomera', 'OK', 'Information') }
    } catch { $btnPdf.Enabled = $true; $btnPdf.Text = (Tr 'Salvar em PDF'); Registrar-Erro $_ -Silencioso }
})
$btnAtualizar.Add_Click({
    try {
        $ps1 = Join-Path $PSScriptRoot 'Atualizar-Telomera.ps1'
        if (-not (Test-Path -LiteralPath $ps1)) {
            [void][System.Windows.Forms.MessageBox]::Show('Não encontrei o Atualizar-Telomera.ps1 ao lado do programa. Instale pelo Instalar-Telomera.bat para ter a atualização.', 'Telomera', 'OK', 'Information')
            return
        }
        $btnAtualizar.Enabled = $false
        $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
        $form.Refresh()
        $codigo = 1
        try {
            $arqRes = Join-Path ([IO.Path]::GetTempPath()) ('Telomera-atu-' + [guid]::NewGuid().ToString('N') + '.txt')
            $h3 = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -File "{0}" -SoVerificar -VersaoAtual "{1}" -ArquivoSaida "{2}"' -f $ps1, $script:Versao, $arqRes)
            $pr = Start-Process -FilePath $h3.Exe -ArgumentList $h3.Args -WindowStyle Hidden -PassThru
            if (-not $pr.WaitForExit(45000)) { try { $pr.Kill() } catch { } }
            elseif (Test-Path -LiteralPath $arqRes) { try { $codigo = [int]((Get-Content -LiteralPath $arqRes -Raw).Trim()) } catch { $codigo = 1 } }
            else { $codigo = $pr.ExitCode }
            try { Remove-Item -LiteralPath $arqRes -Force -ErrorAction SilentlyContinue } catch { }
        } finally {
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnAtualizar.Enabled = $true
        }
        if ($codigo -eq 10) {
            $ok = Show-Dialogo -Titulo 'Telomera' -Texto 'Há uma versão nova do Telomera. Baixar e instalar agora? O Telomera será fechado e aberto de novo sozinho, já atualizado.' -TextoSim 'Sim, atualizar' -TextoNao 'Agora não' -PadraoSim $true
            if ($ok) {
                $argsPs = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -VersaoAtual "{1}" -SemPerguntas -Reabrir' -f $ps1, $script:Versao
                Start-Process -FilePath 'powershell.exe' -ArgumentList $argsPs
                $form.Close()
            }
        } elseif ($codigo -eq 0) {
            [void][System.Windows.Forms.MessageBox]::Show("Você já está com a versão mais recente ($($script:Versao)).", 'Telomera', 'OK', 'Information')
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Não consegui verificar agora. Confira a conexão com a internet e tente de novo.', 'Telomera', 'OK', 'Information')
        }
    } catch { Registrar-Erro $_ -Silencioso }
})
$btnBenchDeNovo.Add_Click({ try { if (Show-EscolhaTeste) { Start-Fase 'bench' } } catch { Registrar-Erro $_ } })
$btnBenchVoltar.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } })
$btnBenchAbrir.Add_Click({
    try { if ($script:UltBenchHtml -and (Test-Path -LiteralPath $script:UltBenchHtml)) { Start-Process -FilePath $script:UltBenchHtml } } catch { Registrar-Erro $_ -Silencioso }
})

$btnDesbloq.Add_Click({
    try {
        if (-not $script:IsAdmin) {
            [void][System.Windows.Forms.MessageBox]::Show('É preciso abrir o Telomera como administrador para desfazer os bloqueios.', 'Telomera', 'OK', 'Information')
            return
        }
        $ok = Show-Dialogo -Titulo 'Telomera' -Texto 'Isso remove os bloqueios de atualização de driver que o Telomera criou (por exemplo, para proteger o driver da placa de vídeo). Depois disso, o Windows Update e os instaladores dos fabricantes voltam a poder instalar drivers nesses dispositivos. Continuar?' -TextoSim 'Sim, remover' -TextoNao 'Cancelar' -PadraoSim $false
        if ($ok) { Start-Fase 'unblock' }
    } catch { Registrar-Erro $_ }
})

$btnDet.Add_Click({ try { Alternar-Detalhes (-not $script:Log.Visible) } catch { Registrar-Erro $_ -Silencioso } })

$btnCancel.Add_Click({
    try {
        if (-not ($script:Async -and -not $script:Async.IsCompleted)) { return }
        if ($script:FaseAtual -eq 'repair') {
            # Interromper o DISM, o SFC ou um driver no meio pode danificar o Windows: espera a correção atual terminar.
            $ok = Show-Dialogo -Titulo 'Telomera' -Texto "O Telomera vai terminar a correção que está em andamento (interrompê-la no meio poderia danificar o Windows) e não fará as próximas.`r`n`r`nIsso pode levar alguns minutos. Parar depois desta correção?" -TextoSim 'Sim, parar depois desta' -TextoNao 'Continuar corrigindo' -PadraoSim $false
            if ($ok) {
                $script:Sync.Cancelar = $true
                $btnCancel.Enabled = $false
                $lblEtapa.Text = 'Terminando a correção atual...'
                $lblDica.Text = 'Aguarde: a correção que já começou precisa terminar com segurança. As próximas não serão feitas.'
            }
            return
        }
        $txtC = 'Cancelar a verificação? Nada foi alterado no seu computador.'
        if ($script:FaseAtual -eq 'bench') { $txtC = 'Cancelar o teste de desempenho? Nada foi alterado no seu computador.' }
        $ok = Show-Dialogo -Titulo 'Telomera' -Texto $txtC -TextoSim 'Sim, cancelar' -TextoNao 'Continuar' -PadraoSim $false
        if ($ok -and $script:Ps) {
            $script:Cancelando = $true
            $lblEtapa.Text = (Tr 'Cancelando...')
            [void]$script:Ps.BeginStop($null, $null)
        }
    } catch { Registrar-Erro $_ }
})

$chkInfo.Add_CheckedChanged({ try { if (-not $script:AtualizandoFiltro) { Atualizar-Filtro; Montar-Cards } } catch { Registrar-Erro $_ -Silencioso } })
$cmbCat.Add_SelectedIndexChanged({ try { if (-not $script:AtualizandoFiltro) { Montar-Cards } } catch { Registrar-Erro $_ -Silencioso } })

$btnCorrigir.Add_Click({
    try {
        # Passo 1: a escolha mais importante, com as duas opções lado a lado e destacadas.
        $txt1 = "ATENÇÃO: existem 2 formas de fazer as correções. Escolha uma:`r`n`r`n1) CORRIGIR TUDO AUTOMATICAMENTE`r`nO Telomera faz todas as correções sozinho, sem perguntar nada (cria antes um ponto de restauração e uma cópia dos drivers). Drivers internos do sistema são sempre pulados, por segurança.`r`n`r`n2) ESCOLHER UMA A UMA`r`nO Telomera mostra cada correção e você decide Sim ou Não em cada uma."
        $auto = Show-Dialogo -Titulo 'Telomera - ESCOLHA COMO CORRIGIR' -Texto $txt1 -Aviso 'Clique no botão da forma que você quer. Se tiver dúvida, escolha "Escolher uma a uma".' -TextoSim '1) Corrigir tudo automaticamente' -TextoNao '2) Escolher uma a uma' -PadraoSim $false
        $script:ModoAuto = [bool]$auto
        # Passo 2: confirmação final, que também permite voltar sem corrigir nada.
        $modo = 'uma a uma, perguntando em cada correção'
        if ($script:ModoAuto) { $modo = 'automaticamente, sem perguntar' }
        $txt2 = "Você escolheu corrigir $modo.`r`n`r`nSalve os trabalhos abertos: algumas correções podem pedir para reiniciar o computador.`r`n`r`nDica: se tem arquivos importantes, faça uma cópia antes (Ferramentas de reparo e restauração > Copiar meus arquivos pessoais).`r`n`r`nIniciar as correções agora?"
        $ok = Show-Dialogo -Titulo 'Telomera - confirmar' -Texto $txt2 -TextoSim 'Iniciar as correções' -TextoNao 'Voltar sem corrigir' -PadraoSim $false
        if ($ok) { Start-Fase 'repair' } else { $script:ModoAuto = $false }
    } catch { Registrar-Erro $_ }
})

$btnRelatorio.Add_Click({
    try {
        if ($script:Res -and $script:Res.Html -and (Test-Path -LiteralPath $script:Res.Html)) { Start-Process -FilePath $script:Res.Html }
    } catch { Registrar-Erro $_ -Silencioso }
})

$btnPasta.Add_Click({
    try {
        if ($script:Res -and $script:Res.Pasta -and (Test-Path -LiteralPath $script:Res.Pasta)) { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $script:Res.Pasta) }
    } catch { Registrar-Erro $_ -Silencioso }
})

$btnNova.Add_Click({ try { if (Show-EscolhaVerificacao) { Start-Fase 'scan' } } catch { Registrar-Erro $_ } })
$btnReiniciar.Add_Click({ try { Iniciar-Ferramenta 'reiniciar-pc' } catch { Registrar-Erro $_ } })
$btnVerif2.Add_Click({ try { if (Show-EscolhaVerificacao) { Start-Fase 'scan' } } catch { Registrar-Erro $_ } })
$btnSair.Add_Click({ $script:Form.Close() })
$btnSair2.Add_Click({ $script:Form.Close() })

$btnReiniciar.Add_Click({ try { Confirmar-Reinicio } catch { Registrar-Erro $_ } })
$btnDesfazer.Add_Click({ try { Iniciar-Desfazer } catch { Registrar-Erro $_ } })
$btnDesfazer2.Add_Click({ try { Iniciar-Desfazer } catch { Registrar-Erro $_ } })

# Atalho com o ícone do escudo: criado sozinho na primeira abertura (e de novo se a pasta do Telomera mudar de lugar)
function Initialize-Atalho {
    param([switch]$Forcar)
    try {
        $script = Join-Path $PSScriptRoot 'Criar-Atalho.ps1'
        if (-not (Test-Path -LiteralPath $script)) { return $false }
        $marca = Join-Path $script:PastaDados 'atalho.txt'
        if (-not $Forcar -and (Test-Path -LiteralPath $marca)) {
            $ant = (Get-Content -LiteralPath $marca -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ("$ant" -eq $PSScriptRoot) { return $true }
        }
        $ok = & $script -SemPerguntas -Silencioso
        if ($ok -eq $true) {
            New-Item -ItemType Directory -Force -Path $script:PastaDados -ErrorAction SilentlyContinue | Out-Null
            Set-Content -LiteralPath $marca -Value $PSScriptRoot -Encoding UTF8
            return $true
        }
    } catch { Registrar-Erro $_ -Silencioso }
    return $false
}
$form.Add_Shown({ try { [void](Initialize-Atalho) } catch { } })
$btnAtalho.Add_Click({
    try {
        if (Initialize-Atalho -Forcar) {
            [void][System.Windows.Forms.MessageBox]::Show('Atalho criado na Área de Trabalho e no Menu Iniciar.', 'Telomera', 'OK', 'Information')
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Não foi possível criar o atalho. Os detalhes foram salvos no log de erros.', 'Telomera', 'OK', 'Warning')
        }
    } catch { Registrar-Erro $_ }
})

# Atalhos de teclado: Ctrl+1/2/3 trocam de aba, F5 verifica de novo, F1 mostra a ajuda
function Mostrar-AjudaTeclas {
    $linhas = @(
        'Atalhos de teclado',
        '',
        'Tab / Shift+Tab: passa de um botão para outro',
        'Enter ou Espaço: aciona o botão selecionado',
        'Ctrl+1, Ctrl+2, Ctrl+3: abas Problemas, Meu computador e Detalhes',
        'F5: verifica o computador de novo',
        'Esc: fecha as caixas de diálogo',
        'F1: esta ajuda'
    )
    [void][System.Windows.Forms.MessageBox]::Show(($linhas -join "`r`n"), 'Telomera - atalhos', 'OK', 'Information')
}
$form.KeyPreview = $true
$form.Add_KeyDown({
    param($remetente, $ev)
    try {
        if ($script:EmDialogo) { return }
        $K = [System.Windows.Forms.Keys]
        if ($ev.KeyCode -eq $K::F1) { $ev.Handled = $true; Mostrar-AjudaTeclas; return }
        $emResultados = ($pgRes.Visible)
        if ($ev.Control -and $emResultados) {
            $aba = -1
            if ($ev.KeyCode -eq $K::D1 -or $ev.KeyCode -eq $K::NumPad1) { $aba = 0 }
            elseif ($ev.KeyCode -eq $K::D2 -or $ev.KeyCode -eq $K::NumPad2) { $aba = 1 }
            elseif ($ev.KeyCode -eq $K::D3 -or $ev.KeyCode -eq $K::NumPad3) { $aba = 2 }
            if ($aba -ge 0) { $ev.Handled = $true; Show-Aba $aba; return }
        }
        if ($ev.KeyCode -eq $K::F5 -and ($pgRes.Visible -or $pgInicio.Visible -or $pgFim.Visible)) {
            $ev.Handled = $true
            if (Show-EscolhaVerificacao) { Start-Fase 'scan' }
        }
    } catch { Registrar-Erro $_ -Silencioso }
})

# Reajuste dos cartões quando a janela muda de tamanho
$script:TimerResize = New-Object System.Windows.Forms.Timer
$script:TimerResize.Interval = 250
$script:TimerResize.Add_Tick({
    $script:TimerResize.Stop()
    try {
        if ($script:Res -and [Math]::Abs($flowCards.ClientSize.Width - $script:LarguraCards) -gt (PX 20)) { Montar-Cards }
        if ($null -ne $script:DadosPC -and $script:AbaAtual -eq 1) { Montar-PC -SePrecisar }
    } catch { }
})
$flowCards.Add_SizeChanged({ $script:TimerResize.Stop(); $script:TimerResize.Start() })
$form.Add_SizeChanged({ try { Ajustar-Margens; Ajustar-Barra $barraRes; Ajustar-Barra $barraFim } catch { } })
$form.Add_ResizeEnd({ try { Ajustar-Margens; Ajustar-Barra $barraRes; Ajustar-Barra $barraFim; $form.Invalidate($true) } catch { } })
$pnlPC.Add_SizeChanged({ $script:TimerResize.Stop(); $script:TimerResize.Start() })

# Fechar a janela
$form.Add_FormClosing({
    param($remetente, $e)
    if ($script:Async -and -not $script:Async.IsCompleted) {
        $msg = 'Há uma operação em andamento. Fechar agora pode deixar uma correção pela metade. Fechar mesmo assim?'
        $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Telomera', 'YesNo', 'Warning', 'Button2')
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { $e.Cancel = $true }
    }
})
$form.Add_FormClosed({
    try { $script:Timer.Stop() } catch { }
    [Environment]::Exit(0)
})

try {
    [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
    [System.Windows.Forms.Application]::add_ThreadException({ param($s, $e) Registrar-Erro $e.Exception })
} catch { }

$form.Add_Shown({ Reposicionar })

# ----------------------------------------------------------------------------
# Início
# ----------------------------------------------------------------------------
try {
    Traduzir-Controles $form
    Show-Pagina $pgInicio
    $script:Timer.Start()
    if ($env:WINDIAG_GUI_FUMACA -eq '1') {
        # Teste de fumaça (usado na integração contínua, no Windows PowerShell 5.1): monta a janela, as telas e os cartões com dados
        # de exemplo e sai com código 0 (tudo certo) ou 1 (alguma etapa falhou). Não altera o computador nem os atalhos.
        $falhasF = New-Object System.Collections.Generic.List[string]
        function Test-EtapaF { param([string]$Nome, [scriptblock]$Corpo)
            try { $r = & $Corpo; if ($r -eq $false) { $falhasF.Add("FALHA: $Nome"); Write-Host "FALHA  $Nome" } else { Write-Host "OK     $Nome" } }
            catch { $falhasF.Add("ERRO: $Nome -> $($_.Exception.Message)"); Write-Host "ERRO   $Nome -> $($_.Exception.Message)" }
        }
        function Find-LabelF { param($Pai, [string]$Trecho) foreach ($c in $Pai.Controls) { if ($c -is [System.Windows.Forms.Label] -and "$($c.Text)" -like "*$Trecho*") { return $true }; if ($c.Controls.Count -gt 0 -and (Find-LabelF $c $Trecho)) { return $true } }; return $false }
        Test-EtapaF 'janela abre' { $form.Show(); [System.Windows.Forms.Application]::DoEvents(); Reposicionar; $form.Visible }
        Test-EtapaF 'barra lateral da tela inicial com dados reais' {
            $script:DadosPcIni = @(Get-ResumoPcRapido); Montar-PcInicio 'dados'
            ($script:DadosPcIni.Count -gt 0) -and ($fluxoLado.Controls.Count -gt 3) -and -not (Find-LabelF $fluxoLado 'Não foi possível')
        }
        Test-EtapaF 'resultados com cartões de exemplo' {
            $li = New-Object System.Collections.Generic.List[object]; $li.Add(@{ R = 'Processador'; V = 'teste'; Nivel = 'ok' }); $li.Add(@{ R = 'Vídeo'; V = 'teste 2'; Nivel = 'aviso' })
            $lb = New-Object System.Collections.Generic.List[object]; $lb.Add(@{ Rotulo = 'C:'; Texto = '10 GB livres de 100 GB'; Fracao = 0.9; Nivel = 'perigo' })
            $s1 = @{ Chave = 'pc'; Titulo = 'Computador'; Destaque = 'PC de teste'; Sub = 'Windows'; Itens = $li; Barras = $lb }
            $s2 = @{ Chave = 'drivers'; Titulo = 'Drivers'; Destaque = 'Tudo em ordem'; Sub = ''; Itens = (New-Object System.Collections.Generic.List[object]); Barras = (New-Object System.Collections.Generic.List[object]) }
            $a1 = [pscustomobject]@{ Gravidade = 'Atencao'; Categoria = 'Drivers'; Titulo = 'Aviso de teste'; Detalhe = 'detalhe'; Solucao = 'solução'; Links = @(); Explicacao = 'explicação'; Veredito = 'Depende'; Reparo = 'Manual' }
            $a2 = [pscustomobject]@{ Gravidade = 'Info'; Categoria = 'Sistema'; Titulo = 'Informativo de teste'; Detalhe = 'detalhe'; Solucao = ''; Links = @(); Explicacao = ''; Veredito = ''; Reparo = 'Manual' }
            $R = @{ Ok = $true; Achados = @($a1, $a2); NAcoes = 0; NDesfaz = 0; ResumoPC = 'resumo'; PC = @($s1, $s2); Comparacao = ''; NotaTexto = ''; NotaValor = -1; NotaRotulo = ''; Html = $null; Pasta = $null }
            Mostrar-Resultados $R; [System.Windows.Forms.Application]::DoEvents(); $true
        }
        Test-EtapaF 'aba Meu computador (listas List[object])' { Show-Aba 1; [System.Windows.Forms.Application]::DoEvents(); ($pnlPC.Controls.Count -gt 0) -and -not (Find-LabelF $pnlPC 'não foi possível mostrar') }
        Test-EtapaF 'abas Problemas e Detalhes' { Show-Aba 0; Show-Aba 2; Show-Aba 0; $true }
        foreach ($ar in $script:AreasFerr) { $idA = $ar.Id; Test-EtapaF "área de ferramentas: $idA" { Abrir-Area $idA; [System.Windows.Forms.Application]::DoEvents(); $true } }
        Test-EtapaF 'configurações' { Show-Pagina $pgCfg; [System.Windows.Forms.Application]::DoEvents(); $true }
        Test-EtapaF 'volta à tela inicial' { Show-Pagina $pgInicio; Reposicionar; $true }
        # Imagens das telas (opcional): WINDIAG_GUI_PRINTS=<pasta>. Salva cada tela em janela normal e maximizada, para conferir o layout sem olhar a tela.
        $dirP = $env:WINDIAG_GUI_PRINTS
        if ($dirP) {
            try { New-Item -ItemType Directory -Force -Path $dirP | Out-Null } catch { }
            function Print-F { param($Alvo, [string]$Nome)
                try {
                    $w = [int]$Alvo.Width; $h = [int]$Alvo.Height
                    $bmp = New-Object System.Drawing.Bitmap($w, $h)
                    $Alvo.DrawToBitmap($bmp, (New-Object System.Drawing.Rectangle(0, 0, $w, $h)))
                    $bmp.Save((Join-Path $dirP ($Nome + '.png')), [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
                    Write-Host "IMAGEM $Nome ($w x $h)"
                } catch { Write-Host "ERRO imagem $Nome -> $($_.Exception.Message)" }
            }
            foreach ($tam in @('janela', 'cheia')) {
                try {
                    if ($tam -eq 'janela') { $form.WindowState = 'Normal'; $form.Size = New-Object System.Drawing.Size((PX 1100), (PX 720)) } else { $form.WindowState = 'Maximized' }
                    [System.Windows.Forms.Application]::DoEvents(); Reposicionar; [System.Windows.Forms.Application]::DoEvents()
                    Show-Pagina $pgInicio; Reposicionar; [System.Windows.Forms.Application]::DoEvents(); Print-F $form "$tam-1-inicio"
                    # Janela de escolha da verificação: um temporizador a fotografa e a fecha
                    $script:TamP = $tam; $script:TmrP = New-Object System.Windows.Forms.Timer; $script:TmrP.Interval = 900
                    $script:TmrP.Add_Tick({ $script:TmrP.Stop(); try { $af = [System.Windows.Forms.Form]::ActiveForm; if ($af -and $af -ne $form) { Print-F $af ($script:TamP + '-2-escolha-verificacao'); $af.Close() } else { Write-Host 'ERRO: janela de escolha nao encontrada' } } catch { Write-Host "ERRO escolha -> $($_.Exception.Message)" } })
                    $script:TmrP.Start(); [void](Show-EscolhaVerificacao); $script:TmrP.Dispose()
                    Show-Pagina $pgRes; try { Ajustar-Barra $barraRes; Montar-Cards } catch { Write-Host "ERRO ajuste -> $($_.Exception.Message)" }; Show-Aba 0; [System.Windows.Forms.Application]::DoEvents(); Print-F $form "$tam-3-resultados-problemas"
                    Show-Aba 1; [System.Windows.Forms.Application]::DoEvents(); Print-F $form "$tam-4-meu-computador"
                    Show-Aba 2; [System.Windows.Forms.Application]::DoEvents(); Print-F $form "$tam-5-detalhes"
                    $iA = 0
                    foreach ($ar in $script:AreasFerr) { $iA++; Abrir-Area $ar.Id; [System.Windows.Forms.Application]::DoEvents(); Print-F $form ("{0}-6-ferramentas-{1:00}-{2}" -f $tam, $iA, $ar.Id) }
                    Show-Pagina $pgCfg; [System.Windows.Forms.Application]::DoEvents(); Print-F $form "$tam-7-configuracoes"
                } catch { Write-Host "ERRO imagens ($tam) -> $($_.Exception.Message)" }
            }
        }
        $form.Close()
        $codigoF = $(if ($falhasF.Count -eq 0) { 0 } else { 1 })
        Write-Host ("FUMACA: {0} falha(s)" -f $falhasF.Count)
        [Environment]::Exit($codigoF)
    }
    $form.Add_Shown({ try { Start-LeituraPcInicio; Update-IconeAtalhos } catch { } })
    [System.Windows.Forms.Application]::Run($form)
} catch {
    Registrar-Erro $_
}
