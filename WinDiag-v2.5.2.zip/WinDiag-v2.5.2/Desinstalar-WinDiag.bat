@echo off
title Desinstalar o WinDiag
rem Abre a janela de desinstalacao (sem janela preta). Para o modo texto: Desinstalar-WinDiag.ps1 -SemPerguntas
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0Desinstalar-WinDiag.ps1"
