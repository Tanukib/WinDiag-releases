﻿<#
.SYNOPSIS
    Procura e instala a versão mais recente do WinDiag (baixa o pacote oficial e confere o SHA-256).

.DESCRIPTION
    Usado pelo botão "Procurar atualização" do WinDiag e pelo Instalar-WinDiag.bat quando ele é enviado sozinho.
    O endereço do canal de versões fica em $UrlBase. Nada é enviado sobre o seu computador.

.PARAMETER SoVerificar
    Só informa se há versão nova (código de saída 10 = há versão nova, 0 = já está atualizado, 1 = falhou).
#>
param([switch]$SoVerificar, [string]$VersaoAtual = '0', [switch]$SemPerguntas, [switch]$Reabrir)

#region nucleo
$ErrorActionPreference = 'Stop'
$UrlBase = 'https://raw.githubusercontent.com/Tanukib/WinDiag-releases/main'
if ($env:WD_TESTE_URL_BASE) { $UrlBase = $env:WD_TESTE_URL_BASE }   # só para os testes automáticos
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$ua = @{ 'User-Agent' = 'WinDiag-Instalador' }

function Get-UltimaVersao {
    # Lê latest.json do canal de versões: @{ versao; arquivo; sha256 }
    $r = Invoke-WebRequest -Uri "$UrlBase/latest.json" -UseBasicParsing -Headers $ua -TimeoutSec 30
    $txt = $r.Content
    if ($txt -is [byte[]]) { $txt = [Text.Encoding]::UTF8.GetString($txt) }
    $j = $txt.TrimStart([char]0xFEFF) | ConvertFrom-Json
    if (-not $j.versao -or -not $j.arquivo -or -not $j.sha256) { throw 'O arquivo latest.json está incompleto.' }
    if ($j.arquivo -notmatch '^WinDiag-v[0-9][0-9A-Za-z.\-]*\.zip$') { throw 'Nome de pacote inesperado no latest.json.' }
    return $j
}

function Get-PacoteWinDiag {
    # Baixa o ZIP, confere o SHA-256 e extrai em $Pasta. Devolve a pasta que contém o WinDiag-GUI.ps1.
    param($Info, [string]$Pasta)
    New-Item -ItemType Directory -Force -Path $Pasta | Out-Null
    $zip = Join-Path $Pasta $Info.arquivo
    Invoke-WebRequest -Uri "$UrlBase/$($Info.arquivo)" -OutFile $zip -UseBasicParsing -Headers $ua -TimeoutSec 300
    $real = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
    if ($real -ne ([string]$Info.sha256).ToLower()) { throw 'O arquivo baixado não confere com o SHA-256 esperado. Nada foi instalado.' }
    $dest = Join-Path $Pasta 'pacote'
    Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
    $gui = Get-ChildItem -LiteralPath $dest -Recurse -Filter 'WinDiag-GUI.ps1' | Select-Object -First 1
    if (-not $gui) { throw 'O pacote baixado não contém o WinDiag.' }
    return $gui.DirectoryName
}

function Test-VersaoNova {
    param([string]$Atual, [string]$Nova)
    try { return ([version]($Nova -replace '[^0-9.].*$', '')) -gt ([version]($Atual -replace '[^0-9.].*$', '')) } catch { return ($Nova -ne $Atual) }
}
#endregion nucleo

try {
    Write-Host 'Procurando a versão mais recente do WinDiag...' -ForegroundColor Cyan
    $info = Get-UltimaVersao
    $nova = Test-VersaoNova -Atual $VersaoAtual -Nova ([string]$info.versao)
    if ($SoVerificar) {
        Write-Host ("Versão mais recente: {0}  (instalada: {1})" -f $info.versao, $VersaoAtual)
        if ($nova) { exit 10 } else { exit 0 }
    }
    if (-not $nova -and $VersaoAtual -ne '0') {
        Write-Host "Você já está com a versão mais recente ($($info.versao))." -ForegroundColor Green
        exit 0
    }
    $tmp = Join-Path $env:TEMP ('WinDiag-atualizar-' + [guid]::NewGuid().ToString('N'))
    try {
        Write-Host "Baixando o WinDiag $($info.versao)..." -ForegroundColor Cyan
        $pasta = Get-PacoteWinDiag -Info $info -Pasta $tmp
        $inst = Join-Path $pasta 'Instalar-WinDiag.ps1'
        if (-not (Test-Path -LiteralPath $inst)) { throw 'O pacote não tem o instalador.' }
        if ($SemPerguntas) { & $inst -SemPerguntas } else { & $inst }
        if ($Reabrir) {
            # Reabre o WinDiag já atualizado (o programa se fechou para permitir a troca dos arquivos)
            $abrir = Join-Path $env:LOCALAPPDATA 'Programs\WinDiag\Abrir-WinDiag.bat'
            if (Test-Path -LiteralPath $abrir) {
                Write-Host 'Reabrindo o WinDiag...' -ForegroundColor Cyan
                Start-Sleep -Seconds 2
                Start-Process -FilePath $abrir -WindowStyle Hidden
            }
        }
    } finally {
        try { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    }
} catch {
    Write-Host ''
    Write-Host "Não foi possível concluir: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Verifique a conexão com a internet e tente de novo.'
    exit 1
}
