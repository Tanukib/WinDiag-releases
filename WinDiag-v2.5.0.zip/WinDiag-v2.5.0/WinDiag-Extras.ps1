﻿# WinDiag-Extras.ps1
# Verificações extras (telas azuis, segurança, bateria, espaço, rede), ferramentas de reparo e restauração,
# comparação com a verificação anterior e histórico de alterações.
# Carregado pelo WinDiag.ps1 (depois das funções principais). Usa Add-Achado, Add-Acao, Confirm-Acao e Add-Alteracao do motor.

# ----------------------------------------------------------------------------
# Dados persistentes (ficam em %LOCALAPPDATA%\WinDiag)
# ----------------------------------------------------------------------------
function Get-ArquivoDados {
    param([string]$Nome)
    $base = $env:WD_DADOS_DIR
    if (-not $base) {
        $la = $env:LOCALAPPDATA
        if (-not $la) { $la = [IO.Path]::GetTempPath() }
        $base = Join-Path $la 'WinDiag'
    }
    return (Join-Path $base $Nome)
}

function Save-LogAlteracao {
    # Acrescenta uma linha por alteração em alteracoes.jsonl: é o histórico de tudo que o WinDiag já mudou neste computador.
    param([string]$Acao, [string]$Resultado, [string]$Quando)
    try {
        $f = Get-ArquivoDados 'alteracoes.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $linha = (@{ Quando = $Quando; Acao = $Acao; Resultado = $Resultado } | ConvertTo-Json -Compress)
        [IO.File]::AppendAllText($f, $linha + "`r`n", (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Get-HistoricoAlteracoes {
    $f = Get-ArquivoDados 'alteracoes.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-DicaDesfazer {
    # Como desfazer, conforme o tipo de alteração.
    param([string]$Acao)
    if ($Acao -match '(?i)bloqueio|exclus') { return 'Para desfazer: "Desfazer bloqueios de driver do WinDiag" (opções avançadas da tela inicial).' }
    if ($Acao -match '(?i)driver|pacote|restaurar c') { return 'Para desfazer: "Desfazer correções (restaurar drivers salvos)" ou a Restauração do Sistema.' }
    if ($Acao -match '(?i)tempor|limpeza') { return 'Não há como desfazer: eram arquivos temporários, que o Windows recria quando precisa.' }
    if ($Acao -match '(?i)backup|c.pia dos arquivos') { return 'Não altera nada no computador: é só uma cópia de arquivos.' }
    if ($Acao -match '(?i)rede|winsock|dns') { return 'Normalmente não precisa desfazer. Se perdeu uma configuração de rede fixa, refaça-a nas propriedades do adaptador.' }
    return 'Para desfazer: Restauração do Sistema, escolhendo o ponto criado antes da correção.'
}

function Format-TextoHistoricoAlteracoes {
    $itens = @(Get-HistoricoAlteracoes)
    if ($itens.Count -eq 0) { return 'O WinDiag ainda não alterou nada neste computador.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("O WinDiag fez $($itens.Count) alteração(ões) neste computador (da mais recente para a mais antiga):")
    $L.Add('')
    foreach ($i in ($itens | Sort-Object { "$($_.Quando)" } -Descending | Select-Object -First 200)) {
        $L.Add("$($i.Quando)  -  $($i.Acao)")
        $L.Add("    Resultado: $($i.Resultado)")
        $L.Add("    $(Get-DicaDesfazer $i.Acao)")
        $L.Add('')
    }
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Comparação com a verificação anterior
# ----------------------------------------------------------------------------
function Get-ChaveAchado {
    param([string]$Titulo)
    return ((("$Titulo" -replace '\d+', '#') -replace '\s+', ' ').Trim().ToLowerInvariant())
}

function Get-ComparacaoVerificacoes {
    # Compara os achados (atenção e críticos) desta verificação com os da anterior. $null se não há anterior.
    $f = Get-ArquivoDados 'ultima_verificacao.json'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { $ant = Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
    if (-not $ant -or -not $ant.Achados) { return $null }
    $atuais = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })
    $chavesAtuais = @{}
    foreach ($a in $atuais) { $chavesAtuais[(Get-ChaveAchado $a.Titulo)] = $a.Titulo }
    $chavesAnt = @{}
    foreach ($a in @($ant.Achados)) { $chavesAnt["$($a.Chave)"] = "$($a.Titulo)" }
    $novos = @($chavesAtuais.Keys | Where-Object { -not $chavesAnt.ContainsKey($_) } | ForEach-Object { $chavesAtuais[$_] })
    $resolvidos = @($chavesAnt.Keys | Where-Object { -not $chavesAtuais.ContainsKey($_) } | ForEach-Object { $chavesAnt[$_] })
    $persistem = @($chavesAtuais.Keys | Where-Object { $chavesAnt.ContainsKey($_) }).Count
    return @{ Data = "$($ant.Data)"; Novos = $novos; Resolvidos = $resolvidos; Persistem = $persistem }
}

function Save-UltimaVerificacao {
    try {
        $f = Get-ArquivoDados 'ultima_verificacao.json'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $lista = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' } | ForEach-Object {
            @{ Chave = (Get-ChaveAchado $_.Titulo); Titulo = $_.Titulo; Gravidade = $_.Gravidade }
        })
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Achados = $lista }
        ($o | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $f -Encoding UTF8
    } catch { }
    Save-NotaSaude
}

function Format-TextoComparacao {
    param($C)
    if (-not $C) { return '' }
    $p = @()
    if (@($C.Novos).Count -gt 0) { $p += "$(@($C.Novos).Count) novo(s)" }
    if (@($C.Resolvidos).Count -gt 0) { $p += "$(@($C.Resolvidos).Count) resolvido(s)" }
    if ($C.Persistem -gt 0) { $p += "$($C.Persistem) continua(m)" }
    if ($p.Count -eq 0) { return "Em relação à verificação de $($C.Data): nenhum ponto de atenção, antes e agora." }
    return "Em relação à verificação de $($C.Data): " + ($p -join ', ') + '.'
}

function ConvertTo-HtmlComparacao {
    param($C)
    if (-not $C) { return '<p class="vazio">Esta é a primeira verificação guardada neste computador.</p>' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<p>' + [System.Net.WebUtility]::HtmlEncode((Format-TextoComparacao $C)) + '</p>')
    if (@($C.Novos).Count -gt 0) {
        [void]$sb.Append('<p><b>Novos:</b></p><ul>')
        foreach ($t in $C.Novos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    if (@($C.Resolvidos).Count -gt 0) {
        [void]$sb.Append('<p><b>Resolvidos:</b></p><ul>')
        foreach ($t in $C.Resolvidos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    return $sb.ToString()
}

# ----------------------------------------------------------------------------
# Nota de saúde (0 a 100) e tendência ao longo das verificações
# ----------------------------------------------------------------------------
function Get-NotaSaude {
    # Nota simples a partir dos achados desta verificação. É um guia, não um laudo.
    # Crítico desconta 12 e atenção 4; se o achado é "provavelmente normal" ou opcional, desconta um quarto.
    # Cada categoria desconta no máximo 30, para que uma enxurrada de avisos do mesmo tipo não zere a nota.
    param()
    $porCat = @{}
    $nc = 0; $na = 0
    foreach ($a in @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })) {
        $p = if ($a.Gravidade -eq 'Critico') { 12 } else { 4 }
        if ($a.Gravidade -eq 'Critico') { $nc++ } else { $na++ }
        if ($a.Veredito -eq 'Normal' -or $a.Veredito -eq 'Opcional') { $p = [Math]::Ceiling($p / 4) }
        $cat = "$($a.Categoria)"
        if (-not $porCat.ContainsKey($cat)) { $porCat[$cat] = 0 }
        $porCat[$cat] += $p
    }
    $desc = 0
    foreach ($v in $porCat.Values) { $desc += [Math]::Min(30, [int]$v) }
    $nota = [int][Math]::Max(0, 100 - $desc)
    if ($nota -ge 90) { $rot = 'Ótima' } elseif ($nota -ge 75) { $rot = 'Boa' } elseif ($nota -ge 55) { $rot = 'Merece atenção' } else { $rot = 'Precisa de cuidado' }
    return @{ Nota = $nota; Rotulo = $rot; Criticos = $nc; Atencoes = $na }
}

function Get-HistoricoNotas {
    $f = Get-ArquivoDados 'saude.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-NotaAtual {
    # Calcula a nota desta verificação e guarda a nota anterior (lida do histórico uma única vez por execução).
    $script:NotaSaude = Get-NotaSaude
    if (-not $script:NotaAnteriorLida) {
        $script:NotaAnteriorLida = $true
        $h = @(Get-HistoricoNotas)
        if ($h.Count -gt 0) { $script:NotaAnterior = $h[$h.Count - 1] } else { $script:NotaAnterior = $null }
    }
    return $script:NotaSaude
}

function Save-NotaSaude {
    try {
        $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
        $f = Get-ArquivoDados 'saude.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $origem = if ($script:Agendada) { 'agendada' } else { 'manual' }
        $linha = (@{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Nota = $n.Nota; Rotulo = $n.Rotulo; Criticos = $n.Criticos; Atencoes = $n.Atencoes; Origem = $origem } | ConvertTo-Json -Compress)
        $todas = @()
        if (Test-Path -LiteralPath $f) { $todas = @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() }) }
        $todas = @($todas + $linha)
        if ($todas.Count -gt 100) { $todas = $todas[($todas.Count - 100)..($todas.Count - 1)] }
        [IO.File]::WriteAllText($f, (($todas -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Format-TextoNota {
    # "Nota de saúde: 82/100 (Boa), 5 pontos acima da verificação anterior."
    param($N = $script:NotaSaude, $Anterior = $script:NotaAnterior)
    if (-not $N) { return '' }
    $t = "Nota de saúde do computador: $($N.Nota)/100 ($($N.Rotulo))"
    if ($Anterior -and $null -ne $Anterior.Nota) {
        $d = [int]$N.Nota - [int]$Anterior.Nota
        if ($d -gt 0) { $t += ", $d ponto(s) acima da verificação anterior" }
        elseif ($d -lt 0) { $t += ", $(-$d) ponto(s) abaixo da verificação anterior" }
        else { $t += ', igual à verificação anterior' }
    }
    return $t + '.'
}

function ConvertTo-HtmlNota {
    $n = Get-NotaAtual
    $txt = [System.Net.WebUtility]::HtmlEncode((Format-TextoNota))
    return "<p><b>$txt</b></p><p class=`"vazio`">A nota é só um guia: começa em 100 e perde pontos por problema encontrado (mais por críticos, menos por avisos que costumam ser normais). Não substitui a leitura dos itens.</p>"
}

function Get-BarraNota {
    param([int]$Nota)
    $n = [Math]::Max(0, [Math]::Min(100, $Nota))
    $cheio = [int][Math]::Round($n / 10)
    return ([string]([char]0x2588) * $cheio) + ([string]([char]0x2591) * (10 - $cheio))
}

function Format-TextoHistoricoNotas {
    $h = @(Get-HistoricoNotas)
    if ($h.Count -eq 0) { return 'Ainda não há verificações guardadas. Depois da primeira verificação, a nota aparece aqui.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("Nota de saúde do computador nas últimas verificações (da mais recente para a mais antiga):")
    $L.Add('')
    $ult = $h | Select-Object -Last 20
    $lista = @($ult)
    for ($i = $lista.Count - 1; $i -ge 0; $i--) {
        $x = $lista[$i]
        $seta = ''
        if ($i -gt 0) {
            $d = [int]$x.Nota - [int]$lista[$i - 1].Nota
            if ($d -gt 0) { $seta = "  (+$d)" } elseif ($d -lt 0) { $seta = "  ($d)" }
        }
        $orig = if ("$($x.Origem)" -eq 'agendada') { ' [automática]' } else { '' }
        $L.Add(("{0}   {1}  {2,3}/100  {3}{4}{5}" -f $x.Data, (Get-BarraNota ([int]$x.Nota)), [int]$x.Nota, $x.Rotulo, $seta, $orig))
    }
    $L.Add('')
    $L.Add('A nota começa em 100 e perde pontos por problema encontrado. É um guia para acompanhar a tendência, não um laudo.')
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Verificação semanal automática (somente leitura) e aviso quando a saúde piora
# ----------------------------------------------------------------------------
$script:NomeTarefa = 'WinDiag - verificação semanal'

function Get-TarefaAgendada {
    try { return (Get-ScheduledTask -TaskName $script:NomeTarefa -ErrorAction Stop) } catch { return $null }
}

function Get-TextoTarefaAgendada {
    $t = Get-TarefaAgendada
    if (-not $t) { return 'A verificação semanal automática está desativada.' }
    $prox = ''
    try {
        $i = Get-ScheduledTaskInfo -TaskName $script:NomeTarefa -ErrorAction Stop
        if ($i.NextRunTime -and $i.NextRunTime.Year -gt 2000) { $prox = ' Próxima execução: ' + $i.NextRunTime.ToString('dd/MM/yyyy HH:mm') + '.' }
    } catch { }
    return 'A verificação semanal automática está ativada.' + $prox
}

function Enable-VerificacaoAgendada {
    # Cria a tarefa semanal. Ela só lê informações (WinDiag.ps1 -Agendada = somente leitura, sem internet, sem abrir relatório).
    param([string]$Dia = 'Sunday', [string]$Hora = '10:00')
    $dir = $PSScriptRoot
    if (-not $dir -and $global:WD_Opc) { $dir = [string]$global:WD_Opc.PastaScripts }
    $ps1 = Join-Path $dir 'WinDiag.ps1'
    if (-not $dir -or -not (Test-Path -LiteralPath $ps1)) { throw 'Não encontrei o WinDiag.ps1 para agendar.' }
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Agendada' -f $ps1
    $acao = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg -WorkingDirectory $dir
    $gatilho = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $Dia -At $Hora
    $cfg = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    $usuario = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $prin = New-ScheduledTaskPrincipal -UserId $usuario -LogonType Interactive -RunLevel Highest
    [void](Register-ScheduledTask -TaskName $script:NomeTarefa -Action $acao -Trigger $gatilho -Settings $cfg -Principal $prin `
        -Description 'WinDiag: verificação semanal somente leitura. Não altera nada no computador; avisa se a saúde piorar.' -Force -ErrorAction Stop)
}

function Disable-VerificacaoAgendada {
    if (Get-TarefaAgendada) { Unregister-ScheduledTask -TaskName $script:NomeTarefa -Confirm:$false -ErrorAction Stop }
}

function Get-ArquivoAviso { return (Get-ArquivoDados 'aviso.json') }

function Get-AvisoPendente {
    $f = Get-ArquivoAviso
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { return (Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json) } catch { return $null }
}

function Clear-AvisoPendente {
    try { $f = Get-ArquivoAviso; if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction Stop } } catch { }
}

function Show-AvisoBalao {
    param([string]$Titulo, [string]$Texto)
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ni.Icon = [System.Drawing.SystemIcons]::Shield
        $ni.Visible = $true
        $ni.BalloonTipTitle = $Titulo
        $ni.BalloonTipText = $Texto
        $ni.BalloonTipIcon = 'Warning'
        $ni.ShowBalloonTip(10000)
        Start-Sleep -Seconds 10
        $ni.Dispose()
    } catch { }
}

function Invoke-AvisoAgendado {
    # Depois da verificação automática: só avisa se a saúde piorou (nota caiu 5 pontos ou mais, ou há mais críticos).
    $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
    $ant = $script:NotaAnterior
    if (-not $ant -or $null -eq $ant.Nota) { return $false }
    $piorou = (([int]$n.Nota) -le ([int]$ant.Nota - 5)) -or (([int]$n.Criticos) -gt ([int]$ant.Criticos))
    if (-not $piorou) { return $false }
    $texto = "A verificação automática de hoje encontrou algo novo: a nota de saúde foi de $($ant.Nota) para $($n.Nota) ($($n.Rotulo)). Abra o WinDiag e rode uma verificação para ver os detalhes."
    try {
        $f = Get-ArquivoAviso
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Texto = $texto; Nota = [int]$n.Nota; NotaAnterior = [int]$ant.Nota; Pasta = "$($script:PastaRelatorioFinal)" }
        [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
    Show-AvisoBalao -Titulo 'WinDiag: a saúde do computador piorou' -Texto $texto
    return $true
}

function Remove-VerificacoesAgendadasAntigas {
    # As verificações automáticas ficam em %LOCALAPPDATA%\WinDiag\Agendadas; só as 4 mais recentes são mantidas.
    param([int]$Manter = 4)
    try {
        $base = Get-ArquivoDados 'Agendadas'
        if (-not (Test-Path -LiteralPath $base)) { return }
        $pastas = @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction Stop | Where-Object { $_.Name -like 'Verificacao_*' } | Sort-Object Name -Descending)
        foreach ($p in ($pastas | Select-Object -Skip $Manter)) { Remove-Item -LiteralPath $p.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    } catch { }
}

# ----------------------------------------------------------------------------
# Telas azuis (arquivos de despejo)
# ----------------------------------------------------------------------------
function Read-CodigoDump {
    # Lê o código da tela azul no cabeçalho do arquivo .dmp (formato do Windows de 64 bits e de 32 bits).
    param([string]$Caminho)
    try {
        $fs = [IO.File]::Open($Caminho, 'Open', 'Read', 'ReadWrite')
        try {
            $b = New-Object byte[] 0x48
            $n = $fs.Read($b, 0, $b.Length)
            if ($n -lt 0x40) { return $null }
        } finally { $fs.Dispose() }
        $sig = [Text.Encoding]::ASCII.GetString($b, 0, 8)
        if ($sig -eq 'PAGEDU64') { return ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x38)) }
        if ($sig -eq 'PAGEDUMP') { return ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x20)) }
    } catch { }
    return $null
}

function Invoke-AnaliseTelasAzuis {
    if (-not $env:SystemRoot) { return }
    $pasta = Join-Path $env:SystemRoot 'Minidump'
    $limite = (Get-Date).AddDays(-60)
    $arqs = @()
    try {
        if (Test-Path -LiteralPath $pasta) { $arqs = @(Get-ChildItem -LiteralPath $pasta -Filter *.dmp -File -ErrorAction Stop | Where-Object { $_.LastWriteTime -gt $limite }) }
    } catch {
        Write-Host '  Telas azuis: não consegui ler a pasta de despejos (precisa de administrador).' -ForegroundColor DarkGray
        return
    }
    if ($arqs.Count -eq 0) {
        Write-Host '  Telas azuis: nenhum arquivo de despejo nos últimos 60 dias.' -ForegroundColor Green
        return
    }
    $cont = @{}
    foreach ($a in $arqs) {
        $c = Read-CodigoDump $a.FullName
        if (-not $c) { $c = 'desconhecido' }
        if ($cont.ContainsKey($c)) { $cont[$c]++ } else { $cont[$c] = 1 }
    }
    $linhas = @($cont.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object {
        if ($_.Key -eq 'desconhecido') { "código não identificado (x$($_.Value))" }
        else { '{0} {1} (x{2})' -f $_.Key, (Get-DescricaoBugcheck $_.Key), $_.Value }
    })
    $ultimo = ($arqs | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    Add-Achado -Gravidade Atencao -Categoria 'Telas azuis' -Titulo "Telas azuis registradas: $($arqs.Count) nos últimos 60 dias" `
        -Detalhe ("Última em $ultimo. " + ($linhas -join ' | ')) `
        -Solucao 'Anote o código. Os mais comuns são causados por driver (atualize o de vídeo e o de rede), memória RAM (use o teste de desempenho) ou disco. Para ver qual driver causou, abra o arquivo .dmp em C:\Windows\Minidump com o BlueScreenView (NirSoft) ou o WinDbg.' `
        -Explicacao 'Cada arquivo na pasta Minidump é uma tela azul que realmente aconteceu. Uma ou duas, com motivo conhecido (queda de energia, driver recém-instalado), costumam ser normais; se se repetem, vale investigar o código mostrado.' `
        -Veredito 'Depende'
}

# ----------------------------------------------------------------------------
# Segurança e manutenção
# ----------------------------------------------------------------------------
function Invoke-AnaliseSeguranca {
    $avDefenderOk = $null
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $avDefenderOk = ([bool]$mp.AntivirusEnabled -and [bool]$mp.RealTimeProtectionEnabled)
        $idade = [int]$mp.AntivirusSignatureAge
        Write-Host ("  Windows Defender: {0}; assinaturas atualizadas há {1} dia(s)." -f $(if ($avDefenderOk) { 'ativo' } else { 'desativado' }), $idade)
        if ($avDefenderOk -and $idade -gt 7) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Assinaturas do antivírus com $idade dias" `
                -Solucao 'Abra a Segurança do Windows > Proteção contra vírus e ameaças > Atualizações de proteção e clique em Verificar atualizações.' -Veredito 'Corrigir' `
                -Explicacao 'O antivírus precisa de atualizações frequentes para reconhecer ameaças novas.'
        }
    } catch { }
    # Outro antivírus instalado?
    $outro = $null
    try {
        $av = @(Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop)
        $ativos = @($av | Where-Object { (([int]$_.productState -shr 12) -band 0xF) -eq 1 -and $_.displayName -notmatch 'Windows Defender' })
        if ($ativos.Count -gt 0) { $outro = ($ativos | Select-Object -First 1).displayName }
        if ($null -eq $avDefenderOk -and $av.Count -gt 0) {
            $dd = @($av | Where-Object { $_.displayName -match 'Windows Defender' } | Select-Object -First 1)
            if ($dd.Count -gt 0) { $avDefenderOk = ((([int]$dd[0].productState -shr 12) -band 0xF) -eq 1) }
        }
    } catch { }
    if ($outro) {
        Write-Host "  Antivírus em uso: $outro"
    } elseif ($avDefenderOk -eq $false) {
        Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo 'Nenhum antivírus está ativo' `
            -Solucao 'Ative a Segurança do Windows (Proteção contra vírus e ameaças > Ativar) ou instale um antivírus.' -Veredito 'Corrigir' `
            -Explicacao 'Sem antivírus ativo, o computador fica exposto a vírus e programas maliciosos.'
    } elseif ($null -eq $avDefenderOk) {
        Write-Host '  Antivírus: não consegui consultar o estado.' -ForegroundColor DarkGray
    }
    try {
        $fw = @(Get-NetFirewallProfile -ErrorAction Stop)
        $off = @($fw | Where-Object { -not $_.Enabled } | ForEach-Object { "$($_.Name)" })
        if ($off.Count -gt 0) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Firewall do Windows desativado ($($off -join ', '))" `
                -Solucao 'Ative o Firewall na Segurança do Windows > Firewall e proteção de rede, a menos que outro programa de segurança faça esse papel.' -Veredito 'Depende' `
                -Explicacao 'O firewall bloqueia acessos indesejados vindos da rede. Alguns pacotes de segurança de terceiros desligam o do Windows de propósito.'
        } else { Write-Host '  Firewall do Windows: ativo.' }
    } catch { }
}

function Invoke-AnaliseManutencao {
    if (Test-RebootPendente) {
        Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'Há uma reinicialização pendente' `
            -Solucao 'Reinicie o computador antes de instalar drivers ou fazer reparos.' -Veredito 'Corrigir' `
            -Explicacao 'O Windows já preparou uma atualização ou alteração que só termina depois de reiniciar. Enquanto isso, reparos e instalações podem falhar.'
    }
    try {
        $hf = @(Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop | Where-Object { $_.InstalledOn })
        if ($hf.Count -gt 0) {
            $ult = ($hf | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn
            $dias = [int]((Get-Date) - [datetime]$ult).TotalDays
            Write-Host ("  Última atualização do Windows instalada há {0} dia(s)." -f $dias)
            if ($dias -gt 90) {
                Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo "Nenhuma atualização do Windows instalada há $dias dias" `
                    -Solucao 'Abra Configurações > Atualização e Segurança e instale as atualizações pendentes.' -Veredito 'Corrigir' `
                    -Explicacao 'As atualizações trazem correções de segurança e de estabilidade. Ficar meses sem instalá-las deixa o computador vulnerável.'
            }
        }
    } catch { }
    try {
        $s = Get-Service -Name wuauserv -ErrorAction Stop
        if ($s.StartType -eq 'Disabled') {
            Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'O serviço do Windows Update está desativado' `
                -Solucao 'Use "Reparar o Windows Update" nas Ferramentas de reparo do WinDiag.' -Veredito 'Corrigir' `
                -Explicacao 'Com o serviço desativado, o Windows não recebe atualizações nem drivers.'
        }
    } catch { }
}

function Invoke-AnaliseBateria {
    try {
        $bat = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
        if ($bat.Count -eq 0) { return }
        $proj = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryStaticData -ErrorAction Stop)
        $cheia = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryFullChargedCapacity -ErrorAction Stop)
        if ($proj.Count -eq 0 -or $cheia.Count -eq 0) { return }
        $d = [double]$proj[0].DesignedCapacity; $f = [double]$cheia[0].FullChargedCapacity
        if ($d -le 0 -or $f -le 0) { return }
        $saude = [math]::Round(100 * $f / $d)
        $script:Dados['Bateria'] = @{ CapacidadeProjetadaMWh = $d; CapacidadeAtualMWh = $f; SaudePct = $saude }
        Write-Host "  Bateria: $saude% da capacidade original."
        if ($saude -lt 50) {
            Add-Achado -Gravidade Atencao -Categoria 'Bateria' -Titulo "A bateria só guarda $saude% da carga original" `
                -Solucao 'Considere trocar a bateria. O notebook continua funcionando ligado na tomada.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso. Abaixo de 50% a duração cai bastante.'
        } elseif ($saude -lt 70) {
            Add-Achado -Gravidade Info -Categoria 'Bateria' -Titulo "A bateria guarda $saude% da carga original" `
                -Solucao 'Desgaste normal para uma bateria usada; se a duração incomoda, avalie trocá-la.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso.'
        }
    } catch { }
}

function Get-TamanhoPasta {
    # Soma dos arquivos de uma pasta, com limite de tempo para não demorar em pastas enormes.
    param([string]$Pasta, [int]$LimiteSeg = 20, [int]$DiasMinimos = 0)
    $total = [int64]0
    if (-not (Test-Path -LiteralPath $Pasta)) { return $total }
    $fim = (Get-Date).AddSeconds($LimiteSeg)
    $corte = (Get-Date).AddDays(-$DiasMinimos)
    try {
        foreach ($f in (Get-ChildItem -LiteralPath $Pasta -Recurse -File -Force -ErrorAction SilentlyContinue)) {
            if ($f.LastWriteTime -lt $corte) { $total += $f.Length }
            if ((Get-Date) -gt $fim) { break }
        }
    } catch { }
    return $total
}

function Get-PastasTemporarios {
    $l = @()
    if ($env:TEMP) { $l += $env:TEMP }
    if ($env:SystemRoot) { $l += (Join-Path $env:SystemRoot 'Temp') }
    return @($l | Select-Object -Unique)
}

function Clear-Temporarios {
    # Apaga arquivos temporários com mais de 2 dias (os mais novos podem estar em uso). Devolve os bytes liberados.
    $liberado = [int64]0
    $corte = (Get-Date).AddDays(-2)
    foreach ($p in (Get-PastasTemporarios)) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        foreach ($f in (Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $corte })) {
            try { $t = $f.Length; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $liberado += $t } catch { }
        }
    }
    return $liberado
}

function Format-Tamanho {
    param([int64]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N0} MB' -f ($Bytes / 1MB)) }
    return ('{0:N0} KB' -f ($Bytes / 1KB))
}

function Invoke-AnaliseEspaco {
    $total = [int64]0
    foreach ($p in (Get-PastasTemporarios)) { $total += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
    Write-Host ("  Arquivos temporários com mais de 2 dias: {0}" -f (Format-Tamanho $total))
    $script:Dados['TemporariosBytes'] = $total
    if ($total -ge 1GB) {
        Add-Achado -Gravidade Info -Categoria 'Espaço' -Titulo ("Arquivos temporários ocupam {0}" -f (Format-Tamanho $total)) `
            -Solucao 'O WinDiag pode apagar os temporários antigos (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'Programas e o Windows deixam arquivos temporários que ninguém mais usa. Apagar os antigos é seguro e libera espaço.'
        Add-Acao -Descricao ("Apagar arquivos temporários antigos (cerca de {0})" -f (Format-Tamanho $total)) -Acao {
            $l = Clear-Temporarios
            Write-Host ("    Liberado: {0}" -f (Format-Tamanho $l)) -ForegroundColor Green
        }
    }
}

function Invoke-AnaliseInicializacao {
    try {
        $itens = @(Get-CimInstance Win32_StartupCommand -ErrorAction Stop)
        Write-Host "  Programas que iniciam com o Windows: $($itens.Count)"
        $script:Dados['Inicializacao'] = @($itens | ForEach-Object { [pscustomobject]@{ Nome = "$($_.Name)"; Comando = "$($_.Command)"; Local = "$($_.Location)" } })
        if ($itens.Count -gt 25) {
            Add-Achado -Gravidade Info -Categoria 'Desempenho' -Titulo "$($itens.Count) programas iniciam junto com o Windows" `
                -Solucao 'Abra o Gerenciador de Tarefas (Ctrl+Shift+Esc) > Inicializar e desative os que você não usa logo ao ligar.' -Veredito 'Opcional' `
                -Explicacao 'Muitos programas na inicialização deixam o computador mais lento para ligar. Desativar na inicialização não desinstala o programa.'
        }
    } catch { }
}

function Invoke-AnaliseRede {
    if ($SemWindowsUpdate) { Write-Host '  Teste de rede: pulado (opção de não usar a internet).' -ForegroundColor DarkGray; return }
    $ativos = @()
    try { $ativos = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' }) } catch { return }
    if ($ativos.Count -eq 0) {
        Add-Achado -Gravidade Info -Categoria 'Rede' -Titulo 'Nenhum adaptador de rede conectado' `
            -Solucao 'Se deveria haver internet, confira o cabo ou o Wi-Fi.' -Veredito 'Depende' -Explicacao 'O teste de rede só faz sentido com um adaptador conectado.'
        return
    }
    $ping = $false; $dns = $false
    try { $ping = [bool](Test-Connection -ComputerName 1.1.1.1 -Count 2 -Quiet -ErrorAction Stop) } catch { }
    try { $r = Resolve-DnsName -Name 'www.microsoft.com' -Type A -ErrorAction Stop; $dns = [bool]$r } catch { }
    Write-Host ("  Rede: conexão {0}; resolução de nomes (DNS) {1}." -f $(if ($ping) { 'ok' } else { 'falhou' }), $(if ($dns) { 'ok' } else { 'falhou' }))
    $script:Dados['Rede'] = @{ Ping = $ping; Dns = $dns }
    if ($ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'A internet responde, mas os nomes de sites não são resolvidos (DNS)' `
            -Solucao 'O WinDiag pode limpar o cache e reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'O computador alcança a internet, mas não consegue traduzir endereços como www.site.com. Costuma ser cache de DNS corrompido ou configuração de rede com problema.'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    } elseif (-not $ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'Sem acesso à internet apesar do adaptador conectado' `
            -Solucao 'Reinicie o roteador e o computador. Se continuar, o WinDiag pode reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Depende' `
            -Explicacao 'O adaptador está ligado, mas nada sai para a internet. Pode ser o provedor ou o roteador (fora do alcance do WinDiag) ou a configuração de rede do Windows (que o WinDiag corrige).'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    }
}

function Invoke-AnaliseVolumesChkdsk {
    # Oferece o CHKDSK completo (na reinicialização) quando a varredura online achou erros.
    $v = @($script:Dados['Volumes'])
    foreach ($x in $v) {
        if ($null -eq $x) { continue }
        if ($x.Tipo -eq 'Fixed' -and "$($x.Varredura)" -notin @('NoErrorsFound', 'não executada', 'requer administrador', 'falhou')) {
            $letra = "$($x.Unidade)"
            Add-Acao -Descricao "Agendar o CHKDSK completo ($letra /F /R) para a próxima reinicialização" -Geral -Arg $letra -Acao {
                param($l)
                Invoke-AgendarChkdsk -Unidade $l
            }
        }
    }
}

function Invoke-AgendarChkdsk {
    param([string]$Unidade)
    $saida = & cmd.exe /c "echo Y| chkdsk $Unidade /F /R" 2>&1
    @($saida) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "    $_" }
    Write-Host '    O CHKDSK roda sozinho na próxima vez que o computador for reiniciado (pode levar de minutos a horas).' -ForegroundColor Cyan
}

function Invoke-AnaliseExtras {
    Write-Titulo '4b) SEGURANÇA, MANUTENÇÃO E ESPAÇO'
    foreach ($par in @(
        @('Telas azuis', { Invoke-AnaliseTelasAzuis }),
        @('Segurança', { Invoke-AnaliseSeguranca }),
        @('Manutenção do Windows', { Invoke-AnaliseManutencao }),
        @('Bateria', { Invoke-AnaliseBateria }),
        @('Espaço', { Invoke-AnaliseEspaco }),
        @('Inicialização', { Invoke-AnaliseInicializacao }),
        @('Rede', { Invoke-AnaliseRede }),
        @('CHKDSK', { Invoke-AnaliseVolumesChkdsk })
    )) {
        try { & $par[1] } catch { Write-Host "  Verificação '$($par[0])' falhou e foi ignorada: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
}

# ----------------------------------------------------------------------------
# Ferramentas de reparo e restauração (manuais; cada uma pede confirmação)
# ----------------------------------------------------------------------------
function Reset-RedeWindows {
    foreach ($c in @('ipconfig /flushdns', 'netsh winsock reset', 'netsh int ip reset', 'netsh int ipv6 reset')) {
        Write-Host "    $c"
        $o = & cmd.exe /c "$c 2>&1"
        @($o) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
    }
    Write-Host '    Reinicie o computador para concluir a reinicialização da rede.' -ForegroundColor Cyan
}

function Reset-WindowsUpdate {
    $svcs = @('wuauserv', 'bits', 'cryptsvc', 'msiserver')
    foreach ($s in $svcs) { try { Stop-Service -Name $s -Force -ErrorAction Stop; Write-Host "    Parado: $s" -ForegroundColor DarkGray } catch { Write-Host "    Não consegui parar $s ($($_.Exception.Message))" -ForegroundColor Yellow } }
    $sufixo = '.bak_WinDiag_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    foreach ($p in @((Join-Path $env:SystemRoot 'SoftwareDistribution'), (Join-Path $env:SystemRoot 'System32\catroot2'))) {
        if (Test-Path -LiteralPath $p) {
            try { Rename-Item -LiteralPath $p -NewName ((Split-Path -Leaf $p) + $sufixo) -ErrorAction Stop; Write-Host "    Pasta renomeada: $p" -ForegroundColor Green }
            catch { Write-Host "    Não consegui renomear $p ($($_.Exception.Message))" -ForegroundColor Yellow }
        }
    }
    foreach ($s in $svcs) { try { Start-Service -Name $s -ErrorAction Stop } catch { Write-Host "    Não consegui iniciar $s" -ForegroundColor Yellow } }
    Write-Host '    O Windows recria as pastas sozinho; as antigas ficaram guardadas com a terminação .bak_WinDiag.' -ForegroundColor Cyan
}

function Repair-LojaWindows {
    $pacotes = @(Get-AppxPackage -AllUsers -Name 'Microsoft.WindowsStore' -ErrorAction SilentlyContinue)
    if ($pacotes.Count -eq 0) { Write-Host '    A Microsoft Store não está instalada neste Windows.' -ForegroundColor Yellow; return }
    foreach ($p in $pacotes) {
        $m = Join-Path $p.InstallLocation 'AppXManifest.xml'
        if (Test-Path -LiteralPath $m) {
            Add-AppxPackage -DisableDevelopmentMode -Register $m -ErrorAction Stop
            Write-Host '    Microsoft Store registrada novamente.' -ForegroundColor Green
        }
    }
}

function Get-ListaPontosRestauracao {
    $l = New-Object System.Collections.Generic.List[string]
    try {
        $pts = @(Get-ComputerRestorePoint -ErrorAction Stop)
        if ($pts.Count -eq 0) { $l.Add('Nenhum ponto de restauração encontrado (a Proteção do Sistema pode estar desativada).') }
        foreach ($p in ($pts | Sort-Object SequenceNumber -Descending)) {
            $quando = $p.CreationTime
            try { $quando = [Management.ManagementDateTimeConverter]::ToDateTime($p.CreationTime).ToString('dd/MM/yyyy HH:mm') } catch { }
            $l.Add("$quando  -  $($p.Description)")
        }
    } catch { $l.Add("Não consegui listar os pontos de restauração: $($_.Exception.Message)") }
    return ($l -join "`r`n")
}

function Invoke-Ferramenta {
    # Executa uma ferramenta e devolve @{ Ok; Titulo; Texto }.
    param([string]$Nome, [string]$Destino)
    $feito = New-Object System.Collections.Generic.List[string]
    $titulo = ''
    switch ($Nome) {
        'pontos-listar' {
            $titulo = 'Pontos de restauração do Windows'
            $feito.Add((Get-ListaPontosRestauracao))
            $feito.Add('')
            $feito.Add('Para voltar o Windows a um desses pontos, use a Restauração do Sistema (botão "Abrir a Restauração do Sistema").')
        }
        'pontos-criar' {
            $titulo = 'Criar ponto de restauração'
            if (Confirm-Acao 'Criar agora um ponto de restauração do sistema? (pode ativar a Proteção do Sistema na unidade do Windows)') {
                try {
                    Enable-ComputerRestore -Drive "$($env:SystemDrive)\" -ErrorAction Stop
                    Checkpoint-Computer -Description 'WinDiag (manual)' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado 'executado'
                    $feito.Add('Ponto de restauração criado.')
                } catch {
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado "falhou: $($_.Exception.Message)"
                    $feito.Add("Não foi possível criar o ponto: $($_.Exception.Message)")
                    $feito.Add('(O Windows limita a um ponto a cada 24 horas por padrão.)')
                }
            } else { $feito.Add('Nada foi feito.') }
        }
        'rede' {
            $titulo = 'Reparar a rede'
            if (Confirm-Acao 'Reiniciar a configuração de rede (limpa o DNS e reinicia o Winsock e o IP)? Configurações de IP fixo podem ser perdidas.') {
                try { Reset-RedeWindows; Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado 'executado'; $feito.Add('Configuração de rede reiniciada. Reinicie o computador para concluir.') }
                catch { Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'wu' {
            $titulo = 'Reparar o Windows Update'
            if (Confirm-Acao 'Reparar o Windows Update? Os serviços serão parados e as pastas temporárias do Windows Update renomeadas (o histórico de atualizações pode ser reiniciado).') {
                try { Reset-WindowsUpdate; Add-Alteracao -Acao 'Reparar o Windows Update (pastas SoftwareDistribution e catroot2)' -Resultado 'executado'; $feito.Add('Windows Update reparado. Reinicie e procure atualizações de novo.') }
                catch { Add-Alteracao -Acao 'Reparar o Windows Update' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'store' {
            $titulo = 'Reparar a Microsoft Store'
            if (Confirm-Acao 'Registrar novamente a Microsoft Store? (corrige loja que não abre ou não baixa)') {
                try { Repair-LojaWindows; Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado 'executado'; $feito.Add('Concluído. Abra a Microsoft Store para testar.') }
                catch { Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'chkdsk' {
            $titulo = 'Verificar o disco (CHKDSK)'
            $u = $env:SystemDrive
            if (-not $u) { $u = 'C:' }
            if (Confirm-Acao "Agendar a verificação completa do disco $u (CHKDSK /F /R)? Ela roda na próxima reinicialização e pode levar de minutos a horas." ) {
                try { Invoke-AgendarChkdsk -Unidade $u; Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado 'executado'; $feito.Add("Verificação do disco $u agendada. Reinicie o computador e aguarde: não desligue durante o processo.") }
                catch { Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'temp' {
            $titulo = 'Limpar arquivos temporários'
            $tam = [int64]0
            foreach ($p in (Get-PastasTemporarios)) { $tam += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
            if (Confirm-Acao ("Apagar os arquivos temporários com mais de 2 dias? (cerca de {0})" -f (Format-Tamanho $tam))) {
                $l = Clear-Temporarios
                Add-Alteracao -Acao 'Apagar arquivos temporários antigos' -Resultado ("liberado {0}" -f (Format-Tamanho $l))
                $feito.Add(("Liberado: {0}" -f (Format-Tamanho $l)))
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-ativar' {
            $titulo = 'Verificação semanal automática'
            if (Confirm-Acao 'Ativar a verificação semanal automática? Todo domingo, às 10:00 (ou na próxima vez que o computador estiver ligado), o WinDiag faz uma verificação rápida só de leitura, sem alterar nada e sem usar a internet. Você só é avisado se a saúde do computador piorar. Dá para desativar quando quiser.') {
                try { Enable-VerificacaoAgendada; Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado 'executado'; $feito.Add((Get-TextoTarefaAgendada)) }
                catch { Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-desativar' {
            $titulo = 'Verificação semanal automática'
            if (-not (Get-TarefaAgendada)) { $feito.Add('A verificação semanal automática já estava desativada.') }
            elseif (Confirm-Acao 'Desativar a verificação semanal automática?') {
                try { Disable-VerificacaoAgendada; Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado 'executado'; $feito.Add('Verificação semanal automática desativada.') }
                catch { Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-estado' {
            $titulo = 'Verificação semanal automática'
            $feito.Add((Get-TextoTarefaAgendada))
            $feito.Add('')
            $feito.Add('Como funciona: uma vez por semana o WinDiag faz uma verificação rápida só de leitura (sem corrigir nada e sem usar a internet). Se a nota de saúde cair 5 pontos ou mais, ou aparecer um problema crítico novo, você recebe um aviso. As 4 verificações automáticas mais recentes ficam em %LOCALAPPDATA%\WinDiag\Agendadas.')
        }
        'saude-historico' {
            $titulo = 'Nota de saúde ao longo do tempo'
            $feito.Add((Format-TextoHistoricoNotas))
        }
        'historico' {
            $titulo = 'O que o WinDiag já mudou neste computador'
            $feito.Add((Format-TextoHistoricoAlteracoes))
        }
        'backup' {
            $titulo = 'Cópia dos arquivos pessoais'
            $feito.Add((Invoke-BackupPessoal -Destino $Destino))
        }
        default { return @{ Ok = $false; Erro = "Ferramenta desconhecida: $Nome" } }
    }
    return @{ Ok = $true; Titulo = $titulo; Texto = ($feito -join "`r`n") }
}

function Invoke-BackupPessoal {
    # Copia Documentos, Imagens e Área de Trabalho para uma pasta escolhida (não altera nem apaga nada na origem).
    param([string]$Destino)
    if (-not $Destino -or -not (Test-Path -LiteralPath $Destino)) { return 'Nenhuma pasta de destino foi escolhida.' }
    $origens = @()
    foreach ($n in @('MyDocuments', 'MyPictures', 'Desktop')) {
        $p = [Environment]::GetFolderPath($n)
        if ($p -and (Test-Path -LiteralPath $p)) { $origens += $p }
    }
    $tam = [int64]0
    foreach ($o in $origens) { $tam += (Get-TamanhoPasta -Pasta $o -LimiteSeg 60) }
    $livre = 0
    try { $livre = (New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Destino))).AvailableFreeSpace } catch { }
    if ($livre -gt 0 -and $tam -gt ($livre * 0.95)) {
        return ("Não há espaço suficiente no destino: precisa de cerca de {0} e há {1} livres." -f (Format-Tamanho $tam), (Format-Tamanho $livre))
    }
    if (-not (Confirm-Acao ("Copiar Documentos, Imagens e Área de Trabalho (cerca de {0}) para '{1}'? Nada é apagado nem alterado na origem." -f (Format-Tamanho $tam), $Destino))) { return 'Nada foi feito.' }
    $raiz = Join-Path $Destino ('WinDiag_Backup_' + (Get-Date -Format 'yyyy-MM-dd_HH-mm'))
    New-Item -ItemType Directory -Force -Path $raiz | Out-Null
    $resumo = New-Object System.Collections.Generic.List[string]
    foreach ($o in $origens) {
        $alvo = Join-Path $raiz (Split-Path -Leaf $o)
        Write-Host "    Copiando $o ..."
        $argsRc = @("`"$o`"", "`"$alvo`"", '/E', '/XJ', '/R:1', '/W:1', '/MT:8', '/NFL', '/NDL', '/NP', '/XD', 'WinDiag')
        $proc = $null
        try {
            $proc = Start-Process -FilePath 'robocopy.exe' -ArgumentList $argsRc -PassThru -WindowStyle Hidden
            while (-not $proc.HasExited) { Start-Sleep -Milliseconds 700 }
            $cod = $proc.ExitCode
        } finally { try { if ($proc -and -not $proc.HasExited) { $proc.Kill() } } catch { } }
        if ($cod -lt 8) { $resumo.Add("OK: $o") } else { $resumo.Add("Com falhas (código $cod): $o") }
    }
    Add-Alteracao -Acao "Cópia dos arquivos pessoais para $raiz" -Resultado 'executado'
    return ("Cópia concluída em:`r`n$raiz`r`n`r`n" + ($resumo -join "`r`n"))
}
