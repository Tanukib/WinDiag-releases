﻿# WinDiag-Monitor.ps1
# Monitor em tempo real: lê os sensores que o HWiNFO, o MSI Afterburner e o LibreHardwareMonitor já publicam e grava um registro
# a cada poucos segundos. Se o computador desligar no meio de um jogo, o último registro mostra temperaturas e tensões do momento da queda.
# Só lê o que os programas publicam: não instala nem carrega driver. Roda em um processo próprio, escondido, até você parar.
param([switch]$Executar, [double]$Intervalo = 0.5)

function Initialize-Msi {
    # Compila o leitor do MSI Afterburner só quando for preciso (assim carregar este arquivo é instantâneo).
    if ('WDMsi' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;

public static class WDMsi
{
    // Memória compartilhada do MSI Afterburner ("MAHMSharedMemory"). Devolve {nome, unidade, valor} ou null se o programa não estiver publicando.
    static string Texto(byte[] b, int off, int len)
    {
        int n = 0;
        while (n < len && off + n < b.Length && b[off + n] != 0) n++;
        return System.Text.Encoding.Default.GetString(b, off, n).Trim();
    }

    public static List<string[]> LerBytes(byte[] b)
    {
        if (b == null || b.Length < 32) return null;
        uint sig = BitConverter.ToUInt32(b, 0);
        if (sig != 0x4D41484Du && sig != 0x4D48414Du) return null;   // "MAHM"
        uint ver = BitConverter.ToUInt32(b, 4), cab = BitConverter.ToUInt32(b, 8), n = BitConverter.ToUInt32(b, 12), tam = BitConverter.ToUInt32(b, 16);
        if (cab < 20 || cab > 4096 || n > 2000 || tam < 528 || tam > 8192) return null;
        if (cab + (long)n * tam > b.Length) return null;
        int offDado = ver >= 0x00020000u ? 1300 : 520;
        if (offDado + 4 > tam) return null;
        List<string[]> r = new List<string[]>();
        for (int i = 0; i < n; i++)
        {
            int o = (int)(cab + (long)i * tam);
            string nome = Texto(b, o, 260);
            if (nome.Length == 0) continue;
            float v = BitConverter.ToSingle(b, o + offDado);
            if (float.IsNaN(v) || float.IsInfinity(v) || Math.Abs(v) > 1e30f) continue;   // FLT_MAX = sem dado
            r.Add(new string[] { nome, Texto(b, o + 260, 260), ((double)v).ToString("R", System.Globalization.CultureInfo.InvariantCulture) });
        }
        return r;
    }

    public static List<string[]> Ler()
    {
        try
        {
            using (System.IO.MemoryMappedFiles.MemoryMappedFile mmf = System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting("MAHMSharedMemory", System.IO.MemoryMappedFiles.MemoryMappedFileRights.Read))
            using (System.IO.MemoryMappedFiles.MemoryMappedViewAccessor acc = mmf.CreateViewAccessor(0, 0, System.IO.MemoryMappedFiles.MemoryMappedFileAccess.Read))
            {
                byte[] h = new byte[32];
                acc.ReadArray(0, h, 0, 32);
                uint sig = BitConverter.ToUInt32(h, 0);
                if (sig != 0x4D41484Du && sig != 0x4D48414Du) return null;
                uint cab = BitConverter.ToUInt32(h, 8), n = BitConverter.ToUInt32(h, 12), tam = BitConverter.ToUInt32(h, 16);
                long total = cab + (long)n * tam;
                if (total < 32 || total > 8 * 1024 * 1024) return null;
                byte[] all = new byte[total];
                acc.ReadArray(0, all, 0, (int)total);
                return LerBytes(all);
            }
        }
        catch (Exception) { return null; }
    }
}
'@
}

$script:MonInv = [Globalization.CultureInfo]::InvariantCulture

#region arquivos e estado
function Get-PastaMonitor {
    if ($env:WD_MONITOR_DIR) { return $env:WD_MONITOR_DIR }
    $base = $env:LOCALAPPDATA
    if (-not $base) { $base = [IO.Path]::GetTempPath() }
    return (Join-Path $base 'WinDiag\Monitor')
}

#region sensores (HWiNFO e LibreHardwareMonitor)
function Get-PastaLhm {
    $base = $env:WD_DADOS_DIR
    if (-not $base) { $la = $env:LOCALAPPDATA; if (-not $la) { $la = [IO.Path]::GetTempPath() }; $base = Join-Path $la 'WinDiag' }
    return (Join-Path $base 'LibreHardwareMonitor')
}

function Get-CaminhoHwinfo {
    # Caminho do HWiNFO64.EXE (processo aberto, instalação ou pasta comum). $null se não achar.
    if ($env:OS -ne 'Windows_NT') { return $null }
    try { $pr = Get-Process -Name 'HWiNFO64', 'HWiNFO32' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($pr -and $pr.Path) { return $pr.Path } } catch { }
    foreach ($c in @((Join-Path $env:ProgramFiles 'HWiNFO64\HWiNFO64.EXE'), (Join-Path ${env:ProgramFiles(x86)} 'HWiNFO32\HWiNFO32.EXE'), (Join-Path $env:ProgramFiles 'HWiNFO32\HWiNFO32.EXE'))) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    return $null
}

function ConvertFrom-IniHwinfo {
    # Lê o texto do HWiNFO64.INI. Devolve @{ SensoresMemoria (bool); SoSensores (bool); Intervalo (ms) }.
    param([string]$Texto)
    $h = @{}
    foreach ($ln in ($Texto -split "`r?`n")) { if ($ln -match '^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$') { $h[$Matches[1]] = $Matches[2] } }
    $iv = 0; if ($h.ContainsKey('SensorInterval')) { [void][int]::TryParse($h['SensorInterval'], [ref]$iv) }
    return @{ SensoresMemoria = ($h['SensorsSM'] -eq '1'); SoSensores = ($h['SensorsOnly'] -eq '1'); Intervalo = $iv }
}

function Update-TextoIniHwinfo {
    # Devolve o texto do INI com a memória compartilhada ligada, abrindo só os sensores e atualizando a cada 500 ms (o resto fica como está).
    param([string]$Texto)
    $alvo = [ordered]@{ SensorsSM = '1'; SensorsOnly = '1'; SensorInterval = '500' }
    $linhas = New-Object System.Collections.Generic.List[string]
    foreach ($ln in ($Texto -split "`r?`n")) { $linhas.Add($ln) }
    while ($linhas.Count -gt 0 -and $linhas[$linhas.Count - 1] -eq '') { $linhas.RemoveAt($linhas.Count - 1) }
    $ini = -1; for ($i = 0; $i -lt $linhas.Count; $i++) { if ($linhas[$i] -match '^\s*\[Settings\]\s*$') { $ini = $i; break } }
    if ($ini -lt 0) { $linhas.Insert(0, '[Settings]'); $ini = 0 }
    $fim = $linhas.Count; for ($i = $ini + 1; $i -lt $linhas.Count; $i++) { if ($linhas[$i] -match '^\s*\[') { $fim = $i; break } }
    foreach ($k in $alvo.Keys) {
        $achou = $false
        for ($i = $ini + 1; $i -lt $fim; $i++) { if ($linhas[$i] -match ('^\s*' + $k + '\s*=')) { $linhas[$i] = "$k=$($alvo[$k])"; $achou = $true; break } }
        if (-not $achou) { $linhas.Insert($fim, "$k=$($alvo[$k])"); $fim++ }
    }
    return (($linhas -join "`r`n") + "`r`n")
}

function Get-EstadoSensores {
    # Foto rápida do que está disponível para ler sensores. Devolve @{ HwinfoCaminho; HwinfoAberto; HwinfoConfig; LhmPasta; LhmAberto }.
    $e = @{ HwinfoCaminho = $null; HwinfoAberto = $false; HwinfoConfig = $null; LhmPasta = $null; LhmAberto = $false }
    if ($env:OS -ne 'Windows_NT') { return $e }
    $e.HwinfoCaminho = Get-CaminhoHwinfo
    try { $e.HwinfoAberto = [bool](Get-Process -Name 'HWiNFO64', 'HWiNFO32' -ErrorAction SilentlyContinue) } catch { }
    if ($e.HwinfoCaminho) {
        $ini = [IO.Path]::ChangeExtension($e.HwinfoCaminho, 'INI')
        try { if (Test-Path -LiteralPath $ini) { $e.HwinfoConfig = ConvertFrom-IniHwinfo ([IO.File]::ReadAllText($ini)) } } catch { }
    }
    $pl = Get-PastaLhm
    if (Test-Path -LiteralPath (Join-Path $pl 'LibreHardwareMonitor.exe')) { $e.LhmPasta = $pl }
    try { $e.LhmAberto = [bool](Get-Process -Name 'LibreHardwareMonitor' -ErrorAction SilentlyContinue) } catch { }
    return $e
}

function Get-AvaliacaoSensores {
    # Texto curto para a interface e próximos passos. Devolve @{ Resumo; Passos; Pronto }.
    param($E)
    $passos = New-Object System.Collections.Generic.List[string]
    if ($E.HwinfoAberto -and $E.HwinfoConfig -and $E.HwinfoConfig.SensoresMemoria) {
        $iv = ''
        if ($E.HwinfoConfig.Intervalo -gt 1000) { $iv = ' O intervalo está em ' + $E.HwinfoConfig.Intervalo + ' ms: reduza para 500 ms para o registro acompanhar o jogo.'; $passos.Add('Ajustar o HWiNFO para 500 ms.') }
        return @{ Resumo = 'HWiNFO aberto e publicando sensores.' + $iv; Passos = $passos.ToArray(); Pronto = $true }
    }
    if ($E.HwinfoAberto) { $passos.Add('Ligar a memória compartilhada do HWiNFO.'); return @{ Resumo = 'HWiNFO aberto, mas sem a memória compartilhada ligada: o WinDiag não consegue ler.'; Passos = $passos.ToArray(); Pronto = $false } }
    if ($E.LhmAberto) { return @{ Resumo = 'LibreHardwareMonitor aberto: o WinDiag lê os sensores dele.'; Passos = @(); Pronto = $true } }
    if ($E.HwinfoCaminho) { $passos.Add('Abrir o HWiNFO com a configuração certa.'); return @{ Resumo = 'HWiNFO instalado, mas fechado. O monitor só lê temperaturas e tensões com ele aberto.'; Passos = $passos.ToArray(); Pronto = $false } }
    if ($E.LhmPasta) { $passos.Add('Abrir a LibreHardwareMonitor (como administrador).'); return @{ Resumo = 'LibreHardwareMonitor baixada, mas fechada.'; Passos = $passos.ToArray(); Pronto = $false } }
    $passos.Add('Instalar o HWiNFO (hwinfo.com) ou baixar a LibreHardwareMonitor pelo WinDiag.')
    return @{ Resumo = 'Nenhum programa de sensores encontrado. Sem eles o WinDiag só lê a placa de vídeo, o disco e o uso do processador.'; Passos = $passos.ToArray(); Pronto = $false }
}

#endregion

# Resumo rápido do computador para a tela inicial (antes de qualquer verificação). Só leitura, sem privilégios.
# ConvertTo-SecoesPcRapido é pura (recebe dados simples) para poder ser testada fora do Windows.
function ConvertTo-SecoesPcRapido {
    # $D: @{ Computador; Fabricante; Modelo; Windows; DiasLigado; Cpu; Nucleos; Threads; RamGB; RamMHz; Gpus (lista de nomes); Bios; Placa; Volumes (lista de @{ Unidade; TotalGB; LivreGB }) }
    param($D)
    $sec = @{ Chave = 'pc'; Titulo = 'Seu computador'; Destaque = '';  Sub = ''
              Itens = (New-Object System.Collections.Generic.List[object]); Barras = (New-Object System.Collections.Generic.List[object]) }
    $nome = ("$($D.Fabricante) $($D.Modelo)").Trim()
    if (-not $nome) { $nome = "$($D.Computador)" }
    $sec.Destaque = $nome
    $partes = @()
    if ($D.Windows) { $partes += "$($D.Windows)" }
    if ($null -ne $D.DiasLigado -and "$($D.DiasLigado)" -ne '') {
        $dl = [int]$D.DiasLigado
        $partes += $(if ($dl -le 0) { 'ligado desde hoje' } elseif ($dl -eq 1) { 'ligado há 1 dia' } else { "ligado há $dl dias" })
    }
    $sec.Sub = ($partes -join ' · ')
    if ($D.Cpu) { $sec.Itens.Add(@{ R = 'Processador'; V = ("{0}{1}" -f $D.Cpu, $(if ($D.Nucleos) { " ($($D.Nucleos) núcleos, $($D.Threads) threads)" } else { '' })) }) }
    if ($D.RamGB) { $sec.Itens.Add(@{ R = 'Memória'; V = ("{0} GB{1}" -f $D.RamGB, $(if ($D.RamMHz) { " a $($D.RamMHz) MHz" } else { '' })) }) }
    foreach ($g in @($D.Gpus)) { if ($g) { $sec.Itens.Add(@{ R = 'Vídeo'; V = "$g" }) } }
    if ($D.Placa) { $sec.Itens.Add(@{ R = 'Placa-mãe'; V = "$($D.Placa)" }) }
    if ($D.Bios) { $sec.Itens.Add(@{ R = 'BIOS/UEFI'; V = "$($D.Bios)" }) }
    foreach ($v in @($D.Volumes)) {
        if (-not $v -or -not $v.TotalGB -or [double]$v.TotalGB -le 0) { continue }
        $usado = 1.0 - ([double]$v.LivreGB / [double]$v.TotalGB)
        $livrePct = 100.0 * [double]$v.LivreGB / [double]$v.TotalGB
        $nv = $(if ($livrePct -lt 10) { 'perigo' } elseif ($livrePct -lt 20) { 'aviso' } else { 'ok' })
        $un = ("$($v.Unidade)" -replace ':', '')
        $sec.Barras.Add(@{ Rotulo = "${un}:"; Texto = ('{0} GB livres de {1} GB' -f [math]::Round([double]$v.LivreGB, 0), [math]::Round([double]$v.TotalGB, 0)); Fracao = $usado; Nivel = $nv })
    }
    return @($sec)
}

function Get-ResumoPcRapido {
    if ($env:OS -ne 'Windows_NT') { return @() }
    $D = @{ Gpus = @(); Volumes = @() }
    try { $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop; $D.Computador = "$($cs.Name)"; $D.Fabricante = "$($cs.Manufacturer)"; $D.Modelo = "$($cs.Model)" } catch { }
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $D.Windows = ("$($os.Caption)" -replace '^Microsoft\s+', '')
        $D.DiasLigado = [int][Math]::Floor(((Get-Date) - $os.LastBootUpTime).TotalDays)
    } catch { }
    try { $c = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1; $D.Cpu = ("$($c.Name)" -replace '\s+', ' ').Trim(); $D.Nucleos = $c.NumberOfCores; $D.Threads = $c.NumberOfLogicalProcessors } catch { }
    try {
        $ram = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $tot = 0.0; foreach ($r in $ram) { $tot += [double]$r.Capacity / 1GB }
        $D.RamGB = [math]::Round($tot, 0)
        $mhz = @($ram | ForEach-Object { if ($_.ConfiguredClockSpeed) { $_.ConfiguredClockSpeed } else { $_.Speed } } | Where-Object { $_ }) | Select-Object -First 1
        if ($mhz) { $D.RamMHz = $mhz }
    } catch { }
    try { $D.Gpus = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object { "$($_.Name)" } | Where-Object { $_ }) } catch { }
    try { $b = Get-CimInstance Win32_BIOS -ErrorAction Stop; $D.Bios = ("{0} {1}" -f $b.Manufacturer, $b.SMBIOSBIOSVersion).Trim() } catch { }
    try { $pb = Get-CimInstance Win32_BaseBoard -ErrorAction Stop; $D.Placa = ("{0} {1}" -f $pb.Manufacturer, $pb.Product).Trim() } catch { }
    try {
        $D.Volumes = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop | ForEach-Object {
            @{ Unidade = "$($_.DeviceID)"; TotalGB = [double]$_.Size / 1GB; LivreGB = [double]$_.FreeSpace / 1GB } })
    } catch { }
    return (ConvertTo-SecoesPcRapido $D)
}

function Get-EstadoMonitor {
    # Devolve o conteúdo de estado.json se o processo do monitor ainda estiver vivo; senão $null.
    try {
        $f = Join-Path (Get-PastaMonitor) 'estado.json'
        if (-not (Test-Path -LiteralPath $f)) { return $null }
        $e = [IO.File]::ReadAllText($f).TrimStart([char]0xFEFF) | ConvertFrom-Json
        if (-not $e.Pid) { return $null }
        $p = Get-Process -Id ([int]$e.Pid) -ErrorAction SilentlyContinue
        if (-not $p) { return $null }
        if ($e.Inicio -and $p.StartTime) {
            # PID reaproveitado por outro programa depois de uma queda? O processo precisa ser mais antigo que o início da sessão.
            $ini = [datetime]::Parse([string]$e.Inicio, $script:MonInv)
            if ($p.StartTime -gt $ini.AddMinutes(2)) { return $null }
        }
        return $e
    } catch { return $null }
}

function Test-MonitorAtivo { return [bool](Get-EstadoMonitor) }

function Stop-Monitor {
    # Pede para o monitor encerrar (ele grava o fim da sessão); se não responder, encerra o processo.
    $e = Get-EstadoMonitor
    if (-not $e) { return $false }
    try { [IO.File]::WriteAllText((Join-Path (Get-PastaMonitor) 'parar.flag'), 'parar') } catch { }
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 250
        if (-not (Get-Process -Id ([int]$e.Pid) -ErrorAction SilentlyContinue)) { return $true }
    }
    try { Stop-Process -Id ([int]$e.Pid) -Force -ErrorAction Stop } catch { return $false }
    return $true
}

function Start-Monitor {
    # Inicia o monitor em um processo escondido e devolve $true se ele subiu.
    param([string]$Pasta, [double]$Intervalo = 0.5)
    $script_ = Join-Path $Pasta 'WinDiag-Monitor.ps1'
    if (-not (Test-Path -LiteralPath $script_)) { return $false }
    $resto = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Executar -Intervalo {1}' -f $script_, $Intervalo.ToString('0.###', $script:MonInv)
    $h = $null
    if (Get-Command Get-ArgsOculto -ErrorAction SilentlyContinue) { $h = Get-ArgsOculto $resto }
    if (-not $h) { $h = @{ Exe = 'powershell.exe'; Args = $resto } }
    Start-Process -FilePath $h.Exe -ArgumentList $h.Args -WindowStyle Hidden | Out-Null
    for ($i = 0; $i -lt 40; $i++) { Start-Sleep -Milliseconds 250; if (Test-MonitorAtivo) { return $true } }
    return $false
}
#endregion arquivos e estado

#region leitura dos sensores
function Get-TipoMonitor {
    # Letra do tipo gravada na chave: T temperatura, V tensão, P potência, F ventoinha, C clock, U uso, O outro (MSI).
    param([string]$Tipo)
    switch ($Tipo) { '1' { 'T' } '2' { 'V' } '3' { 'F' } '4' { 'A' } '5' { 'P' } '6' { 'C' } '7' { 'U' } default { 'O' } }
}

function Get-LeiturasMonitor {
    # Devolve @{ Fontes = 'HWiNFO, MSI Afterburner'; Itens = lista de @{ Chave; Valor } }.
    $itens = New-Object System.Collections.Generic.List[object]
    $fontes = New-Object System.Collections.Generic.List[string]
    $usadas = @{}
    $add = {
        param($tipo, $fonte, $sensor, $rotulo, [double]$valor)
        $c = ('{0}|{1}|{2}|{3}' -f $tipo, $fonte, ($sensor -replace '[;\r\n]', ','), ($rotulo -replace '[;\r\n]', ','))
        if ($usadas.ContainsKey($c)) { $usadas[$c]++; $c = $c + '#' + $usadas[$c] } else { $usadas[$c] = 1 }
        $itens.Add(@{ Chave = $c; Valor = $valor })
    }

    $nFan = 0; $nClk = 0
    $linhas = $null
    try { if ($script:TesteSensoresBytes) { $linhas = [WDSensores]::LerBytes($script:TesteSensoresBytes) } elseif ($env:OS -eq 'Windows_NT') { $linhas = [WDSensores]::LerHWiNFO() } } catch { }
    if ($linhas -and $linhas.Count -gt 0) {
        $fontes.Add('HWiNFO')
        foreach ($l in $linhas) {
            $t = Get-TipoMonitor $l[0]
            $v = [double]::Parse($l[4], $script:MonInv)
            $rot = $l[2]
            $pula = $false
            if ($t -eq 'T') { $pula = ($rot -match 'Distance|TjMax|Limit|Margin|Distância' -or $v -le 0 -or $v -ge 150) }
            elseif ($t -eq 'F') { $nFan++; $pula = ($nFan -gt 8 -or $v -le 0) }
            elseif ($t -eq 'C') { $pula = ($rot -notmatch 'Core.*Clock|GPU.*Clock|Memory.*Clock|Effective|Bus' -or $nClk -ge 12); if (-not $pula) { $nClk++ } }
            elseif ($t -eq 'U') { $pula = ($rot -notmatch 'Total|GPU Core|Core.*Load|Memory.*(Load|Usage)|GPU D3D|Physical') }
            elseif ($t -in 'A', 'O') { $pula = $true }
            if ($pula) { continue }
            & $add $t 'H' $l[1] $rot $v
        }
    }

    $msi = $null
    try { Initialize-Msi } catch { }
    try { if ($script:TesteMsiBytes) { $msi = [WDMsi]::LerBytes($script:TesteMsiBytes) } elseif ($env:OS -eq 'Windows_NT') { $msi = [WDMsi]::Ler() } } catch { }
    if ($msi -and $msi.Count -gt 0) {
        $fontes.Add('MSI Afterburner')
        foreach ($m in $msi) {
            $nome = $m[0]; $un = $m[1]; $v = [double]::Parse($m[2], $script:MonInv)
            $t = 'O'
            if ($un -match '°C|C$' -or $nome -match 'temperature|temperatura') { $t = 'T' }
            elseif ($un -match '^V$|mV' -or $nome -match 'voltage|tens') { $t = 'V' }
            elseif ($un -match '^W$|%?TDP' -or $nome -match 'power|pot[eê]ncia') { $t = 'P' }
            elseif ($un -match 'RPM') { $t = 'F' }
            elseif ($un -match 'MHz') { $t = 'C' }
            elseif ($un -match '%') { $t = 'U' }
            & $add $t 'M' 'MSI Afterburner' $nome $v
        }
    }

    if ($fontes.Count -eq 0 -and $env:OS -eq 'Windows_NT') {
        foreach ($ns in 'root\LibreHardwareMonitor', 'root\OpenHardwareMonitor') {
            try {
                $s = @(Get-CimInstance -Namespace $ns -ClassName Sensor -ErrorAction Stop)
                if ($s.Count -gt 0) {
                    $fontes.Add($(if ($ns -match 'Libre') { 'LibreHardwareMonitor' } else { 'OpenHardwareMonitor' }))
                    $tipos = @{ 'Temperature' = 'T'; 'Voltage' = 'V'; 'Fan' = 'F'; 'Power' = 'P'; 'Clock' = 'C'; 'Load' = 'U' }
                    foreach ($x in $s) {
                        if ($null -eq $x.Value -or -not $tipos.ContainsKey("$($x.SensorType)")) { continue }
                        $t = $tipos["$($x.SensorType)"]
                        if ($t -eq 'F' -and [double]$x.Value -le 0) { continue }
                        & $add $t 'L' "$($x.Parent)" "$($x.Name)" ([double]$x.Value)
                    }
                    break
                }
            } catch { }
        }
    }

    # Leituras próprias do WinDiag (não dependem de nenhum programa): uso do processador e da memória.
    # Só quando nenhum programa de sensores já publicou o uso (a consulta ao Windows leva ~1 s em PCs mais fracos e atrasava o registro);
    # nesse caso é refeita só a cada ~5 s.
    $temUso = @($itens | Where-Object { $_.Chave -match '^U\|' }).Count -gt 0
    $usoCache = $script:MonCacheUso
    if ($temUso) { }
    elseif ($usoCache -and ((Get-Date) - $usoCache.Quando).TotalSeconds -lt 5) {
        foreach ($x in $usoCache.Itens) { & $add $x.Tipo 'W' 'WinDiag' $x.Rotulo $x.Valor }
    } else {
    $novoCache = New-Object System.Collections.Generic.List[object]
    try {
        if ($env:OS -eq 'Windows_NT') {
            $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Measure-Object -Property LoadPercentage -Average
            if ($null -ne $cpu.Average) { & $add 'U' 'W' 'WinDiag' 'Uso do processador (%)' ([double]$cpu.Average); $novoCache.Add(@{ Tipo = 'U'; Rotulo = 'Uso do processador (%)'; Valor = [double]$cpu.Average }) }
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
            if ($os.TotalVisibleMemorySize -gt 0) { $pm = [math]::Round(100.0 * (1 - $os.FreePhysicalMemory / $os.TotalVisibleMemorySize), 1); & $add 'U' 'W' 'WinDiag' 'Memória em uso (%)' $pm; $novoCache.Add(@{ Tipo = 'U'; Rotulo = 'Memória em uso (%)'; Valor = $pm }) }
        }
    } catch { }
    $script:MonCacheUso = @{ Quando = (Get-Date); Itens = $novoCache.ToArray() }
    }
    # Placa de vídeo: se nenhum programa publicou a temperatura dela, pergunta ao driver (nvidia-smi / AMD).
    $temGpu = @($itens | Where-Object { $_.Chave -match '^T\|' -and $_.Chave -match 'GPU|Radeon|GeForce|NVIDIA' }).Count -gt 0
    if (-not $temGpu -and (Get-Command Get-TempGpu -ErrorAction SilentlyContinue)) {
        try {
            $gc = $script:MonCacheGpu
            if ($gc -and ((Get-Date) - $gc.Quando).TotalSeconds -lt 1) { $g = $gc.G } else { $g = Get-TempGpu; $script:MonCacheGpu = @{ Quando = (Get-Date); G = $g } }
            if ($g) {
                if ($null -ne $g.Temp) { & $add 'T' 'W' 'WinDiag' 'GPU (°C)' ([double]$g.Temp) }
                if ($null -ne $g.Hotspot) { & $add 'T' 'W' 'WinDiag' 'GPU ponto quente (°C)' ([double]$g.Hotspot) }
                if ($null -ne $g.Potencia) { & $add 'P' 'W' 'WinDiag' 'GPU potência (W)' ([double]$g.Potencia) }
                if ($null -ne $g.Clock) { & $add 'C' 'W' 'WinDiag' 'GPU clock (MHz)' ([double]$g.Clock) }
                $fontes.Add('driver da placa de vídeo')
            }
        } catch { }
    }
    # Sem HWiNFO: frequência do processador (contadores do Windows), temperatura do disco e zona térmica da placa (a cada ~30 s, é lento).
    if ($env:OS -eq 'Windows_NT') {
        try {
            $sc = $script:MonCacheSensoresW
            if (-not ($sc -and ((Get-Date) - $sc.Quando).TotalSeconds -lt 30)) {
                $lista = New-Object System.Collections.Generic.List[object]
                try {
                    $pi = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'" -ErrorAction Stop | Select-Object -First 1
                    if ($pi -and $null -ne $pi.PercentProcessorPerformance) { $lista.Add(@{ Tipo = 'U'; Rotulo = 'Desempenho do processador (% da frequência base)'; Valor = [double]$pi.PercentProcessorPerformance }) }
                    if ($pi -and $null -ne $pi.ProcessorFrequency) { $lista.Add(@{ Tipo = 'C'; Rotulo = 'Processador clock (MHz)'; Valor = [double]$pi.ProcessorFrequency }) }
                } catch { }
                try {
                    foreach ($pd in @(Get-PhysicalDisk -ErrorAction Stop)) {
                        $rc = $pd | Get-StorageReliabilityCounter -ErrorAction Stop
                        if ($rc -and $rc.Temperature -and $rc.Temperature -gt 0 -and $rc.Temperature -lt 120) { $lista.Add(@{ Tipo = 'T'; Rotulo = ('Disco ' + $pd.FriendlyName + ' (°C)'); Valor = [double]$rc.Temperature }) }
                    }
                } catch { }
                try {
                    foreach ($z in @(Get-CimInstance -Namespace root\wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop)) {
                        $c = [math]::Round($z.CurrentTemperature / 10.0 - 273.15, 1)
                        if ($c -gt 0 -and $c -lt 130) { $lista.Add(@{ Tipo = 'T'; Rotulo = 'Zona térmica da placa (°C)'; Valor = $c }) }
                    }
                } catch { }
                $script:MonCacheSensoresW = @{ Quando = (Get-Date); Itens = $lista.ToArray() }
                $sc = $script:MonCacheSensoresW
            }
            foreach ($x in $sc.Itens) { & $add $x.Tipo 'W' 'WinDiag' $x.Rotulo $x.Valor }
            if ($sc.Itens.Count -gt 0) { $fontes.Add('contadores do Windows (disco, processador)') }
        } catch { }
    }
    return @{ Fontes = ($fontes -join ', '); Itens = $itens.ToArray() }
}
#endregion leitura dos sensores

#region gravação
function Invoke-Monitor {
    # Laço principal. Cada leitura é gravada e empurrada para o disco na hora (WriteThrough + Flush), para sobreviver a um desligamento súbito.
    param([double]$Intervalo = 0.5, [double]$MaxHoras = 12, [scriptblock]$Leitor, [int]$MaxAmostras = 0)
    if ($Intervalo -lt 0.5) { $Intervalo = 0.5 }
    if ($Intervalo -gt 30) { $Intervalo = 30 }
    $pasta = Get-PastaMonitor
    New-Item -ItemType Directory -Force -Path $pasta | Out-Null
    $flag = Join-Path $pasta 'parar.flag'
    Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
    Remove-AntigasSessoes -Manter 9
    $inicio = Get-Date
    $arq = Join-Path $pasta ('sessao-{0}.log' -f $inicio.ToString('yyyyMMdd-HHmmss'))
    $enc = New-Object System.Text.UTF8Encoding($false)
    $fs = New-Object System.IO.FileStream($arq, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite, 4096, [System.IO.FileOptions]::WriteThrough)
    $grava = {
        param([string]$txt)
        $b = $enc.GetBytes($txt + "`n")
        $fs.Write($b, 0, $b.Length)
        $fs.Flush($true)
    }
    $fmt = 'yyyy-MM-ddTHH:mm:ss'
    $fmtAm = 'yyyy-MM-ddTHH:mm:ss.f'   # as amostras têm décimos de segundo
    $motivo = 'erro'
    try {
        $estadoArq = Join-Path $pasta 'estado.json'
        $est = @{ Pid = $PID; Inicio = $inicio.ToString($fmt, $script:MonInv); Arquivo = $arq; Intervalo = $Intervalo.ToString('0.###', $script:MonInv) }
        [IO.File]::WriteAllText($estadoArq, ($est | ConvertTo-Json -Compress))
        & $grava ('#inicio;{0};intervalo={1};pc={2}' -f $inicio.ToString($fmt, $script:MonInv), $Intervalo.ToString('0.###', $script:MonInv), $env:COMPUTERNAME)

        $cols = New-Object System.Collections.Generic.List[string]
        $idx = @{}
        $maximos = @{}
        $n = 0
        $prox = Get-Date
        while ($true) {
            if (Test-Path -LiteralPath $flag) { $motivo = 'usuario'; break }
            if (((Get-Date) - $inicio).TotalHours -ge $MaxHoras) { $motivo = 'limite'; break }
            $r = $null
            try { if ($Leitor) { $r = & $Leitor } else { $r = Get-LeiturasMonitor } } catch { $r = $null }
            $agora = Get-Date
            if ($r -and $r.Itens) {
                if ($n -eq 0) { & $grava ('#fontes;' + $r.Fontes) }
                $novas = $false
                foreach ($i in $r.Itens) { if (-not $idx.ContainsKey($i.Chave)) { $idx[$i.Chave] = $cols.Count; $cols.Add($i.Chave); $novas = $true } }
                if ($novas) { & $grava ('#cols;' + ($cols -join ';')) }
                $vals = New-Object string[] $cols.Count
                foreach ($i in $r.Itens) {
                    $k = $idx[$i.Chave]
                    $vals[$k] = ([double]$i.Valor).ToString('0.###', $script:MonInv)
                    if (-not $maximos.ContainsKey($i.Chave) -or $i.Valor -gt $maximos[$i.Chave]) { $maximos[$i.Chave] = [double]$i.Valor }
                }
                & $grava ($agora.ToString($fmtAm, $script:MonInv) + ';' + ($vals -join ';'))
                $n++
                if ($n % 30 -eq 0) {
                    $mx = New-Object string[] $cols.Count
                    for ($k = 0; $k -lt $cols.Count; $k++) { if ($maximos.ContainsKey($cols[$k])) { $mx[$k] = ([double]$maximos[$cols[$k]]).ToString('0.###', $script:MonInv) } }
                    & $grava ('#max;' + ($mx -join ';'))
                }
                if ($MaxAmostras -gt 0 -and $n -ge $MaxAmostras) { $motivo = 'teste'; break }
            }
            $prox = $prox.AddSeconds($Intervalo)
            if ($prox -lt (Get-Date)) { $prox = (Get-Date).AddSeconds($Intervalo) }
            while ((Get-Date) -lt $prox) {
                if (Test-Path -LiteralPath $flag) { break }
                Start-Sleep -Milliseconds 50
            }
        }
    } catch {
        $motivo = 'erro'
        try { & $grava ('#erro;' + ($_.Exception.Message -replace '[;\r\n]', ' ')) } catch { }
    } finally {
        try { & $grava ('#fim;{0};{1}' -f (Get-Date).ToString($fmt, $script:MonInv), $motivo) } catch { }
        try { $fs.Dispose() } catch { }
        Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath (Join-Path $pasta 'estado.json') -Force -ErrorAction SilentlyContinue
    }
    return $arq
}

function Remove-AntigasSessoes {
    param([int]$Manter = 15)
    try {
        $pasta = Get-PastaMonitor
        $l = @(Get-ChildItem -LiteralPath $pasta -Filter 'sessao-*.log' -File -ErrorAction Stop | Sort-Object Name -Descending)
        foreach ($f in ($l | Select-Object -Skip $Manter)) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
    } catch { }
}
#endregion gravação

#region análise
function Read-SessaoMonitor {
    # Lê um arquivo de sessão. Só as últimas amostras são convertidas em número (rápido mesmo com horas de registro).
    param([string]$Arquivo, [int]$UltimasN = 400)
    $txt = $null
    try {
        $fs = New-Object System.IO.FileStream($Arquivo, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        try { $sr = New-Object System.IO.StreamReader($fs, [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd() } finally { $fs.Dispose() }
    } catch { return $null }
    $linhas = @($txt -split "`n" | ForEach-Object { $_.TrimEnd("`r") } | Where-Object { $_ })
    if ($linhas.Count -eq 0) { return $null }
    $r = @{ Arquivo = $Arquivo; Inicio = $null; Fim = $null; Motivo = $null; Intervalo = 2.0; Fontes = ''; Colunas = @(); Maximos = @{}; Amostras = @(); NAmostras = 0; Erro = $null; UltimoRegistro = $null }
    $cols = @()
    $amostrasTxt = New-Object System.Collections.Generic.List[string]
    $colsPorAmostra = New-Object System.Collections.Generic.List[object]
    $ultimoMax = $null; $colsMax = $null
    foreach ($l in $linhas) {
        if ($l[0] -eq '#') {
            $p = $l.Split(';')
            switch ($p[0]) {
                '#inicio' { try { $r.Inicio = [datetime]::Parse($p[1], $script:MonInv) } catch { }; foreach ($q in $p) { if ($q -match '^intervalo=([\d.]+)') { $r.Intervalo = [double]::Parse($Matches[1], $script:MonInv) } } }
                '#fontes' { $r.Fontes = ($l.Substring(8)) }
                '#cols'   { $cols = @($p[1..($p.Count - 1)]) }
                '#max'    { $ultimoMax = $p; $colsMax = $cols }
                '#fim'    { try { $r.Fim = [datetime]::Parse($p[1], $script:MonInv) } catch { }; if ($p.Count -gt 2) { $r.Motivo = $p[2] } }
                '#erro'   { $r.Erro = ($l.Substring(6)) }
            }
            continue
        }
        $amostrasTxt.Add($l)
        $colsPorAmostra.Add($cols)
    }
    $r.Colunas = $cols
    $r.NAmostras = $amostrasTxt.Count
    if ($ultimoMax -and $colsMax) {
        for ($k = 0; $k -lt $colsMax.Count; $k++) {
            $s = if ($k + 1 -lt $ultimoMax.Count) { $ultimoMax[$k + 1] } else { '' }
            $v = 0.0
            if ($s -and [double]::TryParse($s, 'Float', $script:MonInv, [ref]$v)) { $r.Maximos[$colsMax[$k]] = $v }
        }
    }
    $ini = [math]::Max(0, $amostrasTxt.Count - $UltimasN)
    $am = New-Object System.Collections.Generic.List[object]
    for ($j = $ini; $j -lt $amostrasTxt.Count; $j++) {
        $p = $amostrasTxt[$j].Split(';')
        $t = [datetime]::MinValue
        if (-not [datetime]::TryParse($p[0], $script:MonInv, 'None', [ref]$t)) { continue }
        $c = $colsPorAmostra[$j]
        $h = @{}
        for ($k = 0; $k -lt $c.Count; $k++) {
            if ($k + 1 -ge $p.Count) { break }
            $v = 0.0
            if ($p[$k + 1] -and [double]::TryParse($p[$k + 1], 'Float', $script:MonInv, [ref]$v)) { $h[$c[$k]] = $v }
        }
        $am.Add(@{ T = $t; V = $h })
    }
    $r.Amostras = $am.ToArray()
    if ($am.Count -gt 0) { $r.UltimoRegistro = $am[$am.Count - 1].T } elseif ($r.Inicio) { $r.UltimoRegistro = $r.Inicio }
    return $r
}

function Get-RotuloChave {
    param([string]$Chave)
    $p = $Chave.Split('|')
    if ($p.Count -ge 4) { $s = $p[2]; $rot = ($p[3] -replace '#\d+$', ''); if ($p[1] -eq 'W' -or $s -eq 'MSI Afterburner' -or -not $s) { return $rot } else { return ('{0} - {1}' -f $rot, ($s -replace '^\S+:\s*', '')) } }
    return $Chave
}

function Get-CamposEventoMon {
    # Campos do evento lidos do XML (nome -> valor).
    param($Evento)
    $d = @{}
    try {
        $x = [xml]$Evento.ToXml()
        $i = 0
        foreach ($n in @($x.Event.EventData.Data)) {
            if ($null -eq $n) { continue }
            if ($n -is [string]) { $nome = ''; $val = $n } else { $nome = "$($n.GetAttribute('Name'))"; $val = "$($n.InnerText)" }
            if (-not $nome) { $nome = "Dado$i" }
            $d[$nome] = $val; $i++
        }
    } catch { }
    return $d
}

function Get-EventosSessao {
    # Procura no log do Windows como a sessão terminou: desligamento normal (1074) ou queda (Kernel-Power 41 / 6008).
    # O evento 41 diz se houve tela azul (BugcheckCode) ou se o botão de ligar foi segurado (PowerButtonTimestamp) - ou seja, travamento.
    param([datetime]$Desde)
    $r = @{ Queda = $null; Normal = $null; Botao = $null; Bugcheck = 0 }
    try {
        $q = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Power'; Id = 41; StartTime = $Desde } -MaxEvents 5 -ErrorAction Stop | Sort-Object TimeCreated)
        if ($q.Count -gt 0) {
            $r.Queda = $q[0].TimeCreated
            $d = Get-CamposEventoMon $q[0]
            $bc = 0; $pb = 0
            try { if ($d['BugcheckCode']) { $bc = [int64]$d['BugcheckCode'] } } catch { }
            try { if ($d['PowerButtonTimestamp']) { $pb = [int64]$d['PowerButtonTimestamp'] } } catch { }
            $r.Bugcheck = $bc
            if ($pb -gt 0) { try { $r.Botao = [datetime]::FromFileTimeUtc($pb).ToLocalTime() } catch { } }
        }
    } catch { }
    try {
        $n = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 1074; StartTime = $Desde.AddMinutes(-3) } -MaxEvents 5 -ErrorAction Stop | Sort-Object TimeCreated)
        if ($n.Count -gt 0) { $r.Normal = $n[0].TimeCreated }
    } catch { }
    return $r
}

function Get-PadraoAntesDoFim {
    # Olha o consumo da placa de vídeo ao longo da sessão e diz o que estava acontecendo no fim:
    # 'sustentada' (carga alta havia 2 min ou mais), 'transicao' (a carga alta tinha começado havia menos de 2 min, vinda do repouso),
    # 'ocioso' (placa em repouso) ou 'moderada'. Também detecta sensores que pararam de mudar antes do último registro.
    param($Amostras, $Chaves)
    $r = @{ Padrao = ''; MinCarga = 0.0; ParadosSeg = 0; Linhas = (New-Object System.Collections.Generic.List[string]); Pico = 0.0; Ultimo = 0.0 }
    $am = @($Amostras)
    if ($am.Count -lt 20) { return $r }
    $pk = @($Chaves | Where-Object { $_ -match '^P\|' -and $_ -match 'GPU' } | Select-Object -First 1)
    if ($pk.Count -gt 0) {
        $kp = $pk[0]
        $serie = @($am | Where-Object { $_.V.ContainsKey($kp) })
        if ($serie.Count -ge 20) {
            $pico = ($serie | ForEach-Object { $_.V[$kp] } | Measure-Object -Maximum).Maximum
            $ult = $serie[$serie.Count - 1]; $up = [double]$ult.V[$kp]
            $r.Pico = $pico; $r.Ultimo = $up
            if ($pico -ge 40) {
                if ($up -ge (0.7 * $pico)) {
                    # volta no tempo até o último repouso de verdade (queda de 10 s ou mais abaixo de 50% do pico); quedas curtas são ignoradas
                    $i = $serie.Count - 1; $limite = 0.5 * $pico; $quedaCurta = $null
                    $inicioIdx = 0; $achouRepouso = $false
                    while ($i -ge 0) {
                        if ([double]$serie[$i].V[$kp] -lt $limite) {
                            $fimRun = $i
                            while ($i -gt 0 -and [double]$serie[$i - 1].V[$kp] -lt $limite) { $i-- }
                            $durRun = ($serie[$fimRun].T - $serie[$i].T).TotalSeconds
                            if ($durRun -ge 10 -or $i -eq 0) { $inicioIdx = [math]::Min($fimRun + 1, $serie.Count - 1); $achouRepouso = $true; break }
                            if ($null -eq $quedaCurta -and ($ult.T - $serie[$fimRun].T).TotalSeconds -le 90) {
                                $minRun = ($serie[$i..$fimRun] | ForEach-Object { [double]$_.V[$kp] } | Measure-Object -Minimum).Minimum
                                $quedaCurta = @{ Min = $minRun; Antes = ($ult.T - $serie[$fimRun].T).TotalSeconds; Dur = [math]::Max(1, $durRun) }
                            }
                        }
                        $i--
                    }
                    if ($achouRepouso) { $ini = $serie[$inicioIdx].T } else { $ini = $serie[0].T }
                    $dur = ($ult.T - $ini).TotalSeconds
                    $r.MinCarga = $dur / 60.0
                    if ($achouRepouso -and $dur -lt 120) {
                        $r.Padrao = 'transicao'
                        $r.Linhas.Add(('Padrão antes do fim: a carga da placa de vídeo tinha começado havia só {0:N0} s (vinha do repouso) e estava em {1:N0} W no último registro: o travamento veio logo na troca de repouso para carga.' -f $dur, $up))
                    } else {
                        $r.Padrao = 'sustentada'
                        $r.Linhas.Add(('Padrão antes do fim: a placa de vídeo estava em carga alta havia {0:N1} min seguidos ({1:N0} W no último registro; pico da sessão {2:N0} W).' -f ($dur / 60.0), $up, $pico))
                        if ($quedaCurta) { $r.Linhas.Add(('Houve uma queda breve da carga (até {0:N0} W, por cerca de {1:N0} s) {2:N0} s antes do fim, como numa tela de carregamento, e a carga voltou. Pode ter sido a última troca de cena antes do travamento.' -f $quedaCurta.Min, $quedaCurta.Dur, $quedaCurta.Antes)) }
                    }
                } elseif ($up -lt (0.3 * $pico)) {
                    $r.Padrao = 'ocioso'
                    $r.Linhas.Add(('Padrão antes do fim: a placa de vídeo estava em repouso no último registro ({0:N0} W; pico da sessão {1:N0} W).' -f $up, $pico))
                } else {
                    $r.Padrao = 'moderada'
                    $r.Linhas.Add(('Padrão antes do fim: a placa de vídeo estava em carga moderada ({0:N0} W; pico da sessão {1:N0} W).' -f $up, $pico))
                }
            }
        }
    }
    # sensores que pararam de mudar antes do fim (o monitor continuou gravando, mas o HWiNFO ou o PC deixaram de atualizar)
    $ultA = $am[$am.Count - 1]
    $tMud = $ultA.T
    $max = [math]::Min(240, $am.Count - 1)
    for ($j = 1; $j -le $max; $j++) {
        $x = $am[$am.Count - 1 - $j]
        $dif = $false
        foreach ($k in $ultA.V.Keys) { if (-not $x.V.ContainsKey($k) -or $x.V[$k] -ne $ultA.V[$k]) { $dif = $true; break } }
        if ($dif) { break }
        $tMud = $x.T
    }
    $parado = ($ultA.T - $tMud).TotalSeconds
    if ($parado -ge 6) {
        $r.ParadosSeg = [int]$parado
        $r.Linhas.Add(('Os sensores pararam de mudar {0:N0} s antes do último registro: nesse intervalo o HWiNFO ou o computador deixaram de atualizar as leituras.' -f $parado))
    }
    return $r
}

function Get-TextoPadrao {
    # Frase de conclusão a partir do padrão antes do fim (acrescentada ao veredito da sessão).
    param($Padrao)
    switch ($Padrao.Padrao) {
        'sustentada' { return ('O travamento veio depois de {0:N1} min de carga contínua na placa de vídeo. Isso aponta para algo que só falha com consumo alto e prolongado: fonte, a própria placa de vídeo, memória RAM ou ventilação do gabinete. Para separar: limite a energia da placa a 60% (MSI Afterburner) e jogue de novo, e teste com outra fonte.' -f $Padrao.MinCarga) }
        'transicao'  { return 'O travamento veio logo ao sair do repouso para a carga (menos de 2 minutos depois). Isso aponta para a troca de estado de energia: veja nas configurações a economia de energia do PCIe e o agendamento de GPU, o driver de vídeo e a fonte (queda no pico de consumo).' }
        'ocioso'     { return 'A placa de vídeo estava parada quando travou. Isso costuma vir do driver de vídeo, do cabo ou monitor, da economia de energia ou do travamento em repouso de alguns Ryzen (confira "Power Supply Idle Control" na BIOS).' }
        default      { return '' }
    }
}

function Get-AnaliseSessao {
    # Resume uma sessão: o que estava acontecendo nos últimos segundos antes do último registro e um veredito em linguagem simples.
    param([string]$Arquivo, [int]$JanelaSeg = 90, $Eventos)
    $s = Read-SessaoMonitor $Arquivo -UltimasN 2400
    if (-not $s) { return $null }
    $ativo = Get-EstadoMonitor
    $a = @{ Arquivo = $Arquivo; Inicio = $s.Inicio; UltimoRegistro = $s.UltimoRegistro; Encerrada = [bool]$s.Fim; Motivo = $s.Motivo; Fontes = $s.Fontes
            NAmostras = $s.NAmostras; Alertas = (New-Object System.Collections.Generic.List[string]); Linhas = (New-Object System.Collections.Generic.List[string])
            Veredito = ''; Quem = 'indefinido'; Tipo = ''; Bugcheck = ''; BotaoEm = $null; Gravidade = 'Info'; TemTemperatura = $false; Padrao = ''; MinCarga = 0.0; SensoresParadosSeg = 0 }
    if ($s.Amostras.Count -eq 0) { $a.Veredito = 'A sessão não chegou a gravar leituras (o monitor foi encerrado logo ao iniciar ou não encontrou sensores).'; return $a }
    $ult = $s.Amostras[$s.Amostras.Count - 1]
    $corte = $ult.T.AddSeconds(-$JanelaSeg)
    $jan = @($s.Amostras | Where-Object { $_.T -ge $corte })
    $dur = if ($s.Inicio) { $ult.T - $s.Inicio } else { [timespan]::Zero }

    # Como a sessão terminou
    if ($s.Fim) {
        $a.Quem = 'encerrada'
    } elseif ($ativo -and $ativo.Arquivo -eq $Arquivo) {
        $a.Quem = 'ativa'
    } else {
        $ev = $Eventos
        if (-not $ev) { $ev = Get-EventosSessao -Desde $ult.T.AddSeconds(-1) }
        if ($ev.Normal -and $ev.Normal -ge $ult.T.AddMinutes(-3) -and $ev.Normal -le $ult.T.AddMinutes(1)) { $a.Quem = 'normal' }
        elseif ($ev.Queda -and $ev.Queda -ge $ult.T) {
            $a.Quem = 'queda'; $a.QuedaEm = $ev.Queda
            $a.Tipo = 'seco'
            if ($ev.Bugcheck -and [int64]$ev.Bugcheck -ne 0) { $a.Tipo = 'azul'; $a.Bugcheck = ('0x{0:X8}' -f [int64]$ev.Bugcheck) }
            elseif ($ev.Botao) { $a.Tipo = 'botao'; $a.BotaoEm = $ev.Botao }
        }
        else { $a.Quem = 'indefinido' }
    }

    # Valores nos últimos segundos
    $chaves = @($s.Colunas)
    $max = @{}; $min = @{}; $ultimo = @{}
    foreach ($am in $jan) {
        foreach ($k in $am.V.Keys) {
            $v = $am.V[$k]
            if (-not $max.ContainsKey($k) -or $v -gt $max[$k]) { $max[$k] = $v }
            if (-not $min.ContainsKey($k) -or $v -lt $min[$k]) { $min[$k] = $v }
        }
    }
    foreach ($k in $ult.V.Keys) { $ultimo[$k] = $ult.V[$k] }

    $temps = @($chaves | Where-Object { $_ -match '^T\|' })
    $a.TemTemperatura = ($temps.Count -gt 0)
    $cpuT = @($temps | Where-Object { $_ -match 'CPU|Ryzen|Tctl|Tdie|Package|Core \d|Núcleo' -and $_ -notmatch 'GPU' })
    $gpuT = @($temps | Where-Object { $_ -match 'GPU|Radeon|GeForce|NVIDIA' })
    $hot = @($gpuT | Where-Object { $_ -match 'Hot|quente' })
    $maxDe = { param($lst) $m = $null; foreach ($k in $lst) { if ($max.ContainsKey($k) -and ($null -eq $m -or $max[$k] -gt $m.V)) { $m = @{ K = $k; V = $max[$k] } } }; $m }
    $c = & $maxDe $cpuT; $g = & $maxDe $gpuT; $h = & $maxDe $hot
    $calor = $false
    if ($c) { $a.Linhas.Add(('Processador: {0:N0} °C no máximo nos últimos {1} s ({2}).' -f $c.V, $JanelaSeg, (Get-RotuloChave $c.K))); if ($c.V -ge 92) { $calor = $true; $a.Alertas.Add(('Processador muito quente ({0:N0} °C).' -f $c.V)) } }
    if ($g) { $a.Linhas.Add(('Placa de vídeo: {0:N0} °C no máximo nos últimos {1} s ({2}).' -f $g.V, $JanelaSeg, (Get-RotuloChave $g.K))); if ($g.V -ge 88) { $calor = $true; $a.Alertas.Add(('Placa de vídeo muito quente ({0:N0} °C).' -f $g.V)) } }
    if ($h) { $a.Linhas.Add(('Ponto quente da placa de vídeo: {0:N0} °C.' -f $h.V)); if ($h.V -ge 100) { $calor = $true; $a.Alertas.Add(('Ponto quente da placa de vídeo em {0:N0} °C.' -f $h.V)) } }

    # Tensões da fonte (trilhos de 12 V, 5 V e 3,3 V lidos pela placa-mãe; erro típico de alguns %)
    $tensao = $false
    $trilhos = @(
        @{ Nome = '12 V'; Rx = '(^|[^0-9.])\+?12(\.0+)? ?V'; Min = 11.4; Max = 12.6 },
        @{ Nome = '5 V';  Rx = '(^|[^0-9.])\+?5(\.0+)? ?V(?!SB)'; Min = 4.75; Max = 5.25 },
        @{ Nome = '3,3 V'; Rx = '(^|[^0-9.])\+?3[.,]3 ?V|3V3'; Min = 3.13; Max = 3.47 }
    )
    foreach ($tr in $trilhos) {
        $ks = @($chaves | Where-Object { $_ -match '^V\|' -and ((Get-RotuloChave $_) -match $tr.Rx) -and $_ -notmatch 'GPU|Core|SoC|VDD|DRAM|CPU' } | Select-Object -First 1)
        if ($ks.Count -eq 0) { continue }
        $k = $ks[0]
        if (-not $min.ContainsKey($k)) { continue }
        $a.Linhas.Add(('Trilho de {0}: entre {1:N2} e {2:N2} V nos últimos {3} s; último valor {4:N2} V.' -f $tr.Nome, $min[$k], $max[$k], $JanelaSeg, $ultimo[$k]))
        if ($min[$k] -lt $tr.Min -or $max[$k] -gt $tr.Max) { $tensao = $true; $a.Alertas.Add(('Tensão de {0} fora do normal ({1:N2} a {2:N2} V).' -f $tr.Nome, $min[$k], $max[$k])) }
        elseif ($jan.Count -ge 6) {
            # queda brusca no final em relação ao valor estável de antes
            $antes = @($jan | Select-Object -First ($jan.Count - 2) | ForEach-Object { $_.V[$k] } | Where-Object { $null -ne $_ } | Sort-Object)
            if ($antes.Count -ge 4 -and $ultimo.ContainsKey($k)) {
                $med = $antes[[int]($antes.Count / 2)]
                if (($med - $ultimo[$k]) -gt (0.025 * $med)) { $tensao = $true; $a.Alertas.Add(('Tensão de {0} caiu no fim (de {1:N2} para {2:N2} V).' -f $tr.Nome, $med, $ultimo[$k])) }
            }
        }
    }
    foreach ($tp in 'Uso do processador \(%\)', 'GPU core load|GPU usage|GPU Core') {
        $kk = @($chaves | Where-Object { $_ -match '^U\|' -and $_ -match $tp } | Select-Object -First 1)
        if ($kk.Count -gt 0 -and $ultimo.ContainsKey($kk[0])) { $a.Linhas.Add(('{0}: {1:N0}% no último registro.' -f (Get-RotuloChave $kk[0]), $ultimo[$kk[0]])) }
    }
    $pk = @($chaves | Where-Object { $_ -match '^P\|' -and $_ -match 'GPU' } | Select-Object -First 1)
    if ($pk.Count -gt 0 -and $ultimo.ContainsKey($pk[0])) { $a.Linhas.Add(('Consumo da placa de vídeo no último registro: {0:N0} W (máximo da janela {1:N0} W).' -f $ultimo[$pk[0]], $max[$pk[0]])) }
    $fps = @($chaves | Where-Object { $_ -match '^O\|' -and $_ -match 'Framerate$|FPS' } | Select-Object -First 1)
    if ($fps.Count -gt 0 -and $ultimo.ContainsKey($fps[0])) { $a.Linhas.Add(('Jogo em execução (quadros por segundo no último registro): {0:N0}.' -f $ultimo[$fps[0]])) }

    # Padrão antes do fim: carga contínua, salto de repouso para carga ou placa parada (usa o consumo da placa de vídeo)
    $pp = Get-PadraoAntesDoFim -Amostras $s.Amostras -Chaves $chaves
    $a.Padrao = $pp.Padrao; $a.MinCarga = $pp.MinCarga; $a.SensoresParadosSeg = $pp.ParadosSeg
    foreach ($x in $pp.Linhas) { $a.Linhas.Add($x) }

    # Cabeçalho
    $a.Linhas.Insert(0, ('Sessão de {0}, durou {1:N0} min com {2} leituras (a cada {3} s). Fontes: {4}.' -f $(if ($s.Inicio) { $s.Inicio.ToString('dd/MM/yyyy HH:mm') } else { '?' }), $dur.TotalMinutes, $s.NAmostras, $s.Intervalo, $(if ($s.Fontes) { $s.Fontes } else { 'nenhuma' })))
    $a.Linhas.Insert(1, ('Último registro: {0}.' -f $ult.T.ToString('dd/MM/yyyy HH:mm:ss')))

    # Veredito
    $fim = $ult.T.ToString('HH:mm:ss')
    if ($a.Quem -eq 'ativa') {
        $a.Veredito = 'O monitor ainda está ligado e gravando. Se o computador desligar, o último registro mostrará a situação do momento.'
    } elseif ($a.Quem -eq 'encerrada') {
        $a.Veredito = 'A sessão terminou normalmente (monitor parado por você).'
    } elseif ($a.Quem -eq 'normal') {
        $a.Veredito = 'O Windows foi desligado ou reiniciado normalmente nesse horário; não foi uma queda.'
    } else {
        $pref = if ($a.Quem -eq 'queda') {
            if ($a.Tipo -eq 'botao') {
                $seg = ($a.BotaoEm - $ult.T).TotalSeconds
                $quando = if ($seg -ge 0 -and $seg -lt 36000) { ' (' + ([math]::Round($seg)) + ' s depois do último registro, que é o instante em que o monitor parou de gravar)' } else { '' }
                "O PC travou: o Windows registrou que o botão de ligar foi segurado às $($a.BotaoEm.ToString('HH:mm:ss'))$quando. "
            } elseif ($a.Tipo -eq 'azul') {
                $dsc = ''; if (Get-Command Get-DescricaoBugcheck -ErrorAction SilentlyContinue) { $dsc = ' - ' + (Get-DescricaoBugcheck $a.Bugcheck) }
                "O Windows registrou uma tela azul (código $($a.Bugcheck)$dsc) depois de $fim. "
            } else {
                "O Windows registrou desligamento inesperado depois de $fim (Kernel-Power 41), sem tela azul e sem o botão de ligar ter sido segurado. "
            }
        } else { "O monitor parou sem fechar a sessão às $fim (provável queda, mas o Windows ainda não confirmou). " }
        if ($calor) { $a.Veredito = $pref + 'Antes de parar, a temperatura estava muito alta: o mais provável é superaquecimento (proteção térmica desliga o PC). Limpe o cooler, troque a pasta térmica e confira a ventilação.'; $a.Gravidade = 'Critico' }
        elseif ($tensao) { $a.Veredito = $pref + 'Antes de parar, a tensão da fonte oscilou: indício de fonte fraca ou com defeito (ou sobrecarga quando a placa de vídeo puxa muita energia). Teste com outra fonte de qualidade.'; $a.Gravidade = 'Critico' }
        elseif (-not $a.TemTemperatura) { $a.Veredito = $pref + 'Nenhuma temperatura foi gravada: abra o HWiNFO (modo Sensores, com "Shared Memory Support" ligado) ou o MSI Afterburner antes de jogar, para o próximo registro mostrar calor e tensão.'; $a.Gravidade = 'Atencao' }
        elseif ($a.Tipo -eq 'botao') { $a.Veredito = $pref + 'Até o último registro as temperaturas e as tensões estavam normais, então não parece calor nem fonte. Um travamento assim costuma vir do driver ou da placa de vídeo, da memória RAM, da BIOS/chipset ou do disco: veja os erros do driver de vídeo e de hardware (WHEA) no relatório do WinDiag e rode o teste de RAM.'; $a.Gravidade = 'Atencao' }
        elseif ($a.Tipo -eq 'azul') { $a.Veredito = $pref + 'Procure esse código no relatório de telas azuis do WinDiag: ele aponta o tipo de problema (driver, memória, disco).'; $a.Gravidade = 'Atencao' }
        else { $a.Veredito = $pref + 'Nenhuma temperatura ou tensão estava fora do normal até o último registro. Uma queda assim, sem aviso, costuma ser corte de energia (fonte, filtro de linha, tomada) ou falha elétrica da placa de vídeo/placa-mãe, e não calor. A leitura é a cada ' + $s.Intervalo + ' s e os sensores de tensão da placa-mãe têm erro de alguns %, então um pico mais curto pode não aparecer.'; $a.Gravidade = 'Atencao' }
        $extra = Get-TextoPadrao $pp
        if ($extra) { $a.Veredito = $a.Veredito + ' ' + $extra }
    }
    return $a
}

function Get-UltimaSessaoMonitor {
    # Último arquivo de sessão (que não seja a que está rodando agora).
    try {
        $ativo = Get-EstadoMonitor
        $l = @(Get-ChildItem -LiteralPath (Get-PastaMonitor) -Filter 'sessao-*.log' -File -ErrorAction Stop | Sort-Object Name -Descending)
        foreach ($f in $l) { if ($ativo -and $ativo.Arquivo -eq $f.FullName) { continue }; return $f.FullName }
    } catch { }
    return $null
}

function Format-TextoSessao {
    param($Analise)
    if (-not $Analise) { return 'Nenhum registro do monitor foi encontrado ainda.' }
    $t = New-Object System.Collections.Generic.List[string]
    $t.Add('WinDiag - último registro do monitor')
    $t.Add('')
    foreach ($l in $Analise.Linhas) { $t.Add($l) }
    $t.Add('')
    if ($Analise.Alertas.Count -gt 0) { $t.Add('Alertas: ' + ($Analise.Alertas -join ' ')); $t.Add('') }
    $t.Add('Conclusão: ' + $Analise.Veredito)
    $t.Add('')
    $t.Add('Arquivo completo: ' + $Analise.Arquivo)
    return ($t -join "`r`n")
}

function Invoke-AnaliseMonitor {
    # Usado pela verificação: se a última sessão do monitor foi interrompida por uma queda, mostra o que ela registrou.
    $f = Get-UltimaSessaoMonitor
    if (-not $f) { return }
    $a = Get-AnaliseSessao -Arquivo $f
    if (-not $a -or $a.Encerrada -or $a.Quem -in 'normal', 'ativa') { return }
    if ($a.UltimoRegistro -and $a.UltimoRegistro -lt (Get-Date).AddDays(-14)) { return }
    $linhas = ($a.Linhas -join ' ')
    Add-Achado -Gravidade $a.Gravidade -Categoria 'Monitor' -Titulo ("O monitor em tempo real parou sem fechar a sessão ({0})" -f $a.UltimoRegistro.ToString('dd/MM HH:mm:ss')) `
        -Detalhe ($linhas + ' ' + $(if ($a.Alertas.Count -gt 0) { 'Alertas: ' + ($a.Alertas -join ' ') } else { '' })) `
        -Solucao $a.Veredito `
        -Explicacao 'O monitor grava os sensores a cada poucos segundos e força cada linha para o disco. Quando o computador desliga sozinho durante um jogo, o último registro mostra como estavam temperatura e tensão no momento da queda.' `
        -Veredito 'Depende'
}
#endregion análise

#region investigação de travamento e configurações
function ConvertFrom-SaidaPowercfg {
    # Lê os dois últimos valores hexadecimais da saída do "powercfg /query" (o da tomada e o da bateria). Independe do idioma do Windows.
    param([string]$Texto)
    $m = [regex]::Matches($Texto, '0x[0-9a-fA-F]{8}')
    if ($m.Count -lt 2) { return $null }
    return @{ Tomada = [Convert]::ToInt32($m[$m.Count - 2].Value.Substring(2), 16); Bateria = [Convert]::ToInt32($m[$m.Count - 1].Value.Substring(2), 16) }
}

function Get-AvaliacaoMemoria {
    # Avalia os módulos de memória (lista de @{ Capacidade (bytes); Velocidade; Configurada; Fabricante; Peca }). Devolve @{ Linhas; Atencao }.
    param($Modulos)
    $l = New-Object System.Collections.Generic.List[string]
    $atencao = $false
    $m = @($Modulos)
    if ($m.Count -eq 0) { return @{ Linhas = @(); Atencao = $false } }
    $totalGb = [math]::Round((($m | ForEach-Object { [double]$_.Capacidade } | Measure-Object -Sum).Sum) / 1GB)
    $desc = ($m | ForEach-Object { '{0:N0} GB' -f ([double]$_.Capacidade / 1GB) }) -join ' + '
    $vel = @($m | ForEach-Object { [int]$_.Velocidade } | Where-Object { $_ -gt 0 })
    $cfg = @($m | ForEach-Object { [int]$_.Configurada } | Where-Object { $_ -gt 0 })
    $txt = ('Memória RAM: {0} pente(s) ({1}, total {2} GB)' -f $m.Count, $desc, $totalGb)
    if ($cfg.Count -gt 0) { $txt += (', funcionando a {0} MHz' -f ($cfg | Measure-Object -Minimum).Minimum) }
    if ($vel.Count -gt 0) { $txt += (' (pente de {0} MHz)' -f ($vel | Measure-Object -Maximum).Maximum) }
    $l.Add($txt + '.')
    if ($m.Count -eq 1) { $l.Add('Só um pente: a memória trabalha em canal único (menos desempenho em jogos).') }
    $pecas = @($m | ForEach-Object { ('{0}|{1}|{2}' -f ("$($_.Fabricante)").Trim(), ("$($_.Peca)").Trim(), [double]$_.Capacidade) } | Select-Object -Unique)
    if ($m.Count -ge 2 -and $pecas.Count -gt 1) { $atencao = $true; $l.Add('Os pentes são de modelos ou capacidades diferentes: misturar pentes é uma causa conhecida de travamento sob carga.') }
    if ($vel.Count -gt 0 -and $cfg.Count -gt 0) {
        $v = ($vel | Measure-Object -Maximum).Maximum; $c = ($cfg | Measure-Object -Minimum).Minimum
        if ($c -lt $v) { $l.Add(('A memória está rodando abaixo da velocidade do pente ({0} contra {1} MHz); é o normal quando o perfil XMP/DOCP está desligado e é mais estável.' -f $c, $v)) }
    }
    return @{ Linhas = $l.ToArray(); Atencao = $atencao }
}

function Get-AvaliacaoProgramasJogo {
    # Programas que se encaixam nos jogos (sobreposição, ajuste de placa, iluminação) e podem causar travamento. Recebe os nomes dos processos.
    param([string[]]$Nomes)
    $mapa = [ordered]@{
        'MSIAfterburner' = 'MSI Afterburner'; 'RTSS' = 'RivaTuner (RTSS)'; 'RTSSHooksLoader64' = 'RivaTuner (RTSS)'; 'Discord' = 'Discord (sobreposição)'
        'GameOverlayUI' = 'Sobreposição da Steam'; 'nvsphelper64' = 'Sobreposição da NVIDIA (GeForce Experience)'; 'NVIDIA Share' = 'NVIDIA Share'; 'NVIDIA Overlay' = 'Sobreposição da NVIDIA'
        'GameBar' = 'Xbox Game Bar'; 'GameBarPresenceWriter' = 'Xbox Game Bar'; 'obs64' = 'OBS Studio'; 'Overwolf' = 'Overwolf'; 'OverwolfBrowser' = 'Overwolf'
        'RGBFusion' = 'RGB Fusion (Gigabyte)'; 'GigabyteUpdateService' = 'Gigabyte Update Service'; 'iCUE' = 'Corsair iCUE'; 'RazerCentral' = 'Razer Synapse'
        'ArmouryCrate.Service' = 'ASUS Armoury Crate'; 'LightingService' = 'Serviço de iluminação (MSI/Asus)'; 'MSI Center' = 'MSI Center'; 'Dragon Center' = 'MSI Dragon Center'
    }
    $achou = New-Object System.Collections.Generic.List[string]
    foreach ($n in @($Nomes)) { if ($mapa.Contains($n) -and -not $achou.Contains($mapa[$n])) { $achou.Add($mapa[$n]) } }
    return $achou.ToArray()
}

function Get-ResultadoDiagMemoria {
    # Último resultado do Diagnóstico de Memória do Windows (eventos 1201 = sem erros e 1202 = erros). Devolve @{ Data; Erros; Texto } ou $null.
    if ($env:OS -ne 'Windows_NT') { return $null }
    try {
        $e = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-MemoryDiagnostics-Results' } -MaxEvents 5 -ErrorAction Stop | Sort-Object TimeCreated -Descending)
        if ($e.Count -eq 0) { return $null }
        $x = $e[0]
        $txt = ("$($x.Message)" -split "`r?`n" | Select-Object -First 1)
        return @{ Data = $x.TimeCreated; Erros = ($x.Id -eq 1202); Texto = $txt }
    } catch { return $null }
}

function Get-ConfigTravamento {
    # Lê (sem alterar nada) configurações que costumam causar travamento em jogos. Devolve @{ Linhas; Atencao; Critico }.
    $l = New-Object System.Collections.Generic.List[string]
    $atencao = $false; $critico = $false
    if ($env:OS -ne 'Windows_NT') { return @{ Linhas = @(); Atencao = $false; Critico = $false } }
    try {
        $hw = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction Stop).HwSchMode
        if ($hw -eq 2) { $l.Add('Agendamento de GPU acelerado por hardware: LIGADO. Se o travamento é só em jogos, vale desligar para testar (Configurações > Sistema > Tela > Elementos gráficos).') }
        elseif ($hw -eq 1) { $l.Add('Agendamento de GPU acelerado por hardware: desligado.') }
    } catch { }
    try {
        $o = & powercfg.exe /query SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 2>$null | Out-String
        $v = ConvertFrom-SaidaPowercfg $o
        if ($v) {
            $nome = @{ 0 = 'desligada'; 1 = 'moderada'; 2 = 'máxima' }
            $l.Add(('Economia de energia do PCIe (Link State Power Management), na tomada: {0}.' -f $nome[[int]$v.Tomada]))
            if ($v.Tomada -ge 2) { $atencao = $true; $l.Add('A economia máxima do PCIe pode travar a placa de vídeo na saída do repouso. Para testar: Opções de energia > Alterar configurações do plano > PCI Express > Economia de energia do estado do link > Desativado.') }
        }
    } catch { }
    try {
        $pl = & powercfg.exe /getactivescheme 2>$null | Out-String
        if ($pl -match '\(([^)]+)\)') {
            $nomePlano = $Matches[1].Trim()
            $l.Add(('Plano de energia ativo: {0}.' -f $nomePlano))
            if ($nomePlano -match 'conomia|Power saver') { $atencao = $true; $l.Add('O plano de economia de energia reduz clocks e pode causar travamentos em jogos; use "Equilibrado" ou "Alto desempenho".') }
        }
    } catch { }
    try {
        $fs = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -ErrorAction Stop).HiberbootEnabled
        if ($fs -eq 1) { $l.Add('Inicialização rápida (Fast Startup): ligada. Ela mantém o estado dos drivers entre desligamentos; para testar, desligue em Opções de energia > Escolher a função dos botões.') }
    } catch { }
    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop | ForEach-Object { @{ Capacidade = $_.Capacity; Velocidade = $_.Speed; Configurada = $_.ConfiguredClockSpeed; Fabricante = $_.Manufacturer; Peca = $_.PartNumber } })
        $am = Get-AvaliacaoMemoria $mods
        foreach ($x in $am.Linhas) { $l.Add($x) }
        if ($am.Atencao) { $atencao = $true }
    } catch { }
    try {
        $b = Get-CimInstance Win32_BIOS -ErrorAction Stop
        $pb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
        $data = $null; try { $data = [Management.ManagementDateTimeConverter]::ToDateTime($b.ReleaseDate) } catch { }
        $txt = ('BIOS: versão {0}' -f $b.SMBIOSBIOSVersion)
        if ($data) { $txt += (', de {0}' -f $data.ToString('MM/yyyy')) }
        if ($pb) { $txt += (' (placa-mãe {0} {1})' -f $pb.Manufacturer, $pb.Product) }
        $l.Add($txt + '.')
        if ($data -and $data -lt (Get-Date).AddYears(-3)) { $l.Add('A BIOS tem mais de 3 anos: veja no site do fabricante se há versão nova (atualizações costumam corrigir travamentos de Ryzen e de memória). Atualize só seguindo o guia do fabricante.') }
    } catch { }
    try {
        $nomes = @(Get-Process -ErrorAction Stop | ForEach-Object { $_.ProcessName } | Sort-Object -Unique)
        $prog = @(Get-AvaliacaoProgramasJogo $nomes)
        if ($prog.Count -gt 0) { $l.Add(('Programas abertos que se encaixam nos jogos e podem causar travamento: {0}. Para testar, feche todos antes de jogar.' -f ($prog -join ', '))) }
    } catch { }
    $dm = Get-ResultadoDiagMemoria
    if ($dm) {
        if ($dm.Erros) { $critico = $true; $l.Add(('Diagnóstico de Memória do Windows de {0}: ENCONTROU ERROS. Memória com defeito trava o computador sob carga; teste os pentes um de cada vez.' -f $dm.Data.ToString('dd/MM/yyyy HH:mm'))) }
        else { $l.Add(('Diagnóstico de Memória do Windows de {0}: nenhum erro.' -f $dm.Data.ToString('dd/MM/yyyy HH:mm'))) }
    }
    return @{ Linhas = $l.ToArray(); Atencao = $atencao; Critico = $critico }
}

function Invoke-AnaliseConfigTravamento {
    # Usado pela verificação: mostra as configurações que influenciam travamentos em jogos (somente leitura).
    $c = Get-ConfigTravamento
    if (-not $c -or $c.Linhas.Count -eq 0) { return }
    $grav = 'Info'; $ver = 'Opcional'
    if ($c.Atencao) { $grav = 'Atencao'; $ver = 'Depende' }
    if ($c.Critico) { $grav = 'Critico'; $ver = 'Corrigir' }
    Add-Achado -Gravidade $grav -Categoria 'Configuração' -Titulo 'Configurações que influenciam travamentos em jogos' `
        -Detalhe ($c.Linhas -join ' | ') `
        -Solucao 'Se o computador trava só em jogos, mude uma coisa de cada vez (agendamento de GPU, economia de energia do PCIe, programas de sobreposição) e jogue um tempo a cada mudança.' `
        -Explicacao 'O WinDiag só leu estas configurações, nada foi alterado. Elas não são defeito: são pontos que, em alguns computadores, causam travamento de imagem ou do sistema quando um jogo abre ou fica muito tempo em carga.' `
        -Veredito $ver
}

function Get-EventosAoRedor {
    # Eventos do Windows que ajudam a explicar uma queda, ao redor de um horário. Devolve uma lista de linhas e a quantidade de itens.
    param([datetime]$Ref, [int]$AntesMin = 10, [int]$DepoisMin = 90)
    $l = New-Object System.Collections.Generic.List[string]
    if ($env:OS -ne 'Windows_NT') { return @{ Linhas = @(); N = 0; Whea = 0; Gpu = 0; Disco = 0 } }
    $ini = $Ref.AddMinutes(-$AntesMin); $fim = $Ref.AddMinutes($DepoisMin)
    $provs = 'Microsoft-Windows-Kernel-Power', 'Microsoft-Windows-WHEA-Logger', 'nvlddmkm', 'Display', 'amdkmdag', 'amdwddmg', 'disk', 'stornvme', 'storahci', 'Ntfs', 'volmgr', 'EventLog', 'Microsoft-Windows-WER-SystemErrorReporting', 'Microsoft-Windows-Kernel-PnP', 'Microsoft-Windows-DriverFrameworks-UserMode'
    $n = 0; $whea = 0; $gpu = 0; $disco = 0
    try {
        $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; StartTime = $ini; EndTime = $fim } -MaxEvents 600 -ErrorAction Stop | Where-Object { $provs -contains $_.ProviderName -and ($_.Level -le 3 -or $_.Id -in 41, 6008, 1001) } | Sort-Object TimeCreated)
        $vistos = @{}
        foreach ($e in $ev) {
            $chave = '{0}|{1}' -f $e.ProviderName, $e.Id
            if ($vistos.ContainsKey($chave)) { $vistos[$chave].N++; continue }
            $msg = ("$($e.Message)" -split "`r?`n" | Select-Object -First 1); if ($msg.Length -gt 150) { $msg = $msg.Substring(0, 150) + '...' }
            $o = @{ Hora = $e.TimeCreated; Prov = $e.ProviderName; Id = $e.Id; Msg = $msg; N = 1 }
            $vistos[$chave] = $o
            if ($e.ProviderName -match 'WHEA') { $whea++ }
            if ($e.ProviderName -match 'nvlddmkm|Display|amdkmdag|amdwddmg') { $gpu++ }
            if ($e.ProviderName -match 'disk|stornvme|storahci|Ntfs|volmgr') { $disco++ }
        }
        foreach ($o in ($vistos.Values | Sort-Object { $_.Hora })) {
            $rep = ''; if ($o.N -gt 1) { $rep = (' (x{0})' -f $o.N) }
            $l.Add(('{0}  {1} #{2}{3}: {4}' -f $o.Hora.ToString('HH:mm:ss'), $o.Prov, $o.Id, $rep, $o.Msg))
            $n++
        }
    } catch { }
    try {
        $dumps = @()
        foreach ($d in @((Join-Path $env:SystemRoot 'Minidump'), (Join-Path $env:SystemRoot 'LiveKernelReports'))) {
            if (Test-Path -LiteralPath $d) { $dumps += @(Get-ChildItem -LiteralPath $d -Recurse -Filter '*.dmp' -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $ini -and $_.LastWriteTime -le $fim }) }
        }
        foreach ($f in $dumps) { $l.Add(('{0}  Arquivo de falha: {1}' -f $f.LastWriteTime.ToString('HH:mm:ss'), $f.FullName)); $n++ }
    } catch { }
    return @{ Linhas = $l.ToArray(); N = $n; Whea = $whea; Gpu = $gpu; Disco = $disco }
}

function Get-ConclusaoTravamento {
    # Junta o padrão da sessão e os eventos em passos práticos. Recebe @{ Analise; Eventos }.
    param($Analise, $Eventos)
    $c = New-Object System.Collections.Generic.List[string]
    if ($Eventos -and $Eventos.Whea -gt 0) { $c.Add('O Windows registrou erros de hardware (WHEA) ao redor do travamento: o problema é de hardware (processador, memória ou PCIe). Teste a memória (MemTest86 ou o Diagnóstico de Memória do Windows), reencaixe a placa de vídeo e confira a BIOS.') }
    if ($Eventos -and $Eventos.Disco -gt 0) { $c.Add('Houve erros de disco ao redor do travamento: veja a saúde do disco (SMART) no relatório do WinDiag.') }
    if ($Eventos -and $Eventos.Gpu -gt 0) { $c.Add('O driver de vídeo registrou erros ao redor do travamento: reinstale o driver com limpeza (DDU), de preferência uma versão mais antiga.') }
    if ($Analise) {
        switch ($Analise.Padrao) {
            'sustentada' { $c.Add('Padrão: travou depois de carga contínua. Limite a energia da placa a 60% (MSI Afterburner) e jogue; se não travar, a causa é fonte ou o pico de consumo da placa. Troque a fonte por uma emprestada e confira a ventilação do gabinete.') }
            'transicao'  { $c.Add('Padrão: travou na saída do repouso para a carga. Desligue a economia de energia do PCIe, teste sem o agendamento de GPU por hardware, feche programas de sobreposição e teste com outra fonte.') }
            'ocioso'     { $c.Add('Padrão: travou com a placa em repouso. Veja driver, cabo e monitor, e a opção "Power Supply Idle Control" na BIOS (Ryzen).') }
        }
        if ($Analise.SensoresParadosSeg -ge 6) { $c.Add('Os sensores pararam de atualizar antes do fim do registro: o computador inteiro provavelmente parou (e não só a imagem). Isso afasta o driver de vídeo isolado e reforça fonte, memória ou placa-mãe.') }
    }
    if ($c.Count -eq 0) { $c.Add('Os dados disponíveis não apontam uma causa. Continue com o monitor ligado nas próximas sessões de jogo e repita esta análise depois do próximo travamento.') }
    $c.Add('Nenhum programa prova defeito de fonte, memória ou placa: só a troca de peça confirma.')
    return $c.ToArray()
}

function Format-TextoInvestigacao {
    param($Analise, $Eventos, $Config, $Conclusao)
    $t = New-Object System.Collections.Generic.List[string]
    $t.Add('WinDiag - investigação do último travamento')
    $t.Add('')
    $t.Add('1) O que o monitor gravou')
    if ($Analise) {
        foreach ($x in $Analise.Linhas) { $t.Add('  ' + $x) }
        if ($Analise.Alertas.Count -gt 0) { $t.Add('  Alertas: ' + ($Analise.Alertas -join ' ')) }
        $t.Add('  Conclusão do monitor: ' + $Analise.Veredito)
    } else { $t.Add('  Nenhum registro do monitor foi encontrado. Ligue o monitor antes de jogar para o próximo travamento ficar gravado.') }
    $t.Add('')
    $t.Add('2) O que o Windows registrou ao redor desse horário')
    if ($Eventos -and $Eventos.Linhas.Count -gt 0) { foreach ($x in $Eventos.Linhas) { $t.Add('  ' + $x) } } else { $t.Add('  Nenhum evento de erro relevante nessa janela.') }
    $t.Add('')
    $t.Add('3) Configurações que influenciam travamentos')
    if ($Config -and $Config.Linhas.Count -gt 0) { foreach ($x in $Config.Linhas) { $t.Add('  ' + $x) } } else { $t.Add('  Nada a informar.') }
    $t.Add('')
    $t.Add('4) Próximos passos')
    foreach ($x in $Conclusao) { $t.Add('  - ' + $x) }
    if ($Analise) { $t.Add(''); $t.Add('Arquivo completo do monitor: ' + $Analise.Arquivo) }
    return ($t -join "`r`n")
}

function Invoke-InvestigarTravamento {
    # Reúne tudo sobre o último travamento e devolve o texto pronto. $Arquivo opcional (sessão a analisar).
    param([string]$Arquivo = '')
    $f = $Arquivo
    if (-not $f) { $e = Get-EstadoMonitor; $f = if ($e) { [string]$e.Arquivo } else { Get-UltimaSessaoMonitor } }
    $an = $null; $ev = $null
    if ($f) {
        $an = Get-AnaliseSessao -Arquivo $f
        if ($an -and $an.UltimoRegistro) { $ev = Get-EventosAoRedor -Ref $an.UltimoRegistro }
    }
    if (-not $ev) { $ev = Get-EventosAoRedor -Ref (Get-Date).AddMinutes(-30) -AntesMin 60 -DepoisMin 90 }
    $cfg = Get-ConfigTravamento
    $con = Get-ConclusaoTravamento -Analise $an -Eventos $ev
    return (Format-TextoInvestigacao -Analise $an -Eventos $ev -Config $cfg -Conclusao $con)
}
#endregion investigação de travamento e configurações

if ($Executar) {
    $dir = Split-Path -Parent $MyInvocation.MyCommand.Path
    . (Join-Path $dir 'WinDiag-Bench.ps1')
    [void](Invoke-Monitor -Intervalo $Intervalo)
}
