@echo off
title WinDiag
rem Lancador do WinDiag: de duplo clique neste arquivo.
rem Argumentos opcionais sao repassados, por exemplo:  Executar-WinDiag.bat -SomenteLeitura
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0WinDiag.ps1" %*
if errorlevel 1 pause
