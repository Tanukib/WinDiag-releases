﻿<#
.SYNOPSIS
    Desinstala o WinDiag (programa, atalhos, verificação semanal automática e registro em "Aplicativos e recursos").

.DESCRIPTION
    Não apaga os relatórios (pasta WinDiag na Área de Trabalho) nem desfaz alterações feitas no Windows.
    Se você ativou a proteção do driver de vídeo, use antes, no WinDiag, "Desfazer bloqueios de driver do WinDiag".
    Abre uma janela no mesmo estilo do WinDiag. Com -SemPerguntas (ou se a janela não puder abrir) funciona em modo texto.
#>
param([switch]$SemPerguntas, [switch]$ApagarDados)

$ErrorActionPreference = 'Continue'
$pasta = $PSScriptRoot

function Invoke-Desinstalacao {
    # Faz a desinstalação e devolve as linhas do que foi feito.
    param([bool]$ApagarDados)
    $L = New-Object System.Collections.Generic.List[string]
    try {
        # Se o monitor em tempo real estiver ligado, encerra antes de apagar os arquivos.
        $mon = @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction Stop | Where-Object { $_.CommandLine -match 'WinDiag-Monitor\.ps1' })
        foreach ($p in $mon) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
        if ($mon.Count -gt 0) { $L.Add('Monitor em tempo real encerrado.') }
    } catch { }
    foreach ($atalho in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'WinDiag.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'WinDiag.lnk'))) {
        if (Test-Path -LiteralPath $atalho) { Remove-Item -LiteralPath $atalho -Force -ErrorAction SilentlyContinue; $L.Add("Atalho removido: $atalho") }
    }
    try { Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WinDiag' -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    # Verificação semanal automática (se o usuário a ativou)
    try {
        $t = Get-ScheduledTask -TaskName 'WinDiag - verificação semanal' -ErrorAction Stop
        if ($t) {
            try { Unregister-ScheduledTask -TaskName 'WinDiag - verificação semanal' -Confirm:$false -ErrorAction Stop; $L.Add('Verificação semanal automática removida.') }
            catch { $L.Add('Não consegui remover a verificação semanal automática. Abra o Agendador de Tarefas do Windows e apague a tarefa "WinDiag - verificação semanal".') }
        }
    } catch { }
    if ($ApagarDados) {
        $dados = Join-Path $env:LOCALAPPDATA 'WinDiag'
        if ($env:LOCALAPPDATA -and (Test-Path -LiteralPath $dados)) { Remove-Item -LiteralPath $dados -Recurse -Force -ErrorAction SilentlyContinue; $L.Add("Dados removidos: $dados") }
    }
    # A própria pasta só pode ser apagada depois que este script terminar: um comando separado faz isso.
    if ((Split-Path -Leaf $pasta) -eq 'WinDiag' -and $pasta -like '*\Programs\WinDiag') {
        $cmd = 'ping 127.0.0.1 -n 4 >nul & rd /s /q "{0}"' -f $pasta
        Start-Process -FilePath 'cmd.exe' -ArgumentList "/c $cmd" -WindowStyle Hidden
        $L.Add("A pasta do programa será apagada em instantes: $pasta")
    } else {
        $L.Add("Esta cópia não está na pasta de instalação padrão; apague a pasta manualmente: $pasta")
    }
    return $L.ToArray()
}

function Show-JanelaDesinstalar {
    # Janela no estilo do WinDiag: confirma, desinstala e mostra o resultado. Devolve $false se não conseguiu abrir.
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        try {
            Add-Type -Namespace WD -Name Dpi -MemberDefinition '[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetProcessDPIAware();' -ErrorAction SilentlyContinue
            [void][WD.Dpi]::SetProcessDPIAware()
        } catch { }
        try {
            # Identidade própria na barra de tarefas: sem isso o Windows mostra o ícone do PowerShell em vez do ícone da janela.
            Add-Type -Namespace WD -Name Shell -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);' -ErrorAction SilentlyContinue
            [void][WD.Shell]::SetCurrentProcessExplicitAppUserModelID('WinDiag.Desinstalar')
        } catch { }
        [System.Windows.Forms.Application]::EnableVisualStyles()
    } catch { return $false }

    $g0 = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    $k = [double]($g0.DpiX / 96.0); $g0.Dispose()
    if ($k -lt 1) { $k = 1.0 }
    function PX { param([double]$v) return [int][Math]::Round($v * $k) }
    function Cor { param([string]$h) return [System.Drawing.ColorTranslator]::FromHtml($h) }
    function Fonte { param([double]$t = 10, [bool]$neg = $false) $n = if ($neg) { 'Segoe UI Semibold' } else { 'Segoe UI' }; return (New-Object System.Drawing.Font($n, [single]$t, [System.Drawing.FontStyle]::Regular)) }
    # Mesma paleta do WinDiag
    $Paleta = @{ Fundo = '#F6F7F9'; Borda = '#E3E7ED'; BordaForte = '#D2D8E0'; Texto = '#1B2430'; Texto2 = '#5F6B7A'; Texto3 = '#8A94A3'
            Acento = '#2563EB'; AcentoHover = '#1D4ED8'; Perigo = '#DC2626'; PerigoHover = '#B91C1C'; Ok = '#16A34A' }

    function Nova-Botao {
        param([string]$Texto, [string]$Estilo, [int]$Larg)
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $Texto; $b.Name = $Estilo
        $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0
        $b.Size = New-Object System.Drawing.Size((PX $Larg), (PX 44))
        $b.Cursor = [System.Windows.Forms.Cursors]::Hand
        $b.Font = Fonte 10.5 ($Estilo -ne 'secundario')
        $b.UseVisualStyleBackColor = $false
        $b.Tag = @{ Hover = $false }
        $b.Add_MouseEnter({ param($r, $e) $r.Tag.Hover = $true; $r.Invalidate() })
        $b.Add_MouseLeave({ param($r, $e) $r.Tag.Hover = $false; $r.Invalidate() })
        $b.Add_Paint({
            param($r, $e)
            $gr = $e.Graphics
            $gr.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $h = [bool]$r.Tag.Hover
            $borda = $null
            switch ($r.Name) {
                'primario'   { $fill = if ($h) { Cor $Paleta.AcentoHover } else { Cor $Paleta.Acento }; $fore = [System.Drawing.Color]::White }
                'perigo'     { $fill = if ($h) { Cor $Paleta.PerigoHover } else { Cor $Paleta.Perigo }; $fore = [System.Drawing.Color]::White }
                default      { $fill = if ($h) { Cor '#F1F4F8' } else { [System.Drawing.Color]::White }; $fore = Cor $Paleta.Texto; $borda = Cor $Paleta.BordaForte }
            }
            $gr.Clear($r.Parent.BackColor)
            $rad = PX 8; $d = $rad * 2
            $w = $r.Width - 2; $hh = $r.Height - 2
            $p = New-Object System.Drawing.Drawing2D.GraphicsPath
            $p.AddArc(0.5, 0.5, $d, $d, 180, 90); $p.AddArc(0.5 + $w - $d, 0.5, $d, $d, 270, 90)
            $p.AddArc(0.5 + $w - $d, 0.5 + $hh - $d, $d, $d, 0, 90); $p.AddArc(0.5, 0.5 + $hh - $d, $d, $d, 90, 90); $p.CloseFigure()
            $br = New-Object System.Drawing.SolidBrush($fill); $gr.FillPath($br, $p); $br.Dispose()
            if ($borda) { $pen = New-Object System.Drawing.Pen($borda); $gr.DrawPath($pen, $p); $pen.Dispose() }
            $p.Dispose()
            [System.Windows.Forms.TextRenderer]::DrawText($gr, $r.Text, $r.Font, (New-Object System.Drawing.Rectangle(0, 0, $r.Width, $r.Height)), $fore,
                ([System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::SingleLine))
        })
        return $b
    }
    function Nova-Etiqueta {
        param([string]$Texto, [double]$Tam, [bool]$Neg, [string]$Cor, [int]$X, [int]$Y, [int]$W, [int]$H)
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $Texto; $l.Font = Fonte $Tam $Neg; $l.ForeColor = Cor $Paleta[$Cor]
        $l.AutoSize = $false; $l.BackColor = [System.Drawing.Color]::Transparent
        $l.Location = New-Object System.Drawing.Point((PX $X), (PX $Y)); $l.Size = New-Object System.Drawing.Size((PX $W), (PX $H))
        return $l
    }

    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'Desinstalar o WinDiag'
    $f.StartPosition = 'CenterScreen'
    $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.ShowInTaskbar = $true; $f.ShowIcon = $true
    $f.ClientSize = New-Object System.Drawing.Size((PX 580), (PX 470))
    $f.BackColor = Cor $Paleta.Fundo
    $f.Font = Fonte 10
    try { $f.Icon = New-Object System.Drawing.Icon((Join-Path $pasta 'windiag.ico')) } catch { try { $f.Icon = [System.Drawing.SystemIcons]::Shield } catch { } }

    # Cabeçalho branco, igual ao do WinDiag
    $cab = New-Object System.Windows.Forms.Panel
    $cab.Dock = 'Top'; $cab.Height = PX 64; $cab.BackColor = [System.Drawing.Color]::White
    $logo = New-Object System.Windows.Forms.PictureBox
    $logo.SizeMode = 'Zoom'; $logo.BackColor = [System.Drawing.Color]::White
    try { $logo.Image = New-Object System.Drawing.Bitmap((Join-Path $pasta 'windiag-logo.png')) } catch { try { $logo.Image = [System.Drawing.SystemIcons]::Shield.ToBitmap() } catch { } }
    $logo.Size = New-Object System.Drawing.Size((PX 34), (PX 34)); $logo.Location = New-Object System.Drawing.Point((PX 26), (PX 15))
    $cab.Controls.Add($logo)
    $cab.Controls.Add((Nova-Etiqueta 'WinDiag' 14 $true 'Texto' 70 9 300 26))
    $cab.Controls.Add((Nova-Etiqueta 'Desinstalação' 9 $false 'Texto3' 71 35 300 20))
    $linha = New-Object System.Windows.Forms.Panel
    $linha.Dock = 'Bottom'; $linha.Height = 1; $linha.BackColor = Cor $Paleta.Borda
    $cab.Controls.Add($linha)
    $f.Controls.Add($cab)

    $corpo = New-Object System.Windows.Forms.Panel
    $corpo.Dock = 'Fill'; $corpo.BackColor = Cor $Paleta.Fundo
    $f.Controls.Add($corpo)
    $corpo.BringToFront()

    # --- Tela 1: confirmação ---
    $f.ClientSize = New-Object System.Drawing.Size((PX 620), (PX 560))
    $t1 = Nova-Etiqueta 'Desinstalar o WinDiag?' 18 $true 'Texto' 28 20 564 38
    $t2 = Nova-Etiqueta 'Veja abaixo o que muda. Nada é apagado até você clicar em "Desinstalar".' 10.5 $false 'Texto2' 28 60 564 26
    function Nova-CaixaLista {
        param([string]$Titulo, [string[]]$Linhas, [string]$CorTitulo, [int]$X, [int]$W)
        $p = New-Object System.Windows.Forms.Panel
        $p.BackColor = [System.Drawing.Color]::White
        $p.Location = New-Object System.Drawing.Point((PX $X), (PX 96)); $p.Size = New-Object System.Drawing.Size((PX $W), (PX 128))
        $p.Add_Paint({ param($r, $e) $pen = New-Object System.Drawing.Pen((Cor $Paleta.Borda)); $e.Graphics.DrawRectangle($pen, 0, 0, $r.Width - 1, $r.Height - 1); $pen.Dispose() })
        $p.Controls.Add((Nova-Etiqueta $Titulo 10.5 $true $CorTitulo 14 10 ($W - 28) 22))
        $y = 38
        foreach ($ln in $Linhas) {
            $p.Controls.Add((Nova-Etiqueta ([string][char]0x2022 + '  ' + $ln) 9.5 $false 'Texto2' 14 $y ($W - 28) 40))
            $y += 38
        }
        return $p
    }
    $cxRem = Nova-CaixaLista 'Será removido' @('O programa e os atalhos', 'O registro em "Aplicativos e recursos"') 'Perigo' 28 276
    $cxFic = Nova-CaixaLista 'Continua no computador' @('Os relatórios da pasta "WinDiag" na Área de Trabalho', 'Alterações já feitas no Windows') 'Ok' 316 276
    $aviso = Nova-Etiqueta 'Atenção: desinstalar não desfaz alterações já feitas no Windows (por exemplo, a proteção do driver de vídeo). Para desfazê-las, cancele e use, no WinDiag, "Desfazer bloqueios de driver do WinDiag".' 9.5 $false 'Texto' 28 240 564 76
    $aviso.BackColor = Cor '#FFFBEB'; $aviso.ForeColor = Cor '#92400E'
    $aviso.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
    $chk = New-Object System.Windows.Forms.CheckBox
    $chk.Text = 'Apagar também os dados do WinDiag (estimativas de tempo, histórico de alterações, notas de saúde e testes de desempenho).'
    $chk.AutoSize = $false; $chk.Font = Fonte 9.5; $chk.ForeColor = Cor $Paleta.Texto2
    $chk.Location = New-Object System.Drawing.Point((PX 28), (PX 332)); $chk.Size = New-Object System.Drawing.Size((PX 564), (PX 48))
    $chk.Checked = $ApagarDados
    # Barra de botões embaixo (padrão do Windows): confirmação à direita, cancelar ao lado
    $barra = New-Object System.Windows.Forms.Panel
    $barra.Dock = 'Bottom'; $barra.Height = PX 72; $barra.BackColor = [System.Drawing.Color]::White
    $linhaB = New-Object System.Windows.Forms.Panel
    $linhaB.Dock = 'Top'; $linhaB.Height = 1; $linhaB.BackColor = Cor $Paleta.Borda
    $barra.Controls.Add($linhaB)
    $bCancelar = Nova-Botao 'Cancelar' 'secundario' 140
    $bDesinst  = Nova-Botao 'Desinstalar' 'perigo' 160
    $bDesinst.Location  = New-Object System.Drawing.Point(($f.ClientSize.Width - $bDesinst.Width - (PX 28)), (PX 14))
    $bCancelar.Location = New-Object System.Drawing.Point(($bDesinst.Left - $bCancelar.Width - (PX 12)), (PX 14))
    $rod = Nova-Etiqueta 'Nada é enviado para a internet.' 8.5 $false 'Texto3' 28 26 240 22
    foreach ($c in @($bCancelar, $bDesinst, $rod)) { $barra.Controls.Add($c) }
    $f.Controls.Add($barra)
    foreach ($c in @($t1, $t2, $cxRem, $cxFic, $aviso, $chk)) { $corpo.Controls.Add($c) }
    $corpo.BringToFront()
    $f.CancelButton = $bCancelar
    $f.AcceptButton = $bCancelar   # Enter cancela: desinstalar exige um clique de propósito

    $bCancelar.Add_Click({ $f.Close() })
    $bDesinst.Add_Click({
        try {
            $bDesinst.Enabled = $false; $bCancelar.Enabled = $false
            $f.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $linhas = Invoke-Desinstalacao -ApagarDados $chk.Checked
            $f.Cursor = [System.Windows.Forms.Cursors]::Default
            # --- Tela 2: resultado ---
            $corpo.Controls.Clear()
            $barra.Controls.Clear()
            $r1 = Nova-Etiqueta ([string][char]0x2713 + '  WinDiag desinstalado') 18 $true 'Ok' 28 22 564 40
            $r2 = Nova-Etiqueta ($linhas -join "`r`n") 10 $false 'Texto2' 28 76 564 380
            $bFechar = Nova-Botao 'Fechar' 'primario' 160
            $bFechar.Location = New-Object System.Drawing.Point(($f.ClientSize.Width - $bFechar.Width - (PX 28)), (PX 14))
            $bFechar.Add_Click({ $f.Close() })
            $barra.Controls.Add($bFechar)
            foreach ($c in @($r1, $r2)) { $corpo.Controls.Add($c) }
            $f.AcceptButton = $bFechar; $f.CancelButton = $bFechar
        } catch {
            $f.Cursor = [System.Windows.Forms.Cursors]::Default
            [void][System.Windows.Forms.MessageBox]::Show("Não foi possível desinstalar: $($_.Exception.Message)", 'WinDiag', 'OK', 'Error')
            $f.Close()
        }
    })
    [void]$f.ShowDialog()
    return $true
}

if (-not $SemPerguntas) {
    $abriu = $false
    try { $abriu = Show-JanelaDesinstalar } catch { $abriu = $false }
    if ($abriu) { exit 0 }
    # Sem janela (ex.: ambiente sem interface gráfica): modo texto
    Write-Host 'Desinstalando o WinDiag...' -ForegroundColor Cyan
    Write-Host 'Atenção: isto NÃO desfaz alterações já feitas no Windows (por exemplo, a proteção do driver de vídeo).' -ForegroundColor Yellow
    Write-Host 'Se quiser desfazê-las, cancele agora e use, no WinDiag, "Desfazer bloqueios de driver do WinDiag".'
    $r = Read-Host 'Continuar com a desinstalação? [s/N]'
    if ($r -notmatch '^\s*[sSyY]') { Write-Host 'Nada foi feito.'; exit 0 }
    $d = Read-Host 'Apagar também os dados do WinDiag? Os relatórios da Área de Trabalho são mantidos. [s/N]'
    $ApagarDados = ($d -match '^\s*[sSyY]')
}
foreach ($l in (Invoke-Desinstalacao -ApagarDados ([bool]$ApagarDados))) { Write-Host "  $l" }
Write-Host 'WinDiag desinstalado.' -ForegroundColor Green
