@echo off
setlocal
title WinDiag - criar atalho
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Criar-Atalho.ps1"
echo.
pause
