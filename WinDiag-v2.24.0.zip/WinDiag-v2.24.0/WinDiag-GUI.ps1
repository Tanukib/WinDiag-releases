﻿<#
.SYNOPSIS
    WinDiag - interface gráfica para pessoas leigas.

.DESCRIPTION
    Janela simples em etapas: verificar, ver o que foi encontrado (em linguagem comum) e corrigir
    com confirmação. O motor de diagnóstico é o mesmo do WinDiag.ps1 e roda em segundo plano,
    para a janela não travar.

    Abra com o arquivo Abrir-WinDiag.bat (duplo clique).
    Licença: MIT.
#>

$ErrorActionPreference = 'Continue'

# ----------------------------------------------------------------------------
# Início seguro: qualquer falha antes da janela aparece em uma caixa de mensagem
# ----------------------------------------------------------------------------
try { . (Join-Path $PSScriptRoot 'WinDiag-Monitor.ps1') } catch { }
$script:PastaDados = ''
try { $script:PastaDados = Join-Path $env:LOCALAPPDATA 'WinDiag' } catch { }
if (-not $script:PastaDados) { $script:PastaDados = Join-Path ([IO.Path]::GetTempPath()) 'WinDiag' }
$script:ArquivoErros = Join-Path $script:PastaDados 'erros.log'

function Write-LogErro {
    # Grava o erro (com versão, Windows e pilha de chamadas) em %LOCALAPPDATA%\WinDiag\erros.log e devolve o texto gravado.
    param($Erro, [string]$Origem = '')
    $msg = "$Erro"
    $linhas = New-Object System.Collections.Generic.List[string]
    $linhas.Add(("[{0}] {1} {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Origem, $msg).Trim())
    $linhas.Add(("    WinDiag {0} | PowerShell {1} | {2}" -f $script:Versao, $PSVersionTable.PSVersion, [Environment]::OSVersion.VersionString))
    try {
        $ex = $null
        if ($Erro -is [System.Management.Automation.ErrorRecord]) { $ex = $Erro.Exception } elseif ($Erro -is [Exception]) { $ex = $Erro }
        if ($Erro.ScriptStackTrace) { $linhas.Add($Erro.ScriptStackTrace) }
        if ($ex -and $ex.StackTrace) { $linhas.Add($ex.StackTrace) }
        if ($ex -and $ex.InnerException) { $linhas.Add('Causa: ' + $ex.InnerException.Message) }
    } catch { }
    $texto = ($linhas -join "`r`n")
    try {
        New-Item -ItemType Directory -Force -Path $script:PastaDados -ErrorAction SilentlyContinue | Out-Null
        # Evita um arquivo gigante: acima de 512 KB, guarda só o final
        if ((Test-Path -LiteralPath $script:ArquivoErros) -and ((Get-Item -LiteralPath $script:ArquivoErros).Length -gt 524288)) {
            $resto = Get-Content -LiteralPath $script:ArquivoErros -Tail 400 -ErrorAction Stop
            Set-Content -LiteralPath $script:ArquivoErros -Value $resto -Encoding UTF8
        }
        Add-Content -LiteralPath $script:ArquivoErros -Value ($texto + "`r`n") -Encoding UTF8 -ErrorAction Stop
    } catch { }
    return $texto
}

function Registrar-Erro {
    param($Erro, [switch]$Silencioso)
    $texto = Write-LogErro $Erro
    if (-not $Silencioso) {
        try {
            $r = [System.Windows.Forms.MessageBox]::Show(
                "Ocorreu um erro inesperado:`r`n`r`n$Erro`r`n`r`nOs detalhes foram salvos em:`r`n$($script:ArquivoErros)`r`n`r`nDeseja copiar os detalhes para a área de transferência (para enviar a quem mantém o programa)?",
                'WinDiag', 'YesNo', 'Error')
            if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { [System.Windows.Forms.Clipboard]::SetText($texto) }
        } catch { }
    }
}

try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
} catch {
    Write-Host 'Não foi possível carregar a interface gráfica do Windows (WinForms).'
    exit 1
}

if ($env:OS -ne 'Windows_NT') {
    [void][System.Windows.Forms.MessageBox]::Show('O WinDiag funciona apenas no Windows.', 'WinDiag', 'OK', 'Error')
    exit 1
}
if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    [void][System.Windows.Forms.MessageBox]::Show(
        'O PowerShell está em modo restrito (normalmente por política da empresa ou escola). O WinDiag não consegue rodar assim.',
        'WinDiag', 'OK', 'Error')
    exit 1
}
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'WinDiag.ps1')) -or
    -not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'WinDiag-Worker.ps1'))) {
    [void][System.Windows.Forms.MessageBox]::Show(
        'Não encontrei os arquivos WinDiag.ps1 e WinDiag-Worker.ps1 na mesma pasta. Extraia o ZIP inteiro antes de abrir.',
        'WinDiag', 'OK', 'Error')
    exit 1
}

# Imagem nítida em telas com escala (125%, 150%...)
try {
    Add-Type -Namespace WinDiagNative -Name Dpi -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();'
    [void][WinDiagNative.Dpi]::SetProcessDPIAware()
} catch { }
try {
    # Identidade própria na barra de tarefas: sem isso o Windows agrupa a janela com o PowerShell e mostra o ícone dele.
    Add-Type -Namespace WinDiagNative -Name Shell -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);'
    [void][WinDiagNative.Shell]::SetCurrentProcessExplicitAppUserModelID('WinDiag.Diagnostico.GUI')
} catch { }
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch { }
try {
    # Erros não tratados da interface: registram no log e mostram uma caixa clara, em vez da caixa padrão do .NET.
    [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
    [System.Windows.Forms.Application]::add_ThreadException({
        param($remetente, $ev)
        try { Registrar-Erro $ev.Exception } catch { }
    })
} catch { }
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }

$script:Esc = 1.0
$script:Relogio = $null
try {
    $g0 = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    $script:Esc = [double]$g0.DpiX / 96.0
    $g0.Dispose()
} catch { }

# Ícone do WinDiag (arquivo windiag.ico ao lado dos scripts); se não existir, usa o escudo do Windows.
function Get-IconeWinDiag {
    try { $p = Join-Path $PSScriptRoot 'windiag.ico'; if (Test-Path -LiteralPath $p) { return (New-Object System.Drawing.Icon($p)) } } catch { }
    return [System.Drawing.SystemIcons]::Shield
}
function Get-LogoWinDiag {
    try { $p = Join-Path $PSScriptRoot 'windiag-logo.png'; if (Test-Path -LiteralPath $p) { return (New-Object System.Drawing.Bitmap($p)) } } catch { }
    return [System.Drawing.SystemIcons]::Shield.ToBitmap()
}

function PX { param([double]$n) return [int][Math]::Round($n * $script:Esc) }
function Cor { param([string]$hex) return [System.Drawing.ColorTranslator]::FromHtml($hex) }
function Fonte {
    param([double]$Tam = 10, [bool]$Negrito = $false)
    $nome = 'Segoe UI'
    if ($Negrito) { $nome = 'Segoe UI Semibold' }
    return (New-Object System.Drawing.Font($nome, [single]$Tam, [System.Drawing.FontStyle]::Regular))
}

# ----------------------------------------------------------------------------
# Estado
# ----------------------------------------------------------------------------
$script:Versao = '2.1'
try {
    $m = Select-String -LiteralPath (Join-Path $PSScriptRoot 'WinDiag.ps1') -Pattern "^\`$script:Versao\s*=\s*'([^']+)'" | Select-Object -First 1
    if ($m) { $script:Versao = $m.Matches[0].Groups[1].Value }
} catch { }

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$script:IsAdmin = (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$script:Sync = [hashtable]::Synchronized(@{ Fila = (New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'); Cancelar = $false })
$script:Opc = @{
    PastaScripts     = $PSScriptRoot
    PastaRelatorio   = ''
    SomenteLeitura   = (-not $script:IsAdmin)
    SemWindowsUpdate = $false
    PularScanVolumes = $false
    VerificacaoProfunda = $false
    AceitarTudo      = $false
    DiasEventos      = 30
}
$script:ModoAuto = $false
$script:RS = $null
$script:Ps = $null
$script:Async = $null
$script:WorkerCarregado = $false
$script:FimRecebido = $false
$script:Cancelando = $false
$script:FaseAtual = ''
$script:EmDialogo = $false
$script:Res = $null
$script:LarguraCards = 0

function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

# ----------------------------------------------------------------------------
# Pedido de permissão de administrador
# ----------------------------------------------------------------------------
if (-not $script:IsAdmin -and $PSCommandPath) {
    # Pede direto a permissão do Windows (UAC), sem pergunta extra. Se o usuário recusar, abre só para verificação.
    try {
        $h2 = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $PSCommandPath)
        Start-Process -FilePath $h2.Exe -ArgumentList $h2.Args -Verb RunAs -ErrorAction Stop
        exit
    } catch {
        [void][System.Windows.Forms.MessageBox]::Show(
            "A permissão de administrador não foi concedida. O WinDiag vai abrir apenas para verificação (não será possível corrigir).`r`n`r`nPara corrigir, feche e abra o WinDiag de novo e aceite o pedido do Windows.", 'WinDiag', 'OK', 'Information')
    }
}

# ----------------------------------------------------------------------------
# Janela de confirmação (substitui as perguntas do console)
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Idioma: inglês (parcial). Traduz os textos fixos da interface; os achados do diagnóstico continuam em português.
# Ativado quando o Windows está em inglês, ou com a variável de ambiente WINDIAG_IDIOMA=en.
# ----------------------------------------------------------------------------
$script:Ingles = $false
try {
    if ($env:WINDIAG_IDIOMA -eq 'en') { $script:Ingles = $true }
    elseif ($env:WINDIAG_IDIOMA -eq 'pt') { $script:Ingles = $false }
    elseif ((Get-UICulture).TwoLetterISOLanguageName -eq 'en') { $script:Ingles = $true }
} catch { }
$script:TradEN = @{
    'Vamos verificar o seu computador?' = 'Shall we check your computer?'
    'O WinDiag procura problemas em drivers, discos, memória, placa de vídeo e no histórico de erros do Windows, como telas azuis e travamentos. Ele só lê as informações: nada é alterado sem a sua permissão.' = 'WinDiag looks for problems in drivers, disks, memory, graphics card and the Windows error history, such as blue screens and freezes. It only reads information: nothing is changed without your permission.'
    'Leva de 2 a 10 minutos   ·   Você pode continuar usando o computador' = 'Takes 2 to 10 minutes   ·   You can keep using the computer'
    'Aberto sem permissão de administrador: dá para verificar, mas não para corrigir. Para corrigir, feche e abra de novo aceitando o pedido de permissão.' = 'Opened without administrator permission: you can scan, but not fix. To fix, close and reopen it and accept the permission prompt.'
    'Verificar meu computador' = 'Scan my computer'
    'Testar desempenho (processador, memória e vídeo)' = 'Test performance (CPU, memory and video)'
    'Ferramentas de reparo e restauração' = 'Repair and restore tools'
    'Mostrar opções avançadas' = 'Show advanced options'
    'Ocultar opções avançadas' = 'Hide advanced options'
    'Usar a internet na verificação: Windows Update (drivers pendentes) e teste de rede (pode demorar alguns minutos)' = 'Use the internet during the scan: Windows Update (pending drivers) and network test (may take a few minutes)'
    'Procurar erros nas unidades de disco (mais completo, porém mais lento)' = 'Look for errors on disk drives (more thorough, but slower)'
    'Verificação profunda do Windows (SFC e DISM): bem mais lenta; só se há telas azuis ou arquivos corrompidos' = 'Deep Windows check (SFC and DISM): much slower; only if there are blue screens or corrupted files'
    'Desfazer bloqueios de driver do WinDiag' = 'Undo WinDiag driver blocks'
    'Desfazer correções (restaurar drivers salvos)' = 'Undo fixes (restore saved drivers)'
    'Recriar o atalho do WinDiag (Área de Trabalho e Menu Iniciar)' = 'Recreate the WinDiag shortcut (Desktop and Start Menu)'
    'Abrir a pasta das verificações anteriores' = 'Open the folder of previous scans'
    'Procurar atualização do WinDiag' = 'Check for a WinDiag update'
    'Cada verificação é salva em uma pasta própria dentro de "WinDiag", na Área de Trabalho. Revise os relatórios antes de compartilhar: podem conter o nome do computador e IDs de hardware.' = 'Each scan is saved in its own folder inside "WinDiag" on the Desktop. Review the reports before sharing: they may contain the computer name and hardware IDs.'
    'Diagnóstico de drivers, discos e hardware' = 'Drivers, disks and hardware diagnostics'
    'Corrigir automaticamente' = 'Fix automatically'
    'Corrigir (requer administrador)' = 'Fix (requires administrator)'
    'Nada a corrigir' = 'Nothing to fix'
    'Relatório completo' = 'Full report'
    'Salvar em PDF' = 'Save as PDF'
    'Abrir pasta' = 'Open folder'
    'Copiar resumo' = 'Copy summary'
    'Copiado!' = 'Copied!'
    'Verificar de novo' = 'Scan again'
    'Sair' = 'Exit'
    'Fechar' = 'Close'
    'Cancelar' = 'Cancel'
    'Voltar ao início' = 'Back to start'
    '← Voltar ao início' = '← Back to start'
    'Testar de novo' = 'Test again'
    'Abrir o relatório' = 'Open the report'
    'Desfazer alterações' = 'Undo changes'
    'Reiniciar o computador agora' = 'Restart the computer now'
    'Reiniciar mesmo assim (opcional)' = 'Restart anyway (optional)'
    'Mostrar detalhes técnicos' = 'Show technical details'
    'Meu computador' = 'My computer'
    'Detalhes técnicos' = 'Technical details'
    'Incluir avisos apenas informativos' = 'Include informational notices'
    'Mostrar' = 'Show'
    'Ver mais: o que é isso e preciso me preocupar?' = 'See more: what is this and should I worry?'
    'Ver menos' = 'See less'
    'O QUE FAZER' = 'WHAT TO DO'
    'Preparando...' = 'Preparing...'
    'Cancelando...' = 'Cancelling...'
    'Tempo decorrido: 00:00' = 'Elapsed time: 00:00'
    'Tudo certo! Nenhum problema relevante' = 'All good! No relevant problems'
    'Nenhuma correção foi aplicada' = 'No fix was applied'
    'Correções concluídas' = 'Fixes completed'
    'Correções interrompidas' = 'Fixes interrupted'
    'Teste de desempenho concluído' = 'Performance test completed'
    'Teste de desempenho: há um problema' = 'Performance test: there is a problem'
    'Teste de desempenho: pontos de atenção' = 'Performance test: points of attention'
    'Ferramentas de reparo e restauração ' = 'Repair and restore tools'
    'Cada ferramenta pede a sua confirmação antes de mexer em alguma coisa. As que corrigem o Windows exigem abrir o WinDiag como administrador.' = 'Each tool asks for your confirmation before changing anything. Those that fix Windows require opening WinDiag as administrator.'
    'Ver os pontos de restauração' = 'View restore points'
    'Criar um ponto de restauração agora' = 'Create a restore point now'
    'Abrir a Restauração do Sistema do Windows' = 'Open Windows System Restore'
    'Reparar a rede e a internet' = 'Repair the network and internet'
    'Reparar o Windows Update' = 'Repair Windows Update'
    'Reparar a Microsoft Store' = 'Repair the Microsoft Store'
    'Verificar o disco com o CHKDSK (na reinicialização)' = 'Check the disk with CHKDSK (on restart)'
    'Limpar arquivos temporários' = 'Clear temporary files'
    'Copiar meus arquivos pessoais (backup)' = 'Copy my personal files (backup)'
    'Ver o que o WinDiag já mudou neste computador' = 'See what WinDiag has already changed on this computer'
    'Mostra os pontos de volta que o Windows tem guardados (inclusive os criados pelo WinDiag).' = 'Shows the restore points Windows has stored (including those created by WinDiag).'
    'Guarda o estado atual do Windows para poder voltar a ele se algo der errado.' = 'Saves the current state of Windows so you can go back to it if something goes wrong.'
    'Abre a tela do Windows para voltar o computador a um ponto de restauração anterior.' = 'Opens the Windows screen to roll the computer back to an earlier restore point.'
    'Limpa o DNS e reinicia o Winsock e o IP. Resolve sites que não abrem com a rede conectada.' = 'Flushes DNS and resets Winsock and IP. Fixes websites that will not open while the network is connected.'
    'Corrige atualizações que travam, falham ou não aparecem (renomeia as pastas temporárias do Windows Update).' = 'Fixes updates that hang, fail or do not show up (renames the Windows Update temporary folders).'
    'Registra a loja novamente. Útil quando ela não abre ou não baixa aplicativos.' = 'Registers the store again. Useful when it does not open or does not download apps.'
    'Agenda a verificação completa do disco do Windows. Pode demorar de minutos a horas.' = 'Schedules a full check of the Windows disk. It can take from minutes to hours.'
    'Apaga arquivos temporários com mais de 2 dias para liberar espaço.' = 'Deletes temporary files older than 2 days to free up space.'
    'Copia Documentos, Imagens e Área de Trabalho para uma pasta ou pen drive que você escolher. Nada é apagado.' = 'Copies Documents, Pictures and Desktop to a folder or USB drive of your choice. Nothing is deleted.'
    'Lista todas as alterações feitas pelo WinDiag, com a data e como desfazer cada uma.' = 'Lists every change made by WinDiag, with the date and how to undo each one.'
    'ATENÇÃO: existem 2 formas de fazer as correções. Escolha uma:' = 'ATTENTION: there are 2 ways to apply the fixes. Choose one:'
    'WinDiag - ESCOLHA COMO CORRIGIR' = 'WinDiag - CHOOSE HOW TO FIX'
    '1) Corrigir tudo automaticamente' = '1) Fix everything automatically'
    '2) Escolher uma a uma' = '2) Choose one by one'
    'Clique no botão da forma que você quer. Se tiver dúvida, escolha "Escolher uma a uma".' = 'Click the button for the way you want. If in doubt, choose "Choose one by one".'
    'WinDiag - confirmar' = 'WinDiag - confirm'
    'Iniciar as correções' = 'Start the fixes'
    'Voltar sem corrigir' = 'Go back without fixing'
    'Iniciar o teste' = 'Start the test'
    'Agora não' = 'Not now'
    'Sim' = 'Yes'
    'Não' = 'No'
    'Sim, fazer' = 'Yes, do it'
    'Agora não ' = 'Not now'
    'Sim, cancelar' = 'Yes, cancel'
    'Continuar' = 'Continue'
    'WinDiag - confirmação' = 'WinDiag - confirmation'
    'WinDiag - confirmar correção' = 'WinDiag - confirm fix'
    'Não feche esta janela e não desligue o computador enquanto as correções estiverem em andamento.' = 'Do not close this window or turn off the computer while the fixes are in progress.'
    'Se aparecer uma pergunta, responda na caixa que abrir. Não feche esta janela até terminar.' = 'If a question appears, answer in the box that opens. Do not close this window until it finishes.'
}
# Textos da versão 2.22
$script:TradEN['Seu computador'] = 'Your computer'
$script:TradEN['SEU COMPUTADOR'] = 'YOUR COMPUTER'
$script:TradEN['ARMAZENAMENTO'] = 'STORAGE'
$script:TradEN['Lendo os componentes...'] = 'Reading components...'
$script:TradEN['Não foi possível ler os componentes agora.'] = 'Could not read the components right now.'
$script:TradEN['Sem informações do computador.'] = 'No computer information.'
$script:TradEN['Processador'] = 'Processor'
$script:TradEN['Memória'] = 'Memory'
$script:TradEN['Vídeo'] = 'Graphics'
$script:TradEN['Placa-mãe'] = 'Motherboard'
# Textos da versão 2.21
$script:TradEN['Baixar drivers novos com segurança'] = 'Download new drivers safely'
$script:TradEN['Baixar drivers novos: abrir as páginas oficiais'] = 'New drivers: open the official pages'
$script:TradEN['Conferir e instalar um driver baixado'] = 'Check and install a downloaded driver'
$script:TradEN['Drivers'] = 'Drivers'
$script:TradEN['Entender'] = 'Understand'
$script:TradEN['Corrigir'] = 'Fix'
$script:TradEN['Driver de vídeo: instalação limpa'] = 'Video driver: clean install'
$script:TradEN['Energia que derruba dispositivos'] = 'Power settings that drop devices'
$script:TradEN['Ver todos os drivers e o que cada um faz'] = 'Show all drivers and what each one does'
$script:TradEN['Reparar dispositivos com erro'] = 'Repair devices with errors'
$script:TradEN['Reiniciar o driver de vídeo'] = 'Restart the video driver'
$script:TradEN['Instalar drivers pelo Windows Update'] = 'Install drivers through Windows Update'
$script:TradEN['Limpar versões antigas de driver'] = 'Clean up old driver versions'
$script:TradEN['Limpeza do driver de vídeo (para instalação limpa)'] = 'Video driver cleanup (for a clean install)'
$script:TradEN['Guia: instalar o driver de vídeo do zero'] = 'Guide: install the video driver from scratch'
$script:TradEN['Desligar a economia de energia do USB'] = 'Turn off USB power saving'
# Textos da versão 2.20
$script:TradEN['O PC trava ou desliga'] = 'PC freezes or shuts down'
$script:TradEN['Monitor e sensores'] = 'Monitor and sensors'
$script:TradEN['Reparos e restauração'] = 'Repairs and restore'
$script:TradEN['Ajuda e autoteste'] = 'Help and self-test'
$script:TradEN['Reparos do Windows'] = 'Windows repairs'
$script:TradEN['Testes e estresse'] = 'Tests and stress'
$script:TradEN['Restaurar e desfazer'] = 'Restore and undo'
$script:TradEN['Descobrir o que aconteceu'] = 'Find out what happened'
$script:TradEN['Corrigir configurações que causam travamento (todas com desfazer)'] = 'Fix settings that cause freezes (all can be undone)'
$script:TradEN['Testar hipóteses de hardware'] = 'Test hardware hypotheses'
$script:TradEN['BIOS e drivers'] = 'BIOS and drivers'
$script:TradEN['Programas de sensores'] = 'Sensor programs'
$script:TradEN['Registro durante o jogo'] = 'Recording while you play'
$script:TradEN['Dentro do WinDiag'] = 'Inside WinDiag'
$script:TradEN['Ver o estado dos sensores'] = 'Show the sensor status'
$script:TradEN['Configurar e abrir o HWiNFO para o WinDiag'] = 'Configure and open HWiNFO for WinDiag'
$script:TradEN['Baixar a LibreHardwareMonitor (alternativa ao HWiNFO)'] = 'Download LibreHardwareMonitor (alternative to HWiNFO)'
$script:TradEN['Abrir a LibreHardwareMonitor'] = 'Open LibreHardwareMonitor'
$script:TradEN['Testar desempenho (processador, memória, disco, vídeo e estresse)'] = 'Run performance test (CPU, memory, disk, video and stress)'
$script:TradEN['Escolha pelo assunto: cada bloco abre só o que é dele. O PC trava? Comece por "O PC trava ou desliga". Problema com driver? Vá em "Drivers".'] = 'Pick by topic: each block opens only what belongs to it. PC freezing? Start with "PC freezes or shuts down". Driver problem? Go to "Drivers".'
# Textos da versão 2.19
$script:TradEN['Teste de memória RAM com padrões (cerca de 10 minutos)'] = 'RAM test with patterns (about 10 minutes)'
$script:TradEN['Grava e confere vários padrões de dados em quase toda a memória livre, com mais de um núcleo. Um erro aqui indica pente defeituoso, instável ou mal configurado (XMP/DOCP). Para uma checagem completa, use depois o teste de memória do Windows ou o MemTest86.'] = 'Writes and checks several data patterns across most of the free memory, using more than one core. An error here means a faulty, unstable or badly configured (XMP/DOCP) module. For a full check, also use the Windows memory test or MemTest86 afterwards.'
$script:TradEN['Estresse do disco com verificação (cerca de 10 minutos)'] = 'Disk stress with verification (about 10 minutes)'
$script:TradEN['Grava no disco um arquivo temporário grande e confere cada bloco ao ler, medindo a velocidade e o tempo de acesso. Mostra se o disco (principalmente HD) ou o cabo SATA corrompe dados sob uso contínuo. O arquivo é apagado no fim.'] = 'Writes a large temporary file to the disk and checks every block when reading it back, measuring speed and access time. Shows whether the disk (especially an HDD) or the SATA cable corrupts data under continuous use. The file is deleted at the end.'
$script:TradEN['Prolongar o teste de memória ou de disco para 30 minutos (acha erros que só aparecem com o aquecimento)'] = 'Extend the memory or disk test to 30 minutes (finds errors that only appear as things warm up)'
$script:TradEN['Desligar o agendamento de GPU por hardware'] = 'Turn off hardware-accelerated GPU scheduling'
$script:TradEN['Opção do Windows que em alguns computadores causa travamento de imagem em jogos. Pede confirmação, guarda o valor atual e precisa reiniciar. Dá para desfazer.'] = 'A Windows option that on some computers causes the picture to freeze in games. Asks for confirmation, saves the current value and needs a restart. Can be undone.'
$script:TradEN['Desligar a economia de energia do PCIe'] = 'Turn off PCIe power saving'
$script:TradEN['Impede que a placa de vídeo entre em repouso profundo quando o PC está na tomada. Pede confirmação e dá para desfazer.'] = 'Stops the graphics card from entering deep sleep while the PC is plugged in. Asks for confirmation and can be undone.'
$script:TradEN['Desligar a inicialização rápida do Windows'] = 'Turn off Windows Fast Startup'
$script:TradEN['Faz o Windows carregar os drivers do zero a cada ligada. Pede confirmação, precisa reiniciar e dá para desfazer.'] = 'Makes Windows load the drivers from scratch on every boot. Asks for confirmation, needs a restart and can be undone.'
$script:TradEN['Desfazer as mudanças de configuração'] = 'Undo the configuration changes'
$script:TradEN['Volta o agendamento de GPU, a economia do PCIe e a inicialização rápida ao valor que tinham antes do WinDiag.'] = 'Puts GPU scheduling, PCIe power saving and Fast Startup back to the values they had before WinDiag.'
$script:TradEN['Guia: testar com outra fonte de alimentação'] = 'Guide: test with another power supply'
$script:TradEN['Passo a passo para trocar a fonte por uma emprestada e descobrir se ela é a causa de travamentos sob carga.'] = 'Step by step to swap in a borrowed power supply and find out whether it causes freezes under load.'
$script:TradEN['Guia: limitar a energia da placa de vídeo'] = 'Guide: limit the graphics card power'
$script:TradEN['Passo a passo para reduzir o consumo da placa (Afterburner ou nvidia-smi) e testar se os picos de energia causam o travamento.'] = 'Step by step to reduce the card power draw (Afterburner or nvidia-smi) and test whether power spikes cause the freeze.'
$script:TradEN['BIOS e drivers: abrir a página da placa-mãe'] = 'BIOS and drivers: open the motherboard page'
$script:TradEN['Mostra a BIOS instalada e abre a página de suporte do fabricante da sua placa-mãe para conferir se existe versão mais nova.'] = 'Shows the installed BIOS and opens your motherboard maker support page so you can check for a newer version.'
$script:TradEN['Driver de chipset: abrir a página oficial'] = 'Chipset driver: open the official page'
$script:TradEN['Abre a página oficial do driver de chipset do fabricante do seu processador (AMD ou Intel).'] = 'Opens the official chipset driver page from your processor maker (AMD or Intel).'
$script:TradEN['Autoteste do WinDiag (conferir se tudo funciona)'] = 'WinDiag self-test (check that everything works)'
$script:TradEN['Confere, neste Windows, se cada recurso do WinDiag funciona (sensores, testes, vídeo, SMART). Gera um texto para enviar ao desenvolvedor se algo falhar.'] = 'Checks, on this Windows, whether each WinDiag feature works (sensors, tests, video, SMART). Produces a text to send to the developer if something fails.'
$script:TradEN['Correções de configuração (com desfazer)'] = 'Configuration fixes (with undo)'
$script:TradEN['Guias passo a passo para travamentos'] = 'Step-by-step guides for freezes'
$script:TradEN['Conferir o próprio WinDiag'] = 'Check WinDiag itself'
function Tr {
    param([string]$Texto)
    if ($script:Ingles -and $Texto -and $script:TradEN.ContainsKey($Texto)) { return $script:TradEN[$Texto] }
    return $Texto
}
function Traduzir-Controles {
    param($Pai)
    if (-not $script:Ingles) { return }
    foreach ($c in $Pai.Controls) {
        try {
            $t = [string]$c.Text
            if ($t -and $script:TradEN.ContainsKey($t)) {
                $c.Text = $script:TradEN[$t]
                if ($c -is [System.Windows.Forms.Button]) { Ajustar-LarguraBotao $c $c.Text ([int]($c.Width / [Math]::Max(1, [double](PX 1)))) }
            }
        } catch { }
        if ($c.Controls.Count -gt 0) { Traduzir-Controles $c }
    }
}

function Show-Dialogo {
    param(
        [string]$Titulo = 'WinDiag',
        [string]$Texto,
        [string]$Aviso = '',
        [string]$Exige = '',
        [string]$TextoSim = 'Sim',
        [string]$TextoNao = 'Não',
        [bool]$PadraoSim = $true,
        [bool]$Perigo = $false
    )
    $Titulo = Tr $Titulo; $Texto = Tr $Texto; $Aviso = Tr $Aviso; $TextoSim = Tr $TextoSim; $TextoNao = Tr $TextoNao
    $largura = PX 540
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $Titulo
    $f.StartPosition = 'CenterParent'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    $f.BackColor = [System.Drawing.Color]::White
    $f.Font = Fonte 10
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'

    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding((PX 22))
    $f.Controls.Add($flow)

    $lt = New-Object System.Windows.Forms.Label
    $lt.AutoSize = $true
    $lt.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $lt.Text = $Texto
    $lt.ForeColor = Cor '#1B2430'
    $lt.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $flow.Controls.Add($lt)

    if ($Aviso) {
        $la = New-Object System.Windows.Forms.Label
        $la.AutoSize = $true
        $la.MaximumSize = New-Object System.Drawing.Size($largura, 0)
        $la.Padding = New-Object System.Windows.Forms.Padding((PX 8))
        $la.Text = $Aviso
        if ($Perigo) { $la.BackColor = Cor '#FEF2F2'; $la.ForeColor = Cor '#991B1B' } else { $la.BackColor = Cor '#FFFBEB'; $la.ForeColor = Cor '#92400E' }
        $la.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
        $flow.Controls.Add($la)
    }

    $tb = $null
    if ($Exige) {
        $lx = New-Object System.Windows.Forms.Label
        $lx.AutoSize = $true
        $lx.MaximumSize = New-Object System.Drawing.Size($largura, 0)
        $lx.Text = "Para autorizar, digite $Exige na caixa abaixo:"
        $lx.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
        $flow.Controls.Add($lx)
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Width = PX 220
        $tb.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
        $flow.Controls.Add($tb)
    }

    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.FlowDirection = 'LeftToRight'
    $bar.AutoSize = $true
    $bar.AutoSizeMode = 'GrowAndShrink'
    $bar.WrapContents = $false
    $flow.Controls.Add($bar)

    $estiloSim = 'primario'
    if ($Perigo) { $estiloSim = 'perigo' }
    $btnSim = Nova-BotaoGrande $TextoSim $estiloSim 130 40
    $btnSim.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $btnNao = Nova-BotaoGrande $TextoNao 'secundario' 130 40
    $btnNao.DialogResult = [System.Windows.Forms.DialogResult]::No
    foreach ($bt in @($btnSim, $btnNao)) {
        $bt.AutoSize = $true
        $bt.AutoSizeMode = 'GrowAndShrink'
        $bt.MinimumSize = New-Object System.Drawing.Size((PX 130), (PX 40))
        $bt.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    }
    $bar.Controls.Add($btnSim)
    $bar.Controls.Add($btnNao)

    $f.CancelButton = $btnNao
    if ($PadraoSim -and -not $Exige) { $f.AcceptButton = $btnSim } else { $f.AcceptButton = $btnNao }

    if ($Exige) {
        $btnSim.Enabled = $false
        $tb.Add_TextChanged({ $btnSim.Enabled = ($tb.Text.Trim() -ceq $Exige) }.GetNewClosure())
    }

    $dono = $null
    if ($script:Form -and $script:Form.Visible) { $dono = $script:Form }
    try {
        if ($dono) { $r = $f.ShowDialog($dono) } else { $r = $f.ShowDialog() }
    } finally {
        $f.Dispose()
    }
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

# Janela de escolha do tipo de teste de desempenho. Devolve $true se o usuário iniciou; define $script:TesteLongo e $script:TesteEstresse.
$script:TesteLongo = $false
$script:TesteEstresse = $false
$script:TesteTransicao = $false
$script:TransPesado = $false
$script:EstresseProlongado = $false
$script:TesteMemoria = $false
$script:TesteDiscoEstresse = $false
$script:DuracaoLonga = $false
$script:TipoTeste = 'normal'
function Show-EscolhaTeste {
    $largura = PX 560
    $f = New-Object System.Windows.Forms.Form
    $f.Text = (Tr 'WinDiag - teste de desempenho')
    $f.StartPosition = 'CenterParent'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    $f.BackColor = [System.Drawing.Color]::White
    $f.Font = Fonte 10
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding((PX 22))
    $f.Controls.Add($flow)

    $intro = New-Object System.Windows.Forms.Label
    $intro.AutoSize = $true
    $intro.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $intro.ForeColor = Cor '#1B2430'
    $intro.Text = (Tr 'Qual teste você quer fazer? Os testes usam o computador com força: o processador fica em 100%, parte da memória livre é preenchida, o disco recebe um arquivo temporário (apagado no fim) e uma janela com animação abre sozinha (o teste de transição só abre e fecha uma tela cheia). Antes de começar, o WinDiag lê o computador e ajusta a intensidade para não travar computadores mais fracos.')
    $intro.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $flow.Controls.Add($intro)

    $opcoes = @(
        @{ Id = 'normal'; T = 'Teste normal (de 3 a 4 minutos)'; D = 'Processador, memória RAM, disco e placa de vídeo, com uma animação 3D em janela. É o ideal para conferir o estado geral e comparar com testes futuros.' },
        @{ Id = 'longo'; T = 'Teste longo (cerca de 7 minutos)'; D = 'O processador fica 3 minutos a 100% e a memória RAM é verificada 4 vezes. Mostra se o desempenho e a frequência caem com o aquecimento. Use se o computador esquenta, trava ou desliga sozinho.' },
        @{ Id = 'estresse'; T = 'Estresse de jogo pesado (de 6 a 10 minutos)'; D = 'Além dos testes normais, abre uma janela em tela cheia que leva a placa de vídeo ao limite, com o processador em carga parcial como num jogo. Liga a gravação do monitor sozinha. Use se o computador trava ou desliga ao jogar.' },
        @{ Id = 'transicao'; T = 'Teste de transição (cerca de 10 minutos)'; D = 'Abre e fecha uma tela cheia 40 vezes, trocando a resolução da tela a cada abertura (a tela pisca, como ao abrir um jogo em tela cheia) e deixando a placa de vídeo descansar entre as aberturas. A carga sobe aos poucos. Reproduz a troca de repouso para carga que acontece ao apertar Play num jogo. Use se a imagem trava justamente ao abrir um jogo. Liga a gravação do monitor sozinha.' },
        @{ Id = 'memoria'; T = 'Teste de memória RAM com padrões (cerca de 10 minutos)'; D = 'Grava e confere vários padrões de dados em quase toda a memória livre, com mais de um núcleo. Um erro aqui indica pente defeituoso, instável ou mal configurado (XMP/DOCP). Para uma checagem completa, use depois o teste de memória do Windows ou o MemTest86.' },
        @{ Id = 'disco'; T = 'Estresse do disco com verificação (cerca de 10 minutos)'; D = 'Grava no disco um arquivo temporário grande e confere cada bloco ao ler, medindo a velocidade e o tempo de acesso. Mostra se o disco (principalmente HD) ou o cabo SATA corrompe dados sob uso contínuo. O arquivo é apagado no fim.' }
    )
    $radios = @{}
    foreach ($o in $opcoes) {
        $rb = New-Object System.Windows.Forms.RadioButton
        $rb.Text = (Tr $o.T)
        $rb.AutoSize = $true
        $rb.Font = Fonte 10.5 $true
        $rb.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, 0)
        $rb.Checked = ($o.Id -eq $script:TipoTeste)
        $rb.Tag = $o.Id
        $flow.Controls.Add($rb)
        $radios[$o.Id] = $rb
        $ld = New-Object System.Windows.Forms.Label
        $ld.AutoSize = $true
        $ld.MaximumSize = New-Object System.Drawing.Size(($largura - (PX 24)), 0)
        $ld.ForeColor = Pal 'Texto2'
        $ld.Text = (Tr $o.D)
        $ld.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 6))
        $flow.Controls.Add($ld)
    }
    $chkJunto = New-Object System.Windows.Forms.CheckBox
    $chkJunto.Text = (Tr 'Incluir também o teste longo do processador e da memória (soma cerca de 4 minutos)')
    $chkJunto.AutoSize = $true
    $chkJunto.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $chkJunto.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $chkJunto.Checked = [bool]($script:TesteLongo -and $script:TesteEstresse)
    $chkJunto.Enabled = [bool]$radios['estresse'].Checked
    $flow.Controls.Add($chkJunto)
    $radios['estresse'].Add_CheckedChanged({ $chkJunto.Enabled = [bool]$radios['estresse'].Checked; if (-not $chkJunto.Enabled) { $chkJunto.Checked = $false } }.GetNewClosure())
    $chkProlong = New-Object System.Windows.Forms.CheckBox
    $chkProlong.Text = (Tr 'Prolongar o estresse da placa de vídeo para 20 minutos (para reproduzir travamentos que só aparecem depois de vários minutos de carga; soma cerca de 17 minutos)')
    $chkProlong.AutoSize = $true
    $chkProlong.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $chkProlong.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $chkProlong.Checked = [bool]($script:EstresseProlongado -and $script:TesteEstresse)
    $chkProlong.Enabled = [bool]$radios['estresse'].Checked
    $flow.Controls.Add($chkProlong)
    $radios['estresse'].Add_CheckedChanged({ $chkProlong.Enabled = [bool]$radios['estresse'].Checked; if (-not $chkProlong.Enabled) { $chkProlong.Checked = $false } }.GetNewClosure())

    $chkPesado = New-Object System.Windows.Forms.CheckBox
    $chkPesado.Text = (Tr 'Mais pesado: 60 aberturas, carga bem maior e mais lenta (cerca de 15 minutos). Use se o teste normal não travou.')
    $chkPesado.AutoSize = $true
    $chkPesado.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $chkPesado.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $chkPesado.Checked = [bool]($script:TransPesado -and $script:TesteTransicao)
    $chkPesado.Enabled = [bool]$radios['transicao'].Checked
    $flow.Controls.Add($chkPesado)
    $radios['transicao'].Add_CheckedChanged({ $chkPesado.Enabled = [bool]$radios['transicao'].Checked; if (-not $chkPesado.Enabled) { $chkPesado.Checked = $false } }.GetNewClosure())

    $chkLonga = New-Object System.Windows.Forms.CheckBox
    $chkLonga.Text = (Tr 'Prolongar o teste de memória ou de disco para 30 minutos (acha erros que só aparecem com o aquecimento)')
    $chkLonga.AutoSize = $true
    $chkLonga.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $chkLonga.Margin = New-Object System.Windows.Forms.Padding((PX 24), 0, 0, (PX 8))
    $chkLonga.Checked = [bool]($script:DuracaoLonga -and ($script:TesteMemoria -or $script:TesteDiscoEstresse))
    $chkLonga.Enabled = [bool]($radios['memoria'].Checked -or $radios['disco'].Checked)
    $flow.Controls.Add($chkLonga)
    foreach ($kk in @('memoria', 'disco')) { $radios[$kk].Add_CheckedChanged({ $chkLonga.Enabled = [bool]($radios['memoria'].Checked -or $radios['disco'].Checked); if (-not $chkLonga.Enabled) { $chkLonga.Checked = $false } }.GetNewClosure()) }

    $la = New-Object System.Windows.Forms.Label
    $la.AutoSize = $true
    $la.MaximumSize = New-Object System.Drawing.Size($largura, 0)
    $la.Padding = New-Object System.Windows.Forms.Padding((PX 8))
    $la.BackColor = Cor '#FFFBEB'; $la.ForeColor = Cor '#92400E'
    $la.Text = (Tr 'Salve seus trabalhos e feche jogos e vídeos antes. Se o seu computador já trava, reinicia sozinho ou esquenta muito, faça o teste com cuidado: ele exige bastante do hardware. Para ver as temperaturas, deixe o HWiNFO aberto (opcional). Nada é alterado no seu computador.')
    $la.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 12))
    $flow.Controls.Add($la)

    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.FlowDirection = 'LeftToRight'
    $bar.AutoSize = $true
    $bar.AutoSizeMode = 'GrowAndShrink'
    $bar.WrapContents = $false
    $flow.Controls.Add($bar)
    $btnSim = Nova-BotaoGrande (Tr 'Iniciar o teste') 'primario' 150 40
    $btnSim.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $btnNao = Nova-BotaoGrande (Tr 'Agora não') 'secundario' 130 40
    $btnNao.DialogResult = [System.Windows.Forms.DialogResult]::No
    foreach ($bt in @($btnSim, $btnNao)) {
        $bt.AutoSize = $true; $bt.AutoSizeMode = 'GrowAndShrink'
        $bt.MinimumSize = New-Object System.Drawing.Size((PX 130), (PX 40))
        $bt.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    }
    $bar.Controls.Add($btnSim); $bar.Controls.Add($btnNao)
    $f.AcceptButton = $btnSim; $f.CancelButton = $btnNao

    $dono = $null
    if ($script:Form -and $script:Form.Visible) { $dono = $script:Form }
    try { if ($dono) { $r = $f.ShowDialog($dono) } else { $r = $f.ShowDialog() } }
    finally {
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
            $tipo = 'normal'
            foreach ($k in $radios.Keys) { if ($radios[$k].Checked) { $tipo = $k } }
            $script:TipoTeste = $tipo
            $script:TesteEstresse = ($tipo -eq 'estresse')
            $script:TesteTransicao = ($tipo -eq 'transicao')
            $script:TesteMemoria = ($tipo -eq 'memoria')
            $script:TesteDiscoEstresse = ($tipo -eq 'disco')
            $script:DuracaoLonga = (($tipo -eq 'memoria' -or $tipo -eq 'disco') -and $chkLonga.Checked)
            $script:TransPesado = ($tipo -eq 'transicao' -and $chkPesado.Checked)
            $script:EstresseProlongado = ($tipo -eq 'estresse' -and $chkProlong.Checked)
            $script:TesteLongo = (($tipo -eq 'longo') -or ($tipo -eq 'estresse' -and $chkJunto.Checked))
        }
        $f.Dispose()
    }
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Abrir-Url {
    param([string]$Url)
    if ($Url -match '^https?://') {
        try { Start-Process $Url } catch { }
    }
}

# ----------------------------------------------------------------------------
# Estilo: paleta e componentes
# ----------------------------------------------------------------------------
$script:Pal = @{
    Fundo = '#F6F7F9'; Superficie = '#FFFFFF'; Borda = '#E3E7ED'; BordaForte = '#D2D8E0'
    Texto = '#1B2430'; Texto2 = '#5F6B7A'; Texto3 = '#8A94A3'
    Acento = '#2563EB'; AcentoHover = '#1D4ED8'; AcentoDown = '#1E40AF'
    Perigo = '#DC2626'; PerigoHover = '#B91C1C'; PerigoDown = '#991B1B'
    Aviso = '#D97706'; Ok = '#16A34A'; Info = '#64748B'
}
function Pal { param([string]$Nome) return (Cor $script:Pal[$Nome]) }

function Aplicar-EstiloBotao {
    param($B)
    $est = "$($B.Name)"
    $B.FlatStyle = 'Flat'
    try { $B.Invalidate() } catch { }
    if (-not $B.Enabled) {
        $B.BackColor = Cor '#E9ECF0'
        $B.ForeColor = Cor '#9AA4B2'
        $B.FlatAppearance.BorderSize = 0
        return
    }
    switch ($est) {
        'primario' {
            $B.BackColor = Pal 'Acento'; $B.ForeColor = [System.Drawing.Color]::White
            $B.FlatAppearance.BorderSize = 0
            $B.FlatAppearance.MouseOverBackColor = Pal 'AcentoHover'
            $B.FlatAppearance.MouseDownBackColor = Pal 'AcentoDown'
        }
        'perigo' {
            $B.BackColor = Pal 'Perigo'; $B.ForeColor = [System.Drawing.Color]::White
            $B.FlatAppearance.BorderSize = 0
            $B.FlatAppearance.MouseOverBackColor = Pal 'PerigoHover'
            $B.FlatAppearance.MouseDownBackColor = Pal 'PerigoDown'
        }
        default {
            $B.BackColor = [System.Drawing.Color]::White; $B.ForeColor = Pal 'Texto'
            $B.FlatAppearance.BorderSize = 1
            $B.FlatAppearance.BorderColor = Pal 'BordaForte'
            $B.FlatAppearance.MouseOverBackColor = Cor '#F1F4F8'
            $B.FlatAppearance.MouseDownBackColor = Cor '#E6EAF0'
        }
    }
}

function Nova-CaminhoArredondado {
    param([single]$X, [single]$Y, [single]$W, [single]$H, [single]$R)
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = [single]($R * 2)
    $p.AddArc($X, $Y, $d, $d, 180, 90)
    $p.AddArc(($X + $W - $d), $Y, $d, $d, 270, 90)
    $p.AddArc(($X + $W - $d), ($Y + $H - $d), $d, $d, 0, 90)
    $p.AddArc($X, ($Y + $H - $d), $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

function Ajustar-LarguraBotao {
    # Define o texto e garante que ele caiba no botão (largura mínima + respiro dos lados).
    param($B, [string]$Texto, [double]$LarguraMin = 0)
    $B.Text = $Texto
    $tw = [System.Windows.Forms.TextRenderer]::MeasureText($Texto, $B.Font).Width
    $B.Width = [int][Math]::Max((PX $LarguraMin), ($tw + (PX 44)))
    $B.Invalidate()
}

function Nova-BotaoGrande {
    # Estilo: primario (azul), perigo (vermelho) ou secundario (branco com borda fina). Cantos arredondados.
    param([string]$Texto, [string]$Estilo = 'secundario', [double]$Largura = 200, [double]$Altura = 40)
    $b = New-Object System.Windows.Forms.Button
    $b.Name = $Estilo
    $b.Text = $Texto
    if ($Estilo -eq 'secundario') { $b.Font = Fonte 10 } else { $b.Font = Fonte 10.5 $true }
    $tw = [System.Windows.Forms.TextRenderer]::MeasureText($Texto, $b.Font).Width
    $larg = [int][Math]::Max((PX $Largura), ($tw + (PX 44)))
    $b.Size = New-Object System.Drawing.Size($larg, (PX $Altura))
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 12), 0)
    $b.UseVisualStyleBackColor = $false
    $b.Tag = @{ Hover = $false; Down = $false; Teclado = $false }
    Aplicar-EstiloBotao $b
    $b.Add_EnabledChanged({ param($remetente, $ev) Aplicar-EstiloBotao $remetente })
    $b.Add_MouseEnter({ param($r, $ev) $r.Tag.Hover = $true; $r.Invalidate() })
    $b.Add_MouseLeave({ param($r, $ev) $r.Tag.Hover = $false; $r.Tag.Down = $false; $r.Invalidate() })
    $b.Add_MouseDown({ param($r, $ev) $r.Tag.Down = $true; $r.Tag.Teclado = $false; $r.Invalidate() })
    $b.Add_KeyUp({ param($r, $ev) $r.Tag.Teclado = $true; $r.Invalidate() })
    $b.Add_Enter({ param($r, $ev) $r.Invalidate() })
    $b.Add_MouseUp({ param($r, $ev) $r.Tag.Down = $false; $r.Invalidate() })
    $b.Add_GotFocus({ param($r, $ev) $r.Invalidate() })
    $b.Add_LostFocus({ param($r, $ev) $r.Invalidate() })
    $b.Add_Paint({
        param($r, $ev)
        try {
            $g = $ev.Graphics
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $hover = $false; $down = $false
            if ($r.Tag -is [hashtable]) { $hover = [bool]$r.Tag.Hover; $down = [bool]$r.Tag.Down }
            $borda = $null
            if (-not $r.Enabled) {
                $fill = Cor '#E9ECF0'; $fore = Cor '#9AA4B2'
            } elseif ("$($r.Name)" -eq 'primario') {
                $fill = if ($down) { Pal 'AcentoDown' } elseif ($hover) { Pal 'AcentoHover' } else { Pal 'Acento' }
                $fore = [System.Drawing.Color]::White
            } elseif ("$($r.Name)" -eq 'perigo') {
                $fill = if ($down) { Pal 'PerigoDown' } elseif ($hover) { Pal 'PerigoHover' } else { Pal 'Perigo' }
                $fore = [System.Drawing.Color]::White
            } else {
                $fill = if ($down) { Cor '#E6EAF0' } elseif ($hover) { Cor '#F1F4F8' } else { [System.Drawing.Color]::White }
                $fore = Pal 'Texto'
                $borda = if ($hover) { Cor '#AEB7C4' } else { Pal 'BordaForte' }
            }
            $fundo = [System.Drawing.Color]::White
            if ($r.Parent -and $r.Parent.BackColor.A -gt 0) { $fundo = $r.Parent.BackColor }
            $g.Clear($fundo)
            $rad = PX 8
            $caminho = Nova-CaminhoArredondado 0.5 0.5 ($r.Width - 2) ($r.Height - 2) $rad
            $pb = New-Object System.Drawing.SolidBrush($fill)
            $g.FillPath($pb, $caminho)
            $pb.Dispose()
            if ($borda) {
                $pen = New-Object System.Drawing.Pen($borda, 1)
                $g.DrawPath($pen, $caminho)
                $pen.Dispose()
            }
            $caminho.Dispose()
            if ($r.Focused -and $r.Tag.Teclado -and $r.Enabled) {
                $c2 = Nova-CaminhoArredondado 3 3 ($r.Width - 7) ($r.Height - 7) ($rad - 2)
                $pf = New-Object System.Drawing.Pen((Pal 'Acento'), 2)
                if ("$($r.Name)" -ne 'secundario') { $pf.Color = [System.Drawing.Color]::White }
                $g.DrawPath($pf, $c2)
                $pf.Dispose(); $c2.Dispose()
            }
            $flags = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::SingleLine -bor [System.Windows.Forms.TextFormatFlags]::EndEllipsis -bor [System.Windows.Forms.TextFormatFlags]::NoPrefix
            $ret = New-Object System.Drawing.Rectangle(0, 0, $r.Width, $r.Height)
            [System.Windows.Forms.TextRenderer]::DrawText($g, $r.Text, $r.Font, $ret, $fore, $flags)
        } catch { }
    })
    return $b
}

function Nova-Etiqueta {
    param([string]$Texto, [double]$Tam = 10, [bool]$Negrito = $false, [string]$CorNome = 'Texto', [double]$Altura = 30, [double]$Largura = 620)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Texto
    $l.AutoSize = $false
    $l.Height = PX $Altura
    $l.Width = PX $Largura
    $l.Font = Fonte $Tam $Negrito
    $l.ForeColor = Pal $CorNome
    $l.BackColor = [System.Drawing.Color]::Transparent
    $l.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
    return $l
}

function Centralizar {
    # Centraliza um filho dentro do pai; sem -Topo, centraliza também na vertical.
    param($Pai, $Filho, [double]$Topo = -1)
    $x = [int][Math]::Max((PX 24), ($Pai.ClientSize.Width - $Filho.Width) / 2)
    if ($Topo -ge 0) {
        $y = PX $Topo
    } else {
        $y = [int][Math]::Max((PX 24), ($Pai.ClientSize.Height - $Filho.Height) / 2 - (PX 30))
    }
    $Filho.Location = New-Object System.Drawing.Point($x, $y)
}

function Ajustar-Barra {
    # Quando os botões não cabem numa linha, a barra cresce e eles passam para a linha de baixo.
    # Mede pela largura da própria barra (a do painel interno pode estar desatualizada durante o redimensionamento).
    param($Barra)
    $fl = $Barra.Controls['fluxo']
    if (-not $fl) { return }
    $disp = [int]($Barra.ClientSize.Width - $fl.Padding.Horizontal)
    if ($disp -le 0) { return }
    $linhas = 1; $x = 0
    foreach ($c in $fl.Controls) {
        if (-not $c.Visible) { continue }
        $c.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 12), (PX 8))
        $w = $c.Width + $c.Margin.Horizontal
        if (($x + $w) -gt $disp -and $x -gt 0) { $linhas++; $x = 0 }
        $x += $w
    }
    $alvo = [int]((PX 16) + $linhas * (PX 52) + (PX 8))
    if ($alvo -lt (PX 76)) { $alvo = PX 76 }
    if ($Barra.Height -ne $alvo) { $Barra.Height = $alvo }
    # Força o encaixe do restante da página e o redesenho (evita botões cortados ou "fantasmas" ao maximizar).
    try { $fl.PerformLayout(); if ($Barra.Parent) { $Barra.Parent.PerformLayout() }; $Barra.Invalidate($true) } catch { }
}

function Nova-BarraAcoes {
    # Barra inferior branca com linha fina em cima; os botões entram em .Controls['fluxo'].
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Bottom'
    $p.Height = PX 76
    $p.BackColor = [System.Drawing.Color]::White
    $fl = New-Object System.Windows.Forms.FlowLayoutPanel
    $fl.Name = 'fluxo'
    $fl.Dock = 'Fill'
    $fl.WrapContents = $true
    $fl.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 16), (PX 24), 0)
    $p.Controls.Add($fl)
    $p.Add_Resize({ try { Ajustar-Barra $this } catch { } })
    $linha = New-Object System.Windows.Forms.Panel
    $linha.Dock = 'Top'
    $linha.Height = 1
    $linha.BackColor = Pal 'Borda'
    $p.Controls.Add($linha)
    return $p
}

# ----------------------------------------------------------------------------
# Janela principal
# ----------------------------------------------------------------------------
$script:Form = New-Object System.Windows.Forms.Form
$form = $script:Form
$form.Text = "WinDiag $($script:Versao) - diagnóstico do computador"
$form.StartPosition = 'CenterScreen'
# Tamanho inicial proporcional à tela: em notebook com escala 150% um tamanho fixo ocuparia a tela inteira ou passaria dela.
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.MinimumSize = New-Object System.Drawing.Size([int][Math]::Min((PX 840), $wa.Width * 0.9), [int][Math]::Min((PX 620), $wa.Height * 0.9))
$form.ClientSize = New-Object System.Drawing.Size([int][Math]::Min((PX 1180), $wa.Width * 0.92), [int][Math]::Min((PX 780), $wa.Height * 0.88))
$form.Font = Fonte 10
$form.BackColor = Pal 'Fundo'
try { $form.Icon = Get-IconeWinDiag } catch { }

# Área central (vai primeiro: o painel "Fill" precisa ser o último a ser encaixado)
$conteudo = New-Object System.Windows.Forms.Panel
$conteudo.Dock = 'Fill'
$form.Controls.Add($conteudo)

# Cabeçalho branco, discreto
$cab = New-Object System.Windows.Forms.Panel
$cab.Dock = 'Top'
$cab.Height = PX 64
$cab.BackColor = [System.Drawing.Color]::White
$logo = New-Object System.Windows.Forms.PictureBox
$logo.SizeMode = 'Zoom'
$logo.BackColor = [System.Drawing.Color]::White
try { $logo.Image = Get-LogoWinDiag } catch { }
$logo.Size = New-Object System.Drawing.Size((PX 34), (PX 34))
$logo.Location = New-Object System.Drawing.Point((PX 26), (PX 15))
$lblTitulo = New-Object System.Windows.Forms.Label
$lblTitulo.Text = 'WinDiag'
$lblTitulo.Font = Fonte 14 $true
$lblTitulo.ForeColor = Pal 'Texto'
$lblTitulo.AutoSize = $true
$lblTitulo.Location = New-Object System.Drawing.Point((PX 70), (PX 9))
$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = (Tr 'Diagnóstico de drivers, discos e hardware')
$lblSub.Font = Fonte 9
$lblSub.ForeColor = Pal 'Texto3'
$lblSub.AutoSize = $true
$lblSub.Location = New-Object System.Drawing.Point((PX 71), (PX 35))
$btnInicio = New-Object System.Windows.Forms.Button
$btnInicio.Text = (Tr '← Voltar ao início')
$btnInicio.AccessibleName = 'Voltar ao início'
$btnInicio.FlatStyle = 'Flat'
$btnInicio.FlatAppearance.BorderColor = Cor '#C9D1DB'
$btnInicio.BackColor = [System.Drawing.Color]::White
$btnInicio.ForeColor = Pal 'Texto'
$btnInicio.UseVisualStyleBackColor = $false
$btnInicio.Font = Fonte 9.5
$btnInicio.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnInicio.Size = New-Object System.Drawing.Size((PX 170), (PX 34))
$btnInicio.Anchor = 'Top, Right'
$btnInicio.Visible = $false
$cab.Controls.Add($btnInicio)
function Posicionar-BtnInicio { $btnInicio.Location = New-Object System.Drawing.Point(($cab.ClientSize.Width - $btnInicio.Width - (PX 28)), (PX 15)) }
Posicionar-BtnInicio
$cab.Add_Resize({ try { Posicionar-BtnInicio } catch { } })
$cab.Controls.Add($logo)
$cab.Controls.Add($lblTitulo)
$cab.Controls.Add($lblSub)
$linhaCab = New-Object System.Windows.Forms.Panel
$linhaCab.Dock = 'Bottom'
$linhaCab.Height = 1
$linhaCab.BackColor = Pal 'Borda'
$cab.Controls.Add($linhaCab)
$form.Controls.Add($cab)

# Rodapé sem faixa: só um texto discreto
$rodape = New-Object System.Windows.Forms.Panel
$rodape.Dock = 'Bottom'
$rodape.Height = PX 28
$rodape.BackColor = Pal 'Fundo'
$lblRodape = New-Object System.Windows.Forms.Label
$lblRodape.AutoSize = $true
$lblRodape.Font = Fonte 8.5
$lblRodape.ForeColor = Pal 'Texto3'
$lblRodape.Location = New-Object System.Drawing.Point((PX 26), (PX 6))
if ($script:IsAdmin) { $modo = 'administrador' } else { $modo = 'somente verificação' }
$lblRodape.Text = "v$($script:Versao)   ·   $modo   ·   nada é enviado para a internet"
$rodape.Controls.Add($lblRodape)
$form.Controls.Add($rodape)

function Nova-Pagina {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.Visible = $false
    $p.BackColor = Pal 'Fundo'
    $conteudo.Controls.Add($p)
    return $p
}
$pgInicio = Nova-Pagina
$pgProg   = Nova-Pagina
$pgRes    = Nova-Pagina
$pgFim    = Nova-Pagina
$pgFerr   = Nova-Pagina
$pgCfg    = Nova-Pagina

function Reposicionar {
    try {
        if ($pgInicio.Visible) {
            # Janela larga: apresentação à esquerda e resumo do PC à direita. Estreita: um embaixo do outro.
            # Se for alta demais, a página rola (barra de rolagem) em vez de cortar o conteúdo.
            $mostrarLado = ($pgInicio.ClientSize.Width -ge (PX 980))
            $pnlLado.Visible = $mostrarLado
            $ladoW = $(if ($mostrarLado) { $pnlLado.Width } else { 0 })
            $pw = $pgInicio.ClientSize.Width - $ladoW
            $mg = PX 28
            $xi = [int]($ladoW + [Math]::Max($mg, ($pw - $colIni.Width) / 2))
            $yAlto = ($colIni.Height + (2 * (PX 24))) -gt $pgInicio.ClientSize.Height
            if ($yAlto) {
                $yi = [int]((PX 24) + $pgInicio.AutoScrollPosition.Y)
            } else {
                $pgInicio.AutoScrollPosition = New-Object System.Drawing.Point(0, 0)
                $yi = [int][Math]::Max((PX 24), ($pgInicio.ClientSize.Height - $colIni.Height) / 2 - (PX 20))
            }
            $colIni.Location = New-Object System.Drawing.Point($xi, $yi)
        }
        if ($pgProg.Visible) {
            Ajustar-ColunaProg
            if ($script:Log.Visible) { Centralizar $topoProg $colProg 28 } else { Centralizar $topoProg $colProg }
        }
    } catch { }
}

$script:Margem = 24
function Ajustar-Margens {
    # Em janelas largas o conteúdo fica numa coluna central (até ~1180 px) em vez de colado à esquerda.
    $total = [int]$conteudo.ClientSize.Width
    if ($total -le 0) { return }
    $m = [int][Math]::Max((PX 24), [Math]::Floor(($total - (PX 1180)) / 2))
    $wb0 = [int][Math]::Max((PX 300), ($banner.ClientSize.Width - (2 * $m) - (PX 8)))
    if ($lblBanT.Width -ne $wb0) { $lblBanT.Width = $wb0; $lblBanS.Width = $wb0 }
    if ($m -eq $script:Margem) { return }
    $script:Margem = $m
    $flowCards.Padding = New-Object System.Windows.Forms.Padding($m, (PX 6), $m, (PX 16))
    $pnlFiltro.Padding = New-Object System.Windows.Forms.Padding($m, (PX 14), 0, 0)
    $pnlPC.Padding = New-Object System.Windows.Forms.Padding($m, (PX 10), $m, (PX 16))
    $barraRes.Controls['fluxo'].Padding = New-Object System.Windows.Forms.Padding($m, (PX 16), (PX 24), 0)
    $barraFim.Controls['fluxo'].Padding = New-Object System.Windows.Forms.Padding($m, (PX 16), (PX 24), 0)
    $flowAbas.Padding = New-Object System.Windows.Forms.Padding([int][Math]::Max((PX 18), ($m - (PX 12))), 0, 0, 0)
    $lblBanT.Left = $m + (PX 4)
    $lblBanS.Left = $m + (PX 5)
    $pnlFimCorpo.Padding = New-Object System.Windows.Forms.Padding($m, (PX 8), $m, (PX 16))
    $lblFimT.Padding = New-Object System.Windows.Forms.Padding($m, (PX 22), 0, 0)
    try { Ajustar-Barra $barraRes; Ajustar-Barra $barraFim } catch { }
}

function Show-Pagina {
    param($Pagina)
    foreach ($p in @($pgInicio, $pgProg, $pgRes, $pgFim, $pgFerr, $pgCfg)) { $p.Visible = $false }
    $Pagina.Visible = $true
    $Pagina.BringToFront()
    try { $btnInicio.Visible = (($Pagina -ne $pgInicio) -and ($Pagina -ne $pgProg)); $btnInicio.BringToFront() } catch { }
    try { if ($Pagina -eq $pgInicio) { Atualizar-InfoInicio } } catch { }
    try { if ($Pagina -eq $pgCfg) { Atualizar-Cfg } } catch { }
    try { if ($Pagina -eq $pgFerr) { Atualizar-Monitor } } catch { }
    try { if ($Pagina -eq $pgInicio) { Atualizar-Sensores } } catch { }
    Reposicionar
}

# ----------------------------------------------------------------------------
# Página 1 - Início (conteúdo centralizado)
# ----------------------------------------------------------------------------
$colIni = New-Object System.Windows.Forms.FlowLayoutPanel
$colIni.FlowDirection = 'TopDown'
$colIni.WrapContents = $false
$colIni.AutoSize = $true
$colIni.AutoSizeMode = 'GrowAndShrink'
$colIni.BackColor = Pal 'Fundo'
$pgInicio.AutoScroll = $true
$pgInicio.AutoScrollMargin = New-Object System.Drawing.Size(0, (PX 24))
$pgInicio.Controls.Add($colIni)

$script:LargIni = PX 620
$picIni = New-Object System.Windows.Forms.PictureBox
$picIni.SizeMode = 'Zoom'; $picIni.BackColor = Pal 'Fundo'
$picIni.Size = New-Object System.Drawing.Size((PX 84), (PX 84))
$picIni.Margin = New-Object System.Windows.Forms.Padding((PX (($script:LargIni / $script:Esc - 84) / 2)), 0, 0, (PX 10))
try { $picIni.Image = Get-LogoWinDiag } catch { }
$colIni.Controls.Add($picIni)
$lblIniT = Nova-Etiqueta 'Vamos verificar o seu computador?' 24 $true 'Texto' 56
$lblIniT.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
$colIni.Controls.Add($lblIniT)
$lblIniD = Nova-Etiqueta 'O WinDiag procura problemas em drivers, discos, memória, placa de vídeo e no histórico de erros do Windows, como telas azuis e travamentos. Ele só lê as informações: nada é alterado sem a sua permissão.' 11.5 $false 'Texto2' 84
$lblIniD.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 14))
$colIni.Controls.Add($lblIniD)
$lblTempoEst = Nova-Etiqueta 'Leva de 2 a 10 minutos   ·   Você pode continuar usando o computador' 9.5 $false 'Texto3' 28
$lblTempoEst.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 22))
$lblTempoEst.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
$colIni.Controls.Add($lblTempoEst)
$lblNotaIni = Nova-Etiqueta '' 10 $true 'Texto' 26
$lblNotaIni.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
$lblNotaIni.Visible = $false
$colIni.Controls.Add($lblNotaIni)
$lblAvisoAg = Nova-Etiqueta '' 9.5 $false 'Texto' 70
$lblAvisoAg.BackColor = Cor '#FFFBEB'
$lblAvisoAg.ForeColor = Cor '#92400E'
$lblAvisoAg.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
$lblAvisoAg.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
$lblAvisoAg.Visible = $false
$colIni.Controls.Add($lblAvisoAg)
$lnkAvisoOk = New-Object System.Windows.Forms.LinkLabel
$lnkAvisoOk.Text = (Tr 'Dispensar este aviso')
$lnkAvisoOk.AutoSize = $false
$lnkAvisoOk.Width = $script:LargIni
$lnkAvisoOk.Height = PX 24
$lnkAvisoOk.TextAlign = 'TopCenter'
$lnkAvisoOk.Font = Fonte 9
$lnkAvisoOk.LinkColor = Pal 'Texto2'
$lnkAvisoOk.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
$lnkAvisoOk.Visible = $false
$colIni.Controls.Add($lnkAvisoOk)

$lblSemAdmin = Nova-Etiqueta 'Aberto sem permissão de administrador: dá para verificar, mas não para corrigir. Para corrigir, feche e abra de novo aceitando o pedido de permissão.' 9.5 $false 'Texto' 54
$lblSemAdmin.BackColor = Cor '#FFFBEB'
$lblSemAdmin.ForeColor = Cor '#92400E'
$lblSemAdmin.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 8), (PX 12), (PX 8))
$lblSemAdmin.Visible = (-not $script:IsAdmin)
$colIni.Controls.Add($lblSemAdmin)

$btnIniciar = Nova-BotaoGrande 'Verificar meu computador' 'primario' 700 60
$btnIniciar.Font = Fonte 13 $true
$btnIniciar.Width = $script:LargIni
$btnIniciar.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 14))
$colIni.Controls.Add($btnIniciar)
# Verificação profunda: opção na tela inicial (mais lenta; só leitura). Volta desmarcada toda vez que o app abre.
$chkProfIni = New-Object System.Windows.Forms.CheckBox
$chkProfIni.Text = 'Verificação profunda (+10 a 30 min): confere os arquivos do Windows, 90 dias de histórico, travamentos de programas e a inicialização. Só leitura.'
$chkProfIni.AutoSize = $false
$chkProfIni.Size = New-Object System.Drawing.Size($script:LargIni, (PX 44))
$chkProfIni.Font = Fonte 9.5
$chkProfIni.ForeColor = Pal 'Texto2'
$chkProfIni.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
$colIni.Controls.Add($chkProfIni)
$form.AcceptButton = $btnIniciar

# Seis blocos por assunto (cada um abre só o que é daquele assunto)
$btnBench = Nova-BotaoGrande 'Testar desempenho' 'secundario' 200 56
$btnAreaTravou = Nova-BotaoGrande 'O PC trava ou desliga' 'secundario' 200 56
$btnAreaMonitor = Nova-BotaoGrande 'Monitor e sensores' 'secundario' 200 56
$btnAreaDrivers = Nova-BotaoGrande 'Drivers' 'secundario' 200 56
$btnFerr = Nova-BotaoGrande 'Reparos e restauração' 'secundario' 200 56
$btnAreaAjuda = Nova-BotaoGrande 'Ajuda e autoteste' 'secundario' 200 56
$btnCfg = Nova-BotaoGrande 'Configurações' 'secundario' 200 56
# Blocos por assunto em grade fixa (alinhada): três grandes em cima, quatro menores embaixo.
$linhaSec = New-Object System.Windows.Forms.Panel
$linhaSec.Size = New-Object System.Drawing.Size($script:LargIni, (PX 124))
$linhaSec.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
$linhaSec.BackColor = Pal 'Fundo'
$gapT = PX 12
$w3 = [int][Math]::Floor(($script:LargIni - (2 * $gapT)) / 3)
$w4 = [int][Math]::Floor(($script:LargIni - (3 * $gapT)) / 4)
$k = 0
foreach ($bt in @($btnAreaTravou, $btnAreaDrivers, $btnAreaMonitor)) {
    $bt.Size = New-Object System.Drawing.Size($w3, (PX 56)); $bt.Margin = New-Object System.Windows.Forms.Padding(0)
    $bt.Location = New-Object System.Drawing.Point(($k * ($w3 + $gapT)), 0)
    $linhaSec.Controls.Add($bt); $k++
}
$k = 0
foreach ($bt in @($btnBench, $btnFerr, $btnAreaAjuda, $btnCfg)) {
    $bt.Size = New-Object System.Drawing.Size($w4, (PX 44)); $bt.Margin = New-Object System.Windows.Forms.Padding(0); $bt.Font = Fonte 9.5
    $bt.Location = New-Object System.Drawing.Point(($k * ($w4 + $gapT)), (PX 68))
    $linhaSec.Controls.Add($bt); $k++
}
$colIni.Controls.Add($linhaSec)
$lblLegSec = Nova-Etiqueta 'Escolha pelo assunto: cada bloco abre só o que é dele. O PC trava? Comece por "O PC trava ou desliga". Problema com driver? Vá em "Drivers".' 9 $false 'Texto3' 24
$lblLegSec.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblLegSec.Visible = $false   # legenda removida: os nomes dos blocos já dizem o assunto
$colIni.Controls.Add($lblLegSec)
$lblSensIni = Nova-Etiqueta '' 9 $false 'Texto2' 40
$lblSensIni.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
$colIni.Controls.Add($lblSensIni)

$lnkSeguro = New-Object System.Windows.Forms.LinkLabel
$lnkSeguro.Text = (Tr 'O que o WinDiag faz e o que nunca faz sozinho')
$lnkSeguro.AutoSize = $false
$lnkSeguro.Width = $script:LargIni
$lnkSeguro.Height = PX 26
$lnkSeguro.TextAlign = 'TopCenter'
$lnkSeguro.Font = Fonte 9.5
$lnkSeguro.LinkColor = Pal 'Acento'
$lnkSeguro.LinkBehavior = 'HoverUnderline'
$lnkSeguro.Margin = New-Object System.Windows.Forms.Padding(0, (PX 22), 0, 0)
$colIni.Controls.Add($lnkSeguro)
$lblPriv = Nova-Etiqueta 'Cada verificação é salva em uma pasta própria dentro de "WinDiag", na Área de Trabalho. Revise os relatórios antes de compartilhar: podem conter o nome do computador e IDs de hardware.' 9 $false 'Texto3' 44
$lblPriv.Margin = New-Object System.Windows.Forms.Padding(0, (PX 8), 0, 0)
$colIni.Controls.Add($lblPriv)

# Tudo centralizado na coluna: textos, aviso e rodapé
foreach ($lc in @($lblIniT, $lblIniD, $lblTempoEst, $lblNotaIni, $lblAvisoAg, $lblSemAdmin, $lblLegSec, $lblSensIni, $lblPriv)) {
    $lc.Width = $script:LargIni
    $lc.TextAlign = 'TopCenter'
}
# Resumo do computador (lido em segundo plano; aparece ao lado, ou embaixo em janelas estreitas)
$script:DadosPcIni = $null
# Barra lateral esquerda: componentes do computador (lidos logo que o app abre)
$pnlLado = New-Object System.Windows.Forms.Panel
$pnlLado.Dock = 'Left'
$pnlLado.Width = PX 300
$pnlLado.BackColor = [System.Drawing.Color]::White
$bordaLado = New-Object System.Windows.Forms.Panel
$bordaLado.Dock = 'Right'; $bordaLado.Width = 1; $bordaLado.BackColor = Pal 'Borda'
$pnlLado.Controls.Add($bordaLado)
$fluxoLado = New-Object System.Windows.Forms.FlowLayoutPanel
$fluxoLado.Dock = 'Fill'
$fluxoLado.FlowDirection = 'TopDown'
$fluxoLado.WrapContents = $false
$fluxoLado.AutoScroll = $true
$fluxoLado.BackColor = [System.Drawing.Color]::White
$fluxoLado.Padding = New-Object System.Windows.Forms.Padding((PX 22), (PX 24), (PX 14), (PX 16))
$pnlLado.Controls.Add($fluxoLado)
$fluxoLado.BringToFront()
$pgInicio.Controls.Add($pnlLado)
$pgInicio.Add_SizeChanged({ Reposicionar })
$colIni.Add_SizeChanged({ Reposicionar })
function Get-DirDadosGui {
    $b = $env:WD_DADOS_DIR
    if (-not $b) { $b = Join-Path $env:LOCALAPPDATA 'WinDiag' }
    return $b
}
function Atualizar-InfoInicio {
    # Última nota de saúde e aviso da verificação automática (se houver) na tela inicial.
    try {
        $lblNotaIni.Visible = $false
        $f = Join-Path (Get-DirDadosGui) 'saude.jsonl'
        if (Test-Path -LiteralPath $f) {
            $ult = @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction Stop | Where-Object { "$_".Trim() }) | Select-Object -Last 1
            if ($ult) {
                $o = $ult | ConvertFrom-Json
                $lblNotaIni.Text = "Última verificação ($($o.Data)): nota de saúde $($o.Nota)/100 ($($o.Rotulo))"
                $lblNotaIni.Visible = $true
            }
        }
    } catch { }
    try {
        $lblAvisoAg.Visible = $false; $lnkAvisoOk.Visible = $false
        $fa = Join-Path (Get-DirDadosGui) 'aviso.json'
        if (Test-Path -LiteralPath $fa) {
            $av = Get-Content -LiteralPath $fa -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
            if ($av.Texto) {
                $lblAvisoAg.Text = [string]$av.Texto
                $lblAvisoAg.Visible = $true; $lnkAvisoOk.Visible = $true
            }
        }
    } catch { }
}
$lnkAvisoOk.Add_LinkClicked({
    try {
        $fa = Join-Path (Get-DirDadosGui) 'aviso.json'
        if (Test-Path -LiteralPath $fa) { Remove-Item -LiteralPath $fa -Force -ErrorAction SilentlyContinue }
        Atualizar-InfoInicio
        Reposicionar
    } catch { }
})
$script:TextoSeguro = @"
O QUE O WINDIAG FAZ

- Lê informações do computador (discos, drivers, memória, vídeo, histórico de erros do Windows) e gera um relatório.
- Mostra o que encontrou e, quando existe uma correção, explica o que ela faz.

O QUE ELE SÓ FAZ DEPOIS DO SEU "SIM"

- Qualquer correção: reparar o disco, reativar ou reinstalar um driver, restaurar um driver guardado, proteger o driver de vídeo contra trocas, apagar arquivos temporários antigos, reiniciar a configuração de rede, agendar o CHKDSK.
- No modo "Corrigir automaticamente" você aprova uma vez só as correções comuns. As ações mais delicadas e as proteções opcionais continuam pedindo uma confirmação separada.
- Antes de corrigir, o WinDiag oferece criar um ponto de restauração e guardar uma cópia dos drivers.

O QUE O WINDIAG NUNCA FAZ

- Apagar os seus arquivos pessoais (documentos, fotos, vídeos). A limpeza só mexe em arquivos temporários com mais de 2 dias, e o backup apenas copia.
- Formatar discos, mexer em partições, na BIOS ou no firmware.
- Desativar o antivírus ou o firewall, nem trocar senhas ou contas de usuário.
- Instalar programas. Os drivers pendentes só podem ser instalados pelo Windows Update, e só se você aprovar.
- Enviar informações do seu computador para alguém. Não há conta, nem coleta de dados, nem envio de relatórios.

QUANDO ELE USA A INTERNET

- Na verificação, se a opção estiver marcada: para consultar drivers pendentes no Windows Update e testar a conexão.
- No botão "Procurar atualização": só para ler qual é a versão mais recente do WinDiag.
- Os relatórios ficam na pasta "WinDiag" da Área de Trabalho. Revise-os antes de compartilhar: podem conter o nome do computador.

VERIFICAÇÃO SEMANAL AUTOMÁTICA (OPCIONAL)

- Só existe se você ativar em "Configurações". Ela apenas lê informações, sem corrigir nada e sem usar a internet, e só avisa se a saúde do computador piorar. Dá para desativar quando quiser.
"@
$lnkSeguro.Add_LinkClicked({
    try { [void][System.Windows.Forms.MessageBox]::Show((Tr $script:TextoSeguro), 'WinDiag', 'OK', 'Information') } catch { Registrar-Erro $_ -Silencioso }
})

# ----------------------------------------------------------------------------
# Página 2 - Progresso (centralizado; barra fina)
# ----------------------------------------------------------------------------
$script:Log = New-Object System.Windows.Forms.RichTextBox
$log = $script:Log
$log.Dock = 'Fill'
$log.ReadOnly = $true
$log.BorderStyle = 'None'
$log.BackColor = [System.Drawing.Color]::FromArgb(24, 26, 31)
$log.ForeColor = [System.Drawing.Color]::LightGray
$log.Font = New-Object System.Drawing.Font('Consolas', [single]9)
$log.WordWrap = $true
$log.DetectUrls = $false
$log.Visible = $false
$pgProg.Controls.Add($log)

$topoProg = New-Object System.Windows.Forms.Panel
$topoProg.Dock = 'Fill'
$topoProg.BackColor = Pal 'Fundo'
$pgProg.Controls.Add($topoProg)

$colProg = New-Object System.Windows.Forms.FlowLayoutPanel
$colProg.FlowDirection = 'TopDown'
$colProg.WrapContents = $false
$colProg.AutoSize = $true
$colProg.AutoSizeMode = 'GrowAndShrink'
$colProg.BackColor = Pal 'Fundo'
$topoProg.Controls.Add($colProg)

$lblEtapa = New-Object System.Windows.Forms.Label
$lblEtapa.Font = Fonte 17 $true
$lblEtapa.ForeColor = Pal 'Texto'
$lblEtapa.AutoSize = $false
$lblEtapa.Size = New-Object System.Drawing.Size((PX 620), (PX 72))
$lblEtapa.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblEtapa.TextAlign = 'BottomLeft'
$lblEtapa.Text = (Tr 'Preparando...')
$colProg.Controls.Add($lblEtapa)

$barraFundo = New-Object System.Windows.Forms.Panel
$barraFundo.Size = New-Object System.Drawing.Size((PX 620), (PX 8))
$barraFundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 16))
$barraFundo.BackColor = Pal 'Borda'
$barraFundo.AccessibleName = 'Progresso'
$barraFundo.AccessibleRole = 'ProgressBar'
$barraPreench = New-Object System.Windows.Forms.Panel
$barraPreench.Location = New-Object System.Drawing.Point(0, 0)
$barraPreench.Size = New-Object System.Drawing.Size(0, (PX 8))
$barraPreench.BackColor = Pal 'Acento'
$barraFundo.Controls.Add($barraPreench)
$colProg.Controls.Add($barraFundo)

$lblTempo = New-Object System.Windows.Forms.Label
$lblTempo.Font = Fonte 10.5
$lblTempo.ForeColor = Pal 'Texto2'
$lblTempo.AutoSize = $false
$lblTempo.Size = New-Object System.Drawing.Size((PX 620), (PX 26))
$lblTempo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$colProg.Controls.Add($lblTempo)

$lblDica = New-Object System.Windows.Forms.Label
$lblDica.Font = Fonte 10
$lblDica.ForeColor = Pal 'Texto2'
$lblDica.AutoSize = $true
$lblDica.MaximumSize = New-Object System.Drawing.Size((PX 620), 0)
$lblDica.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 22))
$colProg.Controls.Add($lblDica)

$filaBtnProg = New-Object System.Windows.Forms.FlowLayoutPanel
$filaBtnProg.FlowDirection = 'LeftToRight'
$filaBtnProg.WrapContents = $false
$filaBtnProg.AutoSize = $true
$filaBtnProg.AutoSizeMode = 'GrowAndShrink'
$filaBtnProg.BackColor = Pal 'Fundo'
$filaBtnProg.Margin = New-Object System.Windows.Forms.Padding(0)
$btnDet = Nova-BotaoGrande 'Mostrar detalhes técnicos' 'secundario' 230 40
$btnCancel = Nova-BotaoGrande 'Cancelar' 'secundario' 120 40
$filaBtnProg.Controls.Add($btnDet)
$filaBtnProg.Controls.Add($btnCancel)
$colProg.Controls.Add($filaBtnProg)

function Ajustar-ColunaProg {
    # A coluna central cresce com a janela (620 px no mínimo, 880 px no máximo).
    $w = [int][Math]::Max((PX 620), [Math]::Min((PX 880), $topoProg.ClientSize.Width * 0.5))
    foreach ($c in @($lblEtapa, $barraFundo, $lblTempo)) { if ($c.Width -ne $w) { $c.Width = $w } }
    $lblDica.MaximumSize = New-Object System.Drawing.Size($w, 0)
}

$topoProg.Add_SizeChanged({ Reposicionar })

$script:BarraModo = 'fixo'
$script:BarraFrac = 0.0
$script:BarraPos = 0
function Set-Barra {
    param([double]$Fracao = 0, [switch]$Indeterminada)
    if ($Indeterminada) { $script:BarraModo = 'indet'; return }
    $script:BarraModo = 'fixo'
    $script:BarraFrac = [Math]::Max(0.0, [Math]::Min(1.0, $Fracao))
    $barraPreench.Left = 0
    $barraPreench.Width = [int]($barraFundo.Width * $script:BarraFrac)
}
$barraFundo.Add_SizeChanged({ if ($script:BarraModo -eq 'fixo') { Set-Barra -Fracao $script:BarraFrac } })
$script:TimerBarra = New-Object System.Windows.Forms.Timer
$script:TimerBarra.Interval = 30
$script:TimerBarra.Add_Tick({
    if ($script:BarraModo -ne 'indet' -or -not $pgProg.Visible) { return }
    $w = [int]($barraFundo.Width * 0.28)
    $script:BarraPos += (PX 9)
    if ($script:BarraPos -gt $barraFundo.Width) { $script:BarraPos = -$w }
    $barraPreench.Width = $w
    $barraPreench.Left = $script:BarraPos
})
$script:TimerBarra.Start()

function Alternar-Detalhes {
    param([bool]$Mostrar)
    $script:Log.Visible = $Mostrar
    if ($Mostrar) {
        $topoProg.Dock = 'Top'
        $topoProg.Height = PX 340
        Ajustar-LarguraBotao $btnDet 'Ocultar detalhes técnicos' 230
    } else {
        $topoProg.Dock = 'Fill'
        Ajustar-LarguraBotao $btnDet 'Mostrar detalhes técnicos' 230
    }
    Reposicionar
}

# ----------------------------------------------------------------------------
# Página 3 - Resultados
# ----------------------------------------------------------------------------
# Área das abas (vai primeiro: Fill)
$areaAbas = New-Object System.Windows.Forms.Panel
$areaAbas.Dock = 'Fill'
$pgRes.Controls.Add($areaAbas)

function Nova-PainelAba {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.BackColor = Pal 'Fundo'
    $areaAbas.Controls.Add($p)
    return $p
}
$tpProb = Nova-PainelAba
$tpPC   = Nova-PainelAba
$tpDet  = Nova-PainelAba

# Cabeçalho das abas (estilo "sublinhado")
$cabAbas = New-Object System.Windows.Forms.Panel
$cabAbas.Dock = 'Top'
$cabAbas.Height = PX 48
$cabAbas.BackColor = [System.Drawing.Color]::White
$flowAbas = New-Object System.Windows.Forms.FlowLayoutPanel
$flowAbas.Dock = 'Fill'
$flowAbas.WrapContents = $false
$flowAbas.Padding = New-Object System.Windows.Forms.Padding((PX 18), 0, 0, 0)
$cabAbas.Controls.Add($flowAbas)
$linhaAbas = New-Object System.Windows.Forms.Panel
$linhaAbas.Dock = 'Bottom'
$linhaAbas.Height = 1
$linhaAbas.BackColor = Pal 'Borda'
$cabAbas.Controls.Add($linhaAbas)
$pgRes.Controls.Add($cabAbas)

$script:AbaAtual = 0
function Nova-Aba {
    param([string]$Texto, [int]$Indice)
    $b = New-Object System.Windows.Forms.Button
    $b.Name = "aba$Indice"
    $b.Text = $Texto
    $b.AccessibleName = "Aba $Texto"
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.FlatAppearance.MouseOverBackColor = Cor '#F4F6F9'
    $b.FlatAppearance.MouseDownBackColor = Cor '#EAEEF3'
    $b.BackColor = [System.Drawing.Color]::White
    $b.UseVisualStyleBackColor = $false
    $b.AutoSize = $true
    $b.AutoSizeMode = 'GrowAndShrink'
    $b.MinimumSize = New-Object System.Drawing.Size(0, (PX 47))
    $b.Padding = New-Object System.Windows.Forms.Padding((PX 12), 0, (PX 12), 0)
    $b.Margin = New-Object System.Windows.Forms.Padding(0)
    $b.Font = Fonte 10
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Add_Click({ param($remetente, $ev) Show-Aba ([int]("$($remetente.Name)" -replace '\D', '')) })
    $b.Add_Paint({
        param($remetente, $ev)
        if ("$($remetente.Name)" -eq "aba$($script:AbaAtual)") {
            $br = New-Object System.Drawing.SolidBrush((Cor $script:Pal['Acento']))
            $ev.Graphics.FillRectangle($br, 0, $remetente.Height - (PX 3), $remetente.Width, (PX 3))
            $br.Dispose()
        }
    })
    return $b
}
$abaProb = Nova-Aba 'Problemas encontrados' 0
$abaPC   = Nova-Aba 'Meu computador' 1
$abaDet  = Nova-Aba 'Detalhes técnicos' 2
foreach ($b in @($abaProb, $abaPC, $abaDet)) { $flowAbas.Controls.Add($b) }

function Show-Aba {
    param([int]$I)
    $script:AbaAtual = $I
    $paineis = @($tpProb, $tpPC, $tpDet)
    for ($k = 0; $k -lt $paineis.Count; $k++) { $paineis[$k].Visible = ($k -eq $I) }
    $paineis[$I].BringToFront()
    if ($I -eq 1 -and $null -ne $script:DadosPC) { Montar-PC -SePrecisar }
    $botoes = @($abaProb, $abaPC, $abaDet)
    for ($k = 0; $k -lt $botoes.Count; $k++) {
        if ($k -eq $I) { $botoes[$k].ForeColor = Pal 'Acento'; $botoes[$k].Font = Fonte 10 $true }
        else { $botoes[$k].ForeColor = Pal 'Texto2'; $botoes[$k].Font = Fonte 10 }
        $botoes[$k].Invalidate()
    }
}

# Faixa de status (cor suave + barra lateral)
$banner = New-Object System.Windows.Forms.Panel
$banner.Dock = 'Top'
$banner.Height = PX 108
$faixa = New-Object System.Windows.Forms.Panel
$faixa.Dock = 'Left'
$faixa.Width = PX 6
$lblBanT = New-Object System.Windows.Forms.Label
$lblBanT.Font = Fonte 16 $true
$lblBanT.AutoSize = $false
$lblBanT.Location = New-Object System.Drawing.Point((PX 28), (PX 14))
$lblBanT.Size = New-Object System.Drawing.Size((PX 900), (PX 36))
$lblBanT.Anchor = 'Top, Left, Right'
$lblBanS = New-Object System.Windows.Forms.Label
$lblBanS.Font = Fonte 10
$lblBanS.ForeColor = Pal 'Texto2'
$lblBanS.AutoSize = $false
$lblBanS.Location = New-Object System.Drawing.Point((PX 29), (PX 52))
$lblBanS.Size = New-Object System.Drawing.Size((PX 900), (PX 52))
$lblBanS.Anchor = 'Top, Left, Right'
$banner.Controls.Add($lblBanT)
$banner.Controls.Add($lblBanS)
$banner.Controls.Add($faixa)
$pgRes.Controls.Add($banner)

# Barra de ações
$barraRes = Nova-BarraAcoes
$btnCorrigir  = Nova-BotaoGrande 'Corrigir automaticamente' 'primario' 250 44
$btnRelatorio = Nova-BotaoGrande 'Relatório completo' 'secundario' 170 44
$btnPasta     = Nova-BotaoGrande 'Abrir pasta' 'secundario' 120 44
$btnCopiar    = Nova-BotaoGrande 'Copiar resumo' 'secundario' 140 44
$btnNova      = Nova-BotaoGrande 'Verificar de novo' 'secundario' 160 44
$btnSair      = Nova-BotaoGrande 'Sair' 'secundario' 90 44
$btnPdf       = Nova-BotaoGrande 'Salvar em PDF' 'secundario' 140 44
$btnReiniciar = Nova-BotaoGrande 'Reiniciar o PC agora' 'secundario' 190 44
$btnReiniciar.Visible = $false
foreach ($b in @($btnCorrigir, $btnReiniciar, $btnRelatorio, $btnPdf, $btnPasta, $btnCopiar, $btnNova, $btnSair)) { $barraRes.Controls['fluxo'].Controls.Add($b) }
$pgRes.Controls.Add($barraRes)

# Aba "Problemas encontrados"
$flowCards = New-Object System.Windows.Forms.FlowLayoutPanel
$flowCards.Dock = 'Fill'
$flowCards.FlowDirection = 'TopDown'
$flowCards.WrapContents = $false
$flowCards.AutoScroll = $true
$flowCards.BackColor = Pal 'Fundo'
$flowCards.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 6), (PX 24), (PX 16))
$tpProb.Controls.Add($flowCards)

$pnlFiltro = New-Object System.Windows.Forms.FlowLayoutPanel
$pnlFiltro.Dock = 'Top'
$pnlFiltro.Height = PX 52
$pnlFiltro.WrapContents = $false
$pnlFiltro.BackColor = Pal 'Fundo'
$pnlFiltro.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 14), 0, 0)
$lblFiltro = New-Object System.Windows.Forms.Label
$lblFiltro.Text = (Tr 'Mostrar')
$lblFiltro.AutoSize = $true
$lblFiltro.ForeColor = Pal 'Texto2'
$lblFiltro.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), (PX 8), 0)
$cmbCat = New-Object System.Windows.Forms.ComboBox
$cmbCat.DropDownStyle = 'DropDownList'
$cmbCat.FlatStyle = 'Flat'
$cmbCat.Width = PX 340
$cmbCat.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 24), 0)
$chkInfo = New-Object System.Windows.Forms.CheckBox
$chkInfo.Text = (Tr 'Incluir avisos apenas informativos')
$chkInfo.AutoSize = $true
$chkInfo.ForeColor = Pal 'Texto2'
$chkInfo.Margin = New-Object System.Windows.Forms.Padding(0, (PX 3), 0, 0)
$pnlFiltro.Controls.Add($lblFiltro)
$pnlFiltro.Controls.Add($cmbCat)
$pnlFiltro.Controls.Add($chkInfo)
$tpProb.Controls.Add($pnlFiltro)
$script:CatChaves = @('')
$script:AtualizandoFiltro = $false
$script:Expandidos = @{}

# Aba "Meu computador"
$pnlPC = New-Object System.Windows.Forms.Panel
$pnlPC.Dock = 'Fill'
$pnlPC.AutoScroll = $true
$pnlPC.BackColor = Pal 'Fundo'
$pnlPC.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 10), (PX 24), (PX 16))
$tpPC.Controls.Add($pnlPC)
$script:DadosPC = $null
$script:LarguraPC = 0

# Aba "Detalhes técnicos": o painel de log é encaixado aqui quando a verificação termina
$tpDet.Padding = New-Object System.Windows.Forms.Padding(0)

# ----------------------------------------------------------------------------
# Página 4 - Fim das correções
# ----------------------------------------------------------------------------
$txtFim = New-Object System.Windows.Forms.TextBox
$txtFim.Multiline = $true
$txtFim.ReadOnly = $true
$txtFim.BorderStyle = 'None'
$txtFim.ScrollBars = 'Vertical'
$txtFim.Dock = 'Fill'
$txtFim.Font = Fonte 10.5
$txtFim.BackColor = [System.Drawing.Color]::White
$txtFim.ForeColor = Pal 'Texto'
$pnlFimCorpo = New-Object System.Windows.Forms.Panel
$pnlFimCorpo.Dock = 'Fill'
$pnlFimCorpo.Padding = New-Object System.Windows.Forms.Padding((PX 28), (PX 8), (PX 28), (PX 16))
$pnlFimCorpo.BackColor = Pal 'Fundo'
$pnlTxtFim = New-Object System.Windows.Forms.Panel
$pnlTxtFim.Dock = 'Fill'
$pnlTxtFim.BackColor = [System.Drawing.Color]::White
$pnlTxtFim.Padding = New-Object System.Windows.Forms.Padding((PX 20), (PX 16), (PX 20), (PX 16))
$pnlTxtFim.Controls.Add($txtFim)
$pnlFimCorpo.Controls.Add($pnlTxtFim)
$lblFimT = New-Object System.Windows.Forms.Label
$lblFimT.Font = Fonte 18 $true
$lblFimT.Dock = 'Top'
$lblFimT.Height = PX 78
$lblFimT.Padding = New-Object System.Windows.Forms.Padding((PX 28), (PX 22), 0, 0)
$barraFim = Nova-BarraAcoes
$btnReiniciar = Nova-BotaoGrande 'Reiniciar o computador agora' 'primario' 250 44
$btnDesfazer  = Nova-BotaoGrande 'Desfazer alterações' 'secundario' 190 44
$btnVerif2    = Nova-BotaoGrande 'Verificar de novo' 'secundario' 160 44
$btnSair2     = Nova-BotaoGrande 'Fechar' 'secundario' 100 44
$btnBenchAbrir  = Nova-BotaoGrande 'Abrir o relatório' 'primario' 190 44
$btnBenchDeNovo = Nova-BotaoGrande 'Testar de novo' 'secundario' 160 44
$btnBenchVoltar = Nova-BotaoGrande 'Voltar ao início' 'secundario' 170 44
foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2, $btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar, $btnSair2)) { $barraFim.Controls['fluxo'].Controls.Add($b) }
foreach ($b in @($btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar)) { $b.Visible = $false }
$pgFim.Controls.Add($pnlFimCorpo)
$pgFim.Controls.Add($lblFimT)
$pgFim.Controls.Add($barraFim)

# ----------------------------------------------------------------------------
# Página - Ferramentas de reparo e restauração
# ----------------------------------------------------------------------------
$script:ListaFerramentas = @(
    @{ Id = 'pontos-listar'; Titulo = 'Ver os pontos de restauração'; Desc = 'Mostra os pontos de volta que o Windows tem guardados (inclusive os criados pelo WinDiag).'; Admin = $false },
    @{ Id = 'pontos-criar'; Titulo = 'Criar um ponto de restauração agora'; Desc = 'Guarda o estado atual do Windows para poder voltar a ele se algo der errado.'; Admin = $true },
    @{ Id = 'pontos-abrir'; Titulo = 'Abrir a Restauração do Sistema do Windows'; Desc = 'Abre a tela do Windows para voltar o computador a um ponto de restauração anterior.'; Admin = $false },
    @{ Id = 'rede'; Titulo = 'Reparar a rede e a internet'; Desc = 'Limpa o DNS e reinicia o Winsock e o IP. Resolve sites que não abrem com a rede conectada.'; Admin = $true },
    @{ Id = 'wu'; Titulo = 'Reparar o Windows Update'; Desc = 'Corrige atualizações que travam, falham ou não aparecem (renomeia as pastas temporárias do Windows Update).'; Admin = $true },
    @{ Id = 'store'; Titulo = 'Reparar a Microsoft Store'; Desc = 'Registra a loja novamente. Útil quando ela não abre ou não baixa aplicativos.'; Admin = $true },
    @{ Id = 'chkdsk'; Titulo = 'Verificar o disco com o CHKDSK (na reinicialização)'; Desc = 'Agenda a verificação completa do disco do Windows. Pode demorar de minutos a horas.'; Admin = $true },
    @{ Id = 'temp'; Titulo = 'Limpar arquivos temporários'; Desc = 'Apaga arquivos temporários com mais de 2 dias para liberar espaço.'; Admin = $true },
    @{ Id = 'backup'; Titulo = 'Copiar meus arquivos pessoais (backup)'; Desc = 'Copia Documentos, Imagens e Área de Trabalho para uma pasta ou pen drive que você escolher. Nada é apagado.'; Admin = $false },
    @{ Id = 'historico'; Titulo = 'Ver o que o WinDiag já mudou neste computador'; Desc = 'Lista todas as alterações feitas pelo WinDiag, com a data e como desfazer cada uma.'; Admin = $false },
    @{ Id = 'saude-historico'; Titulo = 'Ver a nota de saúde ao longo do tempo'; Desc = 'Mostra a nota de saúde (0 a 100) de cada verificação, para você ver se o computador está melhorando ou piorando.'; Admin = $false },
    @{ Id = 'cfg-hags'; Titulo = 'Desligar o agendamento de GPU por hardware'; Desc = 'Opção do Windows que em alguns computadores causa travamento de imagem em jogos. Pede confirmação, guarda o valor atual e precisa reiniciar. Dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-pcie'; Titulo = 'Desligar a economia de energia do PCIe'; Desc = 'Impede que a placa de vídeo entre em repouso profundo quando o PC está na tomada. Pede confirmação e dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-fast'; Titulo = 'Desligar a inicialização rápida do Windows'; Desc = 'Faz o Windows carregar os drivers do zero a cada ligada. Pede confirmação, precisa reiniciar e dá para desfazer.'; Admin = $true },
    @{ Id = 'cfg-desfazer'; Titulo = 'Desfazer as mudanças de configuração'; Desc = 'Volta o agendamento de GPU, a economia do PCIe e a inicialização rápida ao valor que tinham antes do WinDiag.'; Admin = $true },
    @{ Id = 'guia-fonte'; Titulo = 'Guia: testar com outra fonte de alimentação'; Desc = 'Passo a passo para trocar a fonte por uma emprestada e descobrir se ela é a causa de travamentos sob carga.'; Admin = $false },
    @{ Id = 'guia-energia'; Titulo = 'Guia: limitar a energia da placa de vídeo'; Desc = 'Passo a passo para reduzir o consumo da placa (Afterburner ou nvidia-smi) e testar se os picos de energia causam o travamento.'; Admin = $false },
    @{ Id = 'reiniciar-pc'; Titulo = 'Reiniciar o computador agora'; Desc = 'Muitos reparos e drivers só terminam depois de reiniciar. Avisa e espera 30 segundos; dá para cancelar com shutdown /a.'; Admin = $true },
    @{ Id = 'drv-lista'; Titulo = 'Ver todos os drivers e o que cada um faz'; Desc = 'Lista os drivers do computador por tipo (vídeo, rede, som, chipset, disco, USB), explica o que cada um faz e marca os com erro, antigos ou sem assinatura.'; Admin = $false },
    @{ Id = 'drv-sites'; Titulo = 'Baixar drivers novos: abrir as páginas oficiais'; Desc = 'Mostra o driver instalado de cada fabricante (NVIDIA, AMD, Intel, Realtek) e abre a página oficial de download para você escolher a versão.'; Admin = $false },
    @{ Id = 'drv-verificar'; Titulo = 'Conferir e instalar um driver baixado'; Desc = 'Você escolhe o instalador que baixou. O WinDiag só deixa executar se a assinatura digital for válida e de um fabricante conhecido, e cria um ponto de restauração antes.'; Admin = $true },
    @{ Id = 'drv-reparar'; Titulo = 'Reparar dispositivos com erro'; Desc = 'Reativa o que está desativado e reinstala (remove e procura de novo) os dispositivos com erro no Gerenciador de Dispositivos. Não mexe em disco, processador e sistema.'; Admin = $true },
    @{ Id = 'drv-video-reiniciar'; Titulo = 'Reiniciar o driver de vídeo'; Desc = 'Desliga e liga de novo o driver da placa de vídeo, sem reiniciar o PC. Útil quando a imagem congela ou a tela fica estranha. A tela pisca por alguns segundos.'; Admin = $true },
    @{ Id = 'drv-wu'; Titulo = 'Instalar drivers pelo Windows Update'; Desc = 'Procura e instala os drivers que o Windows Update tem para o seu hardware (cria um ponto de restauração antes).'; Admin = $true },
    @{ Id = 'drv-limpar'; Titulo = 'Limpar versões antigas de driver'; Desc = 'Remove do sistema os pacotes de driver substituídos por versões mais novas e que não estão em uso. Guarda uma cópia de cada um e dá para voltar.'; Admin = $true },
    @{ Id = 'drv-video-limpo'; Titulo = 'Limpeza do driver de vídeo (para instalação limpa)'; Desc = 'Remove o driver de vídeo do fabricante para você instalar um do zero. Cria ponto de restauração e guarda cópia. Tenha o instalador novo já baixado.'; Admin = $true },
    @{ Id = 'guia-driver-video'; Titulo = 'Guia: instalar o driver de vídeo do zero'; Desc = 'Passo a passo completo: escolher a versão, limpar, reiniciar e instalar sem o Windows Update atrapalhar.'; Admin = $false },
    @{ Id = 'cfg-usb'; Titulo = 'Desligar a economia de energia do USB'; Desc = 'Evita que o Windows corte a energia de portas USB paradas (teclado, mouse e headset desconectando no jogo). Pede confirmação e dá para desfazer.'; Admin = $true },
    @{ Id = 'sensores-estado'; Titulo = 'Ver o estado dos sensores'; Desc = 'Mostra se o HWiNFO ou a LibreHardwareMonitor estão instalados, abertos e configurados para o WinDiag ler.'; Admin = $false },
    @{ Id = 'hwinfo-config'; Titulo = 'Configurar e abrir o HWiNFO para o WinDiag'; Desc = 'Liga a memória compartilhada, deixa só os sensores e a atualização em 500 ms (guarda uma cópia do arquivo antigo) e abre o HWiNFO.'; Admin = $true },
    @{ Id = 'lhm-baixar'; Titulo = 'Baixar a LibreHardwareMonitor (alternativa ao HWiNFO)'; Desc = 'Baixa a versão oficial do GitHub, confere o hash e guarda numa pasta do WinDiag. Ela carrega um driver para ler o processador; antivírus e anticheat podem reclamar.'; Admin = $false },
    @{ Id = 'lhm-abrir'; Titulo = 'Abrir a LibreHardwareMonitor'; Desc = 'Abre como administrador para o WinDiag ler a temperatura do processador por ela quando o HWiNFO não estiver aberto.'; Admin = $false },
    @{ Id = 'bios-site'; Titulo = 'BIOS e drivers: abrir a página da placa-mãe'; Desc = 'Mostra a BIOS instalada e abre a página de suporte do fabricante da sua placa-mãe para conferir se existe versão mais nova.'; Admin = $false },
    @{ Id = 'chipset-site'; Titulo = 'Driver de chipset: abrir a página oficial'; Desc = 'Abre a página oficial do driver de chipset do fabricante do seu processador (AMD ou Intel).'; Admin = $false },
    @{ Id = 'autoteste'; Titulo = 'Autoteste do WinDiag (conferir se tudo funciona)'; Desc = 'Confere, neste Windows, se cada recurso do WinDiag funciona (sensores, testes, vídeo, SMART). Gera um texto para enviar ao desenvolvedor se algo falhar.'; Admin = $false },
    @{ Id = 'agendar-ativar'; Titulo = 'Ativar a verificação semanal'; Desc = ''; Admin = $true },
    @{ Id = 'agendar-desativar'; Titulo = 'Desativar a verificação semanal'; Desc = ''; Admin = $true }
)
$script:LargFerr = PX 640

function Nova-ColunaPagina {
    # Coluna central (largura fixa) dentro de uma página com rolagem.
    param($Pagina)
    $col = New-Object System.Windows.Forms.FlowLayoutPanel
    $col.FlowDirection = 'TopDown'
    $col.WrapContents = $false
    $col.AutoSize = $true
    $col.AutoSizeMode = 'GrowAndShrink'
    $col.BackColor = Pal 'Fundo'
    $col.Padding = New-Object System.Windows.Forms.Padding((PX 24), (PX 24), (PX 24), (PX 24))
    $Pagina.AutoScroll = $true
    $Pagina.Controls.Add($col)
    return $col
}
function Nova-SecaoPagina {
    param($Col, [string]$Titulo)
    $l = Nova-Etiqueta $Titulo 11.5 $true 'Texto' 30 640
    $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 18), 0, (PX 4))
    $Col.Controls.Add($l)
}
function Nova-LinhaBotao {
    # Botão largo com a explicação embaixo.
    param($Col, $Botao, [string]$Desc, [double]$AlturaDesc = 34)
    $Botao.Width = $script:LargFerr
    $Botao.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), 0, 0)
    $Col.Controls.Add($Botao)
    if ($Desc) {
        $ld = Nova-Etiqueta $Desc 9 $false 'Texto3' $AlturaDesc 640
        $ld.Margin = New-Object System.Windows.Forms.Padding((PX 6), 0, 0, (PX 4))
        $Col.Controls.Add($ld)
    }
}

# ----------------------------------------------------------------------------
# Página - Ferramentas de reparo e restauração (só o que corrige, restaura ou desfaz)
# ----------------------------------------------------------------------------
# Menu lateral com as áreas; à direita, só o conteúdo da área escolhida
$pgFerrCorpo = New-Object System.Windows.Forms.Panel
$pgFerrCorpo.Dock = 'Fill'
$pgFerrCorpo.BackColor = Pal 'Fundo'
$pgFerr.Controls.Add($pgFerrCorpo)
$pnlLateral = New-Object System.Windows.Forms.FlowLayoutPanel
$pnlLateral.Dock = 'Left'
$pnlLateral.Width = PX 230
$pnlLateral.FlowDirection = 'TopDown'
$pnlLateral.WrapContents = $false
$pnlLateral.AutoScroll = $true
$pnlLateral.BackColor = Pal 'Superficie'
$pnlLateral.Padding = New-Object System.Windows.Forms.Padding((PX 12), (PX 18), (PX 12), (PX 12))
$pgFerr.Controls.Add($pnlLateral)
$pgFerrCorpo.BringToFront()
$script:ColAreas = @{}
$script:BotoesAreas = @{}
$script:BotoesFerr = @()
$script:BotoesVoltar = @()
$script:AreaAtual = 'travou'
$btnDesbloq = Nova-BotaoGrande 'Desfazer bloqueios de driver do WinDiag' 'secundario' 640 40
$btnDesfazer2 = Nova-BotaoGrande 'Desfazer correções (restaurar drivers salvos)' 'secundario' 640 40
$btnMonIni = Nova-BotaoGrande 'Ligar o monitor (registrar temperaturas durante o jogo)' 'secundario' 640 40
$btnMonParar = Nova-BotaoGrande 'Desligar o monitor' 'secundario' 640 40
$btnMonVer = Nova-BotaoGrande 'Ver o último registro (por que o PC desligou?)' 'secundario' 640 40
$btnMonInv = Nova-BotaoGrande 'Investigar o último travamento (relatório completo)' 'secundario' 640 40
$btnMemWin = Nova-BotaoGrande 'Testar a memória RAM pelo Windows (no próximo reinício)' 'secundario' 640 40
$btnExtOcct = Nova-BotaoGrande 'OCCT (estresse de processador, placa de vídeo, memória e fonte)' 'secundario' 640 40
$btnExtFur = Nova-BotaoGrande 'FurMark (estresse da placa de vídeo)' 'secundario' 640 40
$btnExtMem = Nova-BotaoGrande 'MemTest86 (teste completo da memória RAM, fora do Windows)' 'secundario' 640 40
$descPseudo = @{
    'ext-occt' = 'Abre o site oficial. O OCCT faz estresse combinado e gráficos de tensão e temperatura; o WinDiag não baixa nem instala nada sozinho.'
    'ext-fur' = 'Abre o site oficial do FurMark, o teste de estresse mais usado para placas de vídeo.'
    'ext-mem' = 'Abre o site oficial do MemTest86. Ele roda a partir de um pendrive, antes do Windows, e é o teste de memória mais confiável.'
    'desbloq' = 'Remove a proteção que impede o Windows Update de trocar o driver de vídeo (e os outros bloqueios criados pelo WinDiag).'
    'drivers' = 'Volta aos drivers que o WinDiag guardou antes de corrigir.'
    'mon-ini' = 'Grava temperaturas, tensões e consumo a cada meio segundo enquanto você joga (lê o HWiNFO, o MSI Afterburner ou o LibreHardwareMonitor abertos). Se o computador desligar, o último registro mostra o que estava acontecendo.'
    'mon-parar' = 'Encerra o registro e fecha a sessão. Os arquivos ficam guardados para consulta.'
    'mon-ver' = 'Mostra as últimas temperaturas e tensões gravadas antes de o monitor parar e a provável causa.'
    'mon-inv' = 'Junta o último registro do monitor, os erros que o Windows anotou nessa hora, as configurações que costumam causar travamento e os próximos passos. Use depois de reiniciar o PC que travou.'
    'mem-win' = 'Abre o Diagnóstico de Memória do Windows, que testa a memória RAM antes de o Windows iniciar. O computador reinicia (salve seus trabalhos); o resultado aparece na próxima verificação do WinDiag.'
}
$btnBenchFerr = Nova-BotaoGrande 'Testar desempenho (processador, memória, disco, vídeo e estresse)' 'secundario' 640 40
$descPseudo['testar-desempenho'] = 'Abre a janela de escolha: teste normal, longo, estresse de jogo, transição, memória RAM e disco. Mostra o que cada um faz antes de começar.'
$script:AreasFerr = @(
    @{ Id = 'travou'; Nome = 'O PC trava ou desliga'; Sub = 'Descubra a causa e teste as hipóteses mais comuns: fonte, placa de vídeo, memória e configurações do Windows.'
       Grupos = @(
        @{ T = 'Descobrir o que aconteceu'; Ids = @('mon-inv') },
        @{ T = 'Corrigir configurações que causam travamento (todas com desfazer)'; Ids = @('cfg-hags', 'cfg-pcie', 'cfg-fast') },
        @{ T = 'Testar hipóteses de hardware'; Ids = @('guia-fonte', 'guia-energia', 'mem-win') },
        @{ T = 'BIOS e drivers'; Ids = @('bios-site', 'chipset-site') }) },
    @{ Id = 'drivers'; Nome = 'Drivers'; Sub = 'Entenda o que cada driver faz e corrija de verdade: reinstale, atualize, limpe versões velhas ou refaça o driver de vídeo.'
       Grupos = @(
        @{ T = 'Entender'; Ids = @('drv-lista') },
        @{ T = 'Baixar drivers novos com segurança'; Ids = @('drv-wu', 'drv-sites', 'drv-verificar') },
        @{ T = 'Corrigir'; Ids = @('drv-reparar', 'drv-video-reiniciar', 'drv-limpar') },
        @{ T = 'Driver de vídeo: instalação limpa'; Ids = @('guia-driver-video', 'drv-video-limpo') },
        @{ T = 'Energia que derruba dispositivos'; Ids = @('cfg-usb') }) },
    @{ Id = 'monitor'; Nome = 'Monitor e sensores'; Sub = 'Registra temperaturas, tensões e consumo enquanto você joga. Se o PC desligar, o último registro mostra o que estava acontecendo.'
       Grupos = @(
        @{ T = 'Programas de sensores'; Ids = @('sensores-estado', 'hwinfo-config', 'lhm-baixar', 'lhm-abrir') },
        @{ T = 'Registro durante o jogo'; Ids = @('mon-ini', 'mon-parar', 'mon-ver') }) },
    @{ Id = 'testes'; Nome = 'Testes e estresse'; Sub = 'Leve o computador ao limite de forma controlada para reproduzir o problema.'
       Grupos = @(
        @{ T = 'Dentro do WinDiag'; Ids = @('testar-desempenho') },
        @{ T = 'Programas externos (sites oficiais; o WinDiag não baixa nada)'; Ids = @('ext-occt', 'ext-fur', 'ext-mem') }) },
    @{ Id = 'reparos'; Nome = 'Reparos do Windows'; Sub = 'Cada ferramenta pede a sua confirmação antes de mexer em alguma coisa. As que corrigem o Windows exigem o WinDiag como administrador.'
       Grupos = @(
        @{ T = 'Reparos'; Ids = @('rede', 'wu', 'store', 'chkdsk', 'reiniciar-pc') },
        @{ T = 'Limpeza e cópia de segurança'; Ids = @('temp', 'backup') }) },
    @{ Id = 'restaurar'; Nome = 'Restaurar e desfazer'; Sub = 'Volte atrás: pontos de restauração e tudo o que o WinDiag já alterou.'
       Grupos = @(
        @{ T = 'Pontos de restauração'; Ids = @('pontos-listar', 'pontos-criar', 'pontos-abrir') },
        @{ T = 'Desfazer o que o WinDiag fez'; Ids = @('historico', 'desbloq', 'drivers', 'cfg-desfazer') }) },
    @{ Id = 'ajuda'; Nome = 'Ajuda e autoteste'; Sub = 'Confira se o WinDiag funciona neste Windows e gere um texto para enviar ao desenvolvedor.'
       Grupos = @(
        @{ T = 'Conferir o próprio WinDiag'; Ids = @('autoteste') }) }
)
function Show-Area {
    param([string]$Id)
    if (-not $script:ColAreas.ContainsKey($Id)) { $Id = 'travou' }
    foreach ($k in $script:ColAreas.Keys) { $script:ColAreas[$k].Visible = ($k -eq $Id) }
    foreach ($k in $script:BotoesAreas.Keys) { $bt = $script:BotoesAreas[$k]; $bt.Name = $(if ($k -eq $Id) { 'primario' } else { 'secundario' }); Aplicar-EstiloBotao $bt }
    $script:AreaAtual = $Id
    try { $pgFerrCorpo.AutoScrollPosition = New-Object System.Drawing.Point(0, 0) } catch { }
    try { Ajustar-PaginaFerr } catch { }
}
foreach ($ar in $script:AreasFerr) {
    $colFerr = Nova-ColunaPagina $pgFerrCorpo
    $colFerr.Visible = $false
    $script:ColAreas[$ar.Id] = $colFerr
    $colFerr.Controls.Add((Nova-Etiqueta $ar.Nome 20 $true 'Texto' 44 640))
    $colFerr.Controls.Add((Nova-Etiqueta $ar.Sub 10 $false 'Texto2' 44 640))
    $bar = Nova-BotaoGrande $ar.Nome 'secundario' 200 44
    $bar.Width = PX 204
    $bar.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
    $bar.AccessibleName = 'area:' + $ar.Id
    $pnlLateral.Controls.Add($bar)
    $script:BotoesAreas[$ar.Id] = $bar
    foreach ($gr in $ar.Grupos) {
        Nova-SecaoPagina $colFerr $gr.T
        if ($gr.Ids -contains 'mon-ini') {
            $script:lblMonEstado = Nova-Etiqueta 'Monitor desligado.' 10 $true 'Texto' 24 640
            $colFerr.Controls.Add($script:lblMonEstado)
        }
        if ($gr.Ids -contains 'sensores-estado') {
            $script:lblSensEstado = Nova-Etiqueta '' 9.5 $false 'Texto' 46 640
            $script:lblSensEstado.BackColor = Cor '#EFF6FF'
            $script:lblSensEstado.Padding = New-Object System.Windows.Forms.Padding((PX 10), (PX 6), (PX 10), (PX 6))
            $colFerr.Controls.Add($script:lblSensEstado)
        }
        foreach ($id in $gr.Ids) {
            if ($id -eq 'desbloq') { Nova-LinhaBotao $colFerr $btnDesbloq $descPseudo['desbloq']; continue }
            if ($id -eq 'drivers') { Nova-LinhaBotao $colFerr $btnDesfazer2 $descPseudo['drivers']; continue }
            if ($id -eq 'mon-ini') { Nova-LinhaBotao $colFerr $btnMonIni $descPseudo['mon-ini'] 52; continue }
            if ($id -eq 'testar-desempenho') { Nova-LinhaBotao $colFerr $btnBenchFerr $descPseudo['testar-desempenho']; continue }
            if ($id -eq 'ext-occt') { Nova-LinhaBotao $colFerr $btnExtOcct $descPseudo['ext-occt']; continue }
            if ($id -eq 'ext-fur') { Nova-LinhaBotao $colFerr $btnExtFur $descPseudo['ext-fur']; continue }
            if ($id -eq 'ext-mem') { Nova-LinhaBotao $colFerr $btnExtMem $descPseudo['ext-mem']; continue }
            if ($id -eq 'mon-parar') { Nova-LinhaBotao $colFerr $btnMonParar $descPseudo['mon-parar']; continue }
            if ($id -eq 'mon-ver') { Nova-LinhaBotao $colFerr $btnMonVer $descPseudo['mon-ver']; continue }
            if ($id -eq 'mon-inv') { Nova-LinhaBotao $colFerr $btnMonInv $descPseudo['mon-inv']; continue }
            if ($id -eq 'mem-win') { Nova-LinhaBotao $colFerr $btnMemWin $descPseudo['mem-win']; continue }
            $f = $script:ListaFerramentas | Where-Object { $_.Id -eq $id } | Select-Object -First 1
            $b = Nova-BotaoGrande $f.Titulo 'secundario' 640 40
            $b.AccessibleName = $f.Id
            Nova-LinhaBotao $colFerr $b $f.Desc
            $f.Botao = $b
            $script:BotoesFerr += $b
        }
    }
    $bv = Nova-BotaoGrande 'Voltar ao início' 'secundario' 200 44
    $bv.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, (PX 20))
    $bv.AccessibleName = 'voltar-inicio'
    $colFerr.Controls.Add($bv)
    $script:BotoesVoltar += $bv
}
foreach ($bt in @($script:BotoesAreas.Values)) { $bt.Add_Click({ try { Show-Area (([string]$this.AccessibleName) -replace '^area:', '') } catch { Registrar-Erro $_ } }) }
function Abrir-Area {
    param([string]$Id)
    Ajustar-PaginaFerr
    Show-Pagina $pgFerr
    Show-Area $Id
}
Show-Area 'travou\'

# ----------------------------------------------------------------------------
# Página - Configurações (opções, verificação automática, histórico e manutenção do WinDiag)
# ----------------------------------------------------------------------------
$script:DiasPt = @('Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado')
$script:DiasEn = @('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
$script:CarregandoCfg = $true
$colCfg = Nova-ColunaPagina $pgCfg
$colCfg.Controls.Add((Nova-Etiqueta 'Configurações' 20 $true 'Texto' 44 640))
$colCfg.Controls.Add((Nova-Etiqueta 'Opções da verificação, verificação automática, histórico e manutenção do WinDiag.' 10 $false 'Texto2' 30 640))

function Nova-OpcaoCfg {
    param([string]$Texto, [bool]$Marcado, [double]$Altura)
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = (Tr $Texto)
    $c.AutoSize = $false
    $c.Size = New-Object System.Drawing.Size($script:LargFerr, (PX $Altura))
    $c.Checked = $Marcado
    $c.Font = Fonte 9.5
    $c.ForeColor = Pal 'Texto2'
    $c.Margin = New-Object System.Windows.Forms.Padding((PX 4), (PX 2), 0, (PX 4))
    return $c
}
Nova-SecaoPagina $colCfg 'Ao verificar'
$chkWU   = Nova-OpcaoCfg 'Usar a internet na verificação: Windows Update (drivers pendentes) e teste de rede (pode demorar alguns minutos)' $true 40
$chkVol  = Nova-OpcaoCfg 'Procurar erros nas unidades de disco (mais completo, porém mais lento)' $true 26
foreach ($c0 in @($chkWU, $chkVol)) { $colCfg.Controls.Add($c0) }

Nova-SecaoPagina $colCfg 'Verificação semanal automática'
$lblAgStatus = Nova-Etiqueta '' 10 $false 'Texto2' 44 640
$colCfg.Controls.Add($lblAgStatus)
$linhaAg = New-Object System.Windows.Forms.FlowLayoutPanel
$linhaAg.FlowDirection = 'LeftToRight'
$linhaAg.WrapContents = $false
$linhaAg.AutoSize = $false
$linhaAg.Size = New-Object System.Drawing.Size($script:LargFerr, (PX 36))
$linhaAg.BackColor = Pal 'Fundo'
$linhaAg.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
$lblDia = New-Object System.Windows.Forms.Label
$lblDia.Text = (Tr 'Dia:'); $lblDia.AutoSize = $true; $lblDia.ForeColor = Pal 'Texto2'
$lblDia.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), (PX 6), 0)
$cmbDia = New-Object System.Windows.Forms.ComboBox
$cmbDia.DropDownStyle = 'DropDownList'; $cmbDia.FlatStyle = 'Flat'; $cmbDia.Width = PX 160
foreach ($d0 in $script:DiasPt) { [void]$cmbDia.Items.Add($d0) }
$cmbDia.SelectedIndex = 0
$cmbDia.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), (PX 24), 0)
$lblHora = New-Object System.Windows.Forms.Label
$lblHora.Text = (Tr 'Horário:'); $lblHora.AutoSize = $true; $lblHora.ForeColor = Pal 'Texto2'
$lblHora.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), (PX 6), 0)
$cmbHora = New-Object System.Windows.Forms.ComboBox
$cmbHora.DropDownStyle = 'DropDownList'; $cmbHora.FlatStyle = 'Flat'; $cmbHora.Width = PX 90
foreach ($h0 in 0..23) { [void]$cmbHora.Items.Add(('{0:00}:00' -f $h0)) }
$cmbHora.SelectedItem = '10:00'
$cmbHora.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, 0)
foreach ($c0 in @($lblDia, $cmbDia, $lblHora, $cmbHora)) { $linhaAg.Controls.Add($c0) }
$colCfg.Controls.Add($linhaAg)
$linhaBtnAg = New-Object System.Windows.Forms.FlowLayoutPanel
$linhaBtnAg.FlowDirection = 'LeftToRight'
$linhaBtnAg.WrapContents = $false
$linhaBtnAg.AutoSize = $false
$linhaBtnAg.Size = New-Object System.Drawing.Size($script:LargFerr, (PX 50))
$linhaBtnAg.BackColor = Pal 'Fundo'
$wMetade = [int](($script:LargFerr - (PX 14)) / 2)
$btnAgAtivar = Nova-BotaoGrande 'Ativar a verificação semanal' 'secundario' 300 40
$btnAgAtivar.AccessibleName = 'agendar-ativar'
$btnAgAtivar.Width = $wMetade
$btnAgAtivar.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 14), 0)
$btnAgDesativar = Nova-BotaoGrande 'Desativar' 'secundario' 300 40
$btnAgDesativar.AccessibleName = 'agendar-desativar'
$btnAgDesativar.Width = $script:LargFerr - $wMetade - (PX 14)
$btnAgDesativar.Margin = New-Object System.Windows.Forms.Padding(0)
$linhaBtnAg.Controls.Add($btnAgAtivar); $linhaBtnAg.Controls.Add($btnAgDesativar)
$colCfg.Controls.Add($linhaBtnAg)
$colCfg.Controls.Add((Nova-Etiqueta 'Uma vez por semana o WinDiag faz uma verificação rápida só de leitura (não corrige nada e não usa a internet) e avisa se a nota de saúde cair 5 pontos ou mais, ou se aparecer um problema crítico novo. Ativar e desativar exigem abrir o WinDiag como administrador.' 9 $false 'Texto3' 54 640))

Nova-SecaoPagina $colCfg 'Histórico'
$btnCfgNota = Nova-BotaoGrande 'Ver a nota de saúde ao longo do tempo' 'secundario' 640 40
$btnCfgNota.AccessibleName = 'saude-historico'
Nova-LinhaBotao $colCfg $btnCfgNota 'Mostra a nota de saúde (0 a 100) de cada verificação, para você ver se o computador está melhorando ou piorando.'
$btnPastaBase = Nova-BotaoGrande 'Abrir a pasta das verificações anteriores' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnPastaBase 'Abre a pasta "WinDiag" da Área de Trabalho, onde ficam os relatórios de cada verificação.' 24

Nova-SecaoPagina $colCfg 'Sobre o WinDiag'
$colCfg.Controls.Add((Nova-Etiqueta ("Versão " + $script:Versao) 10 $false 'Texto2' 24 640))
$btnAtualizar = Nova-BotaoGrande 'Procurar atualização do WinDiag' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnAtualizar 'Consulta o canal oficial de versões; se houver versão nova, baixa e instala depois da sua confirmação. Nada sobre o seu computador é enviado.'
$btnAtalho = Nova-BotaoGrande 'Recriar o atalho do WinDiag (Área de Trabalho e Menu Iniciar)' 'secundario' 640 40
Nova-LinhaBotao $colCfg $btnAtalho '' 
$script:BotoesCfg = @($btnAgAtivar, $btnAgDesativar, $btnCfgNota)
$btnCfgVoltar = Nova-BotaoGrande 'Voltar ao início' 'primario' 200 44
$btnCfgVoltar.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, (PX 20))
$colCfg.Controls.Add($btnCfgVoltar)

function Get-ArquivoConfigGui { return (Join-Path (Get-DirDadosGui) 'config.json') }
function Salvar-Config {
    if ($script:CarregandoCfg) { return }
    try {
        $f = Get-ArquivoConfigGui
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $o = @{ UsarInternet = [bool]$chkWU.Checked; ProcurarDiscos = [bool]$chkVol.Checked; AgendaDia = [int]$cmbDia.SelectedIndex; AgendaHora = [string]$cmbHora.SelectedItem }
        [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}
function Carregar-Config {
    $script:CarregandoCfg = $true
    try {
        $f = Get-ArquivoConfigGui
        if (Test-Path -LiteralPath $f) {
            $o = Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
            if ($null -ne $o.UsarInternet) { $chkWU.Checked = [bool]$o.UsarInternet }
            if ($null -ne $o.ProcurarDiscos) { $chkVol.Checked = [bool]$o.ProcurarDiscos }
            if ($null -ne $o.AgendaDia -and [int]$o.AgendaDia -ge 0 -and [int]$o.AgendaDia -le 6) { $cmbDia.SelectedIndex = [int]$o.AgendaDia }
            if ($o.AgendaHora -and $cmbHora.Items.Contains([string]$o.AgendaHora)) { $cmbHora.SelectedItem = [string]$o.AgendaHora }
        }
    } catch { }
    $script:CarregandoCfg = $false
}
$chkWU.Add_CheckedChanged({ Salvar-Config })
$chkVol.Add_CheckedChanged({ Salvar-Config })
$cmbDia.Add_SelectedIndexChanged({ Salvar-Config })
$cmbHora.Add_SelectedIndexChanged({ Salvar-Config })

function Atualizar-Cfg {
    # Mostra se a verificação semanal está ativa (e quando) e ajusta os botões.
    $ativa = $false
    $texto = 'A verificação semanal automática está desativada.'
    try {
        $t = Get-ScheduledTask -TaskName 'WinDiag - verificação semanal' -ErrorAction Stop
        $ativa = $true
        $texto = 'A verificação semanal automática está ativada.'
        try {
            $tr = @($t.Triggers)[0]
            if ($tr -and $tr.StartBoundary) {
                $hora = ([datetime]$tr.StartBoundary).ToString('HH:mm')
                if ($cmbHora.Items.Contains($hora)) { $script:CarregandoCfg = $true; $cmbHora.SelectedItem = $hora; $script:CarregandoCfg = $false }
            }
            if ($tr -and $null -ne $tr.DaysOfWeek -and [int]$tr.DaysOfWeek -gt 0) {
                $idx = [int][Math]::Log([double][int]$tr.DaysOfWeek, 2)
                if ($idx -ge 0 -and $idx -le 6) { $script:CarregandoCfg = $true; $cmbDia.SelectedIndex = $idx; $script:CarregandoCfg = $false }
            }
        } catch { $script:CarregandoCfg = $false }
        try {
            $i = Get-ScheduledTaskInfo -TaskName 'WinDiag - verificação semanal' -ErrorAction Stop
            if ($i.NextRunTime -and $i.NextRunTime.Year -gt 2000) { $texto += ' Próxima execução: ' + $i.NextRunTime.ToString('dd/MM/yyyy HH:mm') + '.' }
        } catch { }
    } catch { }
    $lblAgStatus.Text = $texto
    if ($ativa) { $btnAgAtivar.Text = (Tr 'Salvar o novo dia e horário') } else { $btnAgAtivar.Text = (Tr 'Ativar a verificação semanal') }
    $btnAgDesativar.Enabled = $ativa
    try { $btnAgAtivar.Invalidate(); $btnAgDesativar.Invalidate() } catch { }
}
Carregar-Config
try { Atualizar-Cfg } catch { }

function Ajustar-PaginaFerr {
    $pares = New-Object System.Collections.ArrayList
    [void]$pares.Add(@($pgCfg, $colCfg))
    foreach ($k in @($script:ColAreas.Keys)) { [void]$pares.Add(@($pgFerrCorpo, $script:ColAreas[$k])) }
    foreach ($par in $pares) {
        $esq = [int][Math]::Max((PX 24), ($par[0].ClientSize.Width - $script:LargFerr) / 2)
        $par[1].Padding = New-Object System.Windows.Forms.Padding($esq, (PX 24), (PX 24), (PX 24))
    }
}
$pgFerrCorpo.Add_SizeChanged({ try { Ajustar-PaginaFerr } catch { } })
$pgCfg.Add_SizeChanged({ try { Ajustar-PaginaFerr } catch { } })

# ----------------------------------------------------------------------------
# Resultados: cartões, filtro, faixa de status e resumo do computador
# ----------------------------------------------------------------------------
function Nova-Card {
    param($Achado, [int]$Largura)
    $cores = @{ Critico = $script:Pal['Perigo']; Atencao = $script:Pal['Aviso']; Info = $script:Pal['Info'] }
    $rotulo = @{ Critico = 'GRAVE'; Atencao = 'ATENÇÃO'; Info = 'INFORMAÇÃO' }
    $interna = $Largura - (PX 44)
    $sev = "$($Achado.Gravidade)"
    if (-not $cores.ContainsKey($sev)) { $sev = 'Info' }

    $card = New-Object System.Windows.Forms.FlowLayoutPanel
    $card.FlowDirection = 'TopDown'
    $card.WrapContents = $false
    $card.AutoSize = $true
    $card.AutoSizeMode = 'GrowAndShrink'
    $card.BackColor = [System.Drawing.Color]::White
    $card.Tag = $cores[$sev]
    $card.AccessibleName = ('{0}: {1}' -f $rotulo[$sev], $Achado.Titulo)
    $card.AccessibleRole = 'Grouping'
    $card.Padding = New-Object System.Windows.Forms.Padding((PX 22), (PX 14), (PX 16), (PX 14))
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
    $card.MinimumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    # Borda fina + barra lateral na cor da gravidade
    $card.Add_Paint({
        param($remetente, $ev)
        $pen = New-Object System.Drawing.Pen((Cor $script:Pal['Borda']))
        $ev.Graphics.DrawRectangle($pen, 0, 0, $remetente.Width - 1, $remetente.Height - 1)
        $pen.Dispose()
        $br = New-Object System.Drawing.SolidBrush((Cor "$($remetente.Tag)"))
        $ev.Graphics.FillRectangle($br, 0, 0, (PX 5), $remetente.Height)
        $br.Dispose()
    })

    $linha = New-Object System.Windows.Forms.FlowLayoutPanel
    $linha.FlowDirection = 'LeftToRight'
    $linha.WrapContents = $false
    $linha.AutoSize = $true
    $linha.AutoSizeMode = 'GrowAndShrink'
    $linha.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
    $ls = New-Object System.Windows.Forms.Label
    $ls.AutoSize = $true
    $ls.Text = $rotulo[$sev]
    $ls.Font = Fonte 8.5 $true
    $ls.ForeColor = Cor $cores[$sev]
    $ls.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 8), 0)
    $lc = New-Object System.Windows.Forms.Label
    $lc.AutoSize = $true
    $lc.Text = (Get-NomeCategoria "$($Achado.Categoria)")
    $lc.Font = Fonte 8.5
    $lc.ForeColor = Pal 'Texto3'
    $lc.Margin = New-Object System.Windows.Forms.Padding(0)
    $linha.Controls.Add($ls)
    $linha.Controls.Add($lc)
    if ($Achado.Veredito) {
        $coresV = @{ Normal = $script:Pal['Ok']; Depende = $script:Pal['Aviso']; Corrigir = $script:Pal['Perigo']; Opcional = $script:Pal['Info'] }
        $corV = $coresV["$($Achado.Veredito)"]
        if ($corV) {
            $lv = New-Object System.Windows.Forms.Label
            $lv.AutoSize = $true
            $lv.Text = '·  ' + (Get-RotuloVeredito "$($Achado.Veredito)")
            $lv.Font = Fonte 8.5 $true
            $lv.ForeColor = Cor $corV
            $lv.Margin = New-Object System.Windows.Forms.Padding((PX 8), 0, 0, 0)
            $linha.Controls.Add($lv)
        }
    }
    # Selo de reparo: o WinDiag consegue corrigir este item ou não?
    $lr = New-Object System.Windows.Forms.Label
    $lr.AutoSize = $true
    $lr.Font = Fonte 8.5 $true
    $lr.Margin = New-Object System.Windows.Forms.Padding((PX 8), 0, 0, 0)
    if ("$($Achado.Reparo)" -eq 'Auto') {
        $lr.Text = '·  Corrigível pelo WinDiag'
        $lr.ForeColor = Pal 'Acento'
    } else {
        $lr.Text = '·  Não corrigível pelo WinDiag'
        $lr.ForeColor = Pal 'Texto3'
    }
    $linha.Controls.Add($lr)
    $card.Controls.Add($linha)

    $t = New-Object System.Windows.Forms.Label
    $t.AutoSize = $true
    $t.MaximumSize = New-Object System.Drawing.Size($interna, 0)
    $t.Font = Fonte 11.5 $true
    $t.ForeColor = Pal 'Texto'
    $t.Text = "$($Achado.Titulo)"
    $t.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
    $card.Controls.Add($t)

    if ($Achado.Detalhe) {
        $d = New-Object System.Windows.Forms.Label
        $d.AutoSize = $true
        $d.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $d.Font = Fonte 9.5
        $d.ForeColor = Pal 'Texto2'
        $d.Text = "$($Achado.Detalhe)"
        $d.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 6))
        $card.Controls.Add($d)
    }
    if ($Achado.Solucao) {
        $sh = New-Object System.Windows.Forms.Label
        $sh.AutoSize = $true
        $sh.Text = (Tr 'O QUE FAZER')
        $sh.Font = Fonte 8 $true
        $sh.ForeColor = Pal 'Texto3'
        $sh.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 1))
        $card.Controls.Add($sh)
        $s = New-Object System.Windows.Forms.Label
        $s.AutoSize = $true
        $s.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $s.Font = Fonte 10
        $s.ForeColor = Pal 'Texto'
        $s.Text = "$($Achado.Solucao)"
        $s.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 4))
        $card.Controls.Add($s)
    }
    if ($Achado.Explicacao) {
        $pex = New-Object System.Windows.Forms.FlowLayoutPanel
        $pex.Name = "$($Achado.Titulo)"
        $pex.FlowDirection = 'TopDown'
        $pex.WrapContents = $false
        $pex.AutoSize = $true
        $pex.AutoSizeMode = 'GrowAndShrink'
        $pex.BackColor = Pal 'Fundo'
        $pex.Padding = New-Object System.Windows.Forms.Padding((PX 12))
        $pex.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 8))
        $lex = New-Object System.Windows.Forms.Label
        $lex.AutoSize = $true
        $lex.MaximumSize = New-Object System.Drawing.Size(($interna - (PX 28)), 0)
        $lex.Font = Fonte 9.5
        $lex.ForeColor = Pal 'Texto'
        $lex.Text = "$($Achado.Explicacao)"
        $pex.Controls.Add($lex)
        $aberto = [bool]$script:Expandidos["$($Achado.Titulo)"]
        $pex.Visible = $aberto
        $mais = New-Object System.Windows.Forms.LinkLabel
        $mais.AutoSize = $true
        $mais.Font = Fonte 9.5 $true
        $mais.LinkColor = Pal 'Acento'
        $mais.ActiveLinkColor = Pal 'AcentoDown'
        $mais.LinkBehavior = 'HoverUnderline'
        if ($aberto) { $mais.Text = (Tr 'Ver menos') } else { $mais.Text = (Tr 'Ver mais: o que é isso e preciso me preocupar?') }
        $mais.Tag = $pex
        $mais.Margin = New-Object System.Windows.Forms.Padding(0, (PX 2), 0, (PX 4))
        $mais.Add_LinkClicked({
            param($remetente, $ev)
            $pn = $remetente.Tag
            $pn.Visible = (-not $pn.Visible)
            $script:Expandidos[$pn.Name] = $pn.Visible
            if ($pn.Visible) { $remetente.Text = (Tr 'Ver menos') } else { $remetente.Text = (Tr 'Ver mais: o que é isso e preciso me preocupar?') }
        })
        $card.Controls.Add($mais)
        $card.Controls.Add($pex)
    }
    foreach ($l in @($Achado.Links)) {
        if (-not $l -or -not $l.Url) { continue }
        $ll = New-Object System.Windows.Forms.LinkLabel
        $ll.AutoSize = $true
        $ll.MaximumSize = New-Object System.Drawing.Size($interna, 0)
        $ll.Font = Fonte 9.5
        $ll.LinkColor = Pal 'Acento'
        $ll.ActiveLinkColor = Pal 'AcentoDown'
        $ll.LinkBehavior = 'HoverUnderline'
        $ll.Text = "$($l.Texto)"
        $ll.Tag = "$($l.Url)"
        $ll.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 2))
        $ll.Add_LinkClicked({ param($remetente, $ev) Abrir-Url ([string]$remetente.Tag) })
        $card.Controls.Add($ll)
    }
    return $card
}

function Get-TextoGrupoReparo {
    # Mesmos textos do motor (a interface não carrega o motor): separa o que o WinDiag corrige do que depende do usuário.
    param([string]$Grupo)
    if ($Grupo -eq 'Auto') {
        return @{
            Titulo = 'O WinDiag consegue corrigir'
            Texto  = 'Para estes itens existe uma correção automática. Clique em "Corrigir automaticamente" (como administrador): o WinDiag cria um ponto de restauração antes de mexer.'
        }
    }
    return @{
        Titulo = 'Precisa de você: o WinDiag não conserta sozinho'
        Texto  = 'Aqui estão eventos que já aconteceram (o Windows guarda o histórico por 30 dias, então eles continuam aparecendo depois de corrigir), programas de terceiros como jogos e anti-cheat, peças de hardware e avisos informativos. Siga o "O que fazer" de cada item.'
    }
}

function Get-RotuloVeredito {
    # (A janela e o motor rodam em processos separados; por isso esta função existe nos dois lados.)
    param([string]$Veredito)
    switch ($Veredito) {
        'Normal'   { return 'Provavelmente normal' }
        'Depende'  { return 'Depende' }
        'Corrigir' { return 'Vale corrigir' }
        'Opcional' { return 'Opcional' }
        default    { return '' }
    }
}

function Get-NomeCategoria {
    param([string]$Chave)
    switch ($Chave) {
        'Driver'         { return 'Drivers' }
        'Eventos'        { return 'Eventos do Windows (erros e travamentos)' }
        'Disco'          { return 'Discos' }
        'Volume'         { return 'Unidades (volumes)' }
        'Hardware'       { return 'Hardware' }
        'Sistema'        { return 'Sistema' }
        'Windows Update' { return 'Windows Update' }
        'WinDiag'        { return 'Avisos do próprio WinDiag' }
        default          { return $Chave }
    }
}

function Get-AchadosVisiveis {
    # Achados que passam pelo filtro atual (categoria + avisos informativos).
    param([switch]$IgnorarCategoria)
    if (-not $script:Res) { return @() }
    $catSel = ''
    if (-not $IgnorarCategoria -and $cmbCat.SelectedIndex -ge 0 -and $cmbCat.SelectedIndex -lt $script:CatChaves.Count) { $catSel = $script:CatChaves[$cmbCat.SelectedIndex] }
    $ordem = @{ Critico = 0; Atencao = 1; Info = 2 }
    return @($script:Res.Achados | Where-Object { $_ -and ($chkInfo.Checked -or $_.Gravidade -ne 'Info') -and (-not $catSel -or "$($_.Categoria)" -eq $catSel) } | Sort-Object { if ($_.Reparo -eq 'Auto') { 0 } else { 1 } }, { $ordem["$($_.Gravidade)"] })
}

function Atualizar-Filtro {
    # Recria a lista de categorias (só as que têm itens a mostrar) mantendo a escolha atual.
    if (-not $script:Res) { return }
    $script:AtualizandoFiltro = $true
    try {
        $atual = ''
        if ($cmbCat.SelectedIndex -ge 0 -and $cmbCat.SelectedIndex -lt $script:CatChaves.Count) { $atual = $script:CatChaves[$cmbCat.SelectedIndex] }
        $visiveis = @(Get-AchadosVisiveis -IgnorarCategoria)
        $grupos = @($visiveis | Group-Object Categoria | Sort-Object Name)
        $cmbCat.Items.Clear()
        $script:CatChaves = @('')
        [void]$cmbCat.Items.Add("Todas as categorias ($($visiveis.Count))")
        foreach ($g in $grupos) {
            $script:CatChaves += "$($g.Name)"
            [void]$cmbCat.Items.Add("$(Get-NomeCategoria "$($g.Name)") ($($g.Count))")
        }
        $idx = [Array]::IndexOf($script:CatChaves, $atual)
        if ($idx -lt 0) { $idx = 0 }
        $cmbCat.SelectedIndex = $idx
    } finally {
        $script:AtualizandoFiltro = $false
    }
}

function Montar-Cards {
    if (-not $script:Res) { return }
    $flowCards.SuspendLayout()
    try {
        $flowCards.Controls.Clear()
        $largura = $flowCards.ClientSize.Width - $flowCards.Padding.Horizontal - [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
        $largura = [Math]::Max((PX 360), [Math]::Min((PX 1100), $largura))
        $script:LarguraCards = $flowCards.ClientSize.Width
        $lista = @(Get-AchadosVisiveis)
        if ($lista.Count -eq 0) {
            $l = Nova-Etiqueta 'Nada por aqui.' 12 $false 'Texto3' 36 400
            $l.Margin = New-Object System.Windows.Forms.Padding(0, (PX 20), 0, 0)
            $flowCards.Controls.Add($l)
        }
        $grupoAtual = ''
        foreach ($a in $lista) {
            $gr = if ($a.Reparo -eq 'Auto') { 'Auto' } else { 'Manual' }
            if ($gr -ne $grupoAtual) {
                $grupoAtual = $gr
                $tg = Get-TextoGrupoReparo $gr
                $corG = if ($gr -eq 'Auto') { 'Ok' } else { 'Texto2' }
                $lt = Nova-Etiqueta $tg.Titulo 12.5 $true $corG 28 $largura
                $lt.Margin = New-Object System.Windows.Forms.Padding(0, (PX 6), 0, (PX 2))
                $flowCards.Controls.Add($lt)
                $ld = New-Object System.Windows.Forms.Label
                $ld.AutoSize = $true
                $ld.MaximumSize = New-Object System.Drawing.Size($largura, 0)
                $ld.Text = $tg.Texto
                $ld.Font = Fonte 9.5
                $ld.ForeColor = Pal 'Texto2'
                $ld.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 12))
                $flowCards.Controls.Add($ld)
            }
            $flowCards.Controls.Add((Nova-Card $a $largura))
        }
    } finally {
        $flowCards.ResumeLayout()
    }
}

function Get-CorNivel {
    param([string]$Nivel)
    switch ($Nivel) {
        'ok'     { return (Pal 'Ok') }
        'aviso'  { return (Pal 'Aviso') }
        'perigo' { return (Pal 'Perigo') }
        default  { return (Pal 'Texto3') }
    }
}

function Nova-LinhaPC {
    param([string]$Texto, [double]$Tam, [bool]$Negrito, [string]$CorNome, [int]$Largura, [int]$MargemBaixo = 0)
    $l = New-Object System.Windows.Forms.Label
    $l.AutoSize = $true
    $l.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    $l.Text = $Texto
    $l.Font = Fonte $Tam $Negrito
    $l.ForeColor = Pal $CorNome
    $l.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, $MargemBaixo)
    return $l
}

function Nova-CardPC {
    param($Sec, [int]$Largura)
    $interna = $Largura - (PX 38)
    $card = New-Object System.Windows.Forms.FlowLayoutPanel
    $card.FlowDirection = 'TopDown'
    $card.WrapContents = $false
    $card.AutoSize = $true
    $card.AutoSizeMode = 'GrowAndShrink'
    $card.BackColor = [System.Drawing.Color]::White
    $card.Padding = New-Object System.Windows.Forms.Padding((PX 18), (PX 14), (PX 18), (PX 14))
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 14))
    $card.MinimumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.MaximumSize = New-Object System.Drawing.Size($Largura, 0)
    $card.AccessibleName = ('{0}: {1}' -f $Sec.Titulo, $Sec.Destaque).Trim(' ', ':')
    $card.AccessibleRole = 'Grouping'
    $card.Add_Paint({
        param($remetente, $ev)
        $pen = New-Object System.Drawing.Pen((Cor $script:Pal['Borda']))
        $ev.Graphics.DrawRectangle($pen, 0, 0, $remetente.Width - 1, $remetente.Height - 1)
        $pen.Dispose()
        $br = New-Object System.Drawing.SolidBrush((Cor $script:Pal['Acento']))
        $ev.Graphics.FillRectangle($br, 0, 0, $remetente.Width, (PX 3))
        $br.Dispose()
    })

    $card.Controls.Add((Nova-LinhaPC (("$($Sec.Titulo)").ToUpper()) 8.5 $true 'Acento' $interna (PX 6)))
    if ($Sec.Destaque) {
        $mb = 0; if (-not $Sec.Sub) { $mb = PX 6 }
        $card.Controls.Add((Nova-LinhaPC "$($Sec.Destaque)" 13 $true 'Texto' $interna $mb))
    }
    if ($Sec.Sub) { $card.Controls.Add((Nova-LinhaPC "$($Sec.Sub)" 9.5 $false 'Texto2' $interna (PX 8))) }

    $empilhado = (@('disk', 'net') -contains "$($Sec.Chave)")
    $colR = PX 104
    foreach ($it in (Get-VetorLista $Sec.Itens)) {
        $linha = New-Object System.Windows.Forms.FlowLayoutPanel
        $linha.AutoSize = $true
        $linha.AutoSizeMode = 'GrowAndShrink'
        $linha.WrapContents = $false
        $linha.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 5))
        $nivel = "$($it.Nivel)"
        if ($empilhado) {
            $linha.FlowDirection = 'TopDown'
            $linha.Controls.Add((Nova-LinhaPC "$($it.R)" 10 $true 'Texto' $interna 0))
            $sub = New-Object System.Windows.Forms.FlowLayoutPanel
            $sub.AutoSize = $true; $sub.AutoSizeMode = 'GrowAndShrink'; $sub.WrapContents = $false
            $sub.Margin = New-Object System.Windows.Forms.Padding(0)
            if ($nivel) {
                $d = Nova-LinhaPC ([string][char]0x25CF) 9 $false 'Texto3' (PX 20) 0
                $d.ForeColor = Get-CorNivel $nivel
                $d.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 4), 0)
                $sub.Controls.Add($d)
            }
            $sub.Controls.Add((Nova-LinhaPC "$($it.V)" 9.5 $false 'Texto2' ($interna - (PX 24)) 0))
            $linha.Controls.Add($sub)
        } else {
            $linha.FlowDirection = 'LeftToRight'
            $r = New-Object System.Windows.Forms.Label
            $r.AutoSize = $false
            $r.Width = $colR
            $r.Height = PX 20
            $r.Text = "$($it.R)"
            $r.Font = Fonte 9.5
            $r.ForeColor = Pal 'Texto3'
            $r.Margin = New-Object System.Windows.Forms.Padding(0)
            $linha.Controls.Add($r)
            $linha.Controls.Add((Nova-LinhaPC "$($it.V)" 9.5 $false 'Texto' ($interna - $colR - (PX 6)) 0))
        }
        $card.Controls.Add($linha)
    }

    foreach ($br in (Get-VetorLista $Sec.Barras)) {
        $cab = New-Object System.Windows.Forms.FlowLayoutPanel
        $cab.AutoSize = $true; $cab.AutoSizeMode = 'GrowAndShrink'; $cab.WrapContents = $false
        $cab.Margin = New-Object System.Windows.Forms.Padding(0, (PX 4), 0, (PX 4))
        $rot = Nova-LinhaPC "$($br.Rotulo)" 10 $true 'Texto' (PX 90) 0
        $rot.Margin = New-Object System.Windows.Forms.Padding(0, 0, (PX 8), 0)
        $cab.Controls.Add($rot)
        $cab.Controls.Add((Nova-LinhaPC "$($br.Texto)" 9.5 $false 'Texto2' ($interna - (PX 100)) 0))
        $card.Controls.Add($cab)
        $fundo = New-Object System.Windows.Forms.Panel
        $fundo.Width = $interna
        $fundo.Height = PX 6
        $fundo.BackColor = Pal 'Borda'
        $fundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 8))
        $fr = [Math]::Max(0.0, [Math]::Min(1.0, [double]$br.Fracao))
        $cheio = New-Object System.Windows.Forms.Panel
        $cheio.Height = $fundo.Height
        $cheio.Width = [int][Math]::Round($interna * $fr)
        $cheio.Left = 0; $cheio.Top = 0
        $cheio.BackColor = Get-CorNivel "$($br.Nivel)"
        $fundo.Controls.Add($cheio)
        $card.Controls.Add($fundo)
    }
    return $card
}

function Montar-PC {
    param([switch]$SePrecisar)
    if ($null -eq $script:DadosPC) { return }
    $avail = $pnlPC.ClientSize.Width - $pnlPC.Padding.Horizontal - [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
    if ($avail -lt (PX 200)) { return }
    if ($SePrecisar -and [Math]::Abs($avail - $script:LarguraPC) -le (PX 20) -and $pnlPC.Controls.Count -gt 0) { return }
    $script:LarguraPC = $avail
    $pnlPC.SuspendLayout()
    try {
        foreach ($c in @($pnlPC.Controls)) { $c.Dispose() }
        $pnlPC.Controls.Clear()
        $secoes = @($script:DadosPC | Where-Object { $_ -is [hashtable] })
        if ($secoes.Count -eq 0) {
            $pnlPC.Controls.Add((Nova-LinhaPC 'Sem informações do computador.' 11 $false 'Texto3' (PX 500) 0))
            return
        }
        $gap = PX 16
        $ncols = 1
        if ($avail -ge (PX 780)) { $ncols = 2 }
        $larg = [int][Math]::Floor(($avail - ($gap * ($ncols - 1))) / $ncols)
        $larg = [Math]::Min($larg, (PX 600))
        $linhaCols = New-Object System.Windows.Forms.FlowLayoutPanel
        $linhaCols.FlowDirection = 'LeftToRight'
        $linhaCols.WrapContents = $false
        $linhaCols.AutoSize = $true
        $linhaCols.AutoSizeMode = 'GrowAndShrink'
        $linhaCols.Location = New-Object System.Drawing.Point($pnlPC.Padding.Left, $pnlPC.Padding.Top)
        $cols = @(); $pesos = @()
        for ($i = 0; $i -lt $ncols; $i++) {
            $c = New-Object System.Windows.Forms.FlowLayoutPanel
            $c.FlowDirection = 'TopDown'
            $c.WrapContents = $false
            $c.AutoSize = $true
            $c.AutoSizeMode = 'GrowAndShrink'
            $c.Margin = New-Object System.Windows.Forms.Padding(0, 0, $gap, 0)
            $linhaCols.Controls.Add($c)
            $cols += $c; $pesos += 0.0
        }
        foreach ($sec in $secoes) {
            $nIt = [double]([int]$sec.Itens.Count)
            $nBr = [double]([int]$sec.Barras.Count)
            $w = 3.0 + $nIt + (1.6 * $nBr)
            if ($sec.Destaque) { $w += 2.0 }
            $k = 0
            for ($i = 1; $i -lt $ncols; $i++) { if ($pesos[$i] -lt $pesos[$k]) { $k = $i } }
            try { $cartao = Nova-CardPC $sec $larg }
            catch {
                try { Registrar-Erro $_ -Silencioso } catch { }
                $cartao = Nova-LinhaPC ("$($sec.Titulo): não foi possível mostrar este bloco. Detalhes em erros.log.") 9.5 $false 'Texto3' $larg 6
            }
            $cols[$k].Controls.Add($cartao)
            $pesos[$k] += $w
        }
        $pnlPC.Controls.Add($linhaCols)
    } finally {
        $pnlPC.ResumeLayout()
    }
}

function Add-LinhaLado {
    param([string]$Texto, [double]$Tam, [bool]$Neg, [string]$Cor, [int]$Acima = 0, [int]$Abaixo = 0)
    $larg = [int]($pnlLado.Width - (PX 22) - (PX 14) - (PX 20))
    $l = Nova-LinhaPC $Texto $Tam $Neg $Cor $larg $Abaixo
    $l.Margin = New-Object System.Windows.Forms.Padding(0, $Acima, 0, $Abaixo)
    $fluxoLado.Controls.Add($l)
}

function Montar-PcInicio {
    # $Estado: 'dados' (usa $script:DadosPcIni), 'lendo' ou 'erro' (com $Mensagem)
    param([string]$Estado = 'dados', [string]$Mensagem = '')
    $fluxoLado.SuspendLayout()
    try {
        foreach ($c in @($fluxoLado.Controls)) { $c.Dispose() }
        $fluxoLado.Controls.Clear()
        Add-LinhaLado (Tr 'SEU COMPUTADOR') 8.5 $true 'Acento' 0 10
        if ($Estado -eq 'lendo') { Add-LinhaLado (Tr 'Lendo os componentes...') 10 $false 'Texto3' 0 0; return }
        if ($Estado -eq 'erro') {
            Add-LinhaLado (Tr 'Não foi possível ler os componentes agora.') 10 $false 'Texto2' 0 6
            if ($Mensagem) { Add-LinhaLado $Mensagem 8.5 $false 'Texto3' 0 0 }
            return
        }
        $sec = @($script:DadosPcIni | Where-Object { $_ -is [hashtable] }) | Select-Object -First 1
        if (-not $sec) { Add-LinhaLado (Tr 'Sem informações do computador.') 10 $false 'Texto3' 0 0; return }
        if ($sec.Destaque) { Add-LinhaLado "$($sec.Destaque)" 13 $true 'Texto' 0 2 }
        if ($sec.Sub) { Add-LinhaLado "$($sec.Sub)" 9.5 $false 'Texto2' 0 14 }
        foreach ($it in (Get-VetorLista $sec.Itens)) {
            Add-LinhaLado (Tr "$($it.R)") 8.5 $false 'Texto3' 6 0
            Add-LinhaLado "$($it.V)" 10 $false 'Texto' 0 4
        }
        if ((Get-VetorLista $sec.Barras).Count -gt 0) { Add-LinhaLado (Tr 'ARMAZENAMENTO') 8.5 $true 'Acento' 14 6 }
        $interna = [int]($pnlLado.Width - (PX 22) - (PX 14) - (PX 20))
        foreach ($br in (Get-VetorLista $sec.Barras)) {
            Add-LinhaLado ("$($br.Rotulo)  $($br.Texto)") 9.5 $false 'Texto' 0 3
            $fundo = New-Object System.Windows.Forms.Panel
            $fundo.Width = $interna; $fundo.Height = PX 6; $fundo.BackColor = Pal 'Borda'
            $fundo.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, (PX 10))
            $fr = [Math]::Max(0.0, [Math]::Min(1.0, [double]$br.Fracao))
            $cheio = New-Object System.Windows.Forms.Panel
            $cheio.Height = $fundo.Height; $cheio.Width = [int][Math]::Round($interna * $fr); $cheio.Left = 0; $cheio.Top = 0
            $cheio.BackColor = Get-CorNivel "$($br.Nivel)"
            $fundo.Controls.Add($cheio)
            $fluxoLado.Controls.Add($fundo)
        }
    } finally { $fluxoLado.ResumeLayout() }
}

function Start-LeituraPcInicio {
    # Lê os componentes logo depois de a janela aparecer (1 a 2 segundos). Se falhar, a barra lateral mostra o motivo e o erro vai ao erros.log.
    if ($script:PcIniFeito) { return }
    $script:PcIniFeito = $true
    try { Montar-PcInicio 'lendo' } catch { }
    $script:TimerPcIni = New-Object System.Windows.Forms.Timer
    $script:TimerPcIni.Interval = 150
    $script:TimerPcIni.Add_Tick({
        $script:TimerPcIni.Stop()
        try {
            $res = @(Get-ResumoPcRapido)
            if ($res.Count -gt 0) { $script:DadosPcIni = $res; Montar-PcInicio 'dados' }
            else { Montar-PcInicio 'erro' 'A leitura não devolveu dados.' }
        } catch {
            try { Registrar-Erro $_ -Silencioso } catch { }
            try { Montar-PcInicio 'erro' ("$($_.Exception.Message) [linha $($_.InvocationInfo.ScriptLineNumber): $(("$($_.InvocationInfo.Line)").Trim())]") } catch { }
        }
    })
    $script:TimerPcIni.Start()
}

function Update-IconeAtalhos {
    # Atalhos criados por versões antigas apontam para o escudo; troca para o ícone do WinDiag (sem apagar nem recriar o atalho).
    try {
        $origem = Join-Path $PSScriptRoot 'windiag.ico'
        if (-not (Test-Path -LiteralPath $origem)) { return }
        $dadosDir = Join-Path $env:LOCALAPPDATA 'WinDiag'
        New-Item -ItemType Directory -Force -Path $dadosDir | Out-Null
        $ico = Join-Path $dadosDir 'windiag-app.ico'
        Copy-Item -LiteralPath $origem -Destination $ico -Force
        $ws = New-Object -ComObject WScript.Shell
        $mudou = $false
        foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
            $lnk = Join-Path $pasta 'WinDiag.lnk'
            if (-not (Test-Path -LiteralPath $lnk)) { continue }
            $l = $ws.CreateShortcut($lnk)
            if ("$($l.IconLocation)" -ne "$ico,0") {
                $b = [IO.File]::ReadAllBytes($lnk)   # preserva a opção "Executar como administrador" do atalho
                $l.IconLocation = "$ico,0"; $l.Save()
                try { if ($b[0x15] -band 0x20) { $n = [IO.File]::ReadAllBytes($lnk); $n[0x15] = $n[0x15] -bor 0x20; [IO.File]::WriteAllBytes($lnk, $n) } } catch { }
                $mudou = $true
            }
        }
        try { $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WinDiag'; if (Test-Path -LiteralPath $k) { Set-ItemProperty -LiteralPath $k -Name DisplayIcon -Value $ico } } catch { }
        if ($mudou) { try { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden } catch { } }
    } catch { }
}

function Get-TextoResumo {
    $L = New-Object System.Collections.Generic.List[string]
    $rot = @{ Critico = 'GRAVE'; Atencao = 'ATENÇÃO'; Info = 'INFO' }
    $L.Add("WinDiag v$($script:Versao) - resumo da verificação")
    $L.Add('')
    $grupoAtual = ''
    foreach ($a in @(Get-AchadosVisiveis)) {
        $gr = if ($a.Reparo -eq 'Auto') { 'Auto' } else { 'Manual' }
        if ($gr -ne $grupoAtual) {
            $grupoAtual = $gr
            $tg = Get-TextoGrupoReparo $gr
            $L.Add(('=== ' + $tg.Titulo + ' ==='))
            $L.Add($tg.Texto)
            $L.Add('')
        }
        $L.Add(("[{0}] {1}" -f $rot["$($a.Gravidade)"], $a.Titulo))
        if ($a.Detalhe) { $L.Add("    $($a.Detalhe)") }
        if ($a.Solucao) { $L.Add("    O que fazer: $($a.Solucao)") }
        if ($a.Veredito) { $L.Add("    Avaliação: $(Get-RotuloVeredito "$($a.Veredito)")") }
        if ($a.Reparo -eq 'Auto') { $L.Add('    Reparo: corrigível pelo WinDiag') } else { $L.Add('    Reparo: não corrigível pelo WinDiag') }
        $L.Add('')
    }
    if ($script:Res -and $script:Res.ResumoPC) { $L.Add('--- Meu computador ---'); $L.Add("$($script:Res.ResumoPC)") }
    return ($L -join "`r`n")
}

function Mostrar-Resultados {
    param($R)
    $script:Res = $R
    $script:Expandidos = @{}
    try { Ajustar-Margens } catch { }
    $achados = @($R.Achados)
    $nc = @($achados | Where-Object { $_.Gravidade -eq 'Critico' }).Count
    $na = @($achados | Where-Object { $_.Gravidade -eq 'Atencao' }).Count
    $ni = @($achados | Where-Object { $_.Gravidade -eq 'Info' }).Count

    if ($nc -gt 0) {
        $banner.BackColor = Cor '#FEF2F2'; $faixa.BackColor = Pal 'Perigo'; $lblBanT.ForeColor = Cor '#991B1B'
        $lblBanT.Text = "Encontramos $nc problema(s) grave(s)"
        $sub = 'Veja abaixo o que significam e o que fazer.'
    } elseif ($na -gt 0) {
        $banner.BackColor = Cor '#FFFBEB'; $faixa.BackColor = Pal 'Aviso'; $lblBanT.ForeColor = Cor '#92400E'
        $lblBanT.Text = "Encontramos $na ponto(s) que merecem atenção"
        $sub = 'Nada crítico, mas vale a pena dar uma olhada.'
    } else {
        $banner.BackColor = Cor '#F0FDF4'; $faixa.BackColor = Pal 'Ok'; $lblBanT.ForeColor = Cor '#166534'
        $lblBanT.Text = (Tr 'Tudo certo! Nenhum problema relevante')
        $sub = 'Seu computador passou na verificação.'
    }
    $nAuto = @($achados | Where-Object { $_.Reparo -eq 'Auto' -and $_.Gravidade -ne 'Info' }).Count
    $nMan  = @($achados | Where-Object { $_.Reparo -ne 'Auto' -and $_.Gravidade -ne 'Info' }).Count
    if (($nAuto + $nMan) -gt 0) { $sub += " O WinDiag consegue corrigir $nAuto; $nMan precisa(m) de você." }
    if ($R.NAcoes -gt 0 -and -not $script:IsAdmin) {
        $sub += ' Para corrigir, feche e reabra o WinDiag como administrador.'
    } elseif ($R.NAcoes -gt 0 -and $nAuto -gt 0) {
        $sub += " Há $($R.NAcoes) correção(ões) disponível(is)."
    } elseif ($R.NAcoes -gt 0) {
        $sub += " Há $($R.NAcoes) proteção(ões) opcional(is) disponível(is) (ex.: impedir o Windows Update de trocar o driver de vídeo)."
    }
    if ([int]$R.NDesfaz -gt 0) { $sub += ' O WinDiag já protegeu o driver de vídeo contra trocas; para remover essa proteção, use "Desfazer bloqueios" em Ferramentas de reparo.' }
    if ($ni -gt 0) { $sub += " Há também $ni aviso(s) informativo(s)." }
    if ($R.NotaTexto) { $sub += ' ' + [string]$R.NotaTexto }
    if ($R.Comparacao) { $sub += ' ' + [string]$R.Comparacao }
    $lblBanS.Text = $sub
    try { Ajustar-Barra $barraRes } catch { }

    $abaProb.Text = "Problemas encontrados ($($nc + $na))"

    $chkInfo.Checked = $false
    $cmbCat.SelectedIndex = -1
    Atualizar-Filtro
    $script:DadosPC = @($R.PC)
    $script:LarguraPC = 0
    Montar-PC

    # O painel de log passa a viver na aba "Detalhes técnicos"
    $tpDet.Controls.Add($script:Log)
    $script:Log.Dock = 'Fill'
    $script:Log.Visible = $true

    $btnReiniciar.Visible = [bool](@($R.Achados | Where-Object { "$($_.Titulo)" -eq 'Há uma reinicialização pendente' }).Count -gt 0)
    $btnCorrigir.Enabled = ($script:IsAdmin -and $R.NAcoes -gt 0)
    if ($R.NAcoes -gt 0 -and $script:IsAdmin) { $btnCorrigir.Text = "Corrigir automaticamente ($($R.NAcoes))" }
    elseif ($R.NAcoes -gt 0) { $btnCorrigir.Text = (Tr 'Corrigir (requer administrador)') }
    else { $btnCorrigir.Text = (Tr 'Nada a corrigir') }
    $btnRelatorio.Enabled = [bool]($R.Html -and (Test-Path -LiteralPath $R.Html))

    Show-Aba 0
    Show-Pagina $pgRes
    Montar-Cards
}

function Confirmar-Reinicio {
    $ok = Show-Dialogo -Titulo 'WinDiag' -Texto 'O computador será reiniciado em 20 segundos. Salve seus trabalhos agora. Para cancelar depois de confirmar, abra um prompt e digite: shutdown /a' -TextoSim 'Reiniciar agora' -TextoNao 'Mais tarde' -PadraoSim $false
    if ($ok) { Start-Process -FilePath 'shutdown.exe' -ArgumentList '/r', '/t', '20', '/c', '"WinDiag: reiniciando para concluir as correções"' -WindowStyle Hidden }
}

function Mostrar-Bench {
    param($R)
    try { Ajustar-Margens } catch { }
    $script:UltBenchHtml = [string]$R.Html
    $ehBench = ("$($R.Fase)" -eq 'bench')
    foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2)) { $b.Visible = $false }
    $btnBenchAbrir.Visible = [bool]$R.Html; $btnBenchDeNovo.Visible = $ehBench; $btnBenchVoltar.Visible = $true
    $btnBenchAbrir.Enabled = [bool]($R.Html -and (Test-Path -LiteralPath ([string]$R.Html)))
    if ($R.Titulo) {
        $lblFimT.ForeColor = Pal 'Ok'; $lblFimT.Text = [string]$R.Titulo
    } else {
        switch ("$($R.Pior)") {
            'problema' { $lblFimT.ForeColor = Pal 'Perigo'; $lblFimT.Text = (Tr 'Teste de desempenho: há um problema') }
            'atencao'  { $lblFimT.ForeColor = Pal 'Aviso';  $lblFimT.Text = (Tr 'Teste de desempenho: pontos de atenção') }
            default    { $lblFimT.ForeColor = Pal 'Ok';     $lblFimT.Text = (Tr 'Teste de desempenho concluído') }
        }
    }
    try { Ajustar-Barra $barraFim } catch { }
    $t = [string]$R.Texto
    if ($R.Cancelado) { $t = "O teste foi interrompido; só os testes concluídos aparecem abaixo.`r`n`r`n" + $t }
    $txtFim.Text = $t
    $txtFim.SelectionStart = 0
    $txtFim.SelectionLength = 0
    Show-Pagina $pgFim
}

function Mostrar-Fim {
    param($R)
    try { Ajustar-Margens } catch { }
    foreach ($b in @($btnReiniciar, $btnDesfazer, $btnVerif2)) { $b.Visible = $true }
    foreach ($b in @($btnBenchAbrir, $btnBenchDeNovo, $btnBenchVoltar)) { $b.Visible = $false }
    try { Ajustar-Barra $barraFim } catch { }
    $itens = @($R.Alteracoes)
    $precisaReiniciar = [bool]$R.Reiniciar
    $btnDesfazer.Enabled = ($itens.Count -gt 0)
    if ($itens.Count -eq 0) {
        $lblFimT.ForeColor = Pal 'Aviso'
        $lblFimT.Text = (Tr 'Nenhuma correção foi aplicada')
        $txtFim.Text = "Você não autorizou nenhuma correção (ou nenhuma foi necessária).`r`n`r`nSe quiser, volte e clique em 'Verificar de novo'."
        $btnReiniciar.Enabled = $false
        $btnReiniciar.Text = (Tr 'Reiniciar o computador agora')
    } else {
        if ($R.Cancelado) {
            $lblFimT.ForeColor = Pal 'Aviso'
            $lblFimT.Text = (Tr 'Correções interrompidas')
        } else {
            $lblFimT.ForeColor = Pal 'Ok'
            $lblFimT.Text = (Tr 'Correções concluídas')
        }
        $linhas = New-Object System.Collections.Generic.List[string]
        foreach ($i in $itens) { $linhas.Add(("- {0}`r`n    Resultado: {1}" -f $i.Acao, $i.Resultado)) }
        $linhas.Add('')
        if ($R.Cancelado) { $linhas.Add('Você pediu para parar: as correções que ainda não tinham começado foram puladas.') }
        if ($precisaReiniciar) {
            $linhas.Add('O Windows indicou que precisa reiniciar para concluir as correções. Depois, clique em "Verificar de novo" para conferir o resultado.')
        } else {
            $linhas.Add('Não é preciso reiniciar agora. Se algum problema persistir, reinicie e clique em "Verificar de novo".')
        }
        $linhas.Add('Um relatório atualizado, com todas as alterações feitas, foi salvo na pasta da verificação.')
        $linhas.Add('')
        $linhas.Add('Importante: depois de corrigir, a nova verificação ainda pode mostrar alguns avisos. Isso é esperado para: (1) o histórico de eventos, como desligamentos inesperados e travamentos de driver já ocorridos, que continuam registrados por 30 dias; e (2) drivers e serviços de programas, como jogos e anti-cheat (ex.: Riot Vanguard), que o WinDiag não conserta sozinho: abra "Ver mais" no aviso e reinstale o programa citado.')
        if ($R.TemCopia) { $linhas.Add('Se algo piorar, o botão "Desfazer alterações" restaura a cópia dos drivers feita antes das correções.') }
        $txtFim.Text = ($linhas -join "`r`n")
        $btnReiniciar.Enabled = $true
        if ($precisaReiniciar) { $btnReiniciar.Text = (Tr 'Reiniciar o computador agora') } else { $btnReiniciar.Text = (Tr 'Reiniciar mesmo assim (opcional)') }
    }
    $txtFim.SelectionStart = 0
    $txtFim.SelectionLength = 0
    Show-Pagina $pgFim
    if ($precisaReiniciar -and $itens.Count -gt 0) { Confirmar-Reinicio }
}

function Iniciar-Desfazer {
    if (-not $script:IsAdmin) {
        [void][System.Windows.Forms.MessageBox]::Show('É preciso abrir o WinDiag como administrador para desfazer alterações.', 'WinDiag', 'OK', 'Information')
        return
    }
    $r = Show-Dialogo -Titulo 'WinDiag - desfazer' -Texto "Se você aceitou criar a cópia dos drivers antes das correções, o WinDiag pode reinstalar essa cópia (útil quando um driver atualizado causou problemas).`r`n`r`nPara voltar o Windows inteiro a um ponto anterior, use a Restauração do Sistema (próxima opção)." -TextoSim 'Restaurar drivers salvos' -TextoNao 'Outras opções' -PadraoSim $false
    if ($r) { Start-Fase 'restore'; return }
    $r2 = Show-Dialogo -Titulo 'WinDiag - desfazer' -Texto 'Abrir a Restauração do Sistema do Windows? Ela permite escolher o ponto de restauração criado pelo WinDiag antes das correções.' -TextoSim 'Abrir' -TextoNao 'Cancelar' -PadraoSim $false
    if ($r2) { Start-Process -FilePath 'rstrui.exe' }
}

# Ações novas desta versão
$btnCopiar.Add_Click({
    try {
        [System.Windows.Forms.Clipboard]::SetText((Get-TextoResumo))
        $btnCopiar.Text = (Tr 'Copiado!')
        $script:TimerCopiar.Stop()
        $script:TimerCopiar.Start()
    } catch { Registrar-Erro $_ -Silencioso }
})
$script:TimerCopiar = New-Object System.Windows.Forms.Timer
$script:TimerCopiar.Interval = 1600
$script:TimerCopiar.Add_Tick({ $script:TimerCopiar.Stop(); $btnCopiar.Text = (Tr 'Copiar resumo') })

$btnPastaBase.Add_Click({
    try {
        $base = Join-Path ([Environment]::GetFolderPath('Desktop')) 'WinDiag'
        if (Test-Path -LiteralPath $base) {
            Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $base)
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Ainda não há verificações salvas.', 'WinDiag', 'OK', 'Information')
        }
    } catch { Registrar-Erro $_ -Silencioso }
})

# ----------------------------------------------------------------------------
# Execução em segundo plano
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Tempo decorrido e estimativa de término
# ----------------------------------------------------------------------------
# Duração esperada de cada etapa (segundos) antes de o WinDiag aprender com o seu computador.
$script:PesosPadrao = @{ 1 = 5; 2 = 20; 3 = 15; 4 = 60; 5 = 40; 6 = 90; 7 = 20; 8 = 5 }
$script:ArquivoTempos = Join-Path $env:LOCALAPPDATA 'WinDiag\tempos.json'
$script:Historico = @{}
$script:TempoObs = @{}
$script:EtapaN = 0
$script:EtapaTotal = 0
$script:EtapaInicio = 0.0
$script:ProgPct = 0.0
$script:ProgP0 = 0.0
$script:ProgT0 = 0.0
$script:ProgUlt = -1.0

function Get-ChaveEtapa {
    # A duração depende das opções (Windows Update e varredura de discos), então elas entram na chave.
    param([int]$N)
    $wu = 1; if ($script:Opc.SemWindowsUpdate) { $wu = 0 }
    $vol = 1; if ($script:Opc.PularScanVolumes) { $vol = 0 }
    $pf = 0; if ($script:Opc.VerificacaoProfunda) { $pf = 1 }
    return "$N|$wu|$vol|$pf"
}

function Get-BaseEtapa {
    param([int]$N)
    $k = Get-ChaveEtapa $N
    if ($script:Historico.ContainsKey($k)) { return [double]$script:Historico[$k] }
    $b = 10.0
    # Na verificação profunda há uma etapa extra (8) antes do relatório: o relatório passa a ser a 9 e usa o peso que seria da 8.
    $nPeso = $N
    if ($script:Opc.VerificacaoProfunda -and $N -gt 8) { $nPeso = $N - 1 }
    if ($script:PesosPadrao.ContainsKey($nPeso)) { $b = [double]$script:PesosPadrao[$nPeso] }
    if ($script:Opc.VerificacaoProfunda -and $N -eq 8) { $b = 900.0 }
    if ($N -eq 4 -and $script:Opc.PularScanVolumes) { $b = 5.0 }
    if ($N -eq 6 -and $script:Opc.SemWindowsUpdate) { $b = 45.0 }
    return $b
}

function Get-EstimativaTempo {
    # Fração concluída (0 a 0,97) e segundos que faltam, a partir do passo atual e do tempo gasto nele.
    param([int]$N, [int]$Total, [double]$NaEtapa, [hashtable]$Obs)
    $feitoObs = 0.0; $feitoEsp = 0.0
    for ($k = 1; $k -lt $N; $k++) {
        $ch = Get-ChaveEtapa $k
        if ($Obs.ContainsKey($ch)) { $feitoObs += [double]$Obs[$ch]; $feitoEsp += (Get-BaseEtapa $k) }
    }
    # Ajuste de velocidade deste computador, conforme as etapas já concluídas
    $fator = 1.0
    if ($feitoEsp -gt 5) { $fator = [Math]::Max(0.5, [Math]::Min(3.0, $feitoObs / $feitoEsp)) }
    $soma = 0.0; $feito = 0.0; $falta = 0.0
    for ($k = 1; $k -le $Total; $k++) {
        $b = (Get-BaseEtapa $k) * $fator
        $soma += $b
        if ($k -lt $N) { $feito += $b }
        elseif ($k -eq $N) {
            $feito += [Math]::Min($NaEtapa, $b * 0.95)
            $falta += [Math]::Max($b - $NaEtapa, $b * 0.15)
        } else { $falta += $b }
    }
    $fr = 0.0
    if ($soma -gt 0) { $fr = [Math]::Min(0.97, $feito / $soma) }
    return @{ Fracao = $fr; Falta = $falta }
}

function Get-EstimativaProgresso {
    # Tempo restante (s) de uma tarefa com percentual (DISM/SFC), pela velocidade observada até agora.
    param([double]$Pct, [double]$Pct0, [double]$Dt)
    $avancou = $Pct - $Pct0
    if ($avancou -lt 2 -or $Dt -lt 5) { return $null }
    $taxa = $avancou / $Dt
    if ($taxa -le 0) { return $null }
    return [double]((100 - $Pct) / $taxa)
}

function Format-Duracao {
    param([double]$Seg)
    $t = [int][Math]::Round($Seg)
    return ('{0:00}:{1:00}' -f [int][Math]::Floor($t / 60), ($t % 60))
}

function Format-Restante {
    param([double]$Seg)
    if ($Seg -lt 45) { return 'menos de 1 minuto' }
    $m = [int][Math]::Ceiling($Seg / 60)
    if ($m -eq 1) { return 'cerca de 1 minuto' }
    return "cerca de $m minutos"
}

function Carregar-Historico {
    $script:Historico = @{}
    try {
        if (Test-Path -LiteralPath $script:ArquivoTempos) {
            $o = Get-Content -LiteralPath $script:ArquivoTempos -Raw -ErrorAction Stop | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) {
                $v = [double]$p.Value
                if ($v -gt 0 -and $v -lt 7200) { $script:Historico["$($p.Name)"] = $v }
            }
        }
    } catch { $script:Historico = @{} }
}

function Salvar-Historico {
    # Guarda quanto cada etapa levou (média móvel) para a próxima estimativa ser mais precisa.
    try {
        foreach ($k in @($script:TempoObs.Keys)) {
            $obs = [double]$script:TempoObs[$k]
            if ($obs -le 0) { continue }
            if ($script:Historico.ContainsKey($k)) { $script:Historico[$k] = [Math]::Round(0.5 * [double]$script:Historico[$k] + 0.5 * $obs, 1) }
            else { $script:Historico[$k] = [Math]::Round($obs, 1) }
        }
        $dir = Split-Path -Parent $script:ArquivoTempos
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        ($script:Historico | ConvertTo-Json) | Set-Content -LiteralPath $script:ArquivoTempos -Encoding UTF8
    } catch { }
}
Carregar-Historico

function Atualizar-Tempos {
    if (-not $script:Relogio) { return }
    $dec = $script:Relogio.Elapsed.TotalSeconds
    $txt = 'Tempo decorrido: ' + (Format-Duracao $dec)
    if ($script:FaseAtual -eq 'scan') {
        if ($script:EtapaN -gt 0 -and $script:EtapaTotal -gt 0) {
            $est = Get-EstimativaTempo -N $script:EtapaN -Total $script:EtapaTotal -NaEtapa ($dec - $script:EtapaInicio) -Obs $script:TempoObs
            $txt += '   ·   Tempo restante estimado: ' + (Format-Restante $est.Falta)
            Set-Barra -Fracao $est.Fracao
        } else {
            $txt += '   ·   Tempo restante estimado: calculando...'
        }
    } elseif ($script:FaseAtual -eq 'tool') {
        Set-Barra -Indeterminada
    } elseif ($script:FaseAtual -eq 'bench') {
        if ($script:EtapaN -gt 0 -and $script:EtapaTotal -gt 0) {
            $txt += '   ·   Teste ' + $script:EtapaN + ' de ' + $script:EtapaTotal
            Set-Barra -Fracao ([Math]::Min(0.97, ($script:EtapaN - 0.5) / $script:EtapaTotal))
        } else {
            Set-Barra -Indeterminada
        }
    } else {
        # Reparos: DISM e SFC informam o percentual; a estimativa vale para a tarefa em andamento.
        $ativo = ($script:ProgUlt -ge 0 -and ($dec - $script:ProgUlt) -le 30)
        if ($ativo) {
            $txt += '   ·   Tarefa atual: ' + [int][Math]::Floor($script:ProgPct) + '%'
            $falta = Get-EstimativaProgresso -Pct $script:ProgPct -Pct0 $script:ProgP0 -Dt ($script:ProgUlt - $script:ProgT0)
            if ($null -ne $falta) { $txt += '   ·   Tempo restante estimado desta tarefa: ' + (Format-Restante $falta) }
            else { $txt += '   ·   Tempo restante estimado: calculando...' }
            Set-Barra -Fracao ($script:ProgPct / 100.0)
        } else {
            Set-Barra -Indeterminada
        }
    }
    $lblTempo.Text = $txt
}

function Add-Log {
    param([string]$Texto, [string]$CorNome)
    $l = $script:Log
    if ($l.TextLength -gt 600000) { $l.Clear() }
    $c = [System.Drawing.Color]::LightGray
    if ($CorNome) {
        try {
            $tmp = [System.Drawing.Color]::FromName($CorNome)
            if ($tmp.IsKnownColor) { $c = $tmp }
        } catch { }
    }
    $l.SelectionStart = $l.TextLength
    $l.SelectionLength = 0
    $l.SelectionColor = $c
    $l.AppendText($Texto + "`r`n")
}

function Start-Fase {
    param([ValidateSet('scan', 'repair', 'unblock', 'restore', 'bench', 'tool')][string]$Fase)
    if ($script:Async -and -not $script:Async.IsCompleted) { return }

    $script:FaseAtual = $Fase
    $script:FimRecebido = $false
    $script:Cancelando = $false
    $script:Sync.Cancelar = $false

    $script:Opc.SomenteLeitura   = (-not $script:IsAdmin)
    $script:Opc.SemWindowsUpdate = (-not $chkWU.Checked)
    $script:Opc.PularScanVolumes = (-not $chkVol.Checked)
    $script:Opc.VerificacaoProfunda = [bool]$chkProfIni.Checked
    $script:Opc.BenchLongo = [bool]$script:TesteLongo
    $script:Opc.BenchEstresse = [bool]$script:TesteEstresse
    $script:Opc.BenchTransicao = [bool]$script:TesteTransicao
    $script:Opc.BenchTransicaoPesado = [bool]$script:TransPesado
    $script:Opc.BenchEstresseProlongado = [bool]$script:EstresseProlongado
    $script:Opc.BenchMemoria = [bool]$script:TesteMemoria
    $script:Opc.BenchDiscoEstresse = [bool]$script:TesteDiscoEstresse
    $script:Opc.BenchDuracaoLonga = [bool]$script:DuracaoLonga
    $script:Opc.AceitarTudo      = ($Fase -eq 'repair' -and $script:ModoAuto)
    if ($Fase -eq 'tool') { $script:Opc.SomenteLeitura = $false }

    # Prepara a página de progresso
    $pgProg.Controls.Add($script:Log)
    $script:Log.Dock = 'Fill'
    $script:Log.BringToFront()   # o painel "Fill" precisa ser encaixado por último
    $script:Log.Visible = $false
    $script:Log.Clear()
    Alternar-Detalhes $false
    $btnCancel.Visible = ($Fase -eq 'scan' -or $Fase -eq 'repair' -or $Fase -eq 'bench' -or $Fase -eq 'tool')
    $btnCancel.Enabled = $true
    if ($Fase -eq 'repair') {
        Ajustar-LarguraBotao $btnCancel 'Parar depois desta correção' 120
    } else {
        Ajustar-LarguraBotao $btnCancel 'Cancelar' 120
    }
    Set-Barra -Indeterminada
    $lblTempo.Text = (Tr 'Tempo decorrido: 00:00')
    $script:Relogio = [System.Diagnostics.Stopwatch]::StartNew()
    $script:EtapaN = 0
    $script:EtapaTotal = 0
    $script:EtapaInicio = 0.0
    $script:TempoObs = @{}
    $script:ProgPct = 0.0
    $script:ProgP0 = 0.0
    $script:ProgT0 = 0.0
    $script:ProgUlt = -1.0
    Atualizar-Tempos
    $lblEtapa.Text = (Tr 'Preparando...')
    if ($Fase -eq 'scan') {
        $lblDica.Text = 'Pode continuar usando o computador. A estimativa melhora a cada verificação, porque o WinDiag aprende quanto tempo cada etapa leva no seu computador. Se a janela pedir algo, responda na caixa que aparecer.'
    } elseif ($Fase -eq 'tool') {
        $lblDica.Text = (Tr 'Se aparecer uma pergunta, responda na caixa que abrir. Não feche esta janela até terminar.')
    } elseif ($Fase -eq 'bench') {
        $lblDica.Text = 'O computador pode ficar lento por alguns minutos (de 3 a 14 minutos, conforme o tipo de teste escolhido). Janelas com animação vão abrir e fechar sozinhas, no estresse de jogo pesado em tela cheia (Esc para parar): não mexa nelas. Nada é alterado no seu computador.'
    } else {
        $lblDica.Text = (Tr 'Não feche esta janela e não desligue o computador enquanto as correções estiverem em andamento.')
    }
    Show-Pagina $pgProg

    try {
        if (-not $script:RS) {
            $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
            try { $iss.ExecutionPolicy = [Microsoft.PowerShell.ExecutionPolicy]::Bypass } catch { }
            $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
            $rs.ApartmentState = 'MTA'
            $rs.ThreadOptions = 'ReuseThread'
            $rs.Open()
            $rs.SessionStateProxy.SetVariable('WD_Sync', $script:Sync)
            $rs.SessionStateProxy.SetVariable('WD_Opc', $script:Opc)
            $script:RS = $rs
        }
        $ps = [System.Management.Automation.PowerShell]::Create()
        $ps.Runspace = $script:RS
        $codigo = ''
        if (-not $script:WorkerCarregado) {
            $caminho = (Join-Path $PSScriptRoot 'WinDiag-Worker.ps1').Replace("'", "''")
            $codigo += ". '$caminho'`r`n"
        }
        $codigo += "Invoke-FaseGUI -Fase '$Fase'"
        [void]$ps.AddScript($codigo, $false)
        $script:Ps = $ps
        $script:Async = $ps.BeginInvoke()
    } catch {
        Registrar-Erro $_
        Show-Pagina $pgInicio
    }
}

function Tratar-Ask {
    param($M)
    $p = [string]$M.Prompt
    $resp = ''
    if ($p -match 'Pressione Enter') {
        $resp = ''
    } elseif ($p -match '\[S/n\]\s*$') {
        $txt = ($p -replace '\s*\[[sSnN]/[sSnN]\]\s*$', '').Trim()
        if (Show-Dialogo -Titulo 'WinDiag - confirmação' -Texto $txt -TextoSim 'Sim' -TextoNao 'Não' -PadraoSim $true) { $resp = 's' } else { $resp = 'n' }
    } elseif ($p -match '\[s/N\]\s*$') {
        $txt = ($p -replace '\s*\[[sSnN]/[sSnN]\]\s*$', '').Trim()
        if (Show-Dialogo -Titulo 'WinDiag - confirmação' -Texto $txt -TextoSim 'Sim' -TextoNao 'Não' -PadraoSim $false) { $resp = 's' } else { $resp = 'n' }
    }
    $M.Req.Resp = $resp
    [void]$M.Req.Evt.Set()
}

function Tratar-Confirm {
    param($M)
    $ok = $false
    if ($M.Sensivel) {
        $aviso = 'Este é um driver INTERNO do sistema (chipset, armazenamento, processador ou barramento). Uma troca errada pode impedir o Windows de iniciar. Só continue se tiver certeza. O WinDiag cria um ponto de volta antes.'
        if ($M.Aviso) { $aviso += "`r`n`r`n$($M.Aviso)" }
        $ok = Show-Dialogo -Titulo 'WinDiag - ação sensível' -Texto ([string]$M.Mensagem) -Aviso $aviso -Exige 'RESTAURAR' -TextoSim 'Restaurar' -TextoNao 'Não restaurar' -PadraoSim $false -Perigo $true
    } else {
        $ok = Show-Dialogo -Titulo 'WinDiag - confirmar correção' -Texto ([string]$M.Mensagem) -Aviso ([string]$M.Aviso) -TextoSim 'Sim, fazer' -TextoNao 'Agora não' -PadraoSim $false
    }
    $M.Req.Resp = [bool]$ok
    [void]$M.Req.Evt.Set()
}

function Tratar-Fim {
    param($M)
    $script:FimRecebido = $true
    $script:WorkerCarregado = $true
    Set-Barra -Fracao 1
    if (-not $M.Ok -and "$($M.Fase)" -ne 'scan') {
        # Reparo, restauração ou desbloqueio que falhou: mostra o motivo em vez de uma tela vazia.
        [void][System.Windows.Forms.MessageBox]::Show("A operação não pôde ser concluída.`r`n`r`n$($M.Erro)", 'WinDiag', 'OK', 'Warning')
        if ($script:Res) { Show-Pagina $pgRes } else { Show-Pagina $pgInicio }
        return
    }
    switch ("$($M.Fase)") {
        'scan' {
            if ($M.Ok) {
                if ($script:EtapaN -gt 0 -and -not $script:Cancelando -and $script:Relogio) {
                    $script:TempoObs[(Get-ChaveEtapa $script:EtapaN)] = ($script:Relogio.Elapsed.TotalSeconds - $script:EtapaInicio)
                    Salvar-Historico
                }
                Mostrar-Resultados $M
            } else {
                [void][System.Windows.Forms.MessageBox]::Show("A verificação não pôde ser concluída.`r`n`r`n$($M.Erro)", 'WinDiag', 'OK', 'Warning')
                Show-Pagina $pgInicio
            }
        }
        'repair' { Mostrar-Fim $M }
        'bench' { Mostrar-Bench $M }
        'tool' { Mostrar-Bench $M }
        'restore' {
            if ($M.Restaurado) {
                [void][System.Windows.Forms.MessageBox]::Show('Os drivers da cópia foram restaurados. Reinicie o computador para concluir.', 'WinDiag', 'OK', 'Information')
            } elseif ($M.Aviso) {
                [void][System.Windows.Forms.MessageBox]::Show([string]$M.Aviso, 'WinDiag', 'OK', 'Information')
            } else {
                [void][System.Windows.Forms.MessageBox]::Show('Nada foi restaurado.', 'WinDiag', 'OK', 'Information')
            }
            Show-Pagina $pgInicio
        }
        'unblock' {
            [void][System.Windows.Forms.MessageBox]::Show('Pronto. Reinicie o computador para concluir.', 'WinDiag', 'OK', 'Information')
            Show-Pagina $pgInicio
        }
    }
}

function Tratar-Mensagem {
    param($M)
    switch ("$($M.T)") {
        'log'     { Add-Log ([string]$M.Texto) ([string]$M.Cor) }
        'etapa'   {
            if ([int]$M.Total -gt 0) {
                $agora = 0.0
                if ($script:Relogio) { $agora = $script:Relogio.Elapsed.TotalSeconds }
                if ($script:EtapaN -gt 0 -and $script:FaseAtual -eq 'scan') { $script:TempoObs[(Get-ChaveEtapa $script:EtapaN)] = ($agora - $script:EtapaInicio) }
                $script:EtapaN = [int]$M.N
                $script:EtapaTotal = [int]$M.Total
                $script:EtapaInicio = $agora
                $lblEtapa.Text = "Passo $($M.N) de $($M.Total): $($M.Texto)"
            } else {
                $lblEtapa.Text = [string]$M.Texto
                Set-Barra -Indeterminada
                $script:ProgUlt = -1.0
            }
        }
        'prog'    {
            $agora = 0.0
            if ($script:Relogio) { $agora = $script:Relogio.Elapsed.TotalSeconds }
            $pct = [double]$M.Pct
            # Nova tarefa (percentual voltou a cair ou ficou muito tempo sem atualizar): recomeça a medição
            if ($script:ProgUlt -lt 0 -or $pct -lt ($script:ProgPct - 10) -or ($agora - $script:ProgUlt) -gt 30) {
                $script:ProgP0 = $pct
                $script:ProgT0 = $agora
            }
            $script:ProgPct = $pct
            $script:ProgUlt = $agora
        }
        'ask'     { Tratar-Ask $M }
        'confirm' { Tratar-Confirm $M }
        'fim'     { Tratar-Fim $M }
    }
}

function Finalizar-Fase {
    try { [void]$script:Ps.EndInvoke($script:Async) } catch { }
    try {
        if ($script:Ps.Streams.Error.Count -gt 0) {
            foreach ($e in $script:Ps.Streams.Error) { Registrar-Erro ("[worker] " + $e.ToString()) -Silencioso }
        }
    } catch { }
    try { $script:Ps.Dispose() } catch { }
    $script:Ps = $null
    $script:Async = $null
    if (-not $script:FimRecebido) {
        if (-not $script:Cancelando) {
            [void][System.Windows.Forms.MessageBox]::Show(
                "A etapa terminou de forma inesperada.`r`n`r`nOs detalhes foram salvos em:`r`n$($script:ArquivoErros)",
                'WinDiag', 'OK', 'Warning')
        }
        Set-Barra -Fracao 0
        Show-Pagina $pgInicio
    }
}

$script:Timer = New-Object System.Windows.Forms.Timer
$script:Timer.Interval = 100
$script:Timer.Add_Tick({
    if ($script:EmDialogo) { return }
    $script:EmDialogo = $true
    try {
        $concluido = ($script:Async -ne $null -and $script:Async.IsCompleted)
        $m = $null
        $n = 0
        while ($n -lt 400 -and $script:Sync.Fila.TryDequeue([ref]$m)) {
            $n++
            try { Tratar-Mensagem $m } catch { Registrar-Erro $_ -Silencioso }
            $m = $null
        }
        if ($script:Log.Visible -and $n -gt 0) { $script:Log.ScrollToCaret() }
        if ($script:Async -ne $null) { Atualizar-Tempos }
        if ($concluido -and $script:Sync.Fila.IsEmpty) { Finalizar-Fase }
    } catch {
        Registrar-Erro $_ -Silencioso
    } finally {
        $script:EmDialogo = $false
    }
})

# ----------------------------------------------------------------------------
# Eventos dos botões
# ----------------------------------------------------------------------------
$btnIniciar.Add_Click({
    try { Start-Fase 'scan' } catch { Registrar-Erro $_ }
})

function Iniciar-Desempenho { if (Show-EscolhaTeste) { Start-Fase 'bench' } }
$btnBench.Add_Click({ try { Iniciar-Desempenho } catch { Registrar-Erro $_ } })
$btnBenchFerr.Add_Click({ try { Iniciar-Desempenho } catch { Registrar-Erro $_ } })
function Iniciar-Ferramenta {
    param([string]$Id)
    $f = $script:ListaFerramentas | Where-Object { $_.Id -eq $Id } | Select-Object -First 1
    if (-not $f) { return }
    if ($f.Admin -and -not $script:IsAdmin) {
        [void][System.Windows.Forms.MessageBox]::Show('Esta ferramenta altera o Windows e precisa do WinDiag aberto como administrador. Feche e abra de novo aceitando o pedido de permissão.', 'WinDiag', 'OK', 'Information')
        return
    }
    if ($Id -eq 'pontos-abrir') { try { Start-Process -FilePath 'rstrui.exe' } catch { Registrar-Erro $_ -Silencioso }; return }
    $script:Opc.Ferramenta = $Id
    $script:Opc.DestinoBackup = ''
    if ($Id -eq 'agendar-ativar') {
        $script:Opc.AgendaDia = [string]$script:DiasEn[[Math]::Max(0, $cmbDia.SelectedIndex)]
        $script:Opc.AgendaHora = [string]$cmbHora.SelectedItem
    }
    if ($Id -eq 'drv-verificar') {
        $dlgA = New-Object System.Windows.Forms.OpenFileDialog
        $dlgA.Title = 'Escolha o instalador de driver que você baixou do site do fabricante'
        $dlgA.Filter = 'Instaladores (*.exe;*.msi)|*.exe;*.msi'
        try { $dlgA.InitialDirectory = (Join-Path $env:USERPROFILE 'Downloads') } catch { }
        if ($dlgA.ShowDialog() -ne 'OK') { return }
        $script:Opc.DestinoBackup = $dlgA.FileName
    }
    if ($Id -eq 'backup') {
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Escolha a pasta (ou o pen drive) onde guardar a cópia dos seus arquivos'
        if ($dlg.ShowDialog() -ne 'OK') { return }
        $script:Opc.DestinoBackup = $dlg.SelectedPath
    }
    Start-Fase 'tool'
}
foreach ($bf in @($script:BotoesFerr) + @($script:BotoesCfg)) { $bf.Add_Click({ try { Iniciar-Ferramenta ([string]$this.AccessibleName) } catch { Registrar-Erro $_ } }) }
function Atualizar-Sensores {
    # Estado dos programas de sensores (barato: só lê processos e o INI do HWiNFO).
    $es = Get-EstadoSensores
    $av = Get-AvaliacaoSensores $es
    $txt = $av.Resumo
    if ($av.Passos.Count -gt 0) { $txt += '  Próximo passo: ' + $av.Passos[0] }
    if ($script:lblSensEstado) { $script:lblSensEstado.Text = (Tr $txt); $script:lblSensEstado.BackColor = $(if ($av.Pronto) { Cor '#ECFDF5' } else { Cor '#FFFBEB' }) }
    if ($script:lblSensIni) { $script:lblSensIni.Text = $(if ($av.Pronto) { 'Sensores: ' + $av.Resumo } else { 'Sensores: ' + $av.Resumo + ' (Monitor e sensores)' }) }
}
function Atualizar-Monitor {
    $e = $null
    try { $e = Get-EstadoMonitor } catch { }
    if ($e) {
        $desde = ''
        try { $desde = ([datetime]::Parse([string]$e.Inicio, [Globalization.CultureInfo]::InvariantCulture)).ToString('dd/MM HH:mm') } catch { }
        $script:lblMonEstado.Text = (Tr ("Monitor ligado desde $desde. Pode jogar: o registro é gravado a cada $(([string]$e.Intervalo) -replace '\.', ',') s."))
    } else {
        $script:lblMonEstado.Text = (Tr 'Monitor desligado.')
    }
    try { Atualizar-Sensores } catch { }
    $btnMonIni.Enabled = (-not $e)
    $btnMonParar.Enabled = [bool]$e
    $btnMonVer.Enabled = [bool]($e -or (Get-UltimaSessaoMonitor))
}
$btnMonIni.Add_Click({
    try {
        $achou = @()
        foreach ($n in 'HWiNFO64', 'HWiNFO32', 'MSIAfterburner', 'LibreHardwareMonitor', 'OpenHardwareMonitor') { if (Get-Process -Name $n -ErrorAction SilentlyContinue) { $achou += $n } }
        $aviso = ''
        if ($achou.Count -eq 0) { $aviso = 'Nenhum programa de sensores está aberto. Abra o HWiNFO (modo "Sensors only", com "Shared Memory Support" ligado nas configurações) ou o MSI Afterburner antes de jogar; sem eles o monitor grava só o uso do processador e da memória e a temperatura da placa de vídeo (NVIDIA/AMD).' }
        $txt = "O monitor roda escondido, em segundo plano, até você desligá-lo aqui mesmo. Ele lê a cada meio segundo (0,5 s) o que o HWiNFO, o MSI Afterburner ou o LibreHardwareMonitor estiverem publicando (temperaturas, tensões da fonte, consumo, uso) e grava em um arquivo, forçando cada linha para o disco. Para o HWiNFO acompanhar esse ritmo, nas configurações dele (engrenagem da janela de sensores) deixe o intervalo de atualização em 500 ms.`r`n`r`nSe o computador desligar durante o jogo, abra o WinDiag depois e use 'Ver o último registro': ele mostra as últimas temperaturas e tensões e a provável causa. Não é instalado nada, nada vai para a internet e ele não liga sozinho junto com o Windows."
        $ok = Show-Dialogo -Titulo 'WinDiag - monitor em tempo real' -Texto $txt -Aviso $aviso -TextoSim 'Ligar o monitor' -TextoNao 'Agora não' -PadraoSim $true
        if ($ok) {
            $okIni = Start-Monitor -Pasta $PSScriptRoot -Intervalo 0.5
            if (-not $okIni) { [void][System.Windows.Forms.MessageBox]::Show((Tr 'Não consegui ligar o monitor. Tente de novo.'), 'WinDiag', 'OK', 'Warning') }
            Atualizar-Monitor
        }
    } catch { Registrar-Erro $_ }
})
$btnMonParar.Add_Click({
    try {
        [void](Stop-Monitor)
        Atualizar-Monitor
    } catch { Registrar-Erro $_ }
})
$btnMonVer.Add_Click({
    try {
        $e = Get-EstadoMonitor
        $f = if ($e) { [string]$e.Arquivo } else { Get-UltimaSessaoMonitor }
        $an = $null
        if ($f) { $an = Get-AnaliseSessao -Arquivo $f }
        $txt = Format-TextoSessao $an
        $saida = Join-Path (Get-PastaMonitor) 'ultima-sessao.txt'
        New-Item -ItemType Directory -Force -Path (Get-PastaMonitor) | Out-Null
        [IO.File]::WriteAllText($saida, $txt, (New-Object System.Text.UTF8Encoding($true)))
        Start-Process -FilePath $saida
    } catch { Registrar-Erro $_ }
})
$btnMonInv.Add_Click({
    try {
        $txt = Invoke-InvestigarTravamento
        $saida = Join-Path (Get-PastaMonitor) 'ultimo-travamento.txt'
        New-Item -ItemType Directory -Force -Path (Get-PastaMonitor) | Out-Null
        [IO.File]::WriteAllText($saida, $txt, (New-Object System.Text.UTF8Encoding($true)))
        Start-Process -FilePath $saida
    } catch { Registrar-Erro $_ }
})
$btnMemWin.Add_Click({
    try {
        $r = [System.Windows.Forms.MessageBox]::Show('O Diagnóstico de Memória do Windows vai abrir. Se você escolher reiniciar agora, o computador reinicia, testa a memória por alguns minutos (até cerca de uma hora no teste completo) e volta ao Windows. Salve seus trabalhos antes. Abrir agora?', 'WinDiag', 'YesNo', 'Question')
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\MdSched.exe') }
    } catch { Registrar-Erro $_ }
})
$btnExtOcct.Add_Click({ try { Start-Process 'https://www.ocbase.com/' } catch { Registrar-Erro $_ } })
$btnExtFur.Add_Click({ try { Start-Process 'https://geeks3d.com/furmark/' } catch { Registrar-Erro $_ } })
$btnExtMem.Add_Click({ try { Start-Process 'https://www.memtest86.com/' } catch { Registrar-Erro $_ } })
$btnFerr.Add_Click({ try { Abrir-Area 'reparos' } catch { Registrar-Erro $_ } })
$btnAreaTravou.Add_Click({ try { Abrir-Area 'travou' } catch { Registrar-Erro $_ } })
$btnAreaMonitor.Add_Click({ try { Abrir-Area 'monitor' } catch { Registrar-Erro $_ } })
$btnAreaDrivers.Add_Click({ try { Abrir-Area 'drivers' } catch { Registrar-Erro $_ } })
$btnAreaAjuda.Add_Click({ try { Abrir-Area 'ajuda' } catch { Registrar-Erro $_ } })
$btnInicio.Add_Click({
    try {
        if ($script:Async -and -not $script:Async.IsCompleted) { return }
        Show-Pagina $pgInicio
    } catch { Registrar-Erro $_ }
})
foreach ($bv in $script:BotoesVoltar) { $bv.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } }) }
$btnCfg.Add_Click({ try { Ajustar-PaginaFerr; Show-Pagina $pgCfg } catch { Registrar-Erro $_ } })
$btnCfgVoltar.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } })
$btnPdf.Add_Click({
    try {
        if (-not ($script:Res -and $script:Res.Html -and (Test-Path -LiteralPath $script:Res.Html))) { return }
        $nav = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
        if (-not $nav) { [void][System.Windows.Forms.MessageBox]::Show('Para salvar em PDF é preciso ter o Microsoft Edge ou o Google Chrome. Alternativa: abra o relatório e use Imprimir > Salvar como PDF.', 'WinDiag', 'OK', 'Information'); return }
        $pdf = [IO.Path]::ChangeExtension([string]$script:Res.Html, '.pdf')
        $url = ([Uri]([IO.Path]::GetFullPath([string]$script:Res.Html))).AbsoluteUri
        $perfil = Join-Path ([IO.Path]::GetTempPath()) 'WinDiag-pdf'
        $arg = @('--headless', '--disable-gpu', '--no-pdf-header-footer', "--user-data-dir=`"$perfil`"", "--print-to-pdf=`"$pdf`"", "`"$url`"")
        $btnPdf.Enabled = $false; $btnPdf.Text = 'Gerando...'
        $pr = Start-Process -FilePath $nav -ArgumentList $arg -PassThru -WindowStyle Hidden
        [void]$pr.WaitForExit(60000)
        try { if (-not $pr.HasExited) { $pr.Kill() } } catch { }
        $btnPdf.Enabled = $true; $btnPdf.Text = (Tr 'Salvar em PDF')
        if (Test-Path -LiteralPath $pdf) { Start-Process -FilePath $pdf } else { [void][System.Windows.Forms.MessageBox]::Show('Não consegui gerar o PDF. Abra o relatório e use Imprimir > Salvar como PDF.', 'WinDiag', 'OK', 'Information') }
    } catch { $btnPdf.Enabled = $true; $btnPdf.Text = (Tr 'Salvar em PDF'); Registrar-Erro $_ -Silencioso }
})
$btnAtualizar.Add_Click({
    try {
        $ps1 = Join-Path $PSScriptRoot 'Atualizar-WinDiag.ps1'
        if (-not (Test-Path -LiteralPath $ps1)) {
            [void][System.Windows.Forms.MessageBox]::Show('Não encontrei o Atualizar-WinDiag.ps1 ao lado do programa. Instale pelo Instalar-WinDiag.bat para ter a atualização.', 'WinDiag', 'OK', 'Information')
            return
        }
        $btnAtualizar.Enabled = $false
        $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
        $form.Refresh()
        $codigo = 1
        try {
            $arqRes = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-atu-' + [guid]::NewGuid().ToString('N') + '.txt')
            $h3 = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -File "{0}" -SoVerificar -VersaoAtual "{1}" -ArquivoSaida "{2}"' -f $ps1, $script:Versao, $arqRes)
            $pr = Start-Process -FilePath $h3.Exe -ArgumentList $h3.Args -WindowStyle Hidden -PassThru
            if (-not $pr.WaitForExit(45000)) { try { $pr.Kill() } catch { } }
            elseif (Test-Path -LiteralPath $arqRes) { try { $codigo = [int]((Get-Content -LiteralPath $arqRes -Raw).Trim()) } catch { $codigo = 1 } }
            else { $codigo = $pr.ExitCode }
            try { Remove-Item -LiteralPath $arqRes -Force -ErrorAction SilentlyContinue } catch { }
        } finally {
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnAtualizar.Enabled = $true
        }
        if ($codigo -eq 10) {
            $ok = Show-Dialogo -Titulo 'WinDiag' -Texto 'Há uma versão nova do WinDiag. Baixar e instalar agora? O WinDiag será fechado e aberto de novo sozinho, já atualizado.' -TextoSim 'Sim, atualizar' -TextoNao 'Agora não' -PadraoSim $true
            if ($ok) {
                $argsPs = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -VersaoAtual "{1}" -SemPerguntas -Reabrir' -f $ps1, $script:Versao
                Start-Process -FilePath 'powershell.exe' -ArgumentList $argsPs
                $form.Close()
            }
        } elseif ($codigo -eq 0) {
            [void][System.Windows.Forms.MessageBox]::Show("Você já está com a versão mais recente ($($script:Versao)).", 'WinDiag', 'OK', 'Information')
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Não consegui verificar agora. Confira a conexão com a internet e tente de novo.', 'WinDiag', 'OK', 'Information')
        }
    } catch { Registrar-Erro $_ -Silencioso }
})
$btnBenchDeNovo.Add_Click({ try { if (Show-EscolhaTeste) { Start-Fase 'bench' } } catch { Registrar-Erro $_ } })
$btnBenchVoltar.Add_Click({ try { Show-Pagina $pgInicio } catch { Registrar-Erro $_ } })
$btnBenchAbrir.Add_Click({
    try { if ($script:UltBenchHtml -and (Test-Path -LiteralPath $script:UltBenchHtml)) { Start-Process -FilePath $script:UltBenchHtml } } catch { Registrar-Erro $_ -Silencioso }
})

$btnDesbloq.Add_Click({
    try {
        if (-not $script:IsAdmin) {
            [void][System.Windows.Forms.MessageBox]::Show('É preciso abrir o WinDiag como administrador para desfazer os bloqueios.', 'WinDiag', 'OK', 'Information')
            return
        }
        $ok = Show-Dialogo -Titulo 'WinDiag' -Texto 'Isso remove os bloqueios de atualização de driver que o WinDiag criou (por exemplo, para proteger o driver da placa de vídeo). Depois disso, o Windows Update e os instaladores dos fabricantes voltam a poder instalar drivers nesses dispositivos. Continuar?' -TextoSim 'Sim, remover' -TextoNao 'Cancelar' -PadraoSim $false
        if ($ok) { Start-Fase 'unblock' }
    } catch { Registrar-Erro $_ }
})

$btnDet.Add_Click({ try { Alternar-Detalhes (-not $script:Log.Visible) } catch { Registrar-Erro $_ -Silencioso } })

$btnCancel.Add_Click({
    try {
        if (-not ($script:Async -and -not $script:Async.IsCompleted)) { return }
        if ($script:FaseAtual -eq 'repair') {
            # Interromper o DISM, o SFC ou um driver no meio pode danificar o Windows: espera a correção atual terminar.
            $ok = Show-Dialogo -Titulo 'WinDiag' -Texto "O WinDiag vai terminar a correção que está em andamento (interrompê-la no meio poderia danificar o Windows) e não fará as próximas.`r`n`r`nIsso pode levar alguns minutos. Parar depois desta correção?" -TextoSim 'Sim, parar depois desta' -TextoNao 'Continuar corrigindo' -PadraoSim $false
            if ($ok) {
                $script:Sync.Cancelar = $true
                $btnCancel.Enabled = $false
                $lblEtapa.Text = 'Terminando a correção atual...'
                $lblDica.Text = 'Aguarde: a correção que já começou precisa terminar com segurança. As próximas não serão feitas.'
            }
            return
        }
        $txtC = 'Cancelar a verificação? Nada foi alterado no seu computador.'
        if ($script:FaseAtual -eq 'bench') { $txtC = 'Cancelar o teste de desempenho? Nada foi alterado no seu computador.' }
        $ok = Show-Dialogo -Titulo 'WinDiag' -Texto $txtC -TextoSim 'Sim, cancelar' -TextoNao 'Continuar' -PadraoSim $false
        if ($ok -and $script:Ps) {
            $script:Cancelando = $true
            $lblEtapa.Text = (Tr 'Cancelando...')
            [void]$script:Ps.BeginStop($null, $null)
        }
    } catch { Registrar-Erro $_ }
})

$chkInfo.Add_CheckedChanged({ try { if (-not $script:AtualizandoFiltro) { Atualizar-Filtro; Montar-Cards } } catch { Registrar-Erro $_ -Silencioso } })
$cmbCat.Add_SelectedIndexChanged({ try { if (-not $script:AtualizandoFiltro) { Montar-Cards } } catch { Registrar-Erro $_ -Silencioso } })

$btnCorrigir.Add_Click({
    try {
        # Passo 1: a escolha mais importante, com as duas opções lado a lado e destacadas.
        $txt1 = "ATENÇÃO: existem 2 formas de fazer as correções. Escolha uma:`r`n`r`n1) CORRIGIR TUDO AUTOMATICAMENTE`r`nO WinDiag faz todas as correções sozinho, sem perguntar nada (cria antes um ponto de restauração e uma cópia dos drivers). Drivers internos do sistema são sempre pulados, por segurança.`r`n`r`n2) ESCOLHER UMA A UMA`r`nO WinDiag mostra cada correção e você decide Sim ou Não em cada uma."
        $auto = Show-Dialogo -Titulo 'WinDiag - ESCOLHA COMO CORRIGIR' -Texto $txt1 -Aviso 'Clique no botão da forma que você quer. Se tiver dúvida, escolha "Escolher uma a uma".' -TextoSim '1) Corrigir tudo automaticamente' -TextoNao '2) Escolher uma a uma' -PadraoSim $false
        $script:ModoAuto = [bool]$auto
        # Passo 2: confirmação final, que também permite voltar sem corrigir nada.
        $modo = 'uma a uma, perguntando em cada correção'
        if ($script:ModoAuto) { $modo = 'automaticamente, sem perguntar' }
        $txt2 = "Você escolheu corrigir $modo.`r`n`r`nSalve os trabalhos abertos: algumas correções podem pedir para reiniciar o computador.`r`n`r`nDica: se tem arquivos importantes, faça uma cópia antes (Ferramentas de reparo e restauração > Copiar meus arquivos pessoais).`r`n`r`nIniciar as correções agora?"
        $ok = Show-Dialogo -Titulo 'WinDiag - confirmar' -Texto $txt2 -TextoSim 'Iniciar as correções' -TextoNao 'Voltar sem corrigir' -PadraoSim $false
        if ($ok) { Start-Fase 'repair' } else { $script:ModoAuto = $false }
    } catch { Registrar-Erro $_ }
})

$btnRelatorio.Add_Click({
    try {
        if ($script:Res -and $script:Res.Html -and (Test-Path -LiteralPath $script:Res.Html)) { Start-Process -FilePath $script:Res.Html }
    } catch { Registrar-Erro $_ -Silencioso }
})

$btnPasta.Add_Click({
    try {
        if ($script:Res -and $script:Res.Pasta -and (Test-Path -LiteralPath $script:Res.Pasta)) { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $script:Res.Pasta) }
    } catch { Registrar-Erro $_ -Silencioso }
})

$btnNova.Add_Click({ try { Start-Fase 'scan' } catch { Registrar-Erro $_ } })
$btnReiniciar.Add_Click({ try { Iniciar-Ferramenta 'reiniciar-pc' } catch { Registrar-Erro $_ } })
$btnVerif2.Add_Click({ try { Start-Fase 'scan' } catch { Registrar-Erro $_ } })
$btnSair.Add_Click({ $script:Form.Close() })
$btnSair2.Add_Click({ $script:Form.Close() })

$btnReiniciar.Add_Click({ try { Confirmar-Reinicio } catch { Registrar-Erro $_ } })
$btnDesfazer.Add_Click({ try { Iniciar-Desfazer } catch { Registrar-Erro $_ } })
$btnDesfazer2.Add_Click({ try { Iniciar-Desfazer } catch { Registrar-Erro $_ } })

# Atalho com o ícone do escudo: criado sozinho na primeira abertura (e de novo se a pasta do WinDiag mudar de lugar)
function Initialize-Atalho {
    param([switch]$Forcar)
    try {
        $script = Join-Path $PSScriptRoot 'Criar-Atalho.ps1'
        if (-not (Test-Path -LiteralPath $script)) { return $false }
        $marca = Join-Path $script:PastaDados 'atalho.txt'
        if (-not $Forcar -and (Test-Path -LiteralPath $marca)) {
            $ant = (Get-Content -LiteralPath $marca -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ("$ant" -eq $PSScriptRoot) { return $true }
        }
        $ok = & $script -SemPerguntas -Silencioso
        if ($ok -eq $true) {
            New-Item -ItemType Directory -Force -Path $script:PastaDados -ErrorAction SilentlyContinue | Out-Null
            Set-Content -LiteralPath $marca -Value $PSScriptRoot -Encoding UTF8
            return $true
        }
    } catch { Registrar-Erro $_ -Silencioso }
    return $false
}
$form.Add_Shown({ try { [void](Initialize-Atalho) } catch { } })
$btnAtalho.Add_Click({
    try {
        if (Initialize-Atalho -Forcar) {
            [void][System.Windows.Forms.MessageBox]::Show('Atalho criado na Área de Trabalho e no Menu Iniciar.', 'WinDiag', 'OK', 'Information')
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('Não foi possível criar o atalho. Os detalhes foram salvos no log de erros.', 'WinDiag', 'OK', 'Warning')
        }
    } catch { Registrar-Erro $_ }
})

# Atalhos de teclado: Ctrl+1/2/3 trocam de aba, F5 verifica de novo, F1 mostra a ajuda
function Mostrar-AjudaTeclas {
    $linhas = @(
        'Atalhos de teclado',
        '',
        'Tab / Shift+Tab: passa de um botão para outro',
        'Enter ou Espaço: aciona o botão selecionado',
        'Ctrl+1, Ctrl+2, Ctrl+3: abas Problemas, Meu computador e Detalhes',
        'F5: verifica o computador de novo',
        'Esc: fecha as caixas de diálogo',
        'F1: esta ajuda'
    )
    [void][System.Windows.Forms.MessageBox]::Show(($linhas -join "`r`n"), 'WinDiag - atalhos', 'OK', 'Information')
}
$form.KeyPreview = $true
$form.Add_KeyDown({
    param($remetente, $ev)
    try {
        if ($script:EmDialogo) { return }
        $K = [System.Windows.Forms.Keys]
        if ($ev.KeyCode -eq $K::F1) { $ev.Handled = $true; Mostrar-AjudaTeclas; return }
        $emResultados = ($pgRes.Visible)
        if ($ev.Control -and $emResultados) {
            $aba = -1
            if ($ev.KeyCode -eq $K::D1 -or $ev.KeyCode -eq $K::NumPad1) { $aba = 0 }
            elseif ($ev.KeyCode -eq $K::D2 -or $ev.KeyCode -eq $K::NumPad2) { $aba = 1 }
            elseif ($ev.KeyCode -eq $K::D3 -or $ev.KeyCode -eq $K::NumPad3) { $aba = 2 }
            if ($aba -ge 0) { $ev.Handled = $true; Show-Aba $aba; return }
        }
        if ($ev.KeyCode -eq $K::F5 -and ($pgRes.Visible -or $pgInicio.Visible -or $pgFim.Visible)) {
            $ev.Handled = $true
            Start-Fase 'scan'
        }
    } catch { Registrar-Erro $_ -Silencioso }
})

# Reajuste dos cartões quando a janela muda de tamanho
$script:TimerResize = New-Object System.Windows.Forms.Timer
$script:TimerResize.Interval = 250
$script:TimerResize.Add_Tick({
    $script:TimerResize.Stop()
    try {
        if ($script:Res -and [Math]::Abs($flowCards.ClientSize.Width - $script:LarguraCards) -gt (PX 20)) { Montar-Cards }
        if ($null -ne $script:DadosPC -and $script:AbaAtual -eq 1) { Montar-PC -SePrecisar }
    } catch { }
})
$flowCards.Add_SizeChanged({ $script:TimerResize.Stop(); $script:TimerResize.Start() })
$form.Add_SizeChanged({ try { Ajustar-Margens; Ajustar-Barra $barraRes; Ajustar-Barra $barraFim } catch { } })
$form.Add_ResizeEnd({ try { Ajustar-Margens; Ajustar-Barra $barraRes; Ajustar-Barra $barraFim; $form.Invalidate($true) } catch { } })
$pnlPC.Add_SizeChanged({ $script:TimerResize.Stop(); $script:TimerResize.Start() })

# Fechar a janela
$form.Add_FormClosing({
    param($remetente, $e)
    if ($script:Async -and -not $script:Async.IsCompleted) {
        $msg = 'Há uma operação em andamento. Fechar agora pode deixar uma correção pela metade. Fechar mesmo assim?'
        $r = [System.Windows.Forms.MessageBox]::Show($msg, 'WinDiag', 'YesNo', 'Warning', 'Button2')
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { $e.Cancel = $true }
    }
})
$form.Add_FormClosed({
    try { $script:Timer.Stop() } catch { }
    [Environment]::Exit(0)
})

try {
    [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
    [System.Windows.Forms.Application]::add_ThreadException({ param($s, $e) Registrar-Erro $e.Exception })
} catch { }

$form.Add_Shown({ Reposicionar })

# ----------------------------------------------------------------------------
# Início
# ----------------------------------------------------------------------------
try {
    Traduzir-Controles $form
    Show-Pagina $pgInicio
    $script:Timer.Start()
    if ($env:WINDIAG_GUI_FUMACA -eq '1') {
        # Teste de fumaça (usado na integração contínua, no Windows PowerShell 5.1): monta a janela, as telas e os cartões com dados
        # de exemplo e sai com código 0 (tudo certo) ou 1 (alguma etapa falhou). Não altera o computador nem os atalhos.
        $falhasF = New-Object System.Collections.Generic.List[string]
        function Test-EtapaF { param([string]$Nome, [scriptblock]$Corpo)
            try { $r = & $Corpo; if ($r -eq $false) { $falhasF.Add("FALHA: $Nome"); Write-Host "FALHA  $Nome" } else { Write-Host "OK     $Nome" } }
            catch { $falhasF.Add("ERRO: $Nome -> $($_.Exception.Message)"); Write-Host "ERRO   $Nome -> $($_.Exception.Message)" }
        }
        function Find-LabelF { param($Pai, [string]$Trecho) foreach ($c in $Pai.Controls) { if ($c -is [System.Windows.Forms.Label] -and "$($c.Text)" -like "*$Trecho*") { return $true }; if ($c.Controls.Count -gt 0 -and (Find-LabelF $c $Trecho)) { return $true } }; return $false }
        Test-EtapaF 'janela abre' { $form.Show(); [System.Windows.Forms.Application]::DoEvents(); Reposicionar; $form.Visible }
        Test-EtapaF 'barra lateral da tela inicial com dados reais' {
            $script:DadosPcIni = @(Get-ResumoPcRapido); Montar-PcInicio 'dados'
            ($script:DadosPcIni.Count -gt 0) -and ($fluxoLado.Controls.Count -gt 3) -and -not (Find-LabelF $fluxoLado 'Não foi possível')
        }
        Test-EtapaF 'resultados com cartões de exemplo' {
            $li = New-Object System.Collections.Generic.List[object]; $li.Add(@{ R = 'Processador'; V = 'teste'; Nivel = 'ok' }); $li.Add(@{ R = 'Vídeo'; V = 'teste 2'; Nivel = 'aviso' })
            $lb = New-Object System.Collections.Generic.List[object]; $lb.Add(@{ Rotulo = 'C:'; Texto = '10 GB livres de 100 GB'; Fracao = 0.9; Nivel = 'perigo' })
            $s1 = @{ Chave = 'pc'; Titulo = 'Computador'; Destaque = 'PC de teste'; Sub = 'Windows'; Itens = $li; Barras = $lb }
            $s2 = @{ Chave = 'drivers'; Titulo = 'Drivers'; Destaque = 'Tudo em ordem'; Sub = ''; Itens = (New-Object System.Collections.Generic.List[object]); Barras = (New-Object System.Collections.Generic.List[object]) }
            $a1 = [pscustomobject]@{ Gravidade = 'Atencao'; Categoria = 'Drivers'; Titulo = 'Aviso de teste'; Detalhe = 'detalhe'; Solucao = 'solução'; Links = @(); Explicacao = 'explicação'; Veredito = 'Depende'; Reparo = 'Manual' }
            $a2 = [pscustomobject]@{ Gravidade = 'Info'; Categoria = 'Sistema'; Titulo = 'Informativo de teste'; Detalhe = 'detalhe'; Solucao = ''; Links = @(); Explicacao = ''; Veredito = ''; Reparo = 'Manual' }
            $R = @{ Ok = $true; Achados = @($a1, $a2); NAcoes = 0; NDesfaz = 0; ResumoPC = 'resumo'; PC = @($s1, $s2); Comparacao = ''; NotaTexto = ''; NotaValor = -1; NotaRotulo = ''; Html = $null; Pasta = $null }
            Mostrar-Resultados $R; [System.Windows.Forms.Application]::DoEvents(); $true
        }
        Test-EtapaF 'aba Meu computador (listas List[object])' { Show-Aba 1; [System.Windows.Forms.Application]::DoEvents(); ($pnlPC.Controls.Count -gt 0) -and -not (Find-LabelF $pnlPC 'não foi possível mostrar') }
        Test-EtapaF 'abas Problemas e Detalhes' { Show-Aba 0; Show-Aba 2; Show-Aba 0; $true }
        foreach ($ar in $script:AreasFerr) { $idA = $ar.Id; Test-EtapaF "área de ferramentas: $idA" { Abrir-Area $idA; [System.Windows.Forms.Application]::DoEvents(); $true } }
        Test-EtapaF 'configurações' { Show-Pagina $pgCfg; [System.Windows.Forms.Application]::DoEvents(); $true }
        Test-EtapaF 'volta à tela inicial' { Show-Pagina $pgInicio; Reposicionar; $true }
        $form.Close()
        $codigoF = $(if ($falhasF.Count -eq 0) { 0 } else { 1 })
        Write-Host ("FUMACA: {0} falha(s)" -f $falhasF.Count)
        [Environment]::Exit($codigoF)
    }
    $form.Add_Shown({ try { Start-LeituraPcInicio; Update-IconeAtalhos } catch { } })
    [System.Windows.Forms.Application]::Run($form)
} catch {
    Registrar-Erro $_
}
