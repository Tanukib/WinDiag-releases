﻿# WinDiag-Bench.ps1
# Testes de desempenho e saúde: processador, memória RAM, disco e placa de vídeo.
# Carregado pelo WinDiag-Worker.ps1. As funções devolvem tabelas (hashtables) simples; quem chama decide como exibir.
# Honestidade: estes testes dão uma boa indicação, mas NÃO substituem MemTest86 (memória) nem testes longos de estresse.

if (-not ('WDBench' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

public static class WDBench
{
    public static ulong Sink;

    // Roda "seconds" segundos de cálculo em "threads" threads e devolve quantos blocos de trabalho cada segundo concluiu.
    public static long[] Cpu(int seconds, int threads)
    {
        long[] b = new long[seconds];
        Stopwatch sw = Stopwatch.StartNew();
        Thread[] t = new Thread[threads];
        for (int i = 0; i < threads; i++)
        {
            int id = i;
            t[i] = new Thread(delegate ()
            {
                ulong x = 88172645463325252UL + (ulong)id;
                double d = 1.0001;
                while (true)
                {
                    long s = sw.ElapsedMilliseconds / 1000;
                    if (s >= seconds) break;
                    for (int k = 0; k < 100000; k++)
                    {
                        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                        d = d * 1.0000001 + (x & 255) * 1e-9;
                        if (d > 1e6) d = 1.0001;
                    }
                    Interlocked.Add(ref b[s], 1L);
                }
                Sink ^= x ^ (ulong)d;
            });
            t[i].IsBackground = true;
            t[i].Start();
        }
        for (int i = 0; i < threads; i++) t[i].Join();
        return b;
    }
}

public class WDRamTest
{
    List<ulong[]> chunks = new List<ulong[]>();
    const int ChunkElems = 8 * 1024 * 1024;   // 64 MB por bloco
    public int Threads = 1;
    public volatile bool Cancelar;
    public int Blocos { get { return chunks.Count; } }
    public long MBAlocados { get { return (long)chunks.Count * 64; } }
    public double WriteMBs, ReadMBs, CopyMBs;

    public int Alocar(int mb)
    {
        int n = Math.Max(1, mb / 64);
        for (int i = 0; i < n; i++)
        {
            try { chunks.Add(new ulong[ChunkElems]); }
            catch (OutOfMemoryException) { break; }
        }
        return chunks.Count;
    }

    // Valor esperado na posição idx para cada padrão:
    // 0 zeros, 1 uns, 2 1010.., 3 0101.., 4 endereço (hash), 5 um bit andando, 6 um bit andando invertido, 7 pseudoaleatório
    static ulong Val(int p, ulong idx)
    {
        switch (p)
        {
            case 0: return 0UL;
            case 1: return ulong.MaxValue;
            case 2: return 0xAAAAAAAAAAAAAAAAUL;
            case 3: return 0x5555555555555555UL;
            case 4: return (idx + 1UL) * 0x9E3779B97F4A7C15UL;
            case 5: return 1UL << (int)(idx & 63UL);
            case 6: return ~(1UL << (int)(idx & 63UL));
            default:
                ulong x = idx * 0x2545F4914F6CDD1DUL + 0x9E3779B97F4A7C15UL;
                x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                return x;
        }
    }

    // Executa "acao" (índice do bloco) em vários threads, cada um com os seus blocos.
    void Paralelo(Action<int> acao)
    {
        int nt = Math.Max(1, Math.Min(Threads, chunks.Count));
        Thread[] t = new Thread[nt];
        for (int k = 0; k < nt; k++)
        {
            int id = k;
            t[k] = new Thread(delegate ()
            {
                for (int c = id; c < chunks.Count; c += nt)
                {
                    if (Cancelar) break;
                    acao(c);
                }
            });
            t[k].IsBackground = true;
            t[k].Start();
        }
        for (int k = 0; k < nt; k++) t[k].Join();
    }

    long ErrosTot;

    void Escrever(int p)
    {
        Paralelo(delegate (int c)
        {
            ulong[] a = chunks[c]; ulong b = (ulong)c * (ulong)ChunkElems;
            for (int i = 0; i < a.Length; i++) a[i] = Val(p, b + (ulong)i);
        });
    }

    void Conferir_(int p)
    {
        Paralelo(delegate (int c)
        {
            ulong[] a = chunks[c]; ulong b = (ulong)c * (ulong)ChunkElems; long e = 0;
            for (int i = 0; i < a.Length; i++) if (a[i] != Val(p, b + (ulong)i)) e++;
            if (e > 0) Interlocked.Add(ref ErrosTot, e);
        });
    }

    // Escreve o padrão em toda a memória alocada e confere. Devolve o número de posições com erro.
    public long Padrao(int p, bool medir)
    {
        ErrosTot = 0;
        Stopwatch sw = Stopwatch.StartNew();
        Escrever(p);
        double tw = sw.Elapsed.TotalSeconds;
        sw.Restart();
        Conferir_(p);
        double tr = sw.Elapsed.TotalSeconds;
        if (medir && tw > 0 && tr > 0)
        {
            double mb = (double)chunks.Count * 64;
            WriteMBs = mb / tw; ReadMBs = mb / tr;
        }
        return ErrosTot;
    }

    // Só confere (sem reescrever): usado depois de uma espera, para achar células que perderam o valor.
    public long Conferir(int p) { ErrosTot = 0; Conferir_(p); return ErrosTot; }

    // "Inversão em movimento": confere o padrão, grava o inverso; depois confere o inverso e regrava o original.
    public long Inversao(int p)
    {
        ErrosTot = 0;
        Paralelo(delegate (int c)
        {
            ulong[] a = chunks[c]; ulong b = (ulong)c * (ulong)ChunkElems; long e = 0;
            for (int i = 0; i < a.Length; i++) { ulong v = Val(p, b + (ulong)i); if (a[i] != v) e++; a[i] = ~v; }
            if (e > 0) Interlocked.Add(ref ErrosTot, e);
        });
        Paralelo(delegate (int c)
        {
            ulong[] a = chunks[c]; ulong b = (ulong)c * (ulong)ChunkElems; long e = 0;
            for (int i = a.Length - 1; i >= 0; i--) { ulong v = Val(p, b + (ulong)i); if (a[i] != ~v) e++; a[i] = v; }
            if (e > 0) Interlocked.Add(ref ErrosTot, e);
        });
        return ErrosTot;
    }

    public void Copia()
    {
        if (chunks.Count < 2) return;
        Stopwatch sw = Stopwatch.StartNew();
        int rep = 4;
        for (int r = 0; r < rep; r++) Buffer.BlockCopy(chunks[0], 0, chunks[1], 0, ChunkElems * 8);
        double t = sw.Elapsed.TotalSeconds;
        if (t > 0) CopyMBs = (64.0 * rep) / t;
    }

    public void Liberar() { chunks.Clear(); GC.Collect(); }
}

public static class WDDisk
{
    public static double WriteMBs, ReadMBs, Iops, LatMs;
    public static long Erros;
    public static volatile bool Cancelar;
    const int Bloco = 1024 * 1024;

    public static double ReadQMBs, IopsQ;

    // Leitura sequencial com fila: vários leitores ao mesmo tempo, cada um numa região do arquivo.
    public static void LeituraFila(string arq, int mb, int threads, bool sembuffer)
    {
        int por = Math.Max(1, mb / threads);
        long total = 0;
        Stopwatch sw = Stopwatch.StartNew();
        Thread[] t = new Thread[threads];
        for (int k = 0; k < threads; k++)
        {
            int id = k;
            t[k] = new Thread(delegate ()
            {
                int d; System.Runtime.InteropServices.GCHandle h;
                byte[] buf = Alinhado(Bloco, out d, out h);
                try
                {
                    using (FileStream f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, Opc(sembuffer, true)))
                    {
                        f.Seek((long)id * por * (long)Bloco, SeekOrigin.Begin);
                        for (int i = 0; i < por; i++)
                        {
                            if (Cancelar) break;
                            int n = f.Read(buf, d, Bloco);
                            if (n <= 0) break;
                            Interlocked.Add(ref total, (long)n);
                        }
                    }
                }
                finally { h.Free(); }
            });
            t[k].IsBackground = true;
            t[k].Start();
        }
        for (int k = 0; k < threads; k++) t[k].Join();
        double s = sw.Elapsed.TotalSeconds;
        if (s > 0) ReadQMBs = (total / 1048576.0) / s;
    }

    // Leituras aleatórias de 4 KB com fila (várias ao mesmo tempo, como programas e jogos carregando): IOPS.
    public static void AleatoriaFila(string arq, int mb, int segundos, int threads, bool sembuffer)
    {
        long n = 0;
        long blocos = (long)mb * 256;
        Stopwatch sw = Stopwatch.StartNew();
        Thread[] t = new Thread[threads];
        for (int k = 0; k < threads; k++)
        {
            int id = k;
            t[k] = new Thread(delegate ()
            {
                int d; System.Runtime.InteropServices.GCHandle h;
                byte[] buf = Alinhado(4096, out d, out h);
                try
                {
                    Random rnd = new Random(1000 + id);
                    using (FileStream f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, Opc(sembuffer, false)))
                    {
                        while (sw.Elapsed.TotalSeconds < segundos)
                        {
                            if (Cancelar) break;
                            f.Seek((long)(rnd.NextDouble() * blocos) * 4096L, SeekOrigin.Begin);
                            f.Read(buf, d, 4096);
                            Interlocked.Increment(ref n);
                        }
                    }
                }
                finally { h.Free(); }
            });
            t[k].IsBackground = true;
            t[k].Start();
        }
        for (int k = 0; k < threads; k++) t[k].Join();
        double s = sw.Elapsed.TotalSeconds;
        if (s > 0 && n > 0) IopsQ = n / s;
    }

    static FileOptions Opc(bool sembuffer, bool seq)
    {
        FileOptions o = seq ? FileOptions.SequentialScan : FileOptions.RandomAccess;
        if (sembuffer) o = o | (FileOptions)0x20000000 | FileOptions.WriteThrough;   // FILE_FLAG_NO_BUFFERING: ignora o cache do Windows
        return o;
    }

    // Buffer alinhado em 4096 bytes (exigido pelo modo sem cache).
    static byte[] Alinhado(int tam, out int desloc, out System.Runtime.InteropServices.GCHandle h)
    {
        byte[] raw = new byte[tam + 4096];
        h = System.Runtime.InteropServices.GCHandle.Alloc(raw, System.Runtime.InteropServices.GCHandleType.Pinned);
        long end = h.AddrOfPinnedObject().ToInt64();
        desloc = (int)((4096 - (end % 4096)) % 4096);
        return raw;
    }

    public static void Escrita(string arq, int mb, bool sembuffer)
    {
        int d; System.Runtime.InteropServices.GCHandle h;
        byte[] buf = Alinhado(Bloco, out d, out h);
        try
        {
            Random rnd = new Random(12345);
            byte[] fonte = new byte[Bloco]; rnd.NextBytes(fonte);   // dados que não comprimem
            Stopwatch sw = Stopwatch.StartNew();
            using (FileStream f = new FileStream(arq, FileMode.Create, FileAccess.Write, FileShare.None, 4096, Opc(sembuffer, true)))
            {
                for (int i = 0; i < mb; i++)
                {
                    if (Cancelar) break;
                    Buffer.BlockCopy(fonte, 0, buf, d, Bloco);
                    BitConverter.GetBytes((long)i).CopyTo(buf, d);
                    f.Write(buf, d, Bloco);
                }
                f.Flush(true);
            }
            double t = sw.Elapsed.TotalSeconds;
            if (t > 0) WriteMBs = mb / t;
        }
        finally { h.Free(); }
    }

    public static void Leitura(string arq, int mb, bool sembuffer)
    {
        int d; System.Runtime.InteropServices.GCHandle h;
        byte[] buf = Alinhado(Bloco, out d, out h);
        Erros = 0;
        try
        {
            Random rnd = new Random(12345);
            byte[] fonte = new byte[Bloco]; rnd.NextBytes(fonte);
            Stopwatch sw = Stopwatch.StartNew();
            using (FileStream f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.None, 4096, Opc(sembuffer, true)))
            {
                for (int i = 0; i < mb; i++)
                {
                    if (Cancelar) break;
                    int n = f.Read(buf, d, Bloco);
                    if (n != Bloco) { Erros++; break; }
                    if (BitConverter.ToInt64(buf, d) != i) Erros++;
                    // confere amostras espalhadas do bloco (conferir tudo limitaria a velocidade medida)
                    for (int k = 8; k < Bloco; k += 4099) if (buf[d + k] != fonte[k]) { Erros++; break; }
                }
            }
            double t = sw.Elapsed.TotalSeconds;
            if (t > 0) ReadMBs = mb / t;
        }
        finally { h.Free(); }
    }

    // Leituras aleatórias de 4 KB, uma de cada vez (como o sistema abrindo programas): IOPS e latência média.
    public static void Aleatoria(string arq, int mb, int segundos, bool sembuffer)
    {
        int d; System.Runtime.InteropServices.GCHandle h;
        byte[] buf = Alinhado(4096, out d, out h);
        try
        {
            Random rnd = new Random(99);
            long blocos = (long)mb * 256;   // blocos de 4 KB
            long n = 0;
            Stopwatch sw = Stopwatch.StartNew();
            using (FileStream f = new FileStream(arq, FileMode.Open, FileAccess.Read, FileShare.None, 4096, Opc(sembuffer, false)))
            {
                while (sw.Elapsed.TotalSeconds < segundos)
                {
                    if (Cancelar) break;
                    long pos = (long)(rnd.NextDouble() * blocos) * 4096L;
                    f.Seek(pos, SeekOrigin.Begin);
                    f.Read(buf, d, 4096);
                    n++;
                }
            }
            double t = sw.Elapsed.TotalSeconds;
            if (t > 0 && n > 0) { Iops = n / t; LatMs = (t * 1000.0) / n; }
        }
        finally { h.Free(); }
    }
}

public static class WDSensores
{
    // Lê a memória compartilhada do HWiNFO (formato público "HWiNFO_SENS_SM2"). Devolve linhas {tipo, sensor, rótulo, unidade, valor, mínimo, máximo}
    // com tipo 1=temperatura 2=tensão 3=ventoinha 4=corrente 5=potência 6=clock 7=uso 8=outro; ou null se o HWiNFO não estiver compartilhando.
    static string Texto(byte[] b, int off, int len)
    {
        int n = 0;
        while (n < len && off + n < b.Length && b[off + n] != 0) n++;
        return System.Text.Encoding.Default.GetString(b, off, n).Trim();
    }

    public static List<string[]> LerBytes(byte[] b)
    {
        if (b == null || b.Length < 44) return null;
        if (BitConverter.ToUInt32(b, 0) != 0x53695748u) return null;   // "HWiS"
        long offS = BitConverter.ToUInt32(b, 20), tamS = BitConverter.ToUInt32(b, 24), nS = BitConverter.ToUInt32(b, 28);
        long offR = BitConverter.ToUInt32(b, 32), tamR = BitConverter.ToUInt32(b, 36), nR = BitConverter.ToUInt32(b, 40);
        if (tamS < 264 || tamR < 316 || nS > 5000 || nR > 20000) return null;
        if (offS + nS * tamS > b.Length || offR + nR * tamR > b.Length) return null;
        string[] nomes = new string[nS];
        for (int i = 0; i < nS; i++)
        {
            int o = (int)(offS + i * tamS);
            string u = Texto(b, o + 136, 128);
            nomes[i] = u.Length > 0 ? u : Texto(b, o + 8, 128);
        }
        List<string[]> r = new List<string[]>();
        for (int i = 0; i < nR; i++)
        {
            int o = (int)(offR + i * tamR);
            uint tipo = BitConverter.ToUInt32(b, o);
            uint idx = BitConverter.ToUInt32(b, o + 4);
            string rot = Texto(b, o + 140, 128);
            if (rot.Length == 0) rot = Texto(b, o + 12, 128);
            string un = Texto(b, o + 268, 16);
            double v = BitConverter.ToDouble(b, o + 284), mn = BitConverter.ToDouble(b, o + 292), mx = BitConverter.ToDouble(b, o + 300);
            if (double.IsNaN(v) || double.IsInfinity(v)) continue;
            string sensor = idx < nS ? nomes[idx] : "";
            r.Add(new string[] { tipo.ToString(), sensor, rot, un,
                v.ToString("R", System.Globalization.CultureInfo.InvariantCulture),
                mn.ToString("R", System.Globalization.CultureInfo.InvariantCulture),
                mx.ToString("R", System.Globalization.CultureInfo.InvariantCulture) });
        }
        return r;
    }

    public static List<string[]> LerHWiNFO()
    {
        string[] nomes = new string[] { "Global\\HWiNFO_SENS_SM2", "HWiNFO_SENS_SM2" };
        foreach (string nome in nomes)
        {
            try
            {
                using (System.IO.MemoryMappedFiles.MemoryMappedFile mmf = System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(nome, System.IO.MemoryMappedFiles.MemoryMappedFileRights.Read))
                using (System.IO.MemoryMappedFiles.MemoryMappedViewAccessor acc = mmf.CreateViewAccessor(0, 0, System.IO.MemoryMappedFiles.MemoryMappedFileAccess.Read))
                {
                    byte[] h = new byte[44];
                    acc.ReadArray(0, h, 0, 44);
                    if (BitConverter.ToUInt32(h, 0) != 0x53695748u) continue;
                    long total = Math.Max(BitConverter.ToUInt32(h, 20) + (long)BitConverter.ToUInt32(h, 24) * BitConverter.ToUInt32(h, 28),
                                          BitConverter.ToUInt32(h, 32) + (long)BitConverter.ToUInt32(h, 36) * BitConverter.ToUInt32(h, 40));
                    if (total < 44 || total > 16 * 1024 * 1024) continue;
                    byte[] all = new byte[total];
                    acc.ReadArray(0, all, 0, (int)total);
                    List<string[]> r = LerBytes(all);
                    if (r != null) return r;
                }
            }
            catch (Exception) { }
        }
        return null;
    }
}

public static class WDAmdAdl
{
    // Lê os sensores da placa AMD pela biblioteca que o próprio driver instala (atiadlxx.dll): a mesma fonte do AMD Software.
    // Devolve 512 inteiros (pares "suportado, valor" de 256 sensores) ou null se não houver placa/driver AMD.
    [System.Runtime.InteropServices.UnmanagedFunctionPointer(System.Runtime.InteropServices.CallingConvention.StdCall)]
    delegate IntPtr AllocCb(int tam);
    static IntPtr Aloca(int tam) { return System.Runtime.InteropServices.Marshal.AllocHGlobal(tam); }

    [System.Runtime.InteropServices.DllImport("atiadlxx.dll")] static extern int ADL2_Main_Control_Create(AllocCb cb, int enumConectados, ref IntPtr ctx);
    [System.Runtime.InteropServices.DllImport("atiadlxx.dll")] static extern int ADL2_Main_Control_Destroy(IntPtr ctx);
    [System.Runtime.InteropServices.DllImport("atiadlxx.dll")] static extern int ADL2_Adapter_NumberOfAdapters_Get(IntPtr ctx, ref int n);
    [System.Runtime.InteropServices.DllImport("atiadlxx.dll")] static extern int ADL2_New_QueryPMLogData_Get(IntPtr ctx, int adaptador, IntPtr saida);

    public static int[] Ler()
    {
        IntPtr ctx = IntPtr.Zero;
        AllocCb cb = Aloca;
        try
        {
            if (ADL2_Main_Control_Create(cb, 1, ref ctx) != 0) return null;
            int n = 0;
            if (ADL2_Adapter_NumberOfAdapters_Get(ctx, ref n) != 0 || n <= 0) return null;
            const int tam = 4 + 256 * 8;
            IntPtr buf = System.Runtime.InteropServices.Marshal.AllocHGlobal(tam);
            try
            {
                for (int i = 0; i < n && i < 64; i++)
                {
                    for (int k = 0; k < tam; k += 4) System.Runtime.InteropServices.Marshal.WriteInt32(buf, k, 0);
                    System.Runtime.InteropServices.Marshal.WriteInt32(buf, 0, tam);
                    if (ADL2_New_QueryPMLogData_Get(ctx, i, buf) != 0) continue;
                    int[] r = new int[512];
                    for (int k = 0; k < 512; k++) r[k] = System.Runtime.InteropServices.Marshal.ReadInt32(buf, 4 + 4 * k);
                    if (r[14] == 1 && r[15] > 0) return r;   // sensor 7 (temperatura de borda) suportado
                }
            }
            finally { System.Runtime.InteropServices.Marshal.FreeHGlobal(buf); }
            return null;
        }
        catch (Exception) { return null; }
        finally
        {
            if (ctx != IntPtr.Zero) { try { ADL2_Main_Control_Destroy(ctx); } catch (Exception) { } }
            GC.KeepAlive(cb);
        }
    }
}

public static class WDCarga
{
    static volatile bool parar;
    static Thread[] ts;
    public static ulong Sink;
    // Carga parcial no processador (como um jogo: nunca 100%). duty = % de cada ciclo de 100 ms em que a thread trabalha.
    public static void Iniciar(int segundos, int threads, int duty)
    {
        Encerrar();
        parar = false;
        if (threads < 1) threads = 1;
        if (duty < 5) duty = 5;
        if (duty > 100) duty = 100;
        ts = new Thread[threads];
        Stopwatch total = Stopwatch.StartNew();
        for (int i = 0; i < threads; i++)
        {
            int id = i;
            ts[i] = new Thread(delegate ()
            {
                ulong x = 88172645463325252UL + (ulong)id;
                double d = 1.0001;
                while (!parar && total.ElapsedMilliseconds < segundos * 1000L)
                {
                    long ini = total.ElapsedMilliseconds;
                    while (!parar && total.ElapsedMilliseconds - ini < duty)
                    {
                        for (int k = 0; k < 20000; k++)
                        {
                            x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                            d = d * 1.0000001 + (x & 255) * 1e-9;
                            if (d > 1e6) d = 1.0001;
                        }
                    }
                    if (duty < 100) Thread.Sleep(100 - duty);
                }
                Sink ^= x ^ (ulong)d;
            });
            ts[i].IsBackground = true;
            ts[i].Priority = ThreadPriority.BelowNormal;
            ts[i].Start();
        }
    }
    public static void Encerrar()
    {
        parar = true;
        if (ts != null) { foreach (Thread t in ts) { try { if (t != null) t.Join(500); } catch (Exception) { } } ts = null; }
    }
}

public static class WDGpuTemp
{
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    struct OPENADAPTER
    {
        [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        public uint hAdapter; public int LuidLow; public int LuidHigh; public uint VidPnSourceId;
    }
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct QUERYINFO { public uint hAdapter; public int Type; public IntPtr pData; public int Size; }
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct CLOSEADAPTER { public uint hAdapter; }

    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTOpenAdapterFromGdiDisplayName(ref OPENADAPTER d);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTQueryAdapterInfo(ref QUERYINFO d);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTCloseAdapter(ref CLOSEADAPTER d);

    // Lê (via driver gráfico, KMTQAITYPE_ADAPTERPERFDATA = 62) a temperatura em décimos de grau e a rotação do ventilador.
    // Devolve {status, tempDeciC, fanRpm}; status 0 = leitura obtida.
    public static long[] Ler(string dispositivo)
    {
        long[] r = new long[] { -1, 0, 0 };
        try
        {
            OPENADAPTER o = new OPENADAPTER(); o.DeviceName = dispositivo;
            int st = D3DKMTOpenAdapterFromGdiDisplayName(ref o);
            if (st != 0) { r[0] = st; return r; }
            IntPtr buf = System.Runtime.InteropServices.Marshal.AllocHGlobal(256);
            try
            {
                for (int i = 0; i < 256; i += 8) System.Runtime.InteropServices.Marshal.WriteInt64(buf, i, 0);
                int[] tamanhos = new int[] { 64, 72, 80, 56 };
                foreach (int tam in tamanhos)
                {
                    for (int i = 0; i < 256; i += 8) System.Runtime.InteropServices.Marshal.WriteInt64(buf, i, 0);
                    QUERYINFO q = new QUERYINFO(); q.hAdapter = o.hAdapter; q.Type = 62; q.pData = buf; q.Size = tam;
                    st = D3DKMTQueryAdapterInfo(ref q);
                    if (st == 0) break;
                }
                r[0] = st;
                if (st == 0)
                {
                    r[2] = (uint)System.Runtime.InteropServices.Marshal.ReadInt32(buf, 48);
                    r[1] = (uint)System.Runtime.InteropServices.Marshal.ReadInt32(buf, 56);
                }
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.FreeHGlobal(buf);
                CLOSEADAPTER c = new CLOSEADAPTER(); c.hAdapter = o.hAdapter; D3DKMTCloseAdapter(ref c);
            }
        }
        catch (Exception) { r[0] = -2; }
        return r;
    }
}
'@
}

# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
function Get-ArquivoBench {
    if ($env:WD_BENCH_ARQ) { return $env:WD_BENCH_ARQ }
    $base = $env:LOCALAPPDATA
    if (-not $base) { $base = [IO.Path]::GetTempPath() }
    return (Join-Path $base 'WinDiag\bench.json')
}

function Read-HistoricoBench {
    try {
        $f = Get-ArquivoBench
        if (Test-Path -LiteralPath $f) {
            return (Get-Content -LiteralPath $f -Raw -ErrorAction Stop | ConvertFrom-Json)
        }
    } catch { }
    return $null
}

function Save-HistoricoBench {
    param([hashtable]$Dados)
    try {
        $f = Get-ArquivoBench
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        ($Dados | ConvertTo-Json) | Set-Content -LiteralPath $f -Encoding UTF8
    } catch { }
}

function Get-TempCpuAprox {
    # Zona térmica ACPI: leitura aproximada, nem todo computador informa.
    try {
        $z = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop)
        $t = @($z | ForEach-Object { [math]::Round(($_.CurrentTemperature / 10) - 273.15, 1) } | Where-Object { $_ -gt 0 -and $_ -lt 150 })
        if ($t.Count -gt 0) { return ($t | Measure-Object -Maximum).Maximum }
    } catch { }
    return $null
}

function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

function Get-FreqCpuMHz {
    # Frequência atual do processador (média). Usa a classe WMI de desempenho, que não depende do idioma do Windows.
    param([int]$MaxMhz = 0)
    try {
        $o = Get-CimInstance -ClassName Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'" -ErrorAction Stop | Select-Object -First 1
        if ($o) {
            if ([double]$o.ProcessorFrequency -gt 0) { return [double]$o.ProcessorFrequency }
            if ([double]$o.PercentProcessorPerformance -gt 0 -and $MaxMhz -gt 0) { return ([double]$o.PercentProcessorPerformance * $MaxMhz / 100) }
        }
    } catch { }
    return 0
}

function Get-DeltaTexto {
    # " (+4% em relação ao teste anterior)" ou vazio
    param([double]$Atual, $Antes)
    if ($null -eq $Antes -or [double]$Antes -le 0 -or $Atual -le 0) { return '' }
    return (' ({0:+0%;-0%;0%} em relação ao teste anterior)' -f (($Atual / [double]$Antes) - 1))
}

function Test-BenchCancelado {
    try { return [bool]$global:WD_Sync.Cancelar } catch { return $false }
}

function New-ResultadoBench {
    param([string]$Nome, [string]$Estado, [string]$Resumo, [string[]]$Linhas)
    return @{ Nome = $Nome; Estado = $Estado; Resumo = $Resumo; Linhas = @($Linhas) }
}

# ----------------------------------------------------------------------------
# Sensores de programas que o usuário já usa (HWiNFO e LibreHardwareMonitor / OpenHardwareMonitor)
# O WinDiag não instala nem carrega driver nenhum: só LÊ o que esses programas já estão publicando, se estiverem abertos.
# ----------------------------------------------------------------------------
function Get-GrupoSensor {
    param([string]$Texto)
    if ($Texto -match '^(CPU|/amdcpu|/intelcpu)|Ryzen|Core i\d') { return 'Processador' }
    if ($Texto -match '^(GPU|/gpu)|Radeon|GeForce|NVIDIA') { return 'Placa de vídeo' }
    if ($Texto -match '^(Drive|/nvme|/hdd|/ssd)|S\.M\.A\.R\.T|NVMe') { return 'Disco' }
    if ($Texto -match '^(Memory|/ram)|DIMM') { return 'Memória' }
    return 'Placa-mãe e outros'
}

function Get-SensoresExternos {
    # Devolve @{ Fonte; Leituras = lista de @{ Grupo; Sensor; Rotulo; Tipo; Valor; Max } } ou $null se nenhum programa estiver publicando.
    $lista = New-Object System.Collections.Generic.List[object]
    $fonte = $null
    if ($env:OS -eq 'Windows_NT' -or $script:TesteSensoresBytes) {
        try {
            $linhas = $null
            if ($script:TesteSensoresBytes) { $linhas = [WDSensores]::LerBytes($script:TesteSensoresBytes) } else { $linhas = [WDSensores]::LerHWiNFO() }
            if ($linhas -and $linhas.Count -gt 0) {
                $fonte = 'HWiNFO'
                $tipos = @{ '1' = 'Temp'; '3' = 'Ventoinha'; '5' = 'Potencia'; '6' = 'Clock'; '7' = 'Uso' }
                foreach ($l in $linhas) {
                    if (-not $tipos.ContainsKey($l[0])) { continue }
                    $lista.Add(@{ Grupo = (Get-GrupoSensor $l[1]); Sensor = $l[1]; Rotulo = $l[2]; Tipo = $tipos[$l[0]]; Unidade = $l[3]; Valor = [double]::Parse($l[4], [Globalization.CultureInfo]::InvariantCulture); Max = [double]::Parse($l[6], [Globalization.CultureInfo]::InvariantCulture) })
                }
            }
        } catch { }
    }
    if (-not $fonte -and $env:OS -eq 'Windows_NT') {
        foreach ($ns in 'root\LibreHardwareMonitor', 'root\OpenHardwareMonitor') {
            try {
                $s = @(Get-CimInstance -Namespace $ns -ClassName Sensor -ErrorAction Stop)
                if ($s.Count -gt 0) {
                    $fonte = $(if ($ns -match 'Libre') { 'LibreHardwareMonitor' } else { 'OpenHardwareMonitor' })
                    $tipos = @{ 'Temperature' = 'Temp'; 'Fan' = 'Ventoinha'; 'Power' = 'Potencia'; 'Clock' = 'Clock'; 'Load' = 'Uso' }
                    foreach ($x in $s) {
                        if ($null -eq $x.Value -or -not $tipos.ContainsKey("$($x.SensorType)")) { continue }
                        $lista.Add(@{ Grupo = (Get-GrupoSensor "$($x.Identifier)"); Sensor = "$($x.Parent)"; Rotulo = "$($x.Name)"; Tipo = $tipos["$($x.SensorType)"]; Unidade = ''; Valor = [double]$x.Value; Max = $(if ($null -ne $x.Max) { [double]$x.Max } else { 0 }) })
                    }
                    break
                }
            } catch { }
        }
    }
    if (-not $fonte -or $lista.Count -eq 0) { return $null }
    return @{ Fonte = $fonte; Leituras = $lista.ToArray() }
}

function Get-TempExterna {
    # Maior temperatura de um grupo (ignora "distância até o limite", que o HWiNFO também publica em °C).
    param($Sensores, [string]$Grupo)
    if (-not $Sensores) { return $null }
    $t = @($Sensores.Leituras | Where-Object { $_.Tipo -eq 'Temp' -and $_.Grupo -eq $Grupo -and $_.Rotulo -notmatch 'Distance|TjMax|Limit|Margin|Distância' -and $_.Valor -gt 0 -and $_.Valor -lt 150 })
    if ($t.Count -eq 0) { return $null }
    return ($t | ForEach-Object { $_.Valor } | Measure-Object -Maximum).Maximum
}

function Get-ItemSensores {
    param($Sensores)
    if (-not $Sensores) { return $null }
    $l = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'; $resumo = "Temperaturas lidas pelo $($Sensores.Fonte) durante o teste."
    $l.Add("Fonte: $($Sensores.Fonte) (o WinDiag só lê o que o programa publica; não instala nem carrega nenhum driver).")
    foreach ($g in 'Processador', 'Placa de vídeo', 'Placa-mãe e outros', 'Disco', 'Memória') {
        $ts = @($Sensores.Leituras | Where-Object { $_.Tipo -eq 'Temp' -and $_.Grupo -eq $g -and $_.Rotulo -notmatch 'Distance|TjMax|Limit|Margin|Distância' -and $_.Valor -gt 0 -and $_.Valor -lt 150 })
        if ($ts.Count -eq 0) { continue }
        $top = @($ts | Sort-Object { $_.Valor } -Descending | Select-Object -First 6)
        $txt = ($top | ForEach-Object { "{0} {1:N0} °C" -f $_.Rotulo, $_.Valor }) -join ' · '
        $l.Add("${g}: $txt")
        $max = ($ts | ForEach-Object { $_.Valor } | Measure-Object -Maximum).Maximum
        $lim = @{ 'Processador' = 95; 'Placa de vídeo' = 100; 'Disco' = 70; 'Placa-mãe e outros' = 100; 'Memória' = 85 }[$g]
        if ($max -ge $lim + 5) { $estado = 'problema'; $resumo = "Temperatura muito alta (${g}: $([math]::Round($max)) °C)." }
        elseif ($max -ge $lim -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = "Temperatura alta (${g}: $([math]::Round($max)) °C)." }
    }
    $fans = @($Sensores.Leituras | Where-Object { $_.Tipo -eq 'Ventoinha' -and $_.Valor -gt 0 })
    if ($fans.Count -gt 0) { $l.Add('Ventoinhas: ' + ((@($fans | Select-Object -First 8) | ForEach-Object { "{0} {1:N0} rpm" -f $_.Rotulo, $_.Valor }) -join ' · ')) }
    $pot = @($Sensores.Leituras | Where-Object { $_.Tipo -eq 'Potencia' -and $_.Grupo -eq 'Processador' -and $_.Valor -gt 0 } | Select-Object -First 2)
    if ($pot.Count -gt 0) { $l.Add('Consumo do processador: ' + (($pot | ForEach-Object { "{0} {1:N0} W" -f $_.Rotulo, $_.Valor }) -join ' · ')) }
    $l.Add('Valores do momento em que o teste terminou; as temperaturas máximas durante a carga estão no item do processador.')
    return (New-ResultadoBench -Nome 'Sensores (temperaturas)' -Estado $estado -Resumo $resumo -Linhas $l.ToArray())
}

# ----------------------------------------------------------------------------
# Processador
# ----------------------------------------------------------------------------
function Invoke-BenchCpu {
    param([int]$SegUnico = 5, [int]$SegMulti = 12, [int]$TempLimite = 97)
    $interrompido = $false
    $maxMhz = 0
    $lerFreq = ($env:OS -eq 'Windows_NT')
    $sens0 = Get-SensoresExternos
    $tempsCpu = New-Object System.Collections.Generic.List[double]
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'Desempenho dentro do esperado.'
    $nome = 'Processador'
    $logicos = [Environment]::ProcessorCount
    try {
        $p = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
        $nome = "Processador ($(("$($p.Name)" -replace '\s+', ' ').Trim()))"
        $maxMhz = [int]$p.MaxClockSpeed
    } catch { }


    # Um núcleo
    $u = [WDBench]::Cpu($SegUnico, 1)
    $mediaU = ($u | Select-Object -Skip 1 | Measure-Object -Average).Average
    if (-not $mediaU) { $mediaU = ($u | Measure-Object -Average).Average }
    $unico = [math]::Round([double]$mediaU)

    # Todos os núcleos, em fatias de 1 s para poder cancelar e medir a queda
    $porSeg = New-Object System.Collections.Generic.List[double]
    $freqs = New-Object System.Collections.Generic.List[double]
    for ($i = 0; $i -lt $SegMulti; $i++) {
        if (Test-BenchCancelado) { break }
        $r = [WDBench]::Cpu(1, $logicos)
        $porSeg.Add([double]$r[0])
        if ($sens0) { $tc = Get-TempExterna (Get-SensoresExternos) 'Processador'; if ($tc) { $tempsCpu.Add([double]$tc); if ($tc -ge $TempLimite) { $interrompido = $true; break } } }
        if ($lerFreq) { $f = Get-FreqCpuMHz -MaxMhz $maxMhz; if ($f -gt 0) { $freqs.Add($f) } else { $lerFreq = $false } }
    }
    $multi = 0
    if ($porSeg.Count -ge 3) {
        $multi = [math]::Round((($porSeg | Select-Object -Skip 1 | Measure-Object -Average).Average))
    } elseif ($porSeg.Count -gt 0) { $multi = [math]::Round(($porSeg | Measure-Object -Average).Average) }

    $linhas.Add("Um núcleo: $unico pontos")
    $linhas.Add("Todos os núcleos ($logicos threads): $multi pontos")
    if ($SegMulti -gt 20) { $linhas.Add("Teste longo: $([math]::Round($porSeg.Count / 60, 1)) minutos com todos os núcleos a 100%.") }
    if ($unico -gt 0 -and $multi -gt 0) {
        $escala = $multi / ($unico * $logicos)
        $linhas.Add(("Aproveitamento dos núcleos: {0:P0} do ideal (com hyper-threading/SMT, 60% a 90% é normal)" -f $escala))
        if ($escala -lt 0.35) {
            $estado = 'atencao'
            $resumo = 'Os núcleos renderam bem menos do que o esperado.'
            $linhas.Add('Isso pode indicar outro programa usando o processador durante o teste, plano de energia econômico ou limite de energia/temperatura.')
        }
    }

    # Queda ao longo do teste: sinal de superaquecimento ou limite de energia
    if ($porSeg.Count -ge 8) {
        $ini = ($porSeg | Select-Object -Skip 1 -First 3 | Measure-Object -Average).Average
        $fim = ($porSeg | Select-Object -Last 3 | Measure-Object -Average).Average
        if ($ini -gt 0) {
            $queda = 1 - ($fim / $ini)
            $quedaTxt = [math]::Max(0, $queda)
            $linhas.Add(("Estabilidade sob carga: {0:P0} de queda entre o início e o fim do teste" -f $quedaTxt))
            if ($queda -gt 0.15) {
                $estado = 'atencao'
                $resumo = 'O desempenho caiu durante o teste (possível superaquecimento ou limite de energia).'
                $linhas.Add('Se o computador também trava ou desliga sozinho, limpe o cooler/saídas de ar e confira a pasta térmica.')
            }
        }
    }
    # Frequência durante a carga: mostra limite de energia/temperatura mesmo sem ler a temperatura
    if ($freqs.Count -ge 4) {
        $fIni = ($freqs | Select-Object -Skip 1 -First 3 | Measure-Object -Average).Average
        $fFim = ($freqs | Select-Object -Last 3 | Measure-Object -Average).Average
        $fMin = ($freqs | Measure-Object -Minimum).Minimum; $fMax = ($freqs | Measure-Object -Maximum).Maximum
        $linhas.Add(("Frequência durante a carga: {0:N2} GHz no início, {1:N2} GHz no fim (mínima {2:N2}, máxima {3:N2}; frequência de referência do processador: {4:N2} GHz)" -f ($fIni / 1000), ($fFim / 1000), ($fMin / 1000), ($fMax / 1000), ($maxMhz / 1000)))
        if ($fIni -gt 0 -and ($fFim / $fIni) -lt 0.85) {
            if ($estado -eq 'ok') { $estado = 'atencao'; $resumo = 'A frequência do processador caiu durante o teste.' }
            $linhas.Add('A frequência caiu mais de 15% sob carga: é sinal de limite de temperatura ou de energia. Limpe o cooler e as saídas de ar e confira a pasta térmica e o plano de energia.')
        } elseif ($maxMhz -gt 0 -and $fFim -lt ($maxMhz * 0.85)) {
            $linhas.Add('Sob carga total o processador ficou abaixo da frequência de referência: pode ser limite de energia da placa-mãe/plano de energia econômico.')
        }
    }
    # Teste longo: pontos minuto a minuto
    if ($porSeg.Count -ge 60) {
        $mins = @()
        for ($m = 0; $m + 60 -le $porSeg.Count; $m += 60) { $mins += [math]::Round((($porSeg | Select-Object -Skip $m -First 60 | Measure-Object -Average).Average)) }
        $linhas.Add('Pontos minuto a minuto: ' + ($mins -join ' → '))
    }
    if ($interrompido) { $linhas.Add("O teste do processador foi interrompido por segurança: a temperatura chegou a $TempLimite °C."); if ($estado -eq 'ok') { $estado = 'atencao'; $resumo = 'Teste interrompido: o processador esquentou demais.' } }
    $tempMaxCpu = $null
    if ($tempsCpu.Count -gt 0) {
        $tempMaxCpu = ($tempsCpu | Measure-Object -Maximum).Maximum
        $tFim = ($tempsCpu | Select-Object -Last 1)
        $linhas.Add(("Temperatura do processador sob carga ({0}): máxima {1:N0} °C, no fim do teste {2:N0} °C" -f $sens0.Fonte, $tempMaxCpu, $tFim))
        if ($tempMaxCpu -ge 100) { $estado = 'problema'; $resumo = "Temperatura do processador muito alta ($([math]::Round($tempMaxCpu)) °C)."; $linhas.Add('Perigosamente quente: limpe o cooler e as saídas de ar, confira a pasta térmica e o encaixe do cooler.') }
        elseif ($tempMaxCpu -ge 95) { if ($estado -eq 'ok') { $estado = 'atencao'; $resumo = "Processador muito quente sob carga ($([math]::Round($tempMaxCpu)) °C)." }; $linhas.Add('Muito quente para uma carga de teste: limpe o cooler e confira a pasta térmica.') }
        elseif ($tempMaxCpu -ge 85) { $linhas.Add('Quente, mas aceitável sob carga total em muitos processadores.') }
    } else {
        $linhas.Add('Temperatura do processador: o Windows não informa essa temperatura. Para vê-la aqui, abra o HWiNFO (com "Sensores" e a memória compartilhada ligada em Configurações) ou o LibreHardwareMonitor antes de iniciar o teste: o WinDiag lê o que eles mostram, sem instalar nada.')
    }

    # Comparação com o teste anterior
    $h = Read-HistoricoBench
    # só compara com testes da mesma duração (um teste de 180 s dá menos pontos por segundo que um de 12 s, por causa do calor)
    $mesmaDuracao = ($h -and (($h.CpuSeg -and [int]$h.CpuSeg -eq $SegMulti) -or (-not $h.CpuSeg -and $SegMulti -le 12)))
    if ($h -and $h.CpuMulti -and $mesmaDuracao -and $multi -gt 0 -and [double]$h.CpuMulti -gt 0) {
        $dif = ($multi / [double]$h.CpuMulti) - 1
        $linhas.Add(("Comparado ao teste anterior ({0}): {1:+0%;-0%;0%}" -f $h.Data, $dif))
        if ($dif -lt -0.2 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = 'Desempenho bem abaixo do teste anterior.' }
    }
    $linhas.Add('Os pontos servem para comparar este computador com ele mesmo ao longo do tempo (não são comparáveis com outros programas).')
    $r = New-ResultadoBench -Nome $nome -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    $r.CpuUnico = $unico
    if ($tempMaxCpu) { $r.CpuTempMax = [math]::Round($tempMaxCpu) }
    $r.CpuMulti = $multi
    $r.CpuSeg = $SegMulti
    return $r
}

# ----------------------------------------------------------------------------
# Memória RAM
# ----------------------------------------------------------------------------
function Get-LivreMB {
    try {
        $o = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        return [int]([double]$o.FreePhysicalMemory / 1024)
    } catch { return 0 }
}

function Invoke-BenchRam {
    param([int]$LimiteMB = 8192, [int]$Passadas = 1)
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'Nenhum erro encontrado na parte testada.'
    $totalMB = 0
    $mods = @()
    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $totalMB = [int](($mods | Measure-Object Capacity -Sum).Sum / 1MB)
    } catch { }
    $livre = Get-LivreMB
    if ($livre -le 0) { $livre = 1024 }
    $alvo = [int][math]::Min($LimiteMB, [math]::Floor($livre * 0.6 / 64) * 64)
    if ($alvo -lt 128) {
        return (New-ResultadoBench -Nome 'Memória RAM' -Estado 'nd' -Resumo 'Pouca memória livre para testar agora.' -Linhas @("Memória livre: $livre MB. Feche programas e tente de novo."))
    }
    $t = New-Object WDRamTest
    $t.Threads = [Math]::Max(1, [Math]::Min(8, [Environment]::ProcessorCount))
    $blocos = $t.Alocar($alvo)
    $mb = $t.MBAlocados
    $erros = [long]0
    try {
        # 8 padrões de escrita e conferência (inclusive bit andando e pseudoaleatório)
        for ($passada = 1; $passada -le [math]::Max(1, $Passadas); $passada++) {
            foreach ($p in 0..7) {
                if (Test-BenchCancelado) { break }
                $erros += $t.Padrao($p, ($p -eq 4))
            }
            # "inversão em movimento": confere, inverte tudo, confere de novo (acha células que não trocam de valor)
            foreach ($p in @(2, 5)) {
                if (Test-BenchCancelado) { break }
                $erros += $t.Padrao($p, $false)
                $erros += $t.Inversao($p)
            }
        }
        # retenção: grava, espera e confere (acha células que perdem o valor com o tempo)
        if (-not (Test-BenchCancelado)) {
            $erros += $t.Padrao(4, $false)
            for ($i = 0; $i -lt 6 -and -not (Test-BenchCancelado); $i++) { Start-Sleep -Seconds 1 }
            if (-not (Test-BenchCancelado)) { $erros += $t.Conferir(4) }
        }
        if (-not (Test-BenchCancelado)) { $t.Copia() }
    } finally { $bw = @{ W = $t.WriteMBs; R = $t.ReadMBs; C = $t.CopyMBs }; $t.Liberar() }
    if ($totalMB -gt 0) { $linhas.Add("Testado: $mb MB de $([math]::Round($totalMB / 1024, 1)) GB instalados (8 padrões, 2 inversões em movimento e uma conferência após 6 s de espera; $($t.Threads) núcleos).") }
    else { $linhas.Add("Testado: $mb MB (8 padrões, 2 inversões em movimento e conferência após espera).") }
    $linhas.Add('O Windows não deixa testar a memória que ele mesmo está usando; por isso é uma amostra da parte livre.')
    if ($erros -gt 0) {
        $estado = 'problema'
        $resumo = "$erros erro(s) de memória encontrados."
        $linhas.Add("ERROS: $erros posições leram um valor diferente do que foi gravado.")
        $linhas.Add('Isso indica memória defeituosa, módulo mal encaixado, ou memória/XMP/EXPO instável. Desative o XMP/EXPO na BIOS, reencaixe os pentes e teste um de cada vez.')
    } else {
        $linhas.Add('Erros: nenhum.')
    }
    if ($bw.R -gt 0) {
        $linhas.Add(("Velocidade (vários núcleos): escrita {0:N1} GB/s, leitura {1:N1} GB/s, cópia {2:N1} GB/s" -f ($bw.W / 1024), ($bw.R / 1024), ($bw.C / 1024)))
    }
    $teorGBs = 0; $pctTeor = 0
    if ($mods.Count -gt 0) {
        $v = $mods[0].Speed; $c = $mods[0].ConfiguredClockSpeed
        if ($c) { $linhas.Add("Frequência: configurada $c MHz (nominal do módulo: $v MHz)") }
        if ($c -and $bw.R -gt 0) {
            # Velocidade teórica aproximada: transferências por segundo x 8 bytes x canais (computadores comuns usam até 2 canais)
            $canais = [math]::Min($mods.Count, 2)
            $teorGBs = [double]$c * 8 * $canais / 1000
            if ($teorGBs -gt 0) {
                $pctTeor = ($bw.R / 1024) / $teorGBs
                $linhas.Add(("Aproveitamento da velocidade teórica: leitura de {0:N1} GB/s é {1:P0} dos {2:N1} GB/s possíveis ({3} canal(is) a {4} MT/s; cálculo aproximado)" -f ($bw.R / 1024), $pctTeor, $teorGBs, $canais, $c))
            }
        }
        $cpuNome = ''
        try { $cpuNome = "$((Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).Name)" } catch { }
        if ($c -and [int]$c -le 2666 -and $cpuNome -match 'Ryzen') {
            $linhas.Add("Dica: sua memória roda a $c MT/s. Nos Ryzen, memória de 3200 MT/s ou mais costuma dar ganho perceptível (inclusive no vídeo integrado), se a placa-mãe aceitar. Não é um defeito: só uma possibilidade de melhoria.")
        }
        if ($mods.Count -eq 1) {
            $linhas.Add('Há apenas 1 módulo de memória: ela trabalha em canal simples (mais lenta). Dois módulos iguais costumam dar mais desempenho.')
        }
        if ($c -and $v -and [int]$c -lt [int]$v -and $estado -eq 'ok') {
            $estado = 'atencao'; $resumo = 'Memória rodando abaixo da velocidade do módulo.'
            $linhas.Add('A memória está abaixo da velocidade nominal. Ative o XMP/EXPO na BIOS para usar a velocidade anunciada (se ficar instável, volte ao padrão).')
        }
    }
    $linhas.Add('Para um teste completo e demorado, use o "Diagnóstico de Memória do Windows" ou o MemTest86 (a partir de um pendrive).')
    $r = New-ResultadoBench -Nome 'Memória RAM' -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    $hAnt = Read-HistoricoBench
    if ($hAnt -and $hAnt.RamLeituraMBs -and [double]$hAnt.RamLeituraMBs -gt 0 -and $bw.R -gt 0) {
        $dif = ($bw.R / [double]$hAnt.RamLeituraMBs) - 1
        $r.Linhas = @($r.Linhas) + ("Leitura comparada ao teste anterior ({0}): {1:+0%;-0%;0%}" -f $hAnt.Data, $dif)
        if ($dif -lt -0.25 -and $r.Estado -eq 'ok') { $r.Estado = 'atencao'; $r.Resumo = 'Velocidade da memória bem abaixo do teste anterior.' }
    }
    $r.RamLeituraMBs = [math]::Round($bw.R)
    $r.RamErros = $erros
    $r.RamTeoricoGBs = [math]::Round($teorGBs, 1)
    $r.RamPctTeorico = [math]::Round($pctTeor * 100)
    return $r
}

# ----------------------------------------------------------------------------
# Disco (velocidade e saúde)
# ----------------------------------------------------------------------------
function Get-InfoDisco {
    # Tipo, saúde e desgaste do disco da unidade informada (precisa do módulo Storage do Windows; nem todo disco informa tudo).
    param([string]$Letra)
    $r = @{ Modelo = ''; Tipo = ''; Barramento = ''; Saude = ''; Temp = $null; Desgaste = $null; ErrosLeitura = $null; Horas = $null; TamanhoGB = $null }
    try {
        $pd = Get-Partition -DriveLetter $Letra -ErrorAction Stop | Get-Disk -ErrorAction Stop | Get-PhysicalDisk -ErrorAction Stop | Select-Object -First 1
        if ($pd) {
            $r.Modelo = ("$($pd.FriendlyName)" -replace '\s+', ' ').Trim()
            $r.Tipo = "$($pd.MediaType)"; $r.Barramento = "$($pd.BusType)"; $r.Saude = "$($pd.HealthStatus)"
            if ($pd.Size) { $r.TamanhoGB = [math]::Round($pd.Size / 1GB) }
            try {
                $c = Get-StorageReliabilityCounter -PhysicalDisk $pd -ErrorAction Stop
                if ($c) {
                    if ($null -ne $c.Temperature -and [int]$c.Temperature -gt 0) { $r.Temp = [int]$c.Temperature }
                    if ($null -ne $c.Wear) { $r.Desgaste = [int]$c.Wear }
                    $e = 0; foreach ($n in 'ReadErrorsUncorrected', 'WriteErrorsUncorrected') { if ($null -ne $c.$n) { $e += [int64]$c.$n } }
                    $r.ErrosLeitura = $e
                    if ($null -ne $c.PowerOnHours) { $r.Horas = [int64]$c.PowerOnHours }
                }
            } catch { }
        }
    } catch { }
    return $r
}

function Invoke-BenchDisco {
    param([int]$MaxMB = 1024)
    $linhas = New-Object System.Collections.Generic.List[string]
    $rank = @{ ok = 0; nd = 1; atencao = 2; problema = 3 }
    $estado = 'ok'; $resumo = 'O disco respondeu normalmente.'
    $sobe = { param($e, $t) if ($rank[$e] -gt $rank[$script:_estD]) { $script:_estD = $e; $script:_resD = $t } }
    $script:_estD = 'ok'; $script:_resD = $resumo
    $nome = 'Disco'
    $tmp = [IO.Path]::GetTempPath()
    $raiz = [IO.Path]::GetPathRoot($tmp)
    $letra = ''
    if ($raiz -match '^([A-Za-z]):') { $letra = $matches[1] }
    $livreMB = 0
    try { $livreMB = [int]([IO.DriveInfo]::new($raiz).AvailableFreeSpace / 1MB) } catch { }
    $info = @{ Modelo = ''; Tipo = ''; Barramento = ''; Saude = ''; Temp = $null; Desgaste = $null; ErrosLeitura = $null; Horas = $null; TamanhoGB = $null }
    if ($letra) { $info = Get-InfoDisco -Letra $letra }
    if ($info.Modelo) { $nome = "Disco ($($info.Modelo)" + $(if ($info.TamanhoGB) { ", $($info.TamanhoGB) GB" } else { '' }) + ')' }

    # Saúde informada pelo próprio disco
    $tipoTxt = (@($info.Barramento, $info.Tipo) | Where-Object { $_ -and $_ -notmatch '^(Unspecified|Unknown)$' }) -join ' · '
    if ($tipoTxt) { $linhas.Add("Tipo: $tipoTxt") }
    if ($info.Saude) {
        $linhas.Add("Saúde informada pelo disco: $($info.Saude)")
        if ($info.Saude -ne 'Healthy') { & $sobe 'problema' "O disco informa estado de saúde: $($info.Saude)."; $linhas.Add('Faça backup dos seus arquivos agora e considere trocar o disco.') }
    }
    if ($null -ne $info.Desgaste) {
        $linhas.Add("Desgaste do SSD: $($info.Desgaste)% da vida útil usada")
        if ($info.Desgaste -ge 90) { & $sobe 'problema' "SSD muito desgastado ($($info.Desgaste)%)."; $linhas.Add('Faça backup e planeje a troca do SSD.') }
        elseif ($info.Desgaste -ge 80) { & $sobe 'atencao' "SSD bastante desgastado ($($info.Desgaste)%)." }
    }
    if ($null -ne $info.Temp) {
        $linhas.Add("Temperatura do disco: $($info.Temp) °C")
        if ($info.Temp -ge 85) { & $sobe 'problema' "Disco muito quente ($($info.Temp) °C)." }
        elseif ($info.Temp -ge 70) { & $sobe 'atencao' "Disco quente ($($info.Temp) °C)." }
    }
    if ($null -ne $info.ErrosLeitura) {
        $linhas.Add("Erros de leitura/escrita sem correção registrados pelo disco: $($info.ErrosLeitura)")
        if ($info.ErrosLeitura -gt 0) { & $sobe 'atencao' "O disco registrou $($info.ErrosLeitura) erro(s) sem correção."; $linhas.Add('Faça backup e rode a verificação de erros do disco em Ferramentas.') }
    }
    if ($null -ne $info.Horas) { $linhas.Add("Tempo ligado: $($info.Horas) horas") }
    if (-not $info.Saude -and $null -eq $info.Desgaste -and $null -eq $info.Temp) {
        $linhas.Add('Este disco (ou o Windows neste computador) não informa saúde/desgaste. Para ver o SMART completo use o CrystalDiskInfo.')
    }

    # Velocidade
    $sizeMB = [int][math]::Min($MaxMB, [math]::Floor($livreMB * 0.1 / 64) * 64)
    if ($sizeMB -lt 256) {
        $linhas.Add("Pouco espaço livre em $raiz ($livreMB MB): o teste de velocidade foi pulado. Libere espaço e teste de novo.")
        & $sobe 'nd' 'Teste de velocidade pulado por falta de espaço livre.'
        $r = New-ResultadoBench -Nome $nome -Estado $script:_estD -Resumo $script:_resD -Linhas $linhas.ToArray()
        return $r
    }
    $arq = Join-Path $tmp ('WinDiag-disco-' + [guid]::NewGuid().ToString('N') + '.bin')
    $semCache = $true
    $rodou = $false
    $erroTeste = $null
    try {
        for ($tentativa = 0; $tentativa -lt 2 -and -not $rodou; $tentativa++) {
            try {
                [WDDisk]::WriteMBs = 0; [WDDisk]::ReadMBs = 0; [WDDisk]::Iops = 0; [WDDisk]::LatMs = 0; [WDDisk]::Erros = 0; [WDDisk]::ReadQMBs = 0; [WDDisk]::IopsQ = 0
                [WDDisk]::Escrita($arq, $sizeMB, $semCache)
                if (Test-BenchCancelado) { break }
                [WDDisk]::Leitura($arq, $sizeMB, $semCache)
                if (Test-BenchCancelado) { break }
                [WDDisk]::Aleatoria($arq, $sizeMB, 5, $semCache)
                if (Test-BenchCancelado) { break }
                [WDDisk]::LeituraFila($arq, $sizeMB, 4, $semCache)
                [WDDisk]::AleatoriaFila($arq, $sizeMB, 4, 32, $semCache)
                $rodou = $true
            } catch {
                $erroTeste = $_.Exception.Message
                if ($semCache) { $semCache = $false; try { Remove-Item -LiteralPath $arq -Force -ErrorAction SilentlyContinue } catch { } } else { throw }
            }
        }
    } catch {
        $erroTeste = $_.Exception.Message
    } finally {
        try { if (Test-Path -LiteralPath $arq) { Remove-Item -LiteralPath $arq -Force -ErrorAction SilentlyContinue } } catch { }
    }
    if (-not $rodou -and -not (Test-BenchCancelado)) {
        $linhas.Add("Não consegui medir a velocidade: $erroTeste")
        & $sobe 'nd' 'Não foi possível medir a velocidade do disco.'
        return (New-ResultadoBench -Nome $nome -Estado $script:_estD -Resumo $script:_resD -Linhas $linhas.ToArray())
    }
    $w = [double][WDDisk]::WriteMBs; $rd = [double][WDDisk]::ReadMBs; $io = [double][WDDisk]::Iops; $lat = [double][WDDisk]::LatMs
    $linhas.Add("Testado com um arquivo temporário de $sizeMB MB em $raiz (apagado no fim).")
    $linhas.Add(("Velocidade sequencial: escrita {0:N0} MB/s, leitura {1:N0} MB/s" -f $w, $rd))
    if ($io -gt 0) { $linhas.Add(("Leituras aleatórias de 4 KB (uma de cada vez): {0:N0} por segundo (latência média {1:N2} ms)" -f $io, $lat)) }
    $rq = [double][WDDisk]::ReadQMBs; $iq = [double][WDDisk]::IopsQ
    if ($rq -gt 0) { $linhas.Add(("Leitura sequencial com fila (4 leituras ao mesmo tempo): {0:N0} MB/s: é a velocidade máxima que o disco sustenta, a que o fabricante anuncia" -f $rq)) }
    if ($iq -gt 0) { $linhas.Add(("Leituras aleatórias de 4 KB com fila de 32: {0:N0} por segundo" -f $iq)) }
    if (-not $semCache) { $linhas.Add('Aviso: o Windows não liberou o modo sem cache; a leitura pode estar inflada pelo cache do sistema.') }
    $erros = [int64][WDDisk]::Erros
    if ($erros -gt 0) {
        $linhas.Add("ERROS: $erros bloco(s) leram um conteúdo diferente do que foi gravado.")
        $linhas.Add('Isso indica disco, cabo ou controlador com defeito. Faça backup e verifique o disco.')
        & $sobe 'problema' "$erros erro(s) de leitura no teste do disco."
    } else { $linhas.Add('Erros de leitura/gravação no teste: nenhum.') }
    $hdd = ($info.Tipo -match 'HDD')
    if ($hdd -and ($rd -lt 60 -or $w -lt 40)) { & $sobe 'atencao' 'HD lento para o normal.'; $linhas.Add('Um HD saudável costuma passar de 80 MB/s. Verifique o cabo, o modo de energia e a saúde do disco.') }
    elseif (-not $hdd -and $rd -gt 0 -and [math]::Max($rd, $rq) -lt 150) { & $sobe 'atencao' 'Disco mais lento do que o esperado.'; $linhas.Add('Menos de 150 MB/s de leitura é baixo para SSD; pode ser um HD, cabo ruim ou disco quase cheio.') }
    $h = Read-HistoricoBench
    if ($h -and $h.DiscoLeituraMBs -and [double]$h.DiscoLeituraMBs -gt 0 -and $rd -gt 0) {
        $dif = ($rd / [double]$h.DiscoLeituraMBs) - 1
        $linhas.Add(("Leitura comparada ao teste anterior ({0}): {1:+0%;-0%;0%}" -f $h.Data, $dif))
        if ($dif -lt -0.3) { & $sobe 'atencao' 'Leitura do disco bem abaixo do teste anterior.' }
    }
    $r = New-ResultadoBench -Nome $nome -Estado $script:_estD -Resumo $script:_resD -Linhas $linhas.ToArray()
    $r.DiscoLeituraMBs = [math]::Round($rd); $r.DiscoEscritaMBs = [math]::Round($w); $r.DiscoIops = [math]::Round($io)
    $r.DiscoLeituraFilaMBs = [math]::Round($rq); $r.DiscoIopsFila = [math]::Round($iq)
    return $r
}

function Get-ItemNotasWinSAT {
    # Notas que o próprio Windows guardou (WinSAT), só para comparação. Não roda o WinSAT: só lê o que já existe.
    try {
        $w = Get-CimInstance Win32_WinSAT -ErrorAction Stop | Select-Object -First 1
        if ($w -and [int]$w.WinSATAssessmentState -eq 1) {
            $l = @(
                "Processador: $($w.CPUScore)  ·  Memória: $($w.MemoryScore)  ·  Disco: $($w.DiskScore)  ·  Gráficos: $($w.GraphicsScore)  ·  Jogos 3D: $($w.D3DScore)",
                "Nota geral do Windows: $($w.WinSPRLevel) (de 1,0 a 9,9)",
                'O Windows só refaz essa medição quando é mandado (comando winsat) e ela não mostra erros, queda por temperatura nem comparação com o seu próprio histórico: isso o teste do WinDiag faz.'
            )
            return (New-ResultadoBench -Nome 'Notas do Windows (para comparar)' -Estado 'ok' -Resumo 'Última medição guardada pelo Windows (WinSAT).' -Linhas $l)
        }
    } catch { }
    return $null
}

# ----------------------------------------------------------------------------
# Placa de vídeo
# ----------------------------------------------------------------------------
function Get-TempGpu {
    $script:DiagGpu = ''
    # Devolve @{ Temp; Fan; Fonte } ou $null. NVIDIA: nvidia-smi. Outras (AMD, Intel): leitura do driver via D3DKMT (best-effort).
    $caminhos = @('nvidia-smi.exe', (Join-Path $env:SystemRoot 'System32\nvidia-smi.exe'), (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVSMI\nvidia-smi.exe'))
    foreach ($c in $caminhos) {
        try {
            if (-not $c) { continue }
            $cmd = Get-Command $c -ErrorAction SilentlyContinue
            if (-not $cmd) { continue }
            $o = & $cmd.Source --query-gpu=temperature.gpu,fan.speed,power.draw,clocks.gr,temperature.memory --format=csv,noheader,nounits 2>$null | Select-Object -First 1
            if ($o -match '^\s*(\d+)\s*,') {
                $p = @("$o" -split ',' | ForEach-Object { $_.Trim() })
                $num = { param($i) if ($p.Count -gt $i -and $p[$i] -match '^[\d\.]+$') { [double]::Parse($p[$i], [Globalization.CultureInfo]::InvariantCulture) } else { $null } }
                $fan = $null
                if ($null -ne (& $num 1)) { $fan = ('{0:N0}%' -f (& $num 1)) }
                return @{ Temp = [int]$p[0]; Fan = $fan; Fonte = 'nvidia-smi (a mesma leitura do app da NVIDIA)'; Potencia = (& $num 2); Clock = (& $num 3); TempMem = (& $num 4) }
            }
        } catch { }
    }
    if ($env:OS -eq 'Windows_NT') {
        try {
            $a = [WDAmdAdl]::Ler()
            if ($a) {
                $g = { param($i) $v = $a[2 * $i + 1]; if ($a[2 * $i] -eq 1 -and $v -ge 10 -and $v -le 130) { [double]$v } else { $null } }
                $borda = & $g 7; $hot = & $g 26; $mem = & $g 8
                $script:DiagGpu += ("ADL borda={0} ponto-quente={1} memoria={2} " -f $borda, $hot, $mem)
                if ($borda) {
                    $rpm = $null; if ($a[2 * 13] -eq 1 -and $a[2 * 13 + 1] -gt 0 -and $a[2 * 13 + 1] -lt 20000) { $rpm = ('{0} rpm' -f $a[2 * 13 + 1]) }
                    elseif ($a[2 * 14] -eq 1 -and $a[2 * 14 + 1] -gt 0 -and $a[2 * 14 + 1] -le 100) { $rpm = ('{0}%' -f $a[2 * 14 + 1]) }
                    $pot = $null; if ($a[2 * 22] -eq 1 -and $a[2 * 22 + 1] -gt 0 -and $a[2 * 22 + 1] -lt 1000) { $pot = [double]$a[2 * 22 + 1] }
                    $clk = $null; if ($a[0] -eq 1 -and $a[1] -gt 0 -and $a[1] -lt 6000) { $clk = [double]$a[1] }
                    if ($hot -and $hot -lt $borda) { $hot = $null }   # ponto quente nunca é menor que a borda: leitura inválida
                    return @{ Temp = [int][math]::Round($borda); Hotspot = $(if ($hot) { [int][math]::Round($hot) } else { $null }); TempMem = $(if ($mem) { [int][math]::Round($mem) } else { $null }); Fan = $rpm; Potencia = $pot; Clock = $clk; Fonte = 'AMD (biblioteca do driver, a mesma fonte do AMD Software)' }
                }
            }
        } catch { }
        $melhor = $null
        for ($i = 1; $i -le 6; $i++) {
            try {
                $r = [WDGpuTemp]::Ler("\\.\DISPLAY$i")
                $script:DiagGpu += "DISPLAY$i=0x{0:X} " -f ([int]$r[0])
                if ($r[0] -eq 0 -and $r[1] -ge 100 -and $r[1] -le 1300) {
                    $t = [math]::Round($r[1] / 10.0)
                    if ($null -eq $melhor -or $t -gt $melhor.Temp) {
                        $fan = $null
                        if ($r[2] -gt 0 -and $r[2] -lt 20000) { $fan = "$($r[2]) rpm" }
                        $melhor = @{ Temp = [int]$t; Fan = $fan; Fonte = 'driver gráfico (D3DKMT)' }
                    }
                }
            } catch { }
        }
        return $melhor
    }
    return $null
}

function Get-UsoGpu3D {
    try {
        $s = (Get-Counter '\GPU Engine(*engtype_3D*)\Utilization Percentage' -ErrorAction Stop).CounterSamples
        $soma = ($s | Measure-Object CookedValue -Sum).Sum
        return [math]::Min(100, [math]::Round($soma))
    } catch { return $null }
}

$script:ScriptGpu = @'
param([string]$Saida, [int]$Seg = 6, [string]$Niveis = '20,80,240,700,1500,3000')
$ErrorActionPreference = 'Stop'
$res = @{ Ok = $false; Tier = -1; Niveis = @() }
try {
    # esconde o console desta janela auxiliar (só a animação deve aparecer)
    try {
        Add-Type -Name Con -Namespace WDChild -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int c);'
        $hw = [WDChild.Con]::GetConsoleWindow()
        if ($hw -ne [System.IntPtr]::Zero) { [void][WDChild.Con]::ShowWindow($hw, 0) }
    } catch { }
    Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
    $NS = 'System.Windows.Media.Media3D'
    $res.Tier = [int]([System.Windows.Media.RenderCapability]::Tier -shr 16)
    # malha das esferas gerada em C# (rápido, mesmo com milhões de triângulos)
    $nSeg = 24
    Add-Type -ReferencedAssemblies PresentationCore, WindowsBase -TypeDefinition @"
using System;
using System.Windows.Media.Media3D;
public static class WDMesh
{
    public static MeshGeometry3D Build(int count, int n, double raio, int seed)
    {
        Random rnd = new Random(seed);
        int vs = (n + 1) * (n + 1);
        Point3D[] pos = new Point3D[count * vs];
        Vector3D[] nor = new Vector3D[count * vs];
        int[] idx = new int[count * n * n * 6];
        Point3D[] tp = new Point3D[vs];
        for (int i = 0; i <= n; i++)
        {
            double phi = Math.PI * i / n;
            for (int j = 0; j <= n; j++)
            {
                double th = 2 * Math.PI * j / n;
                tp[i * (n + 1) + j] = new Point3D(Math.Sin(phi) * Math.Cos(th), Math.Cos(phi), Math.Sin(phi) * Math.Sin(th));
            }
        }
        int t = 0;
        for (int s = 0; s < count; s++)
        {
            double cx = (rnd.NextDouble() - 0.5) * 12, cy = (rnd.NextDouble() - 0.5) * 7, cz = (rnd.NextDouble() - 0.5) * 8;
            int bs = s * vs;
            for (int k = 0; k < vs; k++)
            {
                pos[bs + k] = new Point3D(tp[k].X * raio + cx, tp[k].Y * raio + cy, tp[k].Z * raio + cz);
                nor[bs + k] = new Vector3D(tp[k].X, tp[k].Y, tp[k].Z);
            }
            for (int i = 0; i < n; i++) for (int j = 0; j < n; j++)
            {
                int a = bs + i * (n + 1) + j; int b = a + n + 1;
                idx[t++] = a; idx[t++] = b; idx[t++] = a + 1; idx[t++] = a + 1; idx[t++] = b; idx[t++] = b + 1;
            }
        }
        MeshGeometry3D m = new MeshGeometry3D();
        m.Positions = new Point3DCollection(pos);
        m.Normals = new Vector3DCollection(nor);
        m.TriangleIndices = new System.Windows.Media.Int32Collection(idx);
        m.Freeze();
        return m;
    }
}
"@
    $cores = @('#E15759', '#4E79A7', '#59A14F', '#F28E2B')
    $mats = @()
    foreach ($c in $cores) { $m = New-Object System.Windows.Media.Media3D.DiffuseMaterial ([System.Windows.Media.SolidColorBrush][System.Windows.Media.ColorConverter]::ConvertFromString($c)); $m.Freeze(); $mats += $m }

    $grupo = New-Object "$NS.Model3DGroup"
    $rot = New-Object "$NS.AxisAngleRotation3D" -ArgumentList (New-Object "$NS.Vector3D" -ArgumentList 0, 1, 0.3), 0
    $grupo.Transform = New-Object "$NS.RotateTransform3D" -ArgumentList $rot
    $mv = New-Object "$NS.ModelVisual3D"; $mv.Content = $grupo
    $vp = New-Object System.Windows.Controls.Viewport3D
    $vp.Camera = New-Object "$NS.PerspectiveCamera" -ArgumentList (New-Object "$NS.Point3D" -ArgumentList 0, 0, 14), (New-Object "$NS.Vector3D" -ArgumentList 0, 0, -1), (New-Object "$NS.Vector3D" -ArgumentList 0, 1, 0), 50
    $vp.Children.Add($mv)
    $win = New-Object System.Windows.Window
    $win.Title = 'WinDiag - teste 3D (aguarde, fecha sozinho)'
    $win.Width = 1100; $win.Height = 700; $win.WindowStartupLocation = 'CenterScreen'; $win.Topmost = $true
    $win.Background = [System.Windows.Media.Brushes]::Black
    $win.Content = $vp

    $listaNiv = @($Niveis -split ',' | ForEach-Object { [int]$_ })
    $script:parou = $false
    $script:nivel = -1; $script:quadros = 0; $script:ultT = -1.0; $script:sw = New-Object System.Diagnostics.Stopwatch
    $script:tickN = 0
    function Montar([int]$count) {
        $grupo.Children.Clear()
        $l = New-Object "$NS.DirectionalLight" -ArgumentList ([System.Windows.Media.Colors]::White), (New-Object "$NS.Vector3D" -ArgumentList -1, -1, -1)
        $grupo.Children.Add($l)
        $grupo.Children.Add((New-Object "$NS.AmbientLight" -ArgumentList ([System.Windows.Media.Color]::FromRgb(70, 70, 70))))
        for ($k = 0; $k -lt 4; $k++) {
            $g = New-Object "$NS.GeometryModel3D"
            $g.Geometry = [WDMesh]::Build([int]($count / 4), $nSeg, 0.35, 7 + $k)
            $g.Material = $mats[$k]
            $grupo.Children.Add($g)
        }
    }
    $proximo = {
        $script:nivel++
        if ($script:nivel -ge $listaNiv.Count) { $win.Close(); return }
        Montar $listaNiv[$script:nivel]
        $script:quadros = 0; $script:sw.Restart(); $script:tickN = 0
    }
    [System.Windows.Media.CompositionTarget]::add_Rendering({
        param($s, $e)
        $t = $e.RenderingTime.TotalMilliseconds
        if ($t -ne $script:ultT) { $script:ultT = $t; $script:quadros++; $rot.Angle = ($rot.Angle + 1.2) % 360 }
    })
    $tm = New-Object System.Windows.Threading.DispatcherTimer
    $tm.Interval = [TimeSpan]::FromSeconds(1)
    $tm.Add_Tick({
        $script:tickN++
        if ($script:tickN -eq 1) { $script:quadros = 0; $script:sw.Restart(); return }   # aquecimento de 1 s
        if ($script:tickN -ge ($Seg + 1)) {
            $fps = $script:quadros / [math]::Max(0.001, $script:sw.Elapsed.TotalSeconds)
            $res.Niveis += @{ Esferas = $listaNiv[$script:nivel]; Triangulos = $listaNiv[$script:nivel] * 2 * $nSeg * $nSeg; Fps = [math]::Round($fps, 1) }
            if ($fps -lt 10 -and $script:nivel -lt ($listaNiv.Count - 1)) { $script:parou = $true; $win.Close(); return }   # já está sofrendo: não precisa piorar
            & $proximo
        }
    })
    $win.Add_ContentRendered({ & $proximo; $tm.Start() })
    [void]$win.ShowDialog()
    $res.Ok = ($res.Niveis.Count -eq $listaNiv.Count -or ($script:parou -and $res.Niveis.Count -ge 1))
} catch { $res.Erro = $_.Exception.Message }
($res | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Saida -Encoding UTF8
'@

function Invoke-BenchGpu {
    param([int]$SegPorNivel = 6, [int]$TimeoutSeg = 150, [int[]]$Niveis = @(20, 80, 240, 700, 1500, 3000))
    $TimeoutSeg = [math]::Max($TimeoutSeg, 30 + $Niveis.Count * ($SegPorNivel + 3))
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'A placa de vídeo desenhou a animação 3D normalmente.'
    $nome = 'Placa de vídeo'
    try {
        $v = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -and $_.Name -notmatch 'Basic|Remote|Virtual' })
        if ($v.Count -gt 0) { $nome = 'Placa de vídeo (' + (($v | ForEach-Object { $_.Name }) -join ' / ') + ')' }
    } catch { }

    if ($env:OS -ne 'Windows_NT') {
        return (New-ResultadoBench -Nome $nome -Estado 'nd' -Resumo 'O teste 3D só roda no Windows.' -Linhas @())
    }
    $dir = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-gpu-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $arqScript = Join-Path $dir 'gpu.ps1'
    $arqSaida = Join-Path $dir 'saida.json'
    [IO.File]::WriteAllText($arqScript, $script:ScriptGpu, (New-Object System.Text.UTF8Encoding $true))

    $t0 = Get-TempGpu
    $tMax = $null; $usoMax = $null; $fonte = $null; $fan = $null; $mtri = 0; $usos = $null
    $tHot = $null; $tMemV = $null; $potMax = $null; $clkMax = $null
    $atualizaExtra = { param($x) if ($x) {
        if ($x.Hotspot -and ($null -eq $tHot -or $x.Hotspot -gt $tHot)) { $tHot = $x.Hotspot }
        if ($x.TempMem -and ($null -eq $tMemV -or $x.TempMem -gt $tMemV)) { $tMemV = $x.TempMem }
        if ($x.Potencia -and ($null -eq $potMax -or $x.Potencia -gt $potMax)) { $potMax = $x.Potencia }
        if ($x.Clock -and ($null -eq $clkMax -or $x.Clock -gt $clkMax)) { $clkMax = $x.Clock } } }
    if ($t0) { $tMax = $t0.Temp; $fonte = $t0.Fonte; $fan = $t0.Fan; . $atualizaExtra $t0 }
    $proc = $null
    $terminou = $false
    try {
        $hg = Get-ArgsOculto ('-NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -File "{0}" -Saida "{1}" -Seg {2} -Niveis "{3}"' -f $arqScript, $arqSaida, $SegPorNivel, ($Niveis -join ','))
        $proc = Start-Process -FilePath $hg.Exe -ArgumentList $hg.Args -PassThru -WindowStyle Normal
        $limite = (Get-Date).AddSeconds($TimeoutSeg)
        $usos = New-Object System.Collections.Generic.List[double]
        $volta = 0
        while (-not $proc.HasExited -and (Get-Date) -lt $limite) {
            Start-Sleep -Milliseconds 250
            if (Test-BenchCancelado) { break }
            $volta++
            if ($volta % 6 -eq 1) {
                $tt = Get-TempGpu
                if ($tt) { if ($null -eq $tMax -or $tt.Temp -gt $tMax) { $tMax = $tt.Temp }; $fonte = $tt.Fonte; if ($tt.Fan) { $fan = $tt.Fan }; . $atualizaExtra $tt }
            }
            $u = Get-UsoGpu3D
            if ($null -ne $u) { $usos.Add([double]$u); if ($null -eq $usoMax -or $u -gt $usoMax) { $usoMax = $u } }
        }
        $terminou = $proc.HasExited
    } finally {
        try {
            if ($proc -and -not $proc.HasExited) {
                try { Get-CimInstance Win32_Process -Filter "ParentProcessId=$($proc.Id)" -ErrorAction Stop | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } catch { }
                $proc.Kill()
            }
        } catch { }
    }
    $res = $null
    try { if (Test-Path -LiteralPath $arqSaida) { $res = Get-Content -LiteralPath $arqSaida -Raw | ConvertFrom-Json } } catch { }
    try { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue } catch { }

    $r = $null
    if (-not $terminou -and -not (Test-BenchCancelado)) {
        $estado = 'problema'
        $resumo = 'O teste 3D não terminou (travou ou demorou demais).'
        $linhas.Add('A animação não concluiu no tempo esperado. Se a tela piscou ou travou, pode ser driver de vídeo instável ou placa com problema.')
        $linhas.Add('Reinstale o driver de vídeo (site da AMD/NVIDIA/Intel) e teste de novo.')
    } elseif (-not $res -or -not $res.Ok) {
        $estado = 'nd'
        $resumo = 'Não foi possível concluir o teste 3D.'
        if ($res -and $res.Erro) { $linhas.Add("Motivo: $($res.Erro)") }
    } else {
        $tier = [int]$res.Tier
        $fpsLista = @($res.Niveis | ForEach-Object { [double]$_.Fps })
        foreach ($n in @($res.Niveis)) {
            $linhas.Add(("Cena com {0} esferas ({1:N0} mil triângulos): {2:N1} quadros por segundo" -f $n.Esferas, ($n.Triangulos / 1000), [double]$n.Fps))
        }
        $linhas.Add('(A animação é limitada pela taxa de atualização do monitor, em geral 60 quadros por segundo; o que importa é quando ela começa a cair.)')
        $fpsMax = ($fpsLista | Measure-Object -Maximum).Maximum
        $fpsPior = $fpsLista[$fpsLista.Count - 1]
        if ($tier -eq 0) {
            $estado = 'problema'; $resumo = 'O Windows está desenhando em modo por software (sem usar a placa de vídeo).'
            $linhas.Add('Isso costuma ocorrer com driver de vídeo ausente, incompatível ou com falha. Instale o driver oficial da placa.')
        } elseif ($fpsMax -lt 25) {
            $estado = 'atencao'; $resumo = 'Desempenho 3D muito baixo até na cena mais leve.'
            $linhas.Add('Verifique se o driver de vídeo é o do fabricante e se o monitor está ligado na placa de vídeo (e não na saída da placa-mãe).')
        } elseif ($fpsPior -lt 20) {
            if ($nome -match 'Intel|UHD|Iris|Vega|Radeon\(TM\) Graphics|Radeon Graphics|Basic' -and $nome -notmatch 'RX|RTX|GTX|Arc A|Radeon Pro') {
                $linhas.Add('A cena mais pesada ficou lenta; é esperado em vídeo integrado.')
            } else {
                $linhas.Add('A cena mais pesada ficou lenta, mas isso é comum mesmo em placas boas: a animação (WPF) não aproveita toda a potência da placa. O número que vale é o pico de triângulos por segundo, para comparar com o seu teste anterior.')
            }
        }
        $mtri = 0
        foreach ($n in @($res.Niveis)) { $v = [double]$n.Fps * [double]$n.Triangulos / 1000000; if ($v -gt $mtri) { $mtri = $v } }
        if ($mtri -gt 0) {
            $linhas.Add(("Capacidade 3D (pico): {0:N0} milhões de triângulos por segundo" -f $mtri))
            $hg0 = Read-HistoricoBench
            if ($hg0 -and $hg0.GpuMTriS -and [double]$hg0.GpuMTriS -gt 0) {
                $dif = ($mtri / [double]$hg0.GpuMTriS) - 1
                $linhas.Add(("Comparado ao teste anterior ({0}): {1:+0%;-0%;0%}" -f $hg0.Data, $dif))
                if ($dif -lt -0.25 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = 'Desempenho 3D bem abaixo do teste anterior.' }
            }
        }
        $r = $res
    }
    if ($null -ne $usoMax) {
        $usoMed = 0; if ($usos -and $usos.Count -gt 0) { $usoMed = [math]::Round(($usos | Measure-Object -Average).Average) }
        $linhas.Add("Uso da placa durante o teste: máximo $usoMax%, média $usoMed% ($($usos.Count) leituras)")
    }
    if ($null -ne $tMax) {
        $txt = "Temperatura máxima durante o teste: $tMax °C (fonte: $fonte)"
        if ($fan) { $txt += "; ventilador: $fan" }
        $linhas.Add($txt)
        if ($tMax -ge 95) { $estado = 'problema'; $resumo = "Temperatura muito alta ($tMax °C)."; $linhas.Add('Temperatura perigosa para uma carga leve: verifique ventoinhas, poeira e fluxo de ar do gabinete.') }
        elseif ($tMax -ge 85 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = "Temperatura alta ($tMax °C)." }
        if ($tHot) {
            $linhas.Add("Temperatura do ponto mais quente (junção), máxima durante o teste: $tHot °C")
            if ($tHot -ge 105) { $estado = 'problema'; $resumo = "Ponto mais quente da placa muito alto ($tHot °C)."; $linhas.Add('Muito perto do limite da placa: verifique ventoinhas, poeira, fluxo de ar e a pasta térmica.') }
            elseif ($tHot -ge 95 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = "Ponto mais quente da placa alto ($tHot °C)." }
        }
        if ($tMemV) { $linhas.Add("Temperatura da memória de vídeo, máxima: $tMemV °C") }
        if ($potMax) { $linhas.Add(("Consumo máximo da placa durante o teste: {0:N0} W" -f $potMax)) }
        if ($clkMax) { $linhas.Add(("Clock máximo do núcleo da placa: {0:N0} MHz" -f $clkMax)) }
    } else {
        $linhas.Add('Temperatura da placa de vídeo: não foi possível ler neste computador (n/d). Nas placas NVIDIA a leitura usa o nvidia-smi; nas AMD/Intel depende do driver. Veja a temperatura no aplicativo da fabricante (ex.: AMD Software).')
        if ($script:DiagGpu) { $linhas.Add("Diagnóstico técnico da leitura: $($script:DiagGpu)") }
    }
    $linhas.Add('Não é um estresse prolongado como um jogo: serve para ver se a placa e o driver aguentam carga crescente (até cerca de ' + ('{0:N1}' -f ((($Niveis | Measure-Object -Maximum).Maximum * 1152) / 1000000)) + ' milhões de triângulos nesta máquina).')
    $out = New-ResultadoBench -Nome $nome -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    if ($r -and $mtri -gt 0) { $out.GpuMTriS = [math]::Round($mtri, 1) }
    if ($r) { $out.GpuFpsMax = ($r.Niveis | ForEach-Object { [double]$_.Fps } | Measure-Object -Maximum).Maximum; $out.GpuFpsPesado = [double]$r.Niveis[$r.Niveis.Count - 1].Fps }
    if ($null -ne $tMax) { $out.GpuTemp = $tMax }
    if ($tHot) { $out.GpuTempHotspot = $tHot }
    return $out
}

# ----------------------------------------------------------------------------
# Texto e relatório
# ----------------------------------------------------------------------------
function Get-RotuloEstadoBench {
    param([string]$Estado)
    switch ($Estado) { 'ok' { return 'OK' } 'atencao' { return 'ATENÇÃO' } 'problema' { return 'PROBLEMA' } default { return 'NÃO AVALIADO' } }
}

function Get-PiorEstadoBench {
    param([object[]]$Itens)
    $ordem = @{ ok = 0; nd = 1; atencao = 2; problema = 3 }
    $pior = 'ok'
    foreach ($i in $Itens) { if ($i -and $ordem[$i.Estado] -gt $ordem[$pior]) { $pior = $i.Estado } }
    return $pior
}

function Format-TextoBench {
    param([object[]]$Itens)
    $sb = New-Object System.Collections.Generic.List[string]
    foreach ($i in $Itens) {
        if (-not $i) { continue }
        $sb.Add(("{0}  -  {1}" -f $i.Nome.ToUpper(), (Get-RotuloEstadoBench $i.Estado)))
        $sb.Add($i.Resumo)
        foreach ($l in @($i.Linhas)) { $sb.Add("   • $l") }
        $sb.Add('')
    }
    return ($sb -join "`r`n")
}

function Export-RelatorioBench {
    param([object[]]$Itens, [string]$Pasta, [string]$Stamp)
    $arq = Join-Path $Pasta "WinDiag_Desempenho_$Stamp.html"
    $cor = @{ ok = '#15803D'; atencao = '#B45309'; problema = '#B91C1C'; nd = '#475569' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><title>WinDiag - Desempenho</title><style>body{font-family:Segoe UI,Arial,sans-serif;max-width:860px;margin:30px auto;padding:0 16px;color:#1E293B}h1{font-size:22px}.item{border:1px solid #E2E8F0;border-radius:10px;padding:14px 18px;margin:14px 0}.est{font-weight:700}li{margin:4px 0}</style></head><body><h1>WinDiag - Teste de desempenho</h1><p>$(Get-Date -Format 'dd/MM/yyyy HH:mm')</p>")
    foreach ($i in $Itens) {
        if (-not $i) { continue }
        $c = $cor[$i.Estado]
        [void]$sb.Append("<div class='item'><h2>$([System.Net.WebUtility]::HtmlEncode($i.Nome))</h2><p class='est' style='color:$c'>$(Get-RotuloEstadoBench $i.Estado): $([System.Net.WebUtility]::HtmlEncode($i.Resumo))</p><ul>")
        foreach ($l in @($i.Linhas)) { [void]$sb.Append("<li>$([System.Net.WebUtility]::HtmlEncode($l))</li>") }
        [void]$sb.Append('</ul></div>')
    }
    [void]$sb.Append('</body></html>')
    [IO.File]::WriteAllText($arq, $sb.ToString(), (New-Object System.Text.UTF8Encoding $true))
    try { ($Itens | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath (Join-Path $Pasta "WinDiag_Desempenho_$Stamp.json") -Encoding UTF8 } catch { }
    return $arq
}

# ----------------------------------------------------------------------------
# Leitura dos componentes e intensidade do teste
# ----------------------------------------------------------------------------
function Get-ArquivoAndamento { return (Join-Path (Split-Path -Parent (Get-ArquivoBench)) 'bench-andamento.json') }

function Test-ReinicioDesde {
    # $true se o Windows foi reiniciado depois de $Inicio (ou seja, o teste anterior terminou por travamento/queda e não porque o WinDiag foi fechado).
    param([datetime]$Inicio, $Boot = $null)
    try {
        if ($null -eq $Boot) { $Boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime }
        return ([datetime]$Boot -gt $Inicio)
    } catch { return $false }
}

function Clear-FlagsAntigosBench {
    # Versões até 2.15.0 marcavam "etapa fraca" também quando o usuário só fechava o WinDiag no meio do teste. Zera uma vez essas marcas.
    $h = Read-HistoricoBench
    if ($h -and $h.FlagsVersao -ge 2) { return }
    $d = @{}
    if ($h) { foreach ($p in $h.PSObject.Properties) { $d[$p.Name] = $p.Value } }
    foreach ($k in 'LeveCpu', 'LeveRam', 'LeveGpu', 'LeveDisco', 'LeveEstresse') { $d[$k] = $false }
    $d['FlagsVersao'] = 2
    Save-HistoricoBench $d
}

function Set-FlagHistoricoBench {
    param([string]$Nome, $Valor)
    $h = @{}
    $ant = Read-HistoricoBench
    if ($ant) { foreach ($p in $ant.PSObject.Properties) { $h[$p.Name] = $p.Value } }
    $h[$Nome] = $Valor
    Save-HistoricoBench $h
}

# ----------------------------------------------------------------------------
# Estresse de jogo pesado (placa de vídeo no limite + processador em carga parcial, como um jogo)
# ----------------------------------------------------------------------------
$script:ScriptEstresse = @'
param([string]$Saida, [int]$Seg = 180, [int]$MaxCamadas = 24)
$ErrorActionPreference = 'Stop'
$res = @{ Ok = $false; Shader = $false; ErroShader = ''; Amostras = @(); CamadasMax = 0; FpsAlvo = 0; Largura = 0; Altura = 0; Fechou = '' }
try {
    try {
        Add-Type -Name Con -Namespace WDChild -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int c);'
        $hw = [WDChild.Con]::GetConsoleWindow()
        if ($hw -ne [System.IntPtr]::Zero) { [void][WDChild.Con]::ShowWindow($hw, 0) }
    } catch { }
    Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
    Add-Type -ReferencedAssemblies PresentationCore, WindowsBase -TypeDefinition @"
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

public class WDHeavyEffect : ShaderEffect
{
    public static readonly DependencyProperty InputProperty = ShaderEffect.RegisterPixelShaderSamplerProperty("Input", typeof(WDHeavyEffect), 0);
    public static readonly DependencyProperty TimeProperty = DependencyProperty.Register("Time", typeof(double), typeof(WDHeavyEffect), new UIPropertyMetadata(0.0, PixelShaderConstantCallback(0)));
    public WDHeavyEffect(PixelShader ps)
    {
        this.PixelShader = ps;
        UpdateShaderValue(InputProperty);
        UpdateShaderValue(TimeProperty);
    }
    public Brush Input { get { return (Brush)GetValue(InputProperty); } set { SetValue(InputProperty, value); } }
    public double Time { get { return (double)GetValue(TimeProperty); } set { SetValue(TimeProperty, value); } }
}

public static class WDShader
{
    [DllImport("d3dcompiler_47.dll")]
    static extern int D3DCompile(byte[] src, UIntPtr len, string name, IntPtr defs, IntPtr inc, string entry, string target, uint f1, uint f2, out IntPtr code, out IntPtr err);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate IntPtr GetPtrD(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate UIntPtr GetSizeD(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint ReleaseD(IntPtr self);

    static byte[] LerBlob(IntPtr blob, out string texto)
    {
        texto = "";
        if (blob == IntPtr.Zero) return null;
        IntPtr vt = Marshal.ReadIntPtr(blob);
        GetPtrD gp = (GetPtrD)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(vt, 3 * IntPtr.Size), typeof(GetPtrD));
        GetSizeD gs = (GetSizeD)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(vt, 4 * IntPtr.Size), typeof(GetSizeD));
        ReleaseD rel = (ReleaseD)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(vt, 2 * IntPtr.Size), typeof(ReleaseD));
        IntPtr p = gp(blob);
        int n = (int)(ulong)gs(blob);
        byte[] b = new byte[n];
        if (n > 0) Marshal.Copy(p, b, 0, n);
        rel(blob);
        return b;
    }

    // Compila HLSL com o compilador que já vem no Windows (d3dcompiler_47.dll). Devolve o código do shader ou null (com o motivo em "erro").
    public static byte[] Compilar(string hlsl, string target, out string erro)
    {
        erro = "";
        try
        {
            byte[] src = System.Text.Encoding.ASCII.GetBytes(hlsl);
            IntPtr code, err;
            int hr = D3DCompile(src, (UIntPtr)(uint)src.Length, "wd.hlsl", IntPtr.Zero, IntPtr.Zero, "main", target, 0, 0, out code, out err);
            string txtErr; byte[] eb = LerBlob(err, out txtErr);
            if (eb != null) erro = System.Text.Encoding.ASCII.GetString(eb).Trim();
            if (hr < 0 || code == IntPtr.Zero) { if (erro.Length == 0) erro = "D3DCompile falhou (0x" + hr.ToString("X8") + ")"; return null; }
            string t2; return LerBlob(code, out t2);
        }
        catch (Exception ex) { erro = ex.GetType().Name + ": " + ex.Message; return null; }
    }
}
"@
    $hlsl = @"
sampler2D Input : register(s0);
float Time : register(c0);
float4 main(float2 uv : TEXCOORD0) : COLOR0
{
    float2 p = uv * 2.0 - 1.0;
    float3 acc = float3(0.0, 0.0, 0.0);
    [loop] for (int i = 0; i < 120; i++)
    {
        float f = i * 0.0173 + Time;
        p = float2(sin(p.y * 3.1 + f) + p.x * 0.31, cos(p.x * 2.7 - f) + p.y * 0.29);
        float4 t = tex2Dlod(Input, float4(frac(p * 0.25 + 0.5), 0.0, 0.0));
        acc += t.rgb * (0.5 + 0.5 * sin(p.x * p.y + f));
        acc = frac(acc * 1.01 + 0.003);
    }
    return float4(acc, 1.0);
}
"@
    $erroSh = ''
    $codigo = [WDShader]::Compilar($hlsl, 'ps_3_0', [ref]$erroSh)
    if (-not $codigo) { $res.ErroShader = "$erroSh"; throw "Não foi possível compilar o shader do teste: $erroSh" }
    $ps = New-Object System.Windows.Media.Effects.PixelShader
    $ps.SetStreamSource((New-Object System.IO.MemoryStream (, [byte[]]$codigo)))
    $res.Shader = $true

    $win = New-Object System.Windows.Window
    $win.Title = 'WinDiag - estresse (Esc para parar)'
    $win.WindowStyle = 'None'; $win.WindowState = 'Maximized'; $win.Topmost = $true
    $win.Background = [System.Windows.Media.Brushes]::Black
    $grid = New-Object System.Windows.Controls.Grid
    $win.Content = $grid
    $fundo = New-Object System.Windows.Shapes.Rectangle
    $gr = New-Object System.Windows.Media.LinearGradientBrush
    $gr.StartPoint = New-Object System.Windows.Point 0, 0; $gr.EndPoint = New-Object System.Windows.Point 1, 1
    foreach ($par in @(@('#E15759', 0.0), @('#4E79A7', 0.35), @('#59A14F', 0.7), @('#F28E2B', 1.0))) {
        [void]$gr.GradientStops.Add((New-Object System.Windows.Media.GradientStop ([System.Windows.Media.Color][System.Windows.Media.ColorConverter]::ConvertFromString($par[0])), $par[1]))
    }
    $fundo.Fill = $gr
    $aviso = New-Object System.Windows.Controls.TextBlock
    $aviso.Text = 'WinDiag - teste de estresse da placa de vídeo. Esc para parar.'
    $aviso.Foreground = [System.Windows.Media.Brushes]::White; $aviso.FontSize = 18
    $aviso.HorizontalAlignment = 'Left'; $aviso.VerticalAlignment = 'Top'; $aviso.Margin = New-Object System.Windows.Thickness 12
    $script:bordas = @(); $script:efeitos = @()
    function Montar-Camadas([int]$n) {
        foreach ($b in $script:bordas) { $b.Child = $null }
        $grid.Children.Clear()
        $script:bordas = @(); $script:efeitos = @()
        $el = $fundo
        for ($i = 0; $i -lt $n; $i++) {
            $b = New-Object System.Windows.Controls.Border
            $b.Child = $el
            $ef = New-Object WDHeavyEffect $ps
            $b.Effect = $ef
            $script:bordas += $b; $script:efeitos += $ef
            $el = $b
        }
        [void]$grid.Children.Add($el)
        [void]$grid.Children.Add($aviso)
    }
    $script:camadas = 1; $script:quadros = 0; $script:ultT = -1.0; $script:tickN = 0; $script:alvo = 0.0
    $script:travado = $false; $script:pulso = 0; $script:camadasAntes = 1; $script:t0 = [DateTime]::UtcNow
    Montar-Camadas 1
    [System.Windows.Media.CompositionTarget]::add_Rendering({
        param($s, $e)
        $t = $e.RenderingTime.TotalMilliseconds
        if ($t -ne $script:ultT) {
            $script:ultT = $t; $script:quadros++
            $tt = ([DateTime]::UtcNow - $script:t0).TotalSeconds
            foreach ($ef in $script:efeitos) { $ef.Time = $tt }
        }
    })
    $win.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Escape') { $res.Fechou = 'esc'; $win.Close() } })
    $tm = New-Object System.Windows.Threading.DispatcherTimer
    $tm.Interval = [TimeSpan]::FromSeconds(1)
    $tm.Add_Tick({
        $script:tickN++
        $fps = [double]$script:quadros; $script:quadros = 0
        if ($script:tickN -eq 1) { return }   # aquecimento
        if ($script:tickN -le 3 -and $fps -gt $script:alvo) { $script:alvo = $fps }
        $fase = 'subida'
        if ($script:travado) { $fase = 'sustentado' }
        if ($script:pulso -gt 0) { $fase = 'pulso'; $script:pulso--; if ($script:pulso -eq 0) { Montar-Camadas $script:camadasAntes; $script:camadas = $script:camadasAntes } }
        $res.Amostras += @{ T = $script:tickN; Fps = [math]::Round($fps, 1); Camadas = $script:camadas; Fase = $fase }
        if ($script:camadas -gt $res.CamadasMax) { $res.CamadasMax = $script:camadas }
        if ($script:tickN -gt 3 -and $fase -ne 'pulso') {
            if (-not $script:travado) {
                if ($fps -ge 0.9 * $script:alvo -and $script:camadas -lt $MaxCamadas) { $script:camadas++; Montar-Camadas $script:camadas }
                elseif ($fps -lt 0.7 * $script:alvo -and $script:camadas -gt 1) { $script:camadas--; Montar-Camadas $script:camadas; $script:travado = $true }
                elseif ($script:camadas -ge $MaxCamadas -or $script:tickN -ge 60) { $script:travado = $true }
            } elseif (($script:tickN % 30) -eq 0) {
                # pulso: derruba a carga por 3 s e volta (picos e quedas bruscas de consumo, como ao trocar de cena num jogo)
                $script:camadasAntes = $script:camadas; $script:pulso = 3; Montar-Camadas 1; $script:camadas = 1
            }
        }
        if ($script:tickN -ge $Seg) { $res.Fechou = 'tempo'; $win.Close() }
    })
    $win.Add_ContentRendered({
        $res.Largura = [int]$win.ActualWidth; $res.Altura = [int]$win.ActualHeight
        $script:t0 = [DateTime]::UtcNow
        $tm.Start()
    })
    [void]$win.ShowDialog()
    $res.FpsAlvo = [math]::Round($script:alvo, 1)
    $res.Ok = ($res.Amostras.Count -ge 5)
} catch { $res.Erro = $_.Exception.Message }
($res | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Saida -Encoding UTF8
'@

function Get-ResumoEstresse {
    # Interpreta as leituras feitas durante o estresse. $Leituras: lista de @{ T; Temp; Hot; Pot; Clk; Uso } (uma por segundo, aproximadamente).
    # $Amostras: quadros por segundo e camadas de carga registrados pela animação. Devolve @{ Estado; Resumo; Linhas; Uso...}.
    param($Leituras, $Amostras, [int]$Seg = 180, [int]$Camadas = 0, [int]$Largura = 0, [int]$Altura = 0, [bool]$Terminou = $true, [string]$Parada = '')
    $l = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'; $resumo = 'A placa de vídeo e o processador aguentaram o estresse sem travar.'
    $ls = @($Leituras)
    $metade = [math]::Max(0, [int]($ls.Count / 2))
    $sust = @($ls | Select-Object -Skip $metade)
    $num = { param($lst, $campo) @($lst | Where-Object { $null -ne $_.$campo } | ForEach-Object { [double]$_.$campo }) }
    $usos = & $num $sust 'Uso'; $temps = & $num $ls 'Temp'; $hots = & $num $ls 'Hot'; $pots = & $num $ls 'Pot'; $clksS = & $num $sust 'Clk'; $clksT = & $num $ls 'Clk'
    $usoMed = $null; if ($usos.Count -gt 0) { $usoMed = [math]::Round(($usos | Measure-Object -Average).Average) }
    $usoMax = $null; $uA = & $num $ls 'Uso'; if ($uA.Count -gt 0) { $usoMax = [math]::Round(($uA | Measure-Object -Maximum).Maximum) }
    $tMax = $null; if ($temps.Count -gt 0) { $tMax = ($temps | Measure-Object -Maximum).Maximum }
    $hMax = $null; if ($hots.Count -gt 0) { $hMax = ($hots | Measure-Object -Maximum).Maximum }
    $pMax = $null; if ($pots.Count -gt 0) { $pMax = ($pots | Measure-Object -Maximum).Maximum }
    $cMax = $null; if ($clksT.Count -gt 0) { $cMax = ($clksT | Measure-Object -Maximum).Maximum }
    $cMed = $null; if ($clksS.Count -gt 0) { $cMed = ($clksS | Measure-Object -Average).Average }

    $l.Add(("Estresse de jogo pesado: a placa de vídeo foi levada ao limite por {0} s, com o processador em carga parcial (cerca de 45%), como em um jogo." -f $Seg))
    if ($Camadas -gt 0) { $l.Add(("Carga gráfica: nível {0} (de até 24){1}." -f $Camadas, $(if ($Largura -gt 0) { ", tela de ${Largura}x${Altura}" } else { '' }))) }
    $fps = @($Amostras | Where-Object { $_.Fase -eq 'sustentado' } | ForEach-Object { [double]$_.Fps })
    if ($fps.Count -ge 6) {
        $m = [int]($fps.Count / 2)
        $a = ($fps | Select-Object -First $m | Measure-Object -Average).Average; $b = ($fps | Select-Object -Skip $m | Measure-Object -Average).Average
        $l.Add(("Quadros por segundo sustentados: {0:N0} na primeira metade e {1:N0} na segunda." -f $a, $b))
        if ($a -gt 0 -and ($b / $a) -lt 0.85) { $estado = 'atencao'; $resumo = 'O desempenho da placa caiu durante o estresse.'; $l.Add('Uma queda de desempenho com o tempo costuma indicar redução de clock por temperatura ou por limite de consumo.') }
    }
    if ($null -ne $usoMed) {
        $l.Add(("Uso da placa na parte sustentada: média {0}% (máximo {1}%)." -f $usoMed, $usoMax))
        if ($usoMed -lt 80) { $l.Add('A placa não chegou perto de 100%: o estresse pode não ter reproduzido a carga de um jogo pesado neste computador.') }
    }
    if ($null -ne $tMax) {
        $l.Add(("Temperatura máxima da placa: {0:N0} °C{1}." -f $tMax, $(if ($null -ne $hMax) { (", ponto quente {0:N0} °C" -f $hMax) } else { '' })))
        if ($tMax -ge 90 -or ($null -ne $hMax -and $hMax -ge 105)) { $estado = 'problema'; $resumo = 'A placa de vídeo esquentou demais durante o estresse.'; $l.Add('Verifique ventoinhas, poeira, fluxo de ar do gabinete e a pasta térmica da placa.') }
        elseif ($tMax -ge 83 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = 'A placa de vídeo ficou bem quente durante o estresse.' }
    }
    if ($null -ne $pMax) { $l.Add(("Consumo máximo da placa: {0:N0} W." -f $pMax)) }
    if ($null -ne $cMax -and $null -ne $cMed) {
        $l.Add(("Clock do núcleo: máximo {0:N0} MHz; na parte sustentada, média {1:N0} MHz." -f $cMax, $cMed))
        if ($cMed -lt 0.85 * $cMax -and $null -ne $tMax -and $tMax -ge 75) { if ($estado -eq 'ok') { $estado = 'atencao'; $resumo = 'A placa reduziu o clock por temperatura durante o estresse.' }; $l.Add('O clock caiu em relação ao máximo com a placa quente: sinal de limitação térmica.') }
    }
    if (-not $Terminou) {
        $estado = 'problema'; $resumo = 'O estresse não terminou: a animação travou ou demorou demais.'
        $l.Add('A animação não concluiu no tempo esperado. Se a tela travou ou piscou, pode ser driver de vídeo instável ou placa com problema.')
    }
    if ($Parada) { $l.Add($Parada) }
    $r = @{ Estado = $estado; Resumo = $resumo; Linhas = $l.ToArray(); UsoMedio = $usoMed; TempMax = $tMax; PotMax = $pMax }
    return $r
}

function Invoke-BenchEstresse {
    # Roda a animação pesada (shader compilado na hora pelo compilador do Windows) enquanto o processador recebe carga parcial.
    param([int]$Seg = 180, [int]$MaxCamadas = 24, [int]$TempLimite = 93)
    $nome = 'Estresse de jogo pesado'
    $v = $null
    try {
        $v = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -and $_.Name -notmatch 'Basic|Remote|Virtual' })
        if ($v.Count -gt 0) { $nome = 'Estresse de jogo pesado (' + (($v | ForEach-Object { $_.Name }) -join ' / ') + ')' }
    } catch { }
    if ($env:OS -ne 'Windows_NT') { return (New-ResultadoBench -Nome $nome -Estado 'nd' -Resumo 'O estresse só roda no Windows.' -Linhas @()) }
    $dir = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-estresse-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $arqScript = Join-Path $dir 'estresse.ps1'; $arqSaida = Join-Path $dir 'saida.json'
    [IO.File]::WriteAllText($arqScript, $script:ScriptEstresse, (New-Object System.Text.UTF8Encoding $true))
    $leituras = New-Object System.Collections.Generic.List[object]
    $proc = $null; $terminou = $false; $parada = ''
    $hilos = [math]::Max(1, [int][math]::Floor([Environment]::ProcessorCount * 0.75))
    try {
        try { [WDCarga]::Iniciar($Seg + 20, $hilos, 60) } catch { }
        $hg = Get-ArgsOculto ('-NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -File "{0}" -Saida "{1}" -Seg {2} -MaxCamadas {3}' -f $arqScript, $arqSaida, $Seg, $MaxCamadas)
        $proc = Start-Process -FilePath $hg.Exe -ArgumentList $hg.Args -PassThru -WindowStyle Normal
        $t0 = Get-Date
        $limite = $t0.AddSeconds($Seg + 60)
        while (-not $proc.HasExited -and (Get-Date) -lt $limite) {
            Start-Sleep -Milliseconds 700
            if (Test-BenchCancelado) { $parada = 'O teste foi cancelado.'; break }
            $g = Get-TempGpu
            $u = Get-UsoGpu3D
            $leituras.Add(@{ T = ((Get-Date) - $t0).TotalSeconds; Temp = $(if ($g) { $g.Temp }); Hot = $(if ($g) { $g.Hotspot }); Pot = $(if ($g) { $g.Potencia }); Clk = $(if ($g) { $g.Clock }); Uso = $u })
            if ($g -and (($g.Temp -ge $TempLimite) -or ($g.Hotspot -and $g.Hotspot -ge 107))) {
                $parada = "Estresse interrompido por segurança: a placa chegou a $($g.Temp) °C."
                break
            }
        }
        $terminou = $proc.HasExited
    } finally {
        try { [WDCarga]::Encerrar() } catch { }
        try { if ($proc -and -not $proc.HasExited) { $proc.Kill() } } catch { }
    }
    $res = $null
    try { if (Test-Path -LiteralPath $arqSaida) { $res = Get-Content -LiteralPath $arqSaida -Raw | ConvertFrom-Json } } catch { }
    try { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue } catch { }

    if ($parada -and $parada -match 'segurança') { $terminou = $true }
    if (-not $terminou -and -not (Test-BenchCancelado)) {
        $x = Get-ResumoEstresse -Leituras $leituras.ToArray() -Amostras @() -Seg $Seg -Terminou $false -Parada $parada
        return (New-ResultadoBench -Nome $nome -Estado $x.Estado -Resumo $x.Resumo -Linhas $x.Linhas)
    }
    if (-not $res -or -not $res.Ok) {
        $linhas = New-Object System.Collections.Generic.List[string]
        if ($res -and $res.Erro) { $linhas.Add("Motivo: $($res.Erro)") }
        if ($res -and $res.ErroShader) { $linhas.Add('O compilador de shaders do Windows (d3dcompiler_47.dll) não conseguiu preparar a animação pesada neste computador.') }
        $linhas.Add('O resto do teste de desempenho não foi afetado. Para estressar a placa com mais força, use o OCCT ou o FurMark (em Ferramentas de reparo > Testes de estresse externos).')
        return (New-ResultadoBench -Nome $nome -Estado 'nd' -Resumo 'Não foi possível rodar o estresse pesado.' -Linhas $linhas.ToArray())
    }
    $x = Get-ResumoEstresse -Leituras $leituras.ToArray() -Amostras @($res.Amostras) -Seg $Seg -Camadas ([int]$res.CamadasMax) -Largura ([int]$res.Largura) -Altura ([int]$res.Altura) -Terminou $true -Parada $parada
    $out = New-ResultadoBench -Nome $nome -Estado $x.Estado -Resumo $x.Resumo -Linhas $x.Linhas
    if ($null -ne $x.UsoMedio) { $out.EstresseUsoMed = $x.UsoMedio }
    if ($null -ne $x.TempMax) { $out.EstresseTempMax = [math]::Round($x.TempMax) }
    if ($null -ne $x.PotMax) { $out.EstressePotMax = [math]::Round($x.PotMax) }
    return $out
}

function Get-PerfilTeste {
    # Lê o computador (memória, núcleos, tipo, bateria, placa de vídeo, disco) e escolhe a intensidade do teste.
    # Objetivo: o mesmo teste não pode ser igual para um desktop potente e para um notebook simples (que pode travar ou desligar).
    param([bool]$Longo = $false, [string]$FalhaAnterior = '')
    $p = @{
        RamTotalMB = 0; RamLivreMB = 0; Nucleos = [Environment]::ProcessorCount; Cpu = ''
        Notebook = $false; NaBateria = $false; Carga = $null
        Gpus = @(); TemDedicada = $false; TemIntegrada = $false; CapGpu = $false
        DiscoLivreMB = 0; TempOciosa = $null
        Intensidade = 'Total'; Motivos = (New-Object System.Collections.Generic.List[string])
    }
    if ($env:OS -eq 'Windows_NT') {
        try { $p.RamTotalMB = [int]((Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory / 1MB) } catch { }
        try { $p.Cpu = ("$((Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).Name)" -replace '\s+', ' ').Trim() } catch { }
        try {
            $ch = @((Get-CimInstance Win32_SystemEnclosure -ErrorAction Stop).ChassisTypes)
            if (@($ch | Where-Object { $_ -in 8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32 }).Count -gt 0) { $p.Notebook = $true }
        } catch { }
        try {
            $b = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
            if ($b.Count -gt 0) {
                $p.Notebook = $true
                if ($b[0].EstimatedChargeRemaining -ne $null) { $p.Carga = [int]$b[0].EstimatedChargeRemaining }
                if ([int]$b[0].BatteryStatus -eq 1) { $p.NaBateria = $true }
            }
        } catch { }
        try {
            $v = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -and $_.Name -notmatch 'Basic|Remote|Virtual|Mirage|Parsec' })
            $p.Gpus = @($v | ForEach-Object { "$($_.Name)".Trim() })
            foreach ($n in $p.Gpus) {
                if ($n -match 'RX \d|RTX|GTX|Arc A|Radeon Pro|Quadro|Radeon VII|Titan') { $p.TemDedicada = $true }
                elseif ($n -match 'Intel|UHD|Iris|Vega|Radeon\(TM\) Graphics|Radeon Graphics|Radeon 6\d\dM|Radeon 7\d\dM') { $p.TemIntegrada = $true }
                else { $p.TemDedicada = $true }
            }
        } catch { }
    }
    $p.RamLivreMB = Get-LivreMB
    try { $p.DiscoLivreMB = [int]([IO.DriveInfo]::new([IO.Path]::GetPathRoot([IO.Path]::GetTempPath())).AvailableFreeSpace / 1MB) } catch { }
    try { $s = Get-SensoresExternos; if ($s) { $p.TempOciosa = Get-TempExterna $s 'Processador' } } catch { }
    # Em notebook híbrido o Windows desenha na placa integrada por padrão; em desktop com placa dedicada, vale a dedicada.
    $p.CapGpu = (-not $p.TemDedicada) -or ($p.Notebook -and $p.TemIntegrada)

    # Intensidade
    $nivel = 2   # 2 = Total, 1 = Moderada, 0 = Leve
    $baixa = { param($n, $motivo) if ($n -lt $nivel) { Set-Variable -Name nivel -Value $n -Scope 1 }; $p.Motivos.Add($motivo) }
    if ($p.RamTotalMB -gt 0 -and $p.RamTotalMB -le 4096) { & $baixa 0 'Pouca memória (4 GB ou menos).' }
    elseif ($p.RamTotalMB -gt 0 -and $p.RamTotalMB -le 8192) { & $baixa 1 'Memória de 8 GB ou menos.' }
    if ($p.Nucleos -le 2) { & $baixa 0 'Processador com 2 threads ou menos.' }
    elseif ($p.Nucleos -le 4) { & $baixa 1 'Processador com poucos núcleos.' }
    if ($p.Notebook) { & $baixa 1 'É um notebook (esquenta mais e tem menos folga de refrigeração).' }
    if ($p.CapGpu -and $p.Notebook -and $p.RamTotalMB -gt 0 -and $p.RamTotalMB -le 8192) { & $baixa 0 'Notebook com vídeo integrado e pouca memória.' }
    elseif ($p.CapGpu) { & $baixa 1 'Vídeo integrado (divide a memória com o sistema).' }
    if ($p.RamLivreMB -gt 0 -and $p.RamLivreMB -lt 2048) { & $baixa 0 'Pouca memória livre agora (menos de 2 GB).' }
    if ($p.NaBateria) {
        & $baixa 1 'Está na bateria: ligue na tomada para um resultado confiável.'
        if ($null -ne $p.Carga -and $p.Carga -lt 30) { & $baixa 0 "Bateria com $($p.Carga)%: o teste usa o computador no máximo." }
    }
    if ($null -ne $p.TempOciosa -and $p.TempOciosa -ge 80) { & $baixa 0 "O processador já está a $([math]::Round($p.TempOciosa)) °C antes do teste." }
    if ($FalhaAnterior) { & $baixa 0 "O teste anterior não terminou (o computador travou, reiniciou ou o WinDiag foi fechado durante: $FalhaAnterior)." }
    $p.Intensidade = @('Leve', 'Moderada', 'Total')[$nivel]

    # Parâmetros de cada teste
    $livre = [int]$p.RamLivreMB
    if ($livre -le 0) { $livre = 1024 }   # não deu para ler: assume pouco
    switch ($p.Intensidade) {
        'Leve'     { $p.RamLimiteMB = [int][math]::Min(512, [math]::Floor($livre * 0.3 / 64) * 64); $p.SegMulti = 8;  $p.Niveis = @(20, 80, 240);                     $p.DiscoMB = 256 }
        'Moderada' { $p.RamLimiteMB = [int][math]::Min(2048, [math]::Floor($livre * 0.4 / 64) * 64); $p.SegMulti = 12; $p.Niveis = $(if ($p.CapGpu) { @(20, 80, 240, 700) } else { @(20, 80, 240, 700, 1500) }); $p.DiscoMB = 512 }
        default    { $p.RamLimiteMB = 8192; $p.SegMulti = 12; $p.Niveis = @(20, 80, 240, 700, 1500, 3000); $p.DiscoMB = 1024 }
    }
    $p.RamPassadas = 1; $p.EstresseSeg = 0
    $p.EstresseSeg = $(if ($p.Intensidade -eq 'Moderada') { 120 } elseif ($p.Intensidade -eq 'Leve') { 60 } else { 180 })   # quem escolhe o estresse recebe um mais curto no modo Leve, não uma recusa
    if ($Longo -and $p.Intensidade -ne 'Leve') { $p.RamPassadas = 4 }
    if ($Longo -and $p.Intensidade -ne 'Leve') { $p.SegMulti = $(if ($p.Intensidade -eq 'Moderada') { 90 } else { 180 }) }
    if ($livre -lt 3072) { $p.Niveis = @($p.Niveis | Where-Object { $_ -le 700 }) }   # malhas grandes ocupam centenas de MB
    # Etapa que já falhou antes: mantém leve nela
    $h = Read-HistoricoBench
    if ($h) {
        if ($h.LeveCpu) { $p.SegMulti = [math]::Min($p.SegMulti, 8) }
        if ($h.LeveRam) { $p.RamLimiteMB = [int][math]::Min($p.RamLimiteMB, 512) }
        if ($h.LeveGpu) { $p.Niveis = @(20, 80, 240) }
        # o estresse nunca é recusado: quem escolhe esse teste quer justamente reproduzir o travamento (a janela de escolha já avisa)
        if ($h.LeveDisco) { $p.DiscoMB = 256 }
        if ($h.LeveCpu -or $h.LeveRam -or $h.LeveGpu -or $h.LeveEstresse -or $h.LeveDisco) { $p.Motivos.Add('Em um teste anterior o computador travou numa etapa: ela segue em intensidade leve neste computador.') }
    }
    return $p
}

function Get-ItemPerfil {
    param($Perfil, [string]$FalhaAnterior)
    $l = New-Object System.Collections.Generic.List[string]
    if ($Perfil.Cpu) { $l.Add("Processador: $($Perfil.Cpu) ($($Perfil.Nucleos) threads)") }
    if ($Perfil.RamTotalMB -gt 0) { $l.Add(("Memória: {0:N1} GB instalados, {1:N1} GB livres agora" -f ($Perfil.RamTotalMB / 1024), ($Perfil.RamLivreMB / 1024))) }
    if ($Perfil.Gpus.Count -gt 0) { $l.Add('Placa(s) de vídeo: ' + ($Perfil.Gpus -join ' · ') + $(if ($Perfil.CapGpu) { ' (a animação roda no vídeo integrado)' } else { '' })) }
    $tipo = $(if ($Perfil.Notebook) { 'notebook ou portátil' } else { 'computador de mesa' })
    $bat = ''
    if ($Perfil.Notebook) { if ($Perfil.NaBateria) { $bat = ', na bateria' } else { $bat = ', na tomada' }; if ($null -ne $Perfil.Carga) { $bat += " ($($Perfil.Carga)%)" } }
    $l.Add("Tipo: $tipo$bat")
    if ($Perfil.DiscoLivreMB -gt 0) { $l.Add(("Espaço livre no disco do teste: {0:N0} GB" -f ($Perfil.DiscoLivreMB / 1024))) }
    $l.Add("Intensidade escolhida: $($Perfil.Intensidade)")
    foreach ($m in $Perfil.Motivos) { $l.Add("Motivo: $m") }
    $l.Add(("Ajustes: memória até {0} MB · processador {1} s com todos os núcleos · 3D até {2} esferas · disco {3} MB" -f $Perfil.RamLimiteMB, $Perfil.SegMulti, (($Perfil.Niveis | Measure-Object -Maximum).Maximum), $Perfil.DiscoMB))
    $estado = 'ok'; $resumo = "O WinDiag leu o computador e usou a intensidade $($Perfil.Intensidade)."
    if ($FalhaAnterior) { $estado = 'atencao'; $resumo = 'O teste anterior não terminou; desta vez a intensidade foi reduzida.' }
    elseif ($Perfil.Intensidade -eq 'Leve') { $resumo = 'Computador mais fraco ou esquentando: o teste foi feito em intensidade leve, para não travar.' }
    return (New-ResultadoBench -Nome 'Leitura do computador' -Estado $estado -Resumo $resumo -Linhas $l.ToArray())
}

function New-ResumoBench {
    # Uma visão geral no topo do relatório: os números principais de cada teste e a diferença para o teste anterior.
    param([object[]]$Itens, $Anterior)
    $l = New-Object System.Collections.Generic.List[string]
    foreach ($i in $Itens) {
        if (-not $i) { continue }
        if ($i.CpuMulti) { $tcx = ''; if ($i.CpuTempMax) { $tcx = ", até $($i.CpuTempMax) °C" }; $l.Add(("Processador: {0:N0} pontos com todos os núcleos ({1:N0} com um núcleo){3}{2}" -f $i.CpuMulti, $i.CpuUnico, (Get-DeltaTexto ([double]$i.CpuMulti) $(if ($Anterior -and (($Anterior.CpuSeg -and [int]$Anterior.CpuSeg -eq [int]$i.CpuSeg) -or (-not $Anterior.CpuSeg -and [int]$i.CpuSeg -le 12))) { $Anterior.CpuMulti })), $tcx)) }
        if ($i.RamLeituraMBs) {
            $pct = ''; if ($i.RamPctTeorico) { $pct = ", {0}% do teórico" -f $i.RamPctTeorico }
            $l.Add(("Memória RAM: leitura de {0:N1} GB/s{1}{2}; erros: {3}" -f ($i.RamLeituraMBs / 1024), $pct, (Get-DeltaTexto ([double]$i.RamLeituraMBs) $(if ($Anterior) { $Anterior.RamLeituraMBs })), $i.RamErros))
        }
        if ($i.DiscoLeituraMBs) {
            $fila = ''; if ($i.DiscoLeituraFilaMBs) { $fila = (", máxima com fila {0:N0} MB/s" -f $i.DiscoLeituraFilaMBs) }
            $l.Add(("Disco: leitura {0:N0} MB/s, escrita {1:N0} MB/s{2}{3}" -f $i.DiscoLeituraMBs, $i.DiscoEscritaMBs, $fila, (Get-DeltaTexto ([double]$i.DiscoLeituraMBs) $(if ($Anterior) { $Anterior.DiscoLeituraMBs }))))
        }
        if ($i.EstresseTempMax -or $i.EstresseUsoMed) { $l.Add(('Estresse de jogo pesado: placa a {0}% de uso em média{1}{2}' -f $i.EstresseUsoMed, $(if ($i.EstresseTempMax) { ", até $($i.EstresseTempMax) °C" } else { '' }), $(if ($i.EstressePotMax) { ", até $($i.EstressePotMax) W" } else { '' }))) }
        if ($i.GpuMTriS) { $l.Add(("Placa de vídeo: pico de {0:N0} milhões de triângulos por segundo{1}" -f $i.GpuMTriS, (Get-DeltaTexto ([double]$i.GpuMTriS) $(if ($Anterior) { $Anterior.GpuMTriS })))) }
    }
    if ($l.Count -eq 0) { return $null }
    $pior = Get-PiorEstadoBench -Itens $Itens
    $txt = switch ($pior) { 'problema' { 'Há problema em pelo menos um teste: veja abaixo.' } 'atencao' { 'Há pontos de atenção: veja abaixo.' } default { 'Nenhum problema encontrado nos testes.' } }
    $l.Add('Os pontos e as velocidades servem para comparar este computador com ele mesmo ao longo do tempo.')
    return (New-ResultadoBench -Nome 'Resumo do teste' -Estado $(if ($pior -eq 'nd') { 'ok' } else { $pior }) -Resumo $txt -Linhas $l.ToArray())
}

function Invoke-BenchCompleto {
    # Roda os testes escolhidos. $Etapa é um scriptblock opcional chamado com (N, Total, Texto) antes de cada teste.
    param([string[]]$Testes = @('cpu', 'ram', 'disco', 'gpu'), [scriptblock]$Etapa, [switch]$Longo, [switch]$Estresse, [string]$PastaMonitor = '')
    $itens = New-Object System.Collections.Generic.List[object]
    $anterior = Read-HistoricoBench   # lido antes de os testes gravarem o novo histórico
    # Se o teste anterior não terminou (travou, reiniciou ou foi fechado), esta etapa passa a rodar em intensidade leve
    $falha = ''
    $arqAnd = Get-ArquivoAndamento
    try { Clear-FlagsAntigosBench } catch { }
    try {
        if (Test-Path -LiteralPath $arqAnd) {
            $m = Get-Content -LiteralPath $arqAnd -Raw -ErrorAction Stop | ConvertFrom-Json
            $falha = "$($m.Etapa)"
            if (-not $falha) { $falha = 'início' }
            # só conta como falha se o Windows reiniciou depois do início desse teste; se o WinDiag só foi fechado, não é falha
            $inicioAnt = $null; try { $inicioAnt = [datetime]$m.Inicio } catch { }
            if (-not $inicioAnt -or -not (Test-ReinicioDesde $inicioAnt)) { $falha = '' }
            $mapa = @{ cpu = 'LeveCpu'; ram = 'LeveRam'; gpu = 'LeveGpu'; disco = 'LeveDisco'; estresse = 'LeveEstresse' }
            if ($falha -and $mapa.ContainsKey($falha)) { Set-FlagHistoricoBench $mapa[$falha] $true }
            Remove-Item -LiteralPath $arqAnd -Force -ErrorAction SilentlyContinue
        }
    } catch { }
    if ($Etapa) { & $Etapa 0 $Testes.Count 'Lendo os componentes do computador para escolher a intensidade do teste' }
    if ($Estresse -and $Testes -notcontains 'estresse') { $Testes = @($Testes) + 'estresse' }
    $perfil = Get-PerfilTeste -Longo ([bool]$Longo) -FalhaAnterior $falha
    if ($Testes -contains 'estresse' -and $perfil.EstresseSeg -le 0) {
        $Testes = @($Testes | Where-Object { $_ -ne 'estresse' })
        $perfil.Motivos.Add('O estresse de jogo pesado foi pulado: o computador travou ou reiniciou durante um estresse anterior.')
        $estresseMotivo = @($perfil.Motivos | Where-Object { $_ -notmatch 'estresse de jogo pesado foi pulado' })
        $estressePulado = New-ResultadoBench -Nome 'Estresse de jogo pesado' -Estado 'atencao' -Resumo 'O estresse de jogo pesado NÃO foi executado.' -Linhas (@('O computador travou ou reiniciou durante um estresse anterior, então o WinDiag não repete o estresse sozinho (por segurança).') + @($estresseMotivo | ForEach-Object { "Motivo: $_" }) + @('Para liberar de novo, apague a pasta %LOCALAPPDATA%\\WinDiag (ou o arquivo de histórico do teste de desempenho) e rode outra vez. Ou use o OCCT ou o FurMark (Ferramentas de reparo > Testes de estresse externos).'))
    }
    $itemPerfil = Get-ItemPerfil -Perfil $perfil -FalhaAnterior $falha
    $anterior = Read-HistoricoBench
    function Marcar-Andamento([string]$et) { try { $d = Split-Path -Parent $arqAnd; if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }; (@{ Etapa = $et; Inicio = (Get-Date -Format 's') } | ConvertTo-Json) | Set-Content -LiteralPath $arqAnd -Encoding UTF8 } catch { } }
    $rotulos = @{ cpu = $(if ($Longo) { 'Testando o processador (teste longo: cerca de 3 minutos)' } else { 'Testando o processador' }); ram = 'Testando a memória RAM'; disco = 'Testando o disco (velocidade e saúde)'; gpu = 'Testando a placa de vídeo (uma janela com animação vai abrir)'; estresse = 'Estresse de jogo pesado: placa de vídeo no limite (tela cheia, não mexa no computador)' }
    # Gravação automática (monitor) durante os testes pesados: se o computador travar ou desligar, o que aconteceu fica no registro
    $monitorIniciado = $false
    if (($Testes -contains 'estresse' -or $Longo) -and $PastaMonitor) {
        try { if (-not (Test-MonitorAtivo)) { Start-Monitor -Pasta $PastaMonitor -Intervalo 0.5 | Out-Null; $monitorIniciado = $true } } catch { }
    }
    $n = 0
    foreach ($t in $Testes) {
        if (Test-BenchCancelado) { break }
        $n++
        if ($Etapa) { & $Etapa $n $Testes.Count $rotulos[$t] }
        Marcar-Andamento $t
        try {
            switch ($t) {
                'cpu' { $itens.Add((Invoke-BenchCpu -SegMulti $perfil.SegMulti)) }
                'ram' { $itens.Add((Invoke-BenchRam -LimiteMB $perfil.RamLimiteMB -Passadas $perfil.RamPassadas)) }
                'disco' { $itens.Add((Invoke-BenchDisco -MaxMB $perfil.DiscoMB)) }
                'gpu' { $itens.Add((Invoke-BenchGpu -Niveis $perfil.Niveis)) }
                'estresse' { $itens.Add((Invoke-BenchEstresse -Seg $perfil.EstresseSeg)) }
            }
        } catch {
            $itens.Add((New-ResultadoBench -Nome $rotulos[$t] -Estado 'nd' -Resumo 'O teste falhou.' -Linhas @($_.Exception.Message)))
        }
    }
    try { Remove-Item -LiteralPath $arqAnd -Force -ErrorAction SilentlyContinue } catch { }
    if ($monitorIniciado) { try { Stop-Monitor | Out-Null; $itens.Add((New-ResultadoBench -Nome 'Gravação durante o teste' -Estado 'ok' -Resumo 'A gravação do monitor foi ligada sozinha durante os testes pesados e desligada ao fim.' -Linhas @('Se o computador travar ou desligar no meio, abra Ferramentas de reparo > Monitor em tempo real > Ver o que aconteceu.'))) } catch { } }
    if (-not (Test-BenchCancelado)) { $sx = Get-ItemSensores (Get-SensoresExternos); if ($sx) { $itens.Add($sx) } }
    if (-not (Test-BenchCancelado)) { $ws = Get-ItemNotasWinSAT; if ($ws) { $itens.Add($ws) } }
    if ($estressePulado) { $itens.Add($estressePulado) }
    $itens.Insert(0, $itemPerfil)
    $resumoGeral = New-ResumoBench -Itens $itens.ToArray() -Anterior $anterior
    if ($resumoGeral) { $itens.Insert(0, $resumoGeral) }
    # histórico para comparar na próxima vez
    $h = @{ Data = (Get-Date -Format 'dd/MM/yyyy') }
    foreach ($i in $itens) {
        if ($i.CpuMulti) { $h.CpuMulti = $i.CpuMulti; $h.CpuUnico = $i.CpuUnico; $h.CpuSeg = $i.CpuSeg }
        if ($i.RamLeituraMBs) { $h.RamLeituraMBs = $i.RamLeituraMBs }
        if ($i.GpuFpsPesado) { $h.GpuFpsPesado = $i.GpuFpsPesado }
        if ($i.GpuMTriS) { $h.GpuMTriS = $i.GpuMTriS }
        if ($i.DiscoLeituraMBs) { $h.DiscoLeituraMBs = $i.DiscoLeituraMBs; $h.DiscoEscritaMBs = $i.DiscoEscritaMBs }
    }
    if ($h.Count -gt 1) {
        $ant = Read-HistoricoBench
        if ($ant) { foreach ($p in $ant.PSObject.Properties) { if (-not $h.ContainsKey($p.Name)) { $h[$p.Name] = $p.Value } } }
        Save-HistoricoBench $h
    }
    return $itens.ToArray()
}
