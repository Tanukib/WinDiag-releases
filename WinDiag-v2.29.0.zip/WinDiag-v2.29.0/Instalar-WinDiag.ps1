﻿# Instalar-WinDiag.ps1: nome antigo mantido so para compatibilidade com o Atualizar-WinDiag.ps1 de versoes
# anteriores (ate a 2.28.2), que procura este arquivo por esse nome exato apos extrair o pacote.
# So existe neste pacote de transicao; nao faz parte do projeto a partir de agora.
param([switch]$SemPerguntas, [switch]$ComoAdministrador, [string]$Destino)
& (Join-Path $PSScriptRoot 'Instalar-Telomera.ps1') @PSBoundParameters
