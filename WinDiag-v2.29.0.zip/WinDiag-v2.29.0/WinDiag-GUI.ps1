﻿# WinDiag-GUI.ps1: nome antigo mantido so para compatibilidade com o Atualizar-WinDiag.ps1 de versoes
# anteriores (ate a 2.28.2), que procura este arquivo por esse nome para achar a pasta do pacote baixado.
# So existe neste pacote de transicao; nao faz parte do projeto a partir de agora.
& (Join-Path $PSScriptRoot 'Telomera-GUI.ps1') @args
