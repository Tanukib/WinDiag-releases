// TelomeraLauncher: um .exe nativo que só existe para dar ao Telomera uma "porta de entrada" normal de
// aplicativo do Windows (ícone, versão, atalho que abre direto) e então chamar os scripts de sempre
// (WinDiag-GUI.ps1 — o arquivo continua com esse nome; só a marca visível mudou).
// Não reescreve o Telomera em C#; só substitui o "duplo-clique no .bat" por um .exe assinado.
//
// O manifesto (app.manifest) pede "asInvoker" (não força administrador): quem decide isso é o próprio
// WinDiag-GUI.ps1, que já se reabre elevado sozinho quando necessário e, se o usuário recusar o UAC,
// continua aberto em modo somente leitura. Forçar administrador aqui no .exe removeria essa opção.
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class TelomeraLauncher
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            string pastaExe = Path.GetDirectoryName(Application.ExecutablePath) ?? Environment.CurrentDirectory;
            string script = Path.Combine(pastaExe, "WinDiag-GUI.ps1");
            if (!File.Exists(script))
            {
                MessageBox.Show(
                    "Não encontrei o WinDiag-GUI.ps1 ao lado do Telomera.exe." + Environment.NewLine +
                    "Pasta esperada: " + pastaExe,
                    "Telomera", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            string argumentos = "-NoProfile -ExecutionPolicy Bypass -File \"" + script + "\"";
            foreach (string a in args)
            {
                // Repassa qualquer argumento recebido (ex.: -Agendada) direto para o script, entre aspas.
                argumentos += " \"" + a.Replace("\"", "\\\"") + "\"";
            }

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = argumentos,
                UseShellExecute = false,
                WorkingDirectory = pastaExe,
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true
            };
            Process.Start(psi);
            return 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não consegui iniciar o Telomera:" + Environment.NewLine + Environment.NewLine + ex.Message,
                "Telomera", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
