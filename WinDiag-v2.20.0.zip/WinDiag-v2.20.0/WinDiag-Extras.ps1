﻿# WinDiag-Extras.ps1
# Verificações extras (telas azuis, segurança, bateria, espaço, rede), ferramentas de reparo e restauração,
# comparação com a verificação anterior e histórico de alterações.
# Carregado pelo WinDiag.ps1 (depois das funções principais). Usa Add-Achado, Add-Acao, Confirm-Acao e Add-Alteracao do motor.

# ----------------------------------------------------------------------------
# Dados persistentes (ficam em %LOCALAPPDATA%\WinDiag)
# ----------------------------------------------------------------------------
function Get-ArquivoDados {
    param([string]$Nome)
    $base = $env:WD_DADOS_DIR
    if (-not $base) {
        $la = $env:LOCALAPPDATA
        if (-not $la) { $la = [IO.Path]::GetTempPath() }
        $base = Join-Path $la 'WinDiag'
    }
    return (Join-Path $base $Nome)
}

function Save-LogAlteracao {
    # Acrescenta uma linha por alteração em alteracoes.jsonl: é o histórico de tudo que o WinDiag já mudou neste computador.
    param([string]$Acao, [string]$Resultado, [string]$Quando)
    try {
        $f = Get-ArquivoDados 'alteracoes.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $linha = (@{ Quando = $Quando; Acao = $Acao; Resultado = $Resultado } | ConvertTo-Json -Compress)
        [IO.File]::AppendAllText($f, $linha + "`r`n", (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Get-HistoricoAlteracoes {
    $f = Get-ArquivoDados 'alteracoes.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-DicaDesfazer {
    # Como desfazer, conforme o tipo de alteração.
    param([string]$Acao)
    if ($Acao -match '(?i)bloqueio|exclus') { return 'Para desfazer: "Desfazer bloqueios de driver do WinDiag" (Ferramentas de reparo > Desfazer o que o WinDiag fez).' }
    if ($Acao -match '(?i)driver|pacote|restaurar c') { return 'Para desfazer: "Desfazer correções (restaurar drivers salvos)" ou a Restauração do Sistema.' }
    if ($Acao -match '(?i)tempor|limpeza') { return 'Não há como desfazer: eram arquivos temporários, que o Windows recria quando precisa.' }
    if ($Acao -match '(?i)backup|c.pia dos arquivos') { return 'Não altera nada no computador: é só uma cópia de arquivos.' }
    if ($Acao -match '(?i)rede|winsock|dns') { return 'Normalmente não precisa desfazer. Se perdeu uma configuração de rede fixa, refaça-a nas propriedades do adaptador.' }
    return 'Para desfazer: Restauração do Sistema, escolhendo o ponto criado antes da correção.'
}

function Format-TextoHistoricoAlteracoes {
    $itens = @(Get-HistoricoAlteracoes)
    if ($itens.Count -eq 0) { return 'O WinDiag ainda não alterou nada neste computador.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("O WinDiag fez $($itens.Count) alteração(ões) neste computador (da mais recente para a mais antiga):")
    $L.Add('')
    foreach ($i in ($itens | Sort-Object { "$($_.Quando)" } -Descending | Select-Object -First 200)) {
        $L.Add("$($i.Quando)  -  $($i.Acao)")
        $L.Add("    Resultado: $($i.Resultado)")
        $L.Add("    $(Get-DicaDesfazer $i.Acao)")
        $L.Add('')
    }
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Comparação com a verificação anterior
# ----------------------------------------------------------------------------
function Get-ChaveAchado {
    param([string]$Titulo)
    return ((("$Titulo" -replace '\d+', '#') -replace '\s+', ' ').Trim().ToLowerInvariant())
}

function Get-ComparacaoVerificacoes {
    # Compara os achados (atenção e críticos) desta verificação com os da anterior. $null se não há anterior.
    $f = Get-ArquivoDados 'ultima_verificacao.json'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { $ant = Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
    if (-not $ant -or -not $ant.Achados) { return $null }
    $atuais = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })
    $chavesAtuais = @{}
    foreach ($a in $atuais) { $chavesAtuais[(Get-ChaveAchado $a.Titulo)] = $a.Titulo }
    $chavesAnt = @{}
    foreach ($a in @($ant.Achados)) { $chavesAnt["$($a.Chave)"] = "$($a.Titulo)" }
    $novos = @($chavesAtuais.Keys | Where-Object { -not $chavesAnt.ContainsKey($_) } | ForEach-Object { $chavesAtuais[$_] })
    $resolvidos = @($chavesAnt.Keys | Where-Object { -not $chavesAtuais.ContainsKey($_) } | ForEach-Object { $chavesAnt[$_] })
    $persistem = @($chavesAtuais.Keys | Where-Object { $chavesAnt.ContainsKey($_) }).Count
    return @{ Data = "$($ant.Data)"; Novos = $novos; Resolvidos = $resolvidos; Persistem = $persistem }
}

function Save-UltimaVerificacao {
    try {
        $f = Get-ArquivoDados 'ultima_verificacao.json'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $lista = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' } | ForEach-Object {
            @{ Chave = (Get-ChaveAchado $_.Titulo); Titulo = $_.Titulo; Gravidade = $_.Gravidade }
        })
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Achados = $lista }
        ($o | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $f -Encoding UTF8
    } catch { }
    Save-NotaSaude
}

function Format-TextoComparacao {
    param($C)
    if (-not $C) { return '' }
    $p = @()
    if (@($C.Novos).Count -gt 0) { $p += "$(@($C.Novos).Count) novo(s)" }
    if (@($C.Resolvidos).Count -gt 0) { $p += "$(@($C.Resolvidos).Count) resolvido(s)" }
    if ($C.Persistem -gt 0) { $p += "$($C.Persistem) continua(m)" }
    if ($p.Count -eq 0) { return "Em relação à verificação de $($C.Data): nenhum ponto de atenção, antes e agora." }
    return "Em relação à verificação de $($C.Data): " + ($p -join ', ') + '.'
}

function ConvertTo-HtmlComparacao {
    param($C)
    if (-not $C) { return '<p class="vazio">Esta é a primeira verificação guardada neste computador.</p>' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<p>' + [System.Net.WebUtility]::HtmlEncode((Format-TextoComparacao $C)) + '</p>')
    if (@($C.Novos).Count -gt 0) {
        [void]$sb.Append('<p><b>Novos:</b></p><ul>')
        foreach ($t in $C.Novos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    if (@($C.Resolvidos).Count -gt 0) {
        [void]$sb.Append('<p><b>Resolvidos:</b></p><ul>')
        foreach ($t in $C.Resolvidos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    return $sb.ToString()
}

# ----------------------------------------------------------------------------
# Nota de saúde (0 a 100) e tendência ao longo das verificações
# ----------------------------------------------------------------------------
function Get-NotaSaude {
    # Nota simples a partir dos achados desta verificação. É um guia, não um laudo.
    # Crítico desconta 12 e atenção 4; se o achado é "provavelmente normal" ou opcional, desconta um quarto.
    # Cada categoria desconta no máximo 30, para que uma enxurrada de avisos do mesmo tipo não zere a nota.
    param()
    $porCat = @{}
    $nc = 0; $na = 0
    foreach ($a in @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })) {
        $p = if ($a.Gravidade -eq 'Critico') { 12 } else { 4 }
        if ($a.Gravidade -eq 'Critico') { $nc++ } else { $na++ }
        if ($a.Veredito -eq 'Normal' -or $a.Veredito -eq 'Opcional') { $p = [Math]::Ceiling($p / 4) }
        $cat = "$($a.Categoria)"
        if (-not $porCat.ContainsKey($cat)) { $porCat[$cat] = 0 }
        $porCat[$cat] += $p
    }
    $desc = 0
    foreach ($v in $porCat.Values) { $desc += [Math]::Min(30, [int]$v) }
    $nota = [int][Math]::Max(0, 100 - $desc)
    if ($nota -ge 90) { $rot = 'Ótima' } elseif ($nota -ge 75) { $rot = 'Boa' } elseif ($nota -ge 55) { $rot = 'Merece atenção' } else { $rot = 'Precisa de cuidado' }
    return @{ Nota = $nota; Rotulo = $rot; Criticos = $nc; Atencoes = $na }
}

function Get-HistoricoNotas {
    $f = Get-ArquivoDados 'saude.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-NotaAtual {
    # Calcula a nota desta verificação e guarda a nota anterior (lida do histórico uma única vez por execução).
    $script:NotaSaude = Get-NotaSaude
    if (-not $script:NotaAnteriorLida) {
        $script:NotaAnteriorLida = $true
        $h = @(Get-HistoricoNotas)
        if ($h.Count -gt 0) { $script:NotaAnterior = $h[$h.Count - 1] } else { $script:NotaAnterior = $null }
    }
    return $script:NotaSaude
}

function Save-NotaSaude {
    try {
        $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
        $f = Get-ArquivoDados 'saude.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $origem = if ($script:Agendada) { 'agendada' } else { 'manual' }
        $linha = (@{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Nota = $n.Nota; Rotulo = $n.Rotulo; Criticos = $n.Criticos; Atencoes = $n.Atencoes; Origem = $origem } | ConvertTo-Json -Compress)
        $todas = @()
        if (Test-Path -LiteralPath $f) { $todas = @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() }) }
        $todas = @($todas + $linha)
        if ($todas.Count -gt 100) { $todas = $todas[($todas.Count - 100)..($todas.Count - 1)] }
        [IO.File]::WriteAllText($f, (($todas -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Format-TextoNota {
    # "Nota de saúde: 82/100 (Boa), 5 pontos acima da verificação anterior."
    param($N = $script:NotaSaude, $Anterior = $script:NotaAnterior)
    if (-not $N) { return '' }
    $t = "Nota de saúde do computador: $($N.Nota)/100 ($($N.Rotulo))"
    if ($Anterior -and $null -ne $Anterior.Nota) {
        $d = [int]$N.Nota - [int]$Anterior.Nota
        if ($d -gt 0) { $t += ", $d ponto(s) acima da verificação anterior" }
        elseif ($d -lt 0) { $t += ", $(-$d) ponto(s) abaixo da verificação anterior" }
        else { $t += ', igual à verificação anterior' }
    }
    return $t + '.'
}

function ConvertTo-HtmlNota {
    $n = Get-NotaAtual
    $txt = [System.Net.WebUtility]::HtmlEncode((Format-TextoNota))
    return "<p><b>$txt</b></p><p class=`"vazio`">A nota é só um guia: começa em 100 e perde pontos por problema encontrado (mais por críticos, menos por avisos que costumam ser normais). Não substitui a leitura dos itens.</p>"
}

function Get-BarraNota {
    param([int]$Nota)
    $n = [Math]::Max(0, [Math]::Min(100, $Nota))
    $cheio = [int][Math]::Round($n / 10)
    return ([string]([char]0x2588) * $cheio) + ([string]([char]0x2591) * (10 - $cheio))
}

function Format-TextoHistoricoNotas {
    $h = @(Get-HistoricoNotas)
    if ($h.Count -eq 0) { return 'Ainda não há verificações guardadas. Depois da primeira verificação, a nota aparece aqui.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("Nota de saúde do computador nas últimas verificações (da mais recente para a mais antiga):")
    $L.Add('')
    $ult = $h | Select-Object -Last 20
    $lista = @($ult)
    for ($i = $lista.Count - 1; $i -ge 0; $i--) {
        $x = $lista[$i]
        $seta = ''
        if ($i -gt 0) {
            $d = [int]$x.Nota - [int]$lista[$i - 1].Nota
            if ($d -gt 0) { $seta = "  (+$d)" } elseif ($d -lt 0) { $seta = "  ($d)" }
        }
        $orig = if ("$($x.Origem)" -eq 'agendada') { ' [automática]' } else { '' }
        $L.Add(("{0}   {1}  {2,3}/100  {3}{4}{5}" -f $x.Data, (Get-BarraNota ([int]$x.Nota)), [int]$x.Nota, $x.Rotulo, $seta, $orig))
    }
    $L.Add('')
    $L.Add('A nota começa em 100 e perde pontos por problema encontrado. É um guia para acompanhar a tendência, não um laudo.')
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Verificação semanal automática (somente leitura) e aviso quando a saúde piora
# ----------------------------------------------------------------------------
$script:NomeTarefa = 'WinDiag - verificação semanal'

function Get-TarefaAgendada {
    try { return (Get-ScheduledTask -TaskName $script:NomeTarefa -ErrorAction Stop) } catch { return $null }
}

function Get-TextoTarefaAgendada {
    $t = Get-TarefaAgendada
    if (-not $t) { return 'A verificação semanal automática está desativada.' }
    $prox = ''
    try {
        $i = Get-ScheduledTaskInfo -TaskName $script:NomeTarefa -ErrorAction Stop
        if ($i.NextRunTime -and $i.NextRunTime.Year -gt 2000) { $prox = ' Próxima execução: ' + $i.NextRunTime.ToString('dd/MM/yyyy HH:mm') + '.' }
    } catch { }
    return 'A verificação semanal automática está ativada.' + $prox
}

function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

function Enable-VerificacaoAgendada {
    # Cria a tarefa semanal. Ela só lê informações (WinDiag.ps1 -Agendada = somente leitura, sem internet, sem abrir relatório).
    param([string]$Dia = 'Sunday', [string]$Hora = '10:00')
    $dir = $PSScriptRoot
    if (-not $dir -and $global:WD_Opc) { $dir = [string]$global:WD_Opc.PastaScripts }
    $ps1 = Join-Path $dir 'WinDiag.ps1'
    if (-not $dir -or -not (Test-Path -LiteralPath $ps1)) { throw 'Não encontrei o WinDiag.ps1 para agendar.' }
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Agendada' -f $ps1
    $h = Get-ArgsOculto $arg
    $acao = New-ScheduledTaskAction -Execute $h.Exe -Argument $h.Args -WorkingDirectory $dir
    $gatilho = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $Dia -At $Hora
    $cfg = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    $usuario = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $prin = New-ScheduledTaskPrincipal -UserId $usuario -LogonType Interactive -RunLevel Highest
    [void](Register-ScheduledTask -TaskName $script:NomeTarefa -Action $acao -Trigger $gatilho -Settings $cfg -Principal $prin `
        -Description 'WinDiag: verificação semanal somente leitura. Não altera nada no computador; avisa se a saúde piorar.' -Force -ErrorAction Stop)
}

function Disable-VerificacaoAgendada {
    if (Get-TarefaAgendada) { Unregister-ScheduledTask -TaskName $script:NomeTarefa -Confirm:$false -ErrorAction Stop }
}

function Get-ArquivoAviso { return (Get-ArquivoDados 'aviso.json') }

function Get-AvisoPendente {
    $f = Get-ArquivoAviso
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { return (Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json) } catch { return $null }
}

function Clear-AvisoPendente {
    try { $f = Get-ArquivoAviso; if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction Stop } } catch { }
}

function Show-AvisoBalao {
    param([string]$Titulo, [string]$Texto)
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ni.Icon = [System.Drawing.SystemIcons]::Shield
        $ni.Visible = $true
        $ni.BalloonTipTitle = $Titulo
        $ni.BalloonTipText = $Texto
        $ni.BalloonTipIcon = 'Warning'
        $ni.ShowBalloonTip(10000)
        Start-Sleep -Seconds 10
        $ni.Dispose()
    } catch { }
}

function Invoke-AvisoAgendado {
    # Depois da verificação automática: só avisa se a saúde piorou (nota caiu 5 pontos ou mais, ou há mais críticos).
    $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
    $ant = $script:NotaAnterior
    if (-not $ant -or $null -eq $ant.Nota) { return $false }
    $piorou = (([int]$n.Nota) -le ([int]$ant.Nota - 5)) -or (([int]$n.Criticos) -gt ([int]$ant.Criticos))
    if (-not $piorou) { return $false }
    $texto = "A verificação automática de hoje encontrou algo novo: a nota de saúde foi de $($ant.Nota) para $($n.Nota) ($($n.Rotulo)). Abra o WinDiag e rode uma verificação para ver os detalhes."
    try {
        $f = Get-ArquivoAviso
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Texto = $texto; Nota = [int]$n.Nota; NotaAnterior = [int]$ant.Nota; Pasta = "$($script:PastaRelatorioFinal)" }
        [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
    Show-AvisoBalao -Titulo 'WinDiag: a saúde do computador piorou' -Texto $texto
    return $true
}

function Remove-VerificacoesAgendadasAntigas {
    # As verificações automáticas ficam em %LOCALAPPDATA%\WinDiag\Agendadas; só as 4 mais recentes são mantidas.
    param([int]$Manter = 4)
    try {
        $base = Get-ArquivoDados 'Agendadas'
        if (-not (Test-Path -LiteralPath $base)) { return }
        $pastas = @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction Stop | Where-Object { $_.Name -like 'Verificacao_*' } | Sort-Object Name -Descending)
        foreach ($p in ($pastas | Select-Object -Skip $Manter)) { Remove-Item -LiteralPath $p.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    } catch { }
}

# ----------------------------------------------------------------------------
# Telas azuis (arquivos de despejo)
# ----------------------------------------------------------------------------
function Read-DadosDump {
    # Lê, no cabeçalho do .dmp (Windows de 64 e de 32 bits), o código da tela azul e os 4 parâmetros dele.
    param([string]$Caminho)
    try {
        $fs = [IO.File]::Open($Caminho, 'Open', 'Read', 'ReadWrite')
        try {
            $b = New-Object byte[] 0x80
            $n = $fs.Read($b, 0, $b.Length)
            if ($n -lt 0x40) { return $null }
        } finally { $fs.Dispose() }
        $sig = [Text.Encoding]::ASCII.GetString($b, 0, 8)
        if ($sig -eq 'PAGEDU64' -and $n -ge 0x60) {
            return @{ Codigo = ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x38)); Parametros = @(0..3 | ForEach-Object { '0x{0:X}' -f [BitConverter]::ToUInt64($b, 0x40 + 8 * $_) }) }
        }
        if ($sig -eq 'PAGEDUMP' -and $n -ge 0x30) {
            return @{ Codigo = ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x20)); Parametros = @(0..3 | ForEach-Object { '0x{0:X}' -f [BitConverter]::ToUInt32($b, 0x24 + 4 * $_) }) }
        }
    } catch { }
    return $null
}

function Read-CodigoDump {
    param([string]$Caminho)
    $d = Read-DadosDump $Caminho
    if ($d) { return $d.Codigo }
    return $null
}

function Invoke-AnaliseTelasAzuis {
    if (-not $env:SystemRoot) { return }
    $pasta = Join-Path $env:SystemRoot 'Minidump'
    $arqs = @()
    try {
        if (Test-Path -LiteralPath $pasta) { $arqs = @(Get-ChildItem -LiteralPath $pasta -Filter *.dmp -File -ErrorAction Stop) }
    } catch {
        Write-Host '  Telas azuis: não consegui ler a pasta de despejos (precisa de administrador).' -ForegroundColor DarkGray
        return
    }
    if ($arqs.Count -eq 0) {
        Write-Host '  Telas azuis: nenhum arquivo de despejo.' -ForegroundColor Green
        return
    }
    $cont = @{}
    $cada = New-Object System.Collections.Generic.List[string]
    foreach ($a in ($arqs | Sort-Object LastWriteTime -Descending)) {
        $dd = Read-DadosDump $a.FullName
        $c = $null; if ($dd) { $c = $dd.Codigo }
        if (-not $c) { $c = 'desconhecido' }
        if ($cont.ContainsKey($c)) { $cont[$c]++ } else { $cont[$c] = 1 }
        if ($cada.Count -lt 12) {
            $pp = ''; if ($dd) { $pp = ' [' + ($dd.Parametros -join ', ') + ']' }
            $cada.Add(('{0} {1}{2}' -f $a.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), $c, $pp))
        }
    }
    $linhas = @($cont.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object {
        if ($_.Key -eq 'desconhecido') { "código não identificado (x$($_.Value))" }
        else { '{0} {1} (x{2})' -f $_.Key, (Get-DescricaoBugcheck $_.Key), $_.Value }
    })
    $ultimo = ($arqs | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    Add-Achado -Gravidade Atencao -Categoria 'Telas azuis' -Titulo "Telas azuis registradas: $($arqs.Count) arquivo(s) de despejo" `
        -Detalhe ("Última em $ultimo. " + ($linhas -join ' | ') + ' | Uma a uma (data, código e parâmetros): ' + ($cada -join '; ')) `
        -Solucao 'Anote o código. Os mais comuns são causados por driver (atualize o de vídeo e o de rede), memória RAM (use o teste de desempenho) ou disco. Para ver qual driver causou, abra o arquivo .dmp em C:\Windows\Minidump com o BlueScreenView (NirSoft) ou o WinDbg.' `
        -Explicacao 'Cada arquivo na pasta Minidump é uma tela azul que realmente aconteceu. Uma ou duas, com motivo conhecido (queda de energia, driver recém-instalado), costumam ser normais; se se repetem, vale investigar o código mostrado.' `
        -Veredito 'Depende'
}

# ----------------------------------------------------------------------------
# Segurança e manutenção
# ----------------------------------------------------------------------------
function Invoke-AnaliseSeguranca {
    $avDefenderOk = $null
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $avDefenderOk = ([bool]$mp.AntivirusEnabled -and [bool]$mp.RealTimeProtectionEnabled)
        $idade = [int]$mp.AntivirusSignatureAge
        Write-Host ("  Windows Defender: {0}; assinaturas atualizadas há {1} dia(s)." -f $(if ($avDefenderOk) { 'ativo' } else { 'desativado' }), $idade)
        if ($avDefenderOk -and $idade -gt 7) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Assinaturas do antivírus com $idade dias" `
                -Solucao 'Abra a Segurança do Windows > Proteção contra vírus e ameaças > Atualizações de proteção e clique em Verificar atualizações.' -Veredito 'Corrigir' `
                -Explicacao 'O antivírus precisa de atualizações frequentes para reconhecer ameaças novas.'
        }
    } catch { }
    # Outro antivírus instalado?
    $outro = $null
    try {
        $av = @(Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop)
        $ativos = @($av | Where-Object { (([int]$_.productState -shr 12) -band 0xF) -eq 1 -and $_.displayName -notmatch 'Windows Defender' })
        if ($ativos.Count -gt 0) { $outro = ($ativos | Select-Object -First 1).displayName }
        if ($null -eq $avDefenderOk -and $av.Count -gt 0) {
            $dd = @($av | Where-Object { $_.displayName -match 'Windows Defender' } | Select-Object -First 1)
            if ($dd.Count -gt 0) { $avDefenderOk = ((([int]$dd[0].productState -shr 12) -band 0xF) -eq 1) }
        }
    } catch { }
    if ($outro) {
        Write-Host "  Antivírus em uso: $outro"
    } elseif ($avDefenderOk -eq $false) {
        Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo 'Nenhum antivírus está ativo' `
            -Solucao 'Ative a Segurança do Windows (Proteção contra vírus e ameaças > Ativar) ou instale um antivírus.' -Veredito 'Corrigir' `
            -Explicacao 'Sem antivírus ativo, o computador fica exposto a vírus e programas maliciosos.'
    } elseif ($null -eq $avDefenderOk) {
        Write-Host '  Antivírus: não consegui consultar o estado.' -ForegroundColor DarkGray
    }
    try {
        $fw = @(Get-NetFirewallProfile -ErrorAction Stop)
        $off = @($fw | Where-Object { -not $_.Enabled } | ForEach-Object { "$($_.Name)" })
        if ($off.Count -gt 0) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Firewall do Windows desativado ($($off -join ', '))" `
                -Solucao 'Ative o Firewall na Segurança do Windows > Firewall e proteção de rede, a menos que outro programa de segurança faça esse papel.' -Veredito 'Depende' `
                -Explicacao 'O firewall bloqueia acessos indesejados vindos da rede. Alguns pacotes de segurança de terceiros desligam o do Windows de propósito.'
        } else { Write-Host '  Firewall do Windows: ativo.' }
    } catch { }
}

function Invoke-AnaliseManutencao {
    if (Test-RebootPendente) {
        Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'Há uma reinicialização pendente' `
            -Solucao 'Reinicie o computador antes de instalar drivers ou fazer reparos.' -Veredito 'Corrigir' `
            -Explicacao 'O Windows já preparou uma atualização ou alteração que só termina depois de reiniciar. Enquanto isso, reparos e instalações podem falhar.'
    }
    try {
        $hf = @(Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop | Where-Object { $_.InstalledOn })
        if ($hf.Count -gt 0) {
            $ult = ($hf | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn
            $dias = [int]((Get-Date) - [datetime]$ult).TotalDays
            Write-Host ("  Última atualização do Windows instalada há {0} dia(s)." -f $dias)
            if ($dias -gt 90) {
                Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo "Nenhuma atualização do Windows instalada há $dias dias" `
                    -Solucao 'Abra Configurações > Atualização e Segurança e instale as atualizações pendentes.' -Veredito 'Corrigir' `
                    -Explicacao 'As atualizações trazem correções de segurança e de estabilidade. Ficar meses sem instalá-las deixa o computador vulnerável.'
            }
        }
    } catch { }
    try {
        $s = Get-Service -Name wuauserv -ErrorAction Stop
        if ($s.StartType -eq 'Disabled') {
            Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'O serviço do Windows Update está desativado' `
                -Solucao 'Use "Reparar o Windows Update" nas Ferramentas de reparo do WinDiag.' -Veredito 'Corrigir' `
                -Explicacao 'Com o serviço desativado, o Windows não recebe atualizações nem drivers.'
        }
    } catch { }
}

function Invoke-AnaliseBateria {
    try {
        $bat = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
        if ($bat.Count -eq 0) { return }
        $proj = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryStaticData -ErrorAction Stop)
        $cheia = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryFullChargedCapacity -ErrorAction Stop)
        if ($proj.Count -eq 0 -or $cheia.Count -eq 0) { return }
        $d = [double]$proj[0].DesignedCapacity; $f = [double]$cheia[0].FullChargedCapacity
        if ($d -le 0 -or $f -le 0) { return }
        $saude = [math]::Round(100 * $f / $d)
        $script:Dados['Bateria'] = @{ CapacidadeProjetadaMWh = $d; CapacidadeAtualMWh = $f; SaudePct = $saude }
        Write-Host "  Bateria: $saude% da capacidade original."
        if ($saude -lt 50) {
            Add-Achado -Gravidade Atencao -Categoria 'Bateria' -Titulo "A bateria só guarda $saude% da carga original" `
                -Solucao 'Considere trocar a bateria. O notebook continua funcionando ligado na tomada.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso. Abaixo de 50% a duração cai bastante.'
        } elseif ($saude -lt 70) {
            Add-Achado -Gravidade Info -Categoria 'Bateria' -Titulo "A bateria guarda $saude% da carga original" `
                -Solucao 'Desgaste normal para uma bateria usada; se a duração incomoda, avalie trocá-la.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso.'
        }
    } catch { }
}

function Get-TamanhoPasta {
    # Soma dos arquivos de uma pasta, com limite de tempo para não demorar em pastas enormes.
    param([string]$Pasta, [int]$LimiteSeg = 20, [int]$DiasMinimos = 0)
    $total = [int64]0
    if (-not (Test-Path -LiteralPath $Pasta)) { return $total }
    $fim = (Get-Date).AddSeconds($LimiteSeg)
    $corte = (Get-Date).AddDays(-$DiasMinimos)
    try {
        foreach ($f in (Get-ChildItem -LiteralPath $Pasta -Recurse -File -Force -ErrorAction SilentlyContinue)) {
            if ($f.LastWriteTime -lt $corte) { $total += $f.Length }
            if ((Get-Date) -gt $fim) { break }
        }
    } catch { }
    return $total
}

function Get-PastasTemporarios {
    $l = @()
    if ($env:TEMP) { $l += $env:TEMP }
    if ($env:SystemRoot) { $l += (Join-Path $env:SystemRoot 'Temp') }
    return @($l | Select-Object -Unique)
}

function Clear-Temporarios {
    # Apaga arquivos temporários com mais de 2 dias (os mais novos podem estar em uso). Devolve os bytes liberados.
    $liberado = [int64]0
    $corte = (Get-Date).AddDays(-2)
    foreach ($p in (Get-PastasTemporarios)) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        foreach ($f in (Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $corte })) {
            try { $t = $f.Length; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $liberado += $t } catch { }
        }
    }
    return $liberado
}

function Format-Tamanho {
    param([int64]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N0} MB' -f ($Bytes / 1MB)) }
    return ('{0:N0} KB' -f ($Bytes / 1KB))
}

function Invoke-AnaliseEspaco {
    $total = [int64]0
    foreach ($p in (Get-PastasTemporarios)) { $total += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
    Write-Host ("  Arquivos temporários com mais de 2 dias: {0}" -f (Format-Tamanho $total))
    $script:Dados['TemporariosBytes'] = $total
    if ($total -ge 1GB) {
        Add-Achado -Gravidade Info -Categoria 'Espaço' -Titulo ("Arquivos temporários ocupam {0}" -f (Format-Tamanho $total)) `
            -Solucao 'O WinDiag pode apagar os temporários antigos (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'Programas e o Windows deixam arquivos temporários que ninguém mais usa. Apagar os antigos é seguro e libera espaço.'
        Add-Acao -Descricao ("Apagar arquivos temporários antigos (cerca de {0})" -f (Format-Tamanho $total)) -Acao {
            $l = Clear-Temporarios
            Write-Host ("    Liberado: {0}" -f (Format-Tamanho $l)) -ForegroundColor Green
        }
    }
}

function Invoke-AnaliseInicializacao {
    try {
        $itens = @(Get-CimInstance Win32_StartupCommand -ErrorAction Stop)
        Write-Host "  Programas que iniciam com o Windows: $($itens.Count)"
        $script:Dados['Inicializacao'] = @($itens | ForEach-Object { [pscustomobject]@{ Nome = "$($_.Name)"; Comando = "$($_.Command)"; Local = "$($_.Location)" } })
        if ($itens.Count -gt 25) {
            Add-Achado -Gravidade Info -Categoria 'Desempenho' -Titulo "$($itens.Count) programas iniciam junto com o Windows" `
                -Solucao 'Abra o Gerenciador de Tarefas (Ctrl+Shift+Esc) > Inicializar e desative os que você não usa logo ao ligar.' -Veredito 'Opcional' `
                -Explicacao 'Muitos programas na inicialização deixam o computador mais lento para ligar. Desativar na inicialização não desinstala o programa.'
        }
    } catch { }
}

function Invoke-AnaliseRede {
    if ($SemWindowsUpdate) { Write-Host '  Teste de rede: pulado (opção de não usar a internet).' -ForegroundColor DarkGray; return }
    $ativos = @()
    try { $ativos = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' }) } catch { return }
    if ($ativos.Count -eq 0) {
        Add-Achado -Gravidade Info -Categoria 'Rede' -Titulo 'Nenhum adaptador de rede conectado' `
            -Solucao 'Se deveria haver internet, confira o cabo ou o Wi-Fi.' -Veredito 'Depende' -Explicacao 'O teste de rede só faz sentido com um adaptador conectado.'
        return
    }
    $ping = $false; $dns = $false
    try { $ping = [bool](Test-Connection -ComputerName 1.1.1.1 -Count 2 -Quiet -ErrorAction Stop) } catch { }
    try { $r = Resolve-DnsName -Name 'www.microsoft.com' -Type A -ErrorAction Stop; $dns = [bool]$r } catch { }
    Write-Host ("  Rede: conexão {0}; resolução de nomes (DNS) {1}." -f $(if ($ping) { 'ok' } else { 'falhou' }), $(if ($dns) { 'ok' } else { 'falhou' }))
    $script:Dados['Rede'] = @{ Ping = $ping; Dns = $dns }
    if ($ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'A internet responde, mas os nomes de sites não são resolvidos (DNS)' `
            -Solucao 'O WinDiag pode limpar o cache e reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'O computador alcança a internet, mas não consegue traduzir endereços como www.site.com. Costuma ser cache de DNS corrompido ou configuração de rede com problema.'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    } elseif (-not $ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'Sem acesso à internet apesar do adaptador conectado' `
            -Solucao 'Reinicie o roteador e o computador. Se continuar, o WinDiag pode reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Depende' `
            -Explicacao 'O adaptador está ligado, mas nada sai para a internet. Pode ser o provedor ou o roteador (fora do alcance do WinDiag) ou a configuração de rede do Windows (que o WinDiag corrige).'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    }
}

function Invoke-AnaliseVolumesChkdsk {
    # Oferece o CHKDSK completo (na reinicialização) quando a varredura online achou erros.
    $v = @($script:Dados['Volumes'])
    foreach ($x in $v) {
        if ($null -eq $x) { continue }
        if ($x.Tipo -eq 'Fixed' -and "$($x.Varredura)" -notin @('NoErrorsFound', 'não executada', 'requer administrador', 'falhou')) {
            $letra = "$($x.Unidade)"
            Add-Acao -Descricao "Agendar o CHKDSK completo ($letra /F /R) para a próxima reinicialização" -Geral -Arg $letra -Acao {
                param($l)
                Invoke-AgendarChkdsk -Unidade $l
            }
        }
    }
}

function Invoke-AgendarChkdsk {
    param([string]$Unidade)
    $saida = & cmd.exe /c "echo Y| chkdsk $Unidade /F /R" 2>&1
    @($saida) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "    $_" }
    Write-Host '    O CHKDSK roda sozinho na próxima vez que o computador for reiniciado (pode levar de minutos a horas).' -ForegroundColor Cyan
}

function Invoke-AnaliseExtras {
    Write-Titulo '4b) SEGURANÇA, MANUTENÇÃO E ESPAÇO'
    foreach ($par in @(
        @('Telas azuis', { Invoke-AnaliseTelasAzuis }),
        @('Monitor em tempo real', { if (Get-Command Invoke-AnaliseMonitor -ErrorAction SilentlyContinue) { Invoke-AnaliseMonitor } }),
        @('Configurações que influenciam travamentos', { if (Get-Command Invoke-AnaliseConfigTravamento -ErrorAction SilentlyContinue) { Invoke-AnaliseConfigTravamento } }),
        @('SMART detalhado', { Invoke-AnaliseSmartAtributos }),
        @('Drivers de som, rede e chipset', { Invoke-AnaliseDriversGerais }),
        @('Segurança', { Invoke-AnaliseSeguranca }),
        @('Manutenção do Windows', { Invoke-AnaliseManutencao }),
        @('Bateria', { Invoke-AnaliseBateria }),
        @('Espaço', { Invoke-AnaliseEspaco }),
        @('Inicialização', { Invoke-AnaliseInicializacao }),
        @('Rede', { Invoke-AnaliseRede }),
        @('CHKDSK', { Invoke-AnaliseVolumesChkdsk })
    )) {
        try { & $par[1] } catch { Write-Host "  Verificação '$($par[0])' falhou e foi ignorada: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
}


# ----------------------------------------------------------------------------
# Reparos de configuração com confirmação e desfazer (agendamento de GPU, economia do PCIe, inicialização rápida)
# ----------------------------------------------------------------------------
function Get-ArquivoConfigAntes { return (Get-ArquivoDados 'config-antes.json') }

function Get-ConfigAntes {
    # Valores originais guardados antes de cada mudança: @{ Chave = Valor ('' = não existia) }.
    $f = Get-ArquivoConfigAntes
    $h = @{}
    try {
        if (Test-Path -LiteralPath $f) {
            $o = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value }
        }
    } catch { }
    return $h
}

function Save-ConfigAntes {
    # Guarda o valor original só na primeira mudança (assim "desfazer" sempre volta ao que era antes do WinDiag).
    param([string]$Chave, $Valor)
    $h = Get-ConfigAntes
    if ($h.ContainsKey($Chave)) { return }
    $h[$Chave] = $(if ($null -eq $Valor) { '' } else { "$Valor" })
    $f = Get-ArquivoConfigAntes
    $dir = Split-Path -Parent $f
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [IO.File]::WriteAllText($f, ($h | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
}

function Clear-ConfigAntes {
    param([string]$Chave)
    $h = Get-ConfigAntes
    if ($h.ContainsKey($Chave)) { $h.Remove($Chave) }
    $f = Get-ArquivoConfigAntes
    if ($h.Count -eq 0) { try { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } catch { } }
    else { [IO.File]::WriteAllText($f, ($h | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false)) }
}

function Get-PlanoReparoCfg {
    # Descreve cada mudança (texto de confirmação, o que muda e se precisa reiniciar). Id: hags | pcie | fast.
    param([string]$Id)
    switch ($Id) {
        'hags' { return @{ Id = 'hags'; Chave = 'HwSchMode'; Titulo = 'Desligar o agendamento de GPU acelerado por hardware'; Reinicia = $true
            Pergunta = 'Desligar o "Agendamento de GPU acelerado por hardware"? É uma opção do Windows que, em alguns computadores, causa travamento de imagem em jogos. O WinDiag guarda o valor atual para você poder desfazer, e é preciso reiniciar o computador para valer.' } }
        'pcie' { return @{ Id = 'pcie'; Chave = 'PcieAspmAc'; Titulo = 'Desligar a economia de energia do PCIe (na tomada)'; Reinicia = $false
            Pergunta = 'Desligar a economia de energia do PCIe (Link State Power Management) quando o computador está na tomada? Isso evita que a placa de vídeo seja colocada em repouso profundo e travar ao sair dele. O consumo em repouso sobe um pouco. O WinDiag guarda o valor atual para você poder desfazer.' } }
        'fast' { return @{ Id = 'fast'; Chave = 'HiberbootEnabled'; Titulo = 'Desligar a inicialização rápida do Windows'; Reinicia = $true
            Pergunta = 'Desligar a inicialização rápida (Fast Startup)? Ela mantém o estado dos drivers entre desligamentos e pode manter um driver travado. O computador passa a demorar alguns segundos a mais para ligar. O WinDiag guarda o valor atual para você poder desfazer.' } }
    }
    return $null
}

function Set-ConfigValor {
    # Aplica uma mudança de configuração. $Valor $null = remover (voltar ao padrão do Windows). Devolve $true se aplicou.
    param([string]$Id, $Valor)
    switch ($Id) {
        'hags' {
            $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name HwSchMode -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $k -Name HwSchMode -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'fast' {
            $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name HiberbootEnabled -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $k -Name HiberbootEnabled -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'pcie' {
            if ($null -eq $Valor -or "$Valor" -eq '') { $Valor = 1 }
            & powercfg.exe /setacvalueindex SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 ([int]$Valor) 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'O powercfg recusou a mudança.' }
            & powercfg.exe /setactive SCHEME_CURRENT 2>&1 | Out-Null
            return $true
        }
    }
    return $false
}

function Get-ConfigAtual {
    # Valor atual da configuração (para guardar antes de mudar).
    param([string]$Id)
    try {
        switch ($Id) {
            'hags' { return (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction Stop).HwSchMode }
            'fast' { return (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -ErrorAction Stop).HiberbootEnabled }
            'pcie' { $o = & powercfg.exe /query SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 2>$null | Out-String; $v = ConvertFrom-SaidaPowercfg $o; if ($v) { return $v.Tomada } }
        }
    } catch { }
    return $null
}

function Invoke-ReparoCfg {
    # Executa uma mudança de configuração com confirmação, histórico e valor original guardado. Devolve as linhas de texto.
    param([string]$Id)
    $feito = New-Object System.Collections.Generic.List[string]
    $pl = Get-PlanoReparoCfg $Id
    if (-not $pl) { $feito.Add('Mudança desconhecida.'); return $feito.ToArray() }
    if (-not (Confirm-Acao $pl.Pergunta)) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    try {
        $antes = Get-ConfigAtual $Id
        Save-ConfigAntes -Chave $pl.Chave -Valor $antes
        $novo = 0
        [void](Set-ConfigValor -Id $Id -Valor $novo)
        Add-Alteracao -Acao $pl.Titulo -Resultado ("executado (valor anterior: {0})" -f $(if ($null -eq $antes) { 'não definido' } else { $antes }))
        $feito.Add($pl.Titulo + ': feito.')
        if ($pl.Reinicia) { $feito.Add('Reinicie o computador para a mudança valer.') }
        $feito.Add('Para voltar ao que era antes: Ferramentas de reparo > Desfazer o que o WinDiag fez > "Desfazer as mudanças de configuração".')
    } catch {
        Add-Alteracao -Acao $pl.Titulo -Resultado "falhou: $($_.Exception.Message)"
        $feito.Add("Falhou: $($_.Exception.Message)")
    }
    return $feito.ToArray()
}

function Invoke-DesfazerCfg {
    # Volta todas as configurações mudadas pelo WinDiag ao valor que tinham antes.
    $feito = New-Object System.Collections.Generic.List[string]
    $h = Get-ConfigAntes
    if ($h.Count -eq 0) { $feito.Add('O WinDiag não mudou nenhuma configuração neste computador (ou já foram desfeitas).'); return $feito.ToArray() }
    $nomes = @{ HwSchMode = 'Agendamento de GPU acelerado por hardware'; PcieAspmAc = 'Economia de energia do PCIe (na tomada)'; HiberbootEnabled = 'Inicialização rápida' }
    $lista = ($h.Keys | ForEach-Object { $nomes[$_] }) -join ', '
    if (-not (Confirm-Acao ("Voltar estas configurações ao valor que tinham antes do WinDiag: {0}?" -f $lista))) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    $ids = @{ HwSchMode = 'hags'; PcieAspmAc = 'pcie'; HiberbootEnabled = 'fast' }
    foreach ($k in @($h.Keys)) {
        try {
            $v = $h[$k]
            [void](Set-ConfigValor -Id $ids[$k] -Valor $(if ("$v" -eq '') { $null } else { [int]$v }))
            Clear-ConfigAntes -Chave $k
            Add-Alteracao -Acao ("Desfazer: " + $nomes[$k]) -Resultado 'executado'
            $feito.Add($nomes[$k] + ': voltou ao valor anterior.')
        } catch { Add-Alteracao -Acao ("Desfazer: " + $nomes[$k]) -Resultado "falhou: $($_.Exception.Message)"; $feito.Add($nomes[$k] + ": falhou ($($_.Exception.Message)).") }
    }
    $feito.Add('Reinicie o computador para concluir.')
    return $feito.ToArray()
}

# ----------------------------------------------------------------------------
# Guias passo a passo (texto)
# ----------------------------------------------------------------------------
function Get-TextoGuia {
    param([string]$Id)
    switch ($Id) {
        'guia-fonte' { return @(
            'Guia: testar com outra fonte de alimentação',
            '',
            'Para que serve: separar "fonte" de "placa de vídeo" e "memória" quando o computador trava ou desliga sob carga. Nenhum programa mede a fonte de verdade; a troca é o teste.',
            '',
            'Antes de começar',
            '  1. Salve tudo, desligue o Windows e depois a chave atrás da fonte. Tire o cabo da tomada e segure o botão de ligar por 5 segundos para descarregar.',
            '  2. Tire uma foto de como os cabos estão ligados (placa-mãe, placa de vídeo, discos).',
            '  3. Anote o modelo e a potência da fonte atual (está na etiqueta lateral).',
            '',
            'Trocando',
            '  4. Desligue os cabos: o grande de 24 pinos na placa-mãe, o de 4+4 pinos perto do processador, os de 6 ou 8 pinos da placa de vídeo e os dos discos.',
            '  5. Tire os 4 parafusos atrás do gabinete e retire a fonte.',
            '  6. Encaixe a fonte emprestada e use SÓ os cabos dela: nunca misture cabos de modelos diferentes (o encaixe é igual, mas os fios não).',
            '  7. Ligue o 24 pinos, o 4+4 do processador, o 6/8 pinos da placa de vídeo e os discos. Ligue na tomada e a chave atrás da fonte.',
            '',
            'Para o teste valer',
            '  8. Use uma fonte de marca conhecida, de pelo menos 450 W para uma placa como a GTX 1650 com um Ryzen 3.',
            '  9. Ligue o monitor do WinDiag (Ferramentas de reparo > Monitor em tempo real) e jogue por 20 a 30 minutos o jogo que travava.',
            ' 10. Se NÃO travar por vários dias, a fonte antiga é a causa. Se travar do mesmo jeito, a fonte está descartada: passe para a memória e a placa de vídeo.',
            '',
            'Cuidado: a fonte guarda carga mesmo desligada. Não abra a fonte e não mexa com o computador ligado na tomada.') -join "`r`n" }
        'guia-energia' { return @(
            'Guia: limitar a energia da placa de vídeo (para testar picos de consumo)',
            '',
            'Para que serve: se a placa consome menos, os picos de energia ficam menores. Se o travamento some com o limite, o problema está no pico de consumo (fonte ou a própria placa). Nada é danificado: o limite volta ao normal ao reiniciar o computador (no nvidia-smi) ou quando você desfaz (no Afterburner).',
            '',
            'Opção A - MSI Afterburner (a mais fácil)',
            '  1. Baixe o MSI Afterburner no site oficial (msi.com/Landing/afterburner).',
            '  2. Abra o programa e arraste o controle "Power Limit (%)" para 60% (ou 70%).',
            '  3. Clique no botão de confirmar (o "V") e deixe o programa aberto.',
            '  4. Jogue o jogo que travava por 20 a 30 minutos com o monitor do WinDiag ligado.',
            '',
            'Opção B - nvidia-smi (sem instalar nada, precisa de administrador)',
            '  1. Abra o Prompt de Comando como administrador.',
            '  2. Veja os limites aceitos pela placa: nvidia-smi -q -d POWER (procure Min Power Limit e Max Power Limit).',
            '  3. Defina o limite, por exemplo 50 W para uma GTX 1650 de 75 W: nvidia-smi -pl 50',
            '  4. Jogue com o monitor ligado. Ao reiniciar o computador o limite volta ao padrão.',
            '',
            'Como ler o resultado',
            '  - Não travou depois de muito tempo (mais que o tempo em que travava antes): o problema é o pico de consumo. Teste outra fonte.',
            '  - Travou igual: o consumo não é a causa. Passe para memória (teste de memória do WinDiag) e para o driver.',
            '',
            'Dica: limitar os quadros por segundo a 60 no NVIDIA Control Panel (Configurações 3D > Taxa de quadros máxima) também reduz o consumo.') -join "`r`n" }
    }
    return ''
}

# ----------------------------------------------------------------------------
# SMART detalhado (erros de CRC do cabo, setores com problema)
# ----------------------------------------------------------------------------
function ConvertFrom-SmartVendor {
    # Lê os bytes "VendorSpecific" do SMART (12 bytes por atributo a partir do byte 2). Devolve lista de @{ Id; Valor; Pior; Raw }.
    param([byte[]]$Bytes)
    $r = New-Object System.Collections.Generic.List[object]
    if (-not $Bytes -or $Bytes.Length -lt 14) { return @() }
    for ($o = 2; $o + 11 -lt $Bytes.Length -and $o -lt 2 + 30 * 12; $o += 12) {
        $id = $Bytes[$o]
        if ($id -eq 0) { continue }
        $raw = [uint64]0
        for ($k = 5; $k -ge 0; $k--) { $raw = ($raw -shl 8) -bor [uint64]$Bytes[$o + 5 + $k] }
        $r.Add(@{ Id = [int]$id; Valor = [int]$Bytes[$o + 3]; Pior = [int]$Bytes[$o + 4]; Raw = [uint64]$raw })
    }
    return $r.ToArray()
}

function Get-AvaliacaoSmart {
    # Avalia os atributos SMART (lista de @{ Id; Valor; Pior; Raw }). Devolve @{ Linhas; Gravidade; Resumo }.
    param($Atributos, [string]$Nome = 'Disco')
    $l = New-Object System.Collections.Generic.List[string]
    $grav = 'Info'
    $at = @{}; foreach ($a in @($Atributos)) { $at[[int]$a.Id] = $a }
    $g = 'Info'
    if ($at.ContainsKey(199) -and [uint64]$at[199].Raw -gt 0) {
        $n = [uint64]$at[199].Raw
        $l.Add(("{0}: {1} erro(s) de CRC na transferência de dados (SMART 199). Isso quase sempre é o cabo SATA ruim, mal encaixado ou a porta, e não o disco." -f $Nome, $n))
        if ($g -eq 'Info') { $g = 'Atencao' }
        $l.Add('Troque o cabo SATA por um novo (e teste outra porta). Esse contador não zera: se continuar subindo depois da troca, o problema é outro.')
    }
    if ($at.ContainsKey(197) -and [uint64]$at[197].Raw -gt 0) { $l.Add(("{0}: {1} setor(es) pendentes de remapeamento (SMART 197): o disco encontrou áreas que não consegue ler. Faça backup agora." -f $Nome, [uint64]$at[197].Raw)); $g = 'Critico' }
    if ($at.ContainsKey(198) -and [uint64]$at[198].Raw -gt 0) { $l.Add(("{0}: {1} setor(es) incorrigíveis offline (SMART 198). Faça backup agora." -f $Nome, [uint64]$at[198].Raw)); $g = 'Critico' }
    if ($at.ContainsKey(5) -and [uint64]$at[5].Raw -gt 0) {
        $n5 = [uint64]$at[5].Raw
        $l.Add(("{0}: {1} setor(es) já remapeado(s) (SMART 5)." -f $Nome, $n5))
        if ($n5 -ge 50) { $g = 'Critico'; $l.Add('Muitos setores remapeados: o disco está falhando. Faça backup e troque.') } elseif ($g -eq 'Info') { $g = 'Atencao' }
    }
    if ($at.ContainsKey(10) -and [uint64]$at[10].Raw -gt 0) { $l.Add(("{0}: o motor do HD precisou de {1} nova(s) tentativa(s) para girar (SMART 10): sinal de problema de alimentação ou do motor." -f $Nome, [uint64]$at[10].Raw)); if ($g -eq 'Info') { $g = 'Atencao' } }
    if ($at.ContainsKey(188) -and ([uint64]$at[188].Raw -band 0xFFFF) -gt 0) { $l.Add(("{0}: o disco registrou {1} esgotamento(s) de tempo em comandos (SMART 188): costuma ser cabo ou fonte." -f $Nome, ([uint64]$at[188].Raw -band 0xFFFF))); if ($g -eq 'Info') { $g = 'Atencao' } }
    if ($at.ContainsKey(9)) { $l.Add(("{0}: {1:N0} horas ligado (SMART 9)." -f $Nome, [uint64]$at[9].Raw)) }
    return @{ Linhas = $l.ToArray(); Gravidade = $g }
}

function Get-SmartAtributos {
    # Lê os atributos SMART de todos os discos pelo WMI (precisa de administrador). Devolve lista de @{ Instancia; Atributos }.
    if ($env:OS -ne 'Windows_NT') { return @() }
    $r = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($d in @(Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictData -ErrorAction Stop)) {
            $r.Add(@{ Instancia = "$($d.InstanceName)"; Atributos = @(ConvertFrom-SmartVendor ([byte[]]$d.VendorSpecific)) })
        }
    } catch { }
    return $r.ToArray()
}

function Invoke-AnaliseSmartAtributos {
    $discos = @(Get-SmartAtributos)
    if ($discos.Count -eq 0) { return }
    $nomes = @{}
    try { foreach ($pd in @(Get-PhysicalDisk -ErrorAction Stop)) { $nomes[[string]$pd.DeviceId] = "$($pd.FriendlyName)" } } catch { }
    $i = 0
    foreach ($d in $discos) {
        $nome = $(if ($nomes.Count -gt $i) { @($nomes.Values)[$i] } else { "Disco $($i + 1)" })
        $i++
        $av = Get-AvaliacaoSmart -Atributos $d.Atributos -Nome $nome
        $achados = @($av.Linhas | Where-Object { $_ -notmatch 'horas ligado' })
        if ($achados.Count -eq 0) { continue }
        Add-Achado -Gravidade $av.Gravidade -Categoria 'Disco' -Titulo ("SMART detalhado: {0}" -f $nome) -Detalhe ($av.Linhas -join ' | ') `
            -Solucao 'Faça backup dos arquivos importantes. Se for erro de CRC, troque o cabo SATA e a porta antes de pensar em trocar o disco.' `
            -Explicacao 'O SMART é o registro que o próprio disco guarda de erros e de setores com problema. Erros de CRC acontecem na transferência (cabo/porta); setores pendentes e remapeados são defeitos da superfície do disco.' `
            -Veredito $(if ($av.Gravidade -eq 'Critico') { 'Corrigir' } else { 'Depende' })
    }
}

# ----------------------------------------------------------------------------
# Drivers de som, rede, Wi-Fi e chipset; link do fabricante da placa-mãe
# ----------------------------------------------------------------------------
function Get-AvaliacaoDriversGerais {
    # Lista os drivers por tipo, com a idade. $Lista: @{ Classe; Nome; Fabricante; Versao; Data }. Devolve @{ Linhas; Atencao }.
    param($Lista, [datetime]$Agora = (Get-Date))
    $l = New-Object System.Collections.Generic.List[string]
    $atencao = $false
    $tipos = [ordered]@{ MEDIA = 'Som'; NET = 'Rede e Wi-Fi'; SYSTEM = 'Chipset e placa-mãe' }
    foreach ($c in $tipos.Keys) {
        $itens = @($Lista | Where-Object { $_.Classe -eq $c -and $_.Data } | Sort-Object { $_.Data })
        if ($c -eq 'NET') { $itens = @($itens | Where-Object { $_.Nome -notmatch 'Virtual|Miniport|WAN|Bluetooth|Tunnel|Kernel Debug|Loopback|Wi-Fi Direct|VPN' }) }
        if ($c -eq 'SYSTEM') { $itens = @($itens | Where-Object { $_.Nome -match 'AMD|Intel|Chipset|SMBus|PSP|Management Engine|GPIO|I2C|Serial IO' -and $_.Nome -notmatch 'Microsoft' }) }
        if ($c -eq 'MEDIA') { $itens = @($itens | Where-Object { $_.Nome -notmatch 'NVIDIA|AMD High Definition Audio|Intel.*Display Audio|Virtual|Remote' }) }
        foreach ($i in ($itens | Select-Object -First 4)) {
            $anos = ($Agora - $i.Data).TotalDays / 365.25
            $idade = if ($anos -ge 1) { ('{0:N1} anos' -f $anos) } else { 'menos de 1 ano' }
            $fab = if ($i.Fabricante) { $i.Fabricante } else { '?' }
            $l.Add(('{0}: {1} ({2}), versão {3}, de {4} (idade: {5}).' -f $tipos[$c], $i.Nome, $fab, $i.Versao, $i.Data.ToString('MM/yyyy'), $idade))
            if ($anos -ge 5 -and ($c -ne 'MEDIA')) { $atencao = $true }
        }
    }
    if ($atencao) { $l.Add('Há driver de rede ou chipset com mais de 5 anos: baixe a versão atual no site do fabricante da placa-mãe ou do dispositivo (não use programas "atualizadores de driver").') }
    return @{ Linhas = $l.ToArray(); Atencao = $atencao }
}

function Invoke-AnaliseDriversGerais {
    if ($env:OS -ne 'Windows_NT') { return }
    $lista = @()
    try {
        $lista = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -in 'MEDIA', 'NET', 'SYSTEM' -and $_.DriverDate } | ForEach-Object {
            $d = $_.DriverDate; if ($d -isnot [datetime]) { try { $d = [Management.ManagementDateTimeConverter]::ToDateTime("$d") } catch { $d = $null } }
            @{ Classe = "$($_.DeviceClass)"; Nome = "$($_.DeviceName)"; Fabricante = "$($_.Manufacturer)"; Versao = "$($_.DriverVersion)"; Data = $d }
        })
    } catch { return }
    $av = Get-AvaliacaoDriversGerais $lista
    if ($av.Linhas.Count -eq 0) { return }
    Add-Achado -Gravidade $(if ($av.Atencao) { 'Atencao' } else { 'Info' }) -Categoria 'Drivers' -Titulo 'Drivers de som, rede, Wi-Fi e chipset (versões e idades)' `
        -Detalhe ($av.Linhas -join ' | ') `
        -Solucao 'Se algum estiver muito antigo, baixe a versão atual no site do fabricante da placa-mãe (botão "Abrir a página de suporte da placa-mãe" em Ferramentas de reparo). Não use programas atualizadores de driver.' `
        -Explicacao 'Driver antigo de chipset ou de rede pode causar travamentos e quedas de conexão. O WinDiag só lista as versões; nada é instalado ou alterado.' `
        -Veredito 'Opcional'
}

function Get-LinkSuporteFabricante {
    # Página de suporte (BIOS e drivers) da placa-mãe e página de chipset do processador. Devolve @{ Fabricante; Produto; UrlBios; UrlChipset }.
    param([string]$Fabricante, [string]$Produto, [string]$Cpu = '')
    $f = "$Fabricante".Trim(); $p = "$Produto".Trim()
    $q = [Uri]::EscapeDataString($p)
    $url = ''
    switch -Regex ($f) {
        'GIGABYTE' { $url = "https://www.gigabyte.com/Search?kw=$q" }
        'ASUS'     { $url = "https://www.asus.com/search/results/?searchType=support&searchKey=$q" }
        'Micro-Star|MSI' { $url = "https://www.msi.com/search/$q" }
        'ASRock'   { $url = "https://www.asrock.com/search/?q=$q" }
        'Dell'     { $url = 'https://www.dell.com/support/home/' }
        'HP|Hewlett' { $url = 'https://support.hp.com/' }
        'LENOVO'   { $url = 'https://support.lenovo.com/' }
        default    { $url = ("https://www.google.com/search?q=" + [Uri]::EscapeDataString("$f $p BIOS download suporte")) }
    }
    $chip = 'https://www.amd.com/en/support/download/drivers.html'
    if ($Cpu -match 'Intel') { $chip = 'https://www.intel.com/content/www/us/en/support/detect.html' }
    return @{ Fabricante = $f; Produto = $p; UrlBios = $url; UrlChipset = $chip }
}

function Get-InfoBiosAtual {
    # Texto com a BIOS instalada, para comparar com a da página do fabricante.
    if ($env:OS -ne 'Windows_NT') { return @{ Texto = ''; Fabricante = ''; Produto = ''; Cpu = '' } }
    $b = $null; $pb = $null; $cpu = ''
    try { $b = Get-CimInstance Win32_BIOS -ErrorAction Stop } catch { }
    try { $pb = Get-CimInstance Win32_BaseBoard -ErrorAction Stop } catch { }
    try { $cpu = "$((Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).Name)" } catch { }
    $data = ''; try { $data = ' de ' + ([Management.ManagementDateTimeConverter]::ToDateTime($b.ReleaseDate)).ToString('dd/MM/yyyy') } catch { }
    return @{ Texto = ("BIOS instalada: versão {0}{1}." -f $b.SMBIOSBIOSVersion, $data); Fabricante = "$($pb.Manufacturer)"; Produto = "$($pb.Product)"; Cpu = $cpu }
}


# ----------------------------------------------------------------------------
# Sensores: HWiNFO (configuração certa) e LibreHardwareMonitor (alternativa opcional)
# ----------------------------------------------------------------------------
function Invoke-ConfigurarHwinfo {
    # Corrige o INI do HWiNFO (com cópia de segurança) e o abre. Devolve as linhas de texto.
    $feito = New-Object System.Collections.Generic.List[string]
    $exe = Get-CaminhoHwinfo
    if (-not $exe) { $feito.Add('O HWiNFO não está instalado neste computador. Baixe em https://www.hwinfo.com/ (versão Installer ou Portable) e abra esta ferramenta de novo.'); return $feito.ToArray() }
    if (Get-Process -Name 'HWiNFO64', 'HWiNFO32' -ErrorAction SilentlyContinue) {
        $feito.Add('O HWiNFO está aberto. Feche-o (clique direito no ícone da bandeja > Sair) e rode esta ferramenta de novo: ele só lê o arquivo de configuração ao abrir.')
        return $feito.ToArray()
    }
    $ini = [IO.Path]::ChangeExtension($exe, 'INI')
    $texto = ''; try { if (Test-Path -LiteralPath $ini) { $texto = [IO.File]::ReadAllText($ini) } } catch { }
    $novo = Update-TextoIniHwinfo $texto
    if ($novo.Trim() -ne $texto.Trim()) {
        if (-not (Confirm-Acao "Ajustar a configuração do HWiNFO para o WinDiag conseguir ler os sensores (memória compartilhada ligada, só sensores, atualização a cada 500 ms)? Uma cópia do arquivo atual será guardada ao lado.")) { $feito.Add('Nada foi alterado.'); return $feito.ToArray() }
        try {
            if (Test-Path -LiteralPath $ini) { Copy-Item -LiteralPath $ini -Destination ($ini + '.bak-windiag') -Force }
            [IO.File]::WriteAllText($ini, $novo, (New-Object System.Text.UTF8Encoding $false))
            Add-Alteracao -Acao 'Configuração do HWiNFO (HWiNFO64.INI)' -Resultado 'executado (cópia em HWiNFO64.INI.bak-windiag)'
            $feito.Add('Configuração ajustada. A cópia do arquivo antigo ficou como HWiNFO64.INI.bak-windiag na pasta do HWiNFO.')
        } catch {
            $feito.Add("Não consegui gravar o arquivo (pasta protegida?): $($_.Exception.Message)")
            $feito.Add('Faça à mão: no HWiNFO, Configurações > marque "Shared Memory Support" e deixe o intervalo de sensores em 500 ms.')
        }
    } else { $feito.Add('A configuração do HWiNFO já está correta.') }
    try { Start-Process -FilePath $exe; $feito.Add('HWiNFO aberto. Deixe-o aberto (pode minimizar) e ligue o monitor do WinDiag.') } catch { $feito.Add("Não consegui abrir o HWiNFO: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-InstalarLhm {
    # Baixa a LibreHardwareMonitor oficial (GitHub) e confere o SHA-256 informado pelo GitHub. Só com confirmação.
    $feito = New-Object System.Collections.Generic.List[string]
    $dest = Get-PastaLhm
    if (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe')) { $feito.Add("A LibreHardwareMonitor já está em $dest."); return $feito.ToArray() }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $rel = $null
    try { $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/LibreHardwareMonitor/LibreHardwareMonitor/releases/latest' -Headers @{ 'User-Agent' = 'WinDiag' } -TimeoutSec 30 -ErrorAction Stop } catch { }
    if (-not $rel) { $feito.Add('Não consegui consultar o GitHub (sem internet?). Baixe manualmente em https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases e extraia em: ' + $dest); return $feito.ToArray() }
    $ass = @($rel.assets | Where-Object { $_.name -match '^LibreHardwareMonitor.*\.zip$' -and $_.name -notmatch 'NET' }) | Select-Object -First 1
    if (-not $ass) { $ass = @($rel.assets | Where-Object { $_.name -match '\.zip$' }) | Select-Object -First 1 }
    if (-not $ass) { $feito.Add('Não achei o arquivo ZIP na versão mais recente. Baixe manualmente em https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases'); return $feito.ToArray() }
    $sha = ''; if ("$($ass.digest)" -match '^sha256:([0-9a-fA-F]{64})$') { $sha = $Matches[1].ToLower() }
    $aviso = "Baixar a LibreHardwareMonitor $($rel.tag_name) ($($ass.name), $([math]::Round($ass.size / 1MB, 1)) MB) de github.com/LibreHardwareMonitor e guardar em $dest? Ela é um programa de código aberto de terceiros. Para ler a temperatura do processador ela carrega um driver, e antivírus ou anticheat (como o Vanguard) podem reclamar; abra-a só se aceitar isso."
    if ($sha -eq '') { $aviso += " ATENÇÃO: o GitHub não informou o hash deste arquivo, então não dá para conferir a integridade."}
    if (-not (Confirm-Acao $aviso)) { $feito.Add('Nada foi baixado.'); return $feito.ToArray() }
    $zip = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-lhm-' + [guid]::NewGuid().ToString('N') + '.zip')
    try {
        Invoke-WebRequest -Uri $ass.browser_download_url -OutFile $zip -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
        if ($sha -and $h -ne $sha) { $feito.Add('O arquivo baixado NÃO bate com o hash informado pelo GitHub. Descartado, nada foi instalado.'); return $feito.ToArray() }
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
        # Se o ZIP trouxe uma pasta dentro, sobe o conteúdo um nível
        if (-not (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe'))) {
            $sub = Get-ChildItem -LiteralPath $dest -Recurse -Filter 'LibreHardwareMonitor.exe' -File | Select-Object -First 1
            if ($sub) { Get-ChildItem -LiteralPath $sub.DirectoryName | Move-Item -Destination $dest -Force -ErrorAction SilentlyContinue }
        }
        if (-not (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe'))) { $feito.Add('O ZIP não trouxe o LibreHardwareMonitor.exe como esperado.'); return $feito.ToArray() }
        Add-Alteracao -Acao "Baixar a LibreHardwareMonitor $($rel.tag_name)" -Resultado "executado (SHA-256 $h; apagar a pasta $dest para remover)"
        $feito.Add("LibreHardwareMonitor $($rel.tag_name) guardada em $dest (SHA-256 $h$(if ($sha) { ', conferido com o GitHub' } else { ', sem hash do GitHub' })).")
        $feito.Add('Para usar: Monitor e sensores > "Abrir a LibreHardwareMonitor". Para remover, apague essa pasta.')
    } catch { $feito.Add("Falhou: $($_.Exception.Message)") }
    finally { try { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue } catch { } }
    return $feito.ToArray()
}

function Invoke-AbrirLhm {
    $feito = New-Object System.Collections.Generic.List[string]
    $e = Get-EstadoSensores
    if (-not $e.LhmPasta) { $feito.Add('A LibreHardwareMonitor ainda não foi baixada. Use primeiro "Baixar a LibreHardwareMonitor".'); return $feito.ToArray() }
    if (-not (Confirm-Acao 'Abrir a LibreHardwareMonitor como administrador? Ela precisa disso para ler a temperatura do processador e vai carregar o driver dela. Se o anticheat ou o antivírus reclamar, feche-a.')) { $feito.Add('Nada foi aberto.'); return $feito.ToArray() }
    try { Start-Process -FilePath (Join-Path $e.LhmPasta 'LibreHardwareMonitor.exe') -Verb RunAs; $feito.Add('Aberta. Deixe-a aberta (pode minimizar): o monitor do WinDiag passa a ler os sensores dela quando o HWiNFO não está aberto.') }
    catch { $feito.Add("Não consegui abrir: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-EstadoSensores {
    $e = Get-EstadoSensores
    $a = Get-AvaliacaoSensores $e
    $l = New-Object System.Collections.Generic.List[string]
    $l.Add($a.Resumo)
    $l.Add('HWiNFO: ' + $(if ($e.HwinfoCaminho) { $e.HwinfoCaminho + $(if ($e.HwinfoAberto) { ' (aberto)' } else { ' (fechado)' }) } else { 'não encontrado' }))
    if ($e.HwinfoConfig) { $l.Add(('  Memória compartilhada: {0} | só sensores: {1} | intervalo: {2} ms' -f $(if ($e.HwinfoConfig.SensoresMemoria) { 'ligada' } else { 'DESLIGADA' }), $(if ($e.HwinfoConfig.SoSensores) { 'sim' } else { 'não' }), $e.HwinfoConfig.Intervalo)) }
    $l.Add('LibreHardwareMonitor: ' + $(if ($e.LhmPasta) { $e.LhmPasta + $(if ($e.LhmAberto) { ' (aberta)' } else { ' (fechada)' }) } else { 'não baixada' }))
    foreach ($p in $a.Passos) { $l.Add('Próximo passo: ' + $p) }
    return $l.ToArray()
}

# ----------------------------------------------------------------------------
# Autoteste: confere se cada recurso do WinDiag funciona neste Windows (para mandar o resultado ao desenvolvedor)
# ----------------------------------------------------------------------------
function Invoke-AutoTeste {
    $l = New-Object System.Collections.Generic.List[string]
    $ok = 0; $falha = 0; $pula = 0
    $v = 'desconhecida'; try { $v = $script:Versao } catch { }
    $l.Add("WinDiag - autoteste (versão $v)")
    $l.Add("Windows: $([Environment]::OSVersion.VersionString) | PowerShell $($PSVersionTable.PSVersion) | Administrador: $([bool]$script:IsAdmin)")
    $l.Add('')
    $passo = {
        param([string]$Nome, [scriptblock]$Bloco)
        try {
            $r = & $Bloco
            if ($r -is [string] -and $r.StartsWith('PULADO')) { $script:_at.Pula++; $script:_at.L.Add(('  PULADO  {0}: {1}' -f $Nome, $r.Substring(7))) }
            else { $script:_at.Ok++; $script:_at.L.Add(('  OK      {0}{1}' -f $Nome, $(if ($r) { ': ' + $r } else { '' }))) }
        } catch { $script:_at.Falha++; $script:_at.L.Add(('  FALHOU  {0}: {1}' -f $Nome, $_.Exception.Message)) }
    }
    $script:_at = @{ Ok = 0; Falha = 0; Pula = 0; L = $l }
    if ($env:OS -ne 'Windows_NT') { $l.Add('O autoteste só roda no Windows.'); return ($l -join "`r`n") }
    & $passo 'Interface (Windows Forms)' { Add-Type -AssemblyName System.Windows.Forms, System.Drawing; 'carregada' }
    & $passo 'WPF e compilador de shader (d3dcompiler_47.dll)' { Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase; if (-not (Test-Path (Join-Path $env:SystemRoot 'System32\d3dcompiler_47.dll'))) { throw 'd3dcompiler_47.dll não encontrada (o estresse de jogo pesado não vai rodar)' }; 'ok' }
    & $passo 'Modo de vídeo (troca de resolução do teste de transição)' { if (-not ('WDModo' -as [type])) { Add-Type -TypeDefinition $script:CodigoModo }; $a = [WDModo]::Atual(); if (-not $a) { throw 'não conseguiu ler o modo atual' }; $alt = [WDModo]::Alternativo(); "atual $a; alternativo " + $(if ($alt) { $alt } else { 'nenhum' }) }
    & $passo 'Placa de vídeo (temperatura, consumo, clock)' { $g = Get-TempGpu; if (-not $g) { throw 'sem leitura (nvidia-smi ou driver AMD indisponível)' }; "{0} °C, {1} W, {2} MHz via {3}" -f $g.Temp, $g.Potencia, $g.Clock, $g.Fonte }
    & $passo 'NVIDIA: PCIe e motivos de redução de clock' { $e = Get-NvidiaExtra; if (-not $e) { return 'PULADO sem placa NVIDIA' }; "PCIe gen $($e.Gen)/$($e.GenMax) x$($e.Larg)/$($e.LargMax); motivos informados: $($e.Motivos)" }
    & $passo 'Programas de sensores (HWiNFO / LibreHardwareMonitor)' { $e = Get-EstadoSensores; $a = Get-AvaliacaoSensores $e; $a.Resumo }
    & $passo 'Sensores (HWiNFO / MSI Afterburner)' { $r = Get-LeiturasMonitor; if (-not $r.Fontes) { return 'PULADO nenhum programa de sensores aberto' }; "$($r.Fontes) com $(@($r.Itens).Count) leituras" }
    & $passo 'Eventos do Windows' { $n = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; StartTime = (Get-Date).AddDays(-7) } -MaxEvents 5 -ErrorAction Stop).Count; "$n evento(s) lidos" }
    & $passo 'Configurações que influenciam travamentos' { $c = Get-ConfigTravamento; if ($c.Linhas.Count -eq 0) { throw 'nenhuma configuração lida' }; "$($c.Linhas.Count) linhas" }
    & $passo 'Discos (SMART pelo Windows)' { $d = @(Get-PhysicalDisk -ErrorAction Stop); "$($d.Count) disco(s)" }
    & $passo 'SMART detalhado (atributos, CRC)' { if (-not $script:IsAdmin) { return 'PULADO precisa de administrador' }; $s = @(Get-SmartAtributos); if ($s.Count -eq 0) { throw 'o disco ou o driver não expõe os atributos' }; "$($s.Count) disco(s), $(@($s[0].Atributos).Count) atributos no primeiro" }
    & $passo 'Memória instalada (pentes)' { $m = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop); "$($m.Count) pente(s)" }
    & $passo 'Drivers de som, rede e chipset' { $n = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -in 'MEDIA', 'NET', 'SYSTEM' }).Count; "$n driver(s)" }
    & $passo 'Teste de memória com padrões (10 s, 128 MB)' {
        if (-not (Get-Command Initialize-Testes -ErrorAction SilentlyContinue)) { return 'PULADO módulo de testes ausente' }
        Initialize-Testes; [WDTestes]::MemIniciar(128, 10, 2); while ([WDTestes]::MemRodando) { Start-Sleep -Milliseconds 300 }
        if ([WDTestes]::MemErros -gt 0) { throw "ENCONTROU $([WDTestes]::MemErros) erro(s) de memória" }; "$([WDTestes]::MemPassadas) passada(s), sem erros" }
    & $passo 'Estresse do disco (10 s, 64 MB)' {
        Initialize-Testes; $a = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-auto-' + [guid]::NewGuid().ToString('N') + '.tmp')
        [WDTestes]::DiscoIniciar($a, 64, 10); while ([WDTestes]::DiscoRodando) { Start-Sleep -Milliseconds 300 }
        if ([WDTestes]::DiscoExcecao) { throw [WDTestes]::DiscoExcecao }; if ([WDTestes]::DiscoErros -gt 0) { throw "dados diferentes em $([WDTestes]::DiscoErros) bloco(s)" }
        'gravou e leu com verificação' }
    & $passo 'Pasta de dados do WinDiag (escrita)' { $f = Get-ArquivoDados 'autoteste.tmp'; $d = Split-Path -Parent $f; if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }; [IO.File]::WriteAllText($f, 'x'); Remove-Item $f -Force; $d }
    & $passo 'Monitor em tempo real (gravação em disco)' { $dir = Get-PastaMonitor; if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }; $t = Join-Path $dir 'autoteste.tmp'; [IO.File]::WriteAllText($t, 'x'); Remove-Item $t -Force; $dir }
    $l.Add('')
    $l.Add(("Resultado: {0} OK, {1} falhou, {2} pulado(s)." -f $script:_at.Ok, $script:_at.Falha, $script:_at.Pula))
    if ($script:_at.Falha -gt 0) { $l.Add('Mande este texto ao desenvolvedor: cada linha FALHOU mostra o motivo.') }
    return ($l -join "`r`n")
}

# ----------------------------------------------------------------------------
# Ferramentas de reparo e restauração (manuais; cada uma pede confirmação)
# ----------------------------------------------------------------------------
function Reset-RedeWindows {
    foreach ($c in @('ipconfig /flushdns', 'netsh winsock reset', 'netsh int ip reset', 'netsh int ipv6 reset')) {
        Write-Host "    $c"
        $o = & cmd.exe /c "$c 2>&1"
        @($o) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
    }
    Write-Host '    Reinicie o computador para concluir a reinicialização da rede.' -ForegroundColor Cyan
}

function Reset-WindowsUpdate {
    $svcs = @('wuauserv', 'bits', 'cryptsvc', 'msiserver')
    foreach ($s in $svcs) { try { Stop-Service -Name $s -Force -ErrorAction Stop; Write-Host "    Parado: $s" -ForegroundColor DarkGray } catch { Write-Host "    Não consegui parar $s ($($_.Exception.Message))" -ForegroundColor Yellow } }
    $sufixo = '.bak_WinDiag_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    foreach ($p in @((Join-Path $env:SystemRoot 'SoftwareDistribution'), (Join-Path $env:SystemRoot 'System32\catroot2'))) {
        if (Test-Path -LiteralPath $p) {
            try { Rename-Item -LiteralPath $p -NewName ((Split-Path -Leaf $p) + $sufixo) -ErrorAction Stop; Write-Host "    Pasta renomeada: $p" -ForegroundColor Green }
            catch { Write-Host "    Não consegui renomear $p ($($_.Exception.Message))" -ForegroundColor Yellow }
        }
    }
    foreach ($s in $svcs) { try { Start-Service -Name $s -ErrorAction Stop } catch { Write-Host "    Não consegui iniciar $s" -ForegroundColor Yellow } }
    Write-Host '    O Windows recria as pastas sozinho; as antigas ficaram guardadas com a terminação .bak_WinDiag.' -ForegroundColor Cyan
}

function Repair-LojaWindows {
    $pacotes = @(Get-AppxPackage -AllUsers -Name 'Microsoft.WindowsStore' -ErrorAction SilentlyContinue)
    if ($pacotes.Count -eq 0) { Write-Host '    A Microsoft Store não está instalada neste Windows.' -ForegroundColor Yellow; return }
    foreach ($p in $pacotes) {
        $m = Join-Path $p.InstallLocation 'AppXManifest.xml'
        if (Test-Path -LiteralPath $m) {
            Add-AppxPackage -DisableDevelopmentMode -Register $m -ErrorAction Stop
            Write-Host '    Microsoft Store registrada novamente.' -ForegroundColor Green
        }
    }
}

function Get-ListaPontosRestauracao {
    $l = New-Object System.Collections.Generic.List[string]
    try {
        $pts = @(Get-ComputerRestorePoint -ErrorAction Stop)
        if ($pts.Count -eq 0) { $l.Add('Nenhum ponto de restauração encontrado (a Proteção do Sistema pode estar desativada).') }
        foreach ($p in ($pts | Sort-Object SequenceNumber -Descending)) {
            $quando = $p.CreationTime
            try { $quando = [Management.ManagementDateTimeConverter]::ToDateTime($p.CreationTime).ToString('dd/MM/yyyy HH:mm') } catch { }
            $l.Add("$quando  -  $($p.Description)")
        }
    } catch { $l.Add("Não consegui listar os pontos de restauração: $($_.Exception.Message)") }
    return ($l -join "`r`n")
}

function Invoke-Ferramenta {
    # Executa uma ferramenta e devolve @{ Ok; Titulo; Texto }.
    param([string]$Nome, [string]$Destino, [string]$Dia = 'Sunday', [string]$Hora = '10:00')
    if (-not $Dia) { $Dia = 'Sunday' }
    if (-not $Hora) { $Hora = '10:00' }
    $feito = New-Object System.Collections.Generic.List[string]
    $titulo = ''
    switch ($Nome) {
        'pontos-listar' {
            $titulo = 'Pontos de restauração do Windows'
            $feito.Add((Get-ListaPontosRestauracao))
            $feito.Add('')
            $feito.Add('Para voltar o Windows a um desses pontos, use a Restauração do Sistema (botão "Abrir a Restauração do Sistema").')
        }
        'pontos-criar' {
            $titulo = 'Criar ponto de restauração'
            if (Confirm-Acao 'Criar agora um ponto de restauração do sistema? (pode ativar a Proteção do Sistema na unidade do Windows)') {
                try {
                    Enable-ComputerRestore -Drive "$($env:SystemDrive)\" -ErrorAction Stop
                    Checkpoint-Computer -Description 'WinDiag (manual)' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado 'executado'
                    $feito.Add('Ponto de restauração criado.')
                } catch {
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado "falhou: $($_.Exception.Message)"
                    $feito.Add("Não foi possível criar o ponto: $($_.Exception.Message)")
                    $feito.Add('(O Windows limita a um ponto a cada 24 horas por padrão.)')
                }
            } else { $feito.Add('Nada foi feito.') }
        }
        'rede' {
            $titulo = 'Reparar a rede'
            if (Confirm-Acao 'Reiniciar a configuração de rede (limpa o DNS e reinicia o Winsock e o IP)? Configurações de IP fixo podem ser perdidas.') {
                try { Reset-RedeWindows; Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado 'executado'; $feito.Add('Configuração de rede reiniciada. Reinicie o computador para concluir.') }
                catch { Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'wu' {
            $titulo = 'Reparar o Windows Update'
            if (Confirm-Acao 'Reparar o Windows Update? Os serviços serão parados e as pastas temporárias do Windows Update renomeadas (o histórico de atualizações pode ser reiniciado).') {
                try { Reset-WindowsUpdate; Add-Alteracao -Acao 'Reparar o Windows Update (pastas SoftwareDistribution e catroot2)' -Resultado 'executado'; $feito.Add('Windows Update reparado. Reinicie e procure atualizações de novo.') }
                catch { Add-Alteracao -Acao 'Reparar o Windows Update' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'store' {
            $titulo = 'Reparar a Microsoft Store'
            if (Confirm-Acao 'Registrar novamente a Microsoft Store? (corrige loja que não abre ou não baixa)') {
                try { Repair-LojaWindows; Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado 'executado'; $feito.Add('Concluído. Abra a Microsoft Store para testar.') }
                catch { Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'chkdsk' {
            $titulo = 'Verificar o disco (CHKDSK)'
            $u = $env:SystemDrive
            if (-not $u) { $u = 'C:' }
            if (Confirm-Acao "Agendar a verificação completa do disco $u (CHKDSK /F /R)? Ela roda na próxima reinicialização e pode levar de minutos a horas." ) {
                try { Invoke-AgendarChkdsk -Unidade $u; Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado 'executado'; $feito.Add("Verificação do disco $u agendada. Reinicie o computador e aguarde: não desligue durante o processo.") }
                catch { Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'temp' {
            $titulo = 'Limpar arquivos temporários'
            $tam = [int64]0
            foreach ($p in (Get-PastasTemporarios)) { $tam += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
            if (Confirm-Acao ("Apagar os arquivos temporários com mais de 2 dias? (cerca de {0})" -f (Format-Tamanho $tam))) {
                $l = Clear-Temporarios
                Add-Alteracao -Acao 'Apagar arquivos temporários antigos' -Resultado ("liberado {0}" -f (Format-Tamanho $l))
                $feito.Add(("Liberado: {0}" -f (Format-Tamanho $l)))
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-ativar' {
            $titulo = 'Verificação semanal automática'
            $diasOk = @('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
            $diasPt = @{ Sunday = 'domingo'; Monday = 'segunda-feira'; Tuesday = 'terça-feira'; Wednesday = 'quarta-feira'; Thursday = 'quinta-feira'; Friday = 'sexta-feira'; Saturday = 'sábado' }
            if ($diasOk -notcontains $Dia -or $Hora -notmatch '^([01]\d|2[0-3]):[0-5]\d$') {
                $feito.Add('Dia ou horário inválido. Escolha de novo na página de Configurações.')
            } elseif (Confirm-Acao "Ativar a verificação semanal automática, toda $($diasPt[$Dia]) às $Hora (ou na próxima vez que o computador estiver ligado)? O WinDiag faz uma verificação rápida só de leitura, sem alterar nada e sem usar a internet, e só avisa se a saúde do computador piorar. Dá para desativar quando quiser.") {
                try { Enable-VerificacaoAgendada -Dia $Dia -Hora $Hora; Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado 'executado'; $feito.Add((Get-TextoTarefaAgendada)) }
                catch { Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-desativar' {
            $titulo = 'Verificação semanal automática'
            if (-not (Get-TarefaAgendada)) { $feito.Add('A verificação semanal automática já estava desativada.') }
            elseif (Confirm-Acao 'Desativar a verificação semanal automática?') {
                try { Disable-VerificacaoAgendada; Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado 'executado'; $feito.Add('Verificação semanal automática desativada.') }
                catch { Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-estado' {
            $titulo = 'Verificação semanal automática'
            $feito.Add((Get-TextoTarefaAgendada))
            $feito.Add('')
            $feito.Add('Como funciona: uma vez por semana o WinDiag faz uma verificação rápida só de leitura (sem corrigir nada e sem usar a internet). Se a nota de saúde cair 5 pontos ou mais, ou aparecer um problema crítico novo, você recebe um aviso. As 4 verificações automáticas mais recentes ficam em %LOCALAPPDATA%\WinDiag\Agendadas.')
        }
        'saude-historico' {
            $titulo = 'Nota de saúde ao longo do tempo'
            $feito.Add((Format-TextoHistoricoNotas))
        }
        'historico' {
            $titulo = 'O que o WinDiag já mudou neste computador'
            $feito.Add((Format-TextoHistoricoAlteracoes))
        }
        'cfg-hags' { $titulo = 'Agendamento de GPU acelerado por hardware'; foreach ($x in (Invoke-ReparoCfg 'hags')) { $feito.Add($x) } }
        'cfg-pcie' { $titulo = 'Economia de energia do PCIe'; foreach ($x in (Invoke-ReparoCfg 'pcie')) { $feito.Add($x) } }
        'cfg-fast' { $titulo = 'Inicialização rápida do Windows'; foreach ($x in (Invoke-ReparoCfg 'fast')) { $feito.Add($x) } }
        'cfg-desfazer' { $titulo = 'Desfazer mudanças de configuração'; foreach ($x in (Invoke-DesfazerCfg)) { $feito.Add($x) } }
        'sensores-estado' { $titulo = 'Estado dos sensores'; foreach ($x in (Invoke-EstadoSensores)) { $feito.Add($x) } }
        'hwinfo-config' { $titulo = 'Configurar o HWiNFO'; foreach ($x in (Invoke-ConfigurarHwinfo)) { $feito.Add($x) } }
        'lhm-baixar' { $titulo = 'Baixar a LibreHardwareMonitor'; foreach ($x in (Invoke-InstalarLhm)) { $feito.Add($x) } }
        'lhm-abrir' { $titulo = 'Abrir a LibreHardwareMonitor'; foreach ($x in (Invoke-AbrirLhm)) { $feito.Add($x) } }
        'bios-site' { $titulo = 'BIOS e drivers da placa-mãe'
            $b = Get-InfoBiosAtual; $lk = Get-LinkSuporteFabricante -Fabricante $b.Fabricante -Produto $b.Produto -Cpu $b.Cpu
            $feito.Add("Placa-mãe: $($b.Fabricante) $($b.Produto)"); $feito.Add($b.Texto)
            $feito.Add('O WinDiag não consegue saber sozinho qual é a BIOS mais nova: abrimos a página de suporte do fabricante. Compare a versão e a data da lista com a instalada. Atualizar a BIOS tem risco: só faça se a nota da versão citar estabilidade, memória ou o seu processador, e nunca desligue o computador durante a atualização.')
            if ($lk.UrlBios -match '^https://') { try { Start-Process $lk.UrlBios; $feito.Add("Página aberta: $($lk.UrlBios)") } catch { $feito.Add("Endereço: $($lk.UrlBios)") } } }
        'chipset-site' { $titulo = 'Driver de chipset'
            $b = Get-InfoBiosAtual; $lk = Get-LinkSuporteFabricante -Fabricante $b.Fabricante -Produto $b.Produto -Cpu $b.Cpu
            $feito.Add("Processador: $($b.Cpu)")
            $feito.Add('Abrimos a página oficial do driver de chipset do fabricante do processador (AMD ou Intel). Baixe só dali ou do site da placa-mãe.')
            try { Start-Process $lk.UrlChipset; $feito.Add("Página aberta: $($lk.UrlChipset)") } catch { $feito.Add("Endereço: $($lk.UrlChipset)") } }
        'guia-fonte' { $titulo = 'Guia: testar com outra fonte'; $feito.Add((Get-TextoGuia 'guia-fonte')) }
        'guia-energia' { $titulo = 'Guia: limitar a energia da placa de vídeo'; $feito.Add((Get-TextoGuia 'guia-energia')) }
        'autoteste' { $titulo = 'Autoteste do WinDiag'; $feito.Add((Invoke-AutoTeste)) }
        'backup' {
            $titulo = 'Cópia dos arquivos pessoais'
            $feito.Add((Invoke-BackupPessoal -Destino $Destino))
        }
        default { return @{ Ok = $false; Erro = "Ferramenta desconhecida: $Nome" } }
    }
    return @{ Ok = $true; Titulo = $titulo; Texto = ($feito -join "`r`n") }
}

function Invoke-BackupPessoal {
    # Copia Documentos, Imagens e Área de Trabalho para uma pasta escolhida (não altera nem apaga nada na origem).
    param([string]$Destino)
    if (-not $Destino -or -not (Test-Path -LiteralPath $Destino)) { return 'Nenhuma pasta de destino foi escolhida.' }
    $origens = @()
    foreach ($n in @('MyDocuments', 'MyPictures', 'Desktop')) {
        $p = [Environment]::GetFolderPath($n)
        if ($p -and (Test-Path -LiteralPath $p)) { $origens += $p }
    }
    $tam = [int64]0
    foreach ($o in $origens) { $tam += (Get-TamanhoPasta -Pasta $o -LimiteSeg 60) }
    $livre = 0
    try { $livre = (New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Destino))).AvailableFreeSpace } catch { }
    if ($livre -gt 0 -and $tam -gt ($livre * 0.95)) {
        return ("Não há espaço suficiente no destino: precisa de cerca de {0} e há {1} livres." -f (Format-Tamanho $tam), (Format-Tamanho $livre))
    }
    if (-not (Confirm-Acao ("Copiar Documentos, Imagens e Área de Trabalho (cerca de {0}) para '{1}'? Nada é apagado nem alterado na origem." -f (Format-Tamanho $tam), $Destino))) { return 'Nada foi feito.' }
    $raiz = Join-Path $Destino ('WinDiag_Backup_' + (Get-Date -Format 'yyyy-MM-dd_HH-mm'))
    New-Item -ItemType Directory -Force -Path $raiz | Out-Null
    $resumo = New-Object System.Collections.Generic.List[string]
    foreach ($o in $origens) {
        $alvo = Join-Path $raiz (Split-Path -Leaf $o)
        Write-Host "    Copiando $o ..."
        $argsRc = @("`"$o`"", "`"$alvo`"", '/E', '/XJ', '/R:1', '/W:1', '/MT:8', '/NFL', '/NDL', '/NP', '/XD', 'WinDiag')
        $proc = $null
        try {
            $proc = Start-Process -FilePath 'robocopy.exe' -ArgumentList $argsRc -PassThru -WindowStyle Hidden
            while (-not $proc.HasExited) { Start-Sleep -Milliseconds 700 }
            $cod = $proc.ExitCode
        } finally { try { if ($proc -and -not $proc.HasExited) { $proc.Kill() } } catch { } }
        if ($cod -lt 8) { $resumo.Add("OK: $o") } else { $resumo.Add("Com falhas (código $cod): $o") }
    }
    Add-Alteracao -Acao "Cópia dos arquivos pessoais para $raiz" -Resultado 'executado'
    return ("Cópia concluída em:`r`n$raiz`r`n`r`n" + ($resumo -join "`r`n"))
}
