﻿# WinDiag-Monitor.ps1
# Monitor em tempo real: lê os sensores que o HWiNFO, o MSI Afterburner e o LibreHardwareMonitor já publicam e grava um registro
# a cada poucos segundos. Se o computador desligar no meio de um jogo, o último registro mostra temperaturas e tensões do momento da queda.
# Só lê o que os programas publicam: não instala nem carrega driver. Roda em um processo próprio, escondido, até você parar.
param([switch]$Executar, [int]$Intervalo = 2)

function Initialize-Msi {
    # Compila o leitor do MSI Afterburner só quando for preciso (assim carregar este arquivo é instantâneo).
    if ('WDMsi' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;

public static class WDMsi
{
    // Memória compartilhada do MSI Afterburner ("MAHMSharedMemory"). Devolve {nome, unidade, valor} ou null se o programa não estiver publicando.
    static string Texto(byte[] b, int off, int len)
    {
        int n = 0;
        while (n < len && off + n < b.Length && b[off + n] != 0) n++;
        return System.Text.Encoding.Default.GetString(b, off, n).Trim();
    }

    public static List<string[]> LerBytes(byte[] b)
    {
        if (b == null || b.Length < 32) return null;
        uint sig = BitConverter.ToUInt32(b, 0);
        if (sig != 0x4D41484Du && sig != 0x4D48414Du) return null;   // "MAHM"
        uint ver = BitConverter.ToUInt32(b, 4), cab = BitConverter.ToUInt32(b, 8), n = BitConverter.ToUInt32(b, 12), tam = BitConverter.ToUInt32(b, 16);
        if (cab < 20 || cab > 4096 || n > 2000 || tam < 528 || tam > 8192) return null;
        if (cab + (long)n * tam > b.Length) return null;
        int offDado = ver >= 0x00020000u ? 1300 : 520;
        if (offDado + 4 > tam) return null;
        List<string[]> r = new List<string[]>();
        for (int i = 0; i < n; i++)
        {
            int o = (int)(cab + (long)i * tam);
            string nome = Texto(b, o, 260);
            if (nome.Length == 0) continue;
            float v = BitConverter.ToSingle(b, o + offDado);
            if (float.IsNaN(v) || float.IsInfinity(v) || Math.Abs(v) > 1e30f) continue;   // FLT_MAX = sem dado
            r.Add(new string[] { nome, Texto(b, o + 260, 260), ((double)v).ToString("R", System.Globalization.CultureInfo.InvariantCulture) });
        }
        return r;
    }

    public static List<string[]> Ler()
    {
        try
        {
            using (System.IO.MemoryMappedFiles.MemoryMappedFile mmf = System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting("MAHMSharedMemory", System.IO.MemoryMappedFiles.MemoryMappedFileRights.Read))
            using (System.IO.MemoryMappedFiles.MemoryMappedViewAccessor acc = mmf.CreateViewAccessor(0, 0, System.IO.MemoryMappedFiles.MemoryMappedFileAccess.Read))
            {
                byte[] h = new byte[32];
                acc.ReadArray(0, h, 0, 32);
                uint sig = BitConverter.ToUInt32(h, 0);
                if (sig != 0x4D41484Du && sig != 0x4D48414Du) return null;
                uint cab = BitConverter.ToUInt32(h, 8), n = BitConverter.ToUInt32(h, 12), tam = BitConverter.ToUInt32(h, 16);
                long total = cab + (long)n * tam;
                if (total < 32 || total > 8 * 1024 * 1024) return null;
                byte[] all = new byte[total];
                acc.ReadArray(0, all, 0, (int)total);
                return LerBytes(all);
            }
        }
        catch (Exception) { return null; }
    }
}
'@
}

$script:MonInv = [Globalization.CultureInfo]::InvariantCulture

#region arquivos e estado
function Get-PastaMonitor {
    if ($env:WD_MONITOR_DIR) { return $env:WD_MONITOR_DIR }
    $base = $env:LOCALAPPDATA
    if (-not $base) { $base = [IO.Path]::GetTempPath() }
    return (Join-Path $base 'WinDiag\Monitor')
}

function Get-EstadoMonitor {
    # Devolve o conteúdo de estado.json se o processo do monitor ainda estiver vivo; senão $null.
    try {
        $f = Join-Path (Get-PastaMonitor) 'estado.json'
        if (-not (Test-Path -LiteralPath $f)) { return $null }
        $e = [IO.File]::ReadAllText($f).TrimStart([char]0xFEFF) | ConvertFrom-Json
        if (-not $e.Pid) { return $null }
        $p = Get-Process -Id ([int]$e.Pid) -ErrorAction SilentlyContinue
        if (-not $p) { return $null }
        if ($e.Inicio -and $p.StartTime) {
            # PID reaproveitado por outro programa depois de uma queda? O processo precisa ser mais antigo que o início da sessão.
            $ini = [datetime]::Parse([string]$e.Inicio, $script:MonInv)
            if ($p.StartTime -gt $ini.AddMinutes(2)) { return $null }
        }
        return $e
    } catch { return $null }
}

function Test-MonitorAtivo { return [bool](Get-EstadoMonitor) }

function Stop-Monitor {
    # Pede para o monitor encerrar (ele grava o fim da sessão); se não responder, encerra o processo.
    $e = Get-EstadoMonitor
    if (-not $e) { return $false }
    try { [IO.File]::WriteAllText((Join-Path (Get-PastaMonitor) 'parar.flag'), 'parar') } catch { }
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 250
        if (-not (Get-Process -Id ([int]$e.Pid) -ErrorAction SilentlyContinue)) { return $true }
    }
    try { Stop-Process -Id ([int]$e.Pid) -Force -ErrorAction Stop } catch { return $false }
    return $true
}

function Start-Monitor {
    # Inicia o monitor em um processo escondido e devolve $true se ele subiu.
    param([string]$Pasta, [int]$Intervalo = 2)
    $script_ = Join-Path $Pasta 'WinDiag-Monitor.ps1'
    if (-not (Test-Path -LiteralPath $script_)) { return $false }
    $resto = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Executar -Intervalo {1}' -f $script_, $Intervalo
    $h = $null
    if (Get-Command Get-ArgsOculto -ErrorAction SilentlyContinue) { $h = Get-ArgsOculto $resto }
    if (-not $h) { $h = @{ Exe = 'powershell.exe'; Args = $resto } }
    Start-Process -FilePath $h.Exe -ArgumentList $h.Args -WindowStyle Hidden | Out-Null
    for ($i = 0; $i -lt 40; $i++) { Start-Sleep -Milliseconds 250; if (Test-MonitorAtivo) { return $true } }
    return $false
}
#endregion arquivos e estado

#region leitura dos sensores
function Get-TipoMonitor {
    # Letra do tipo gravada na chave: T temperatura, V tensão, P potência, F ventoinha, C clock, U uso, O outro (MSI).
    param([string]$Tipo)
    switch ($Tipo) { '1' { 'T' } '2' { 'V' } '3' { 'F' } '4' { 'A' } '5' { 'P' } '6' { 'C' } '7' { 'U' } default { 'O' } }
}

function Get-LeiturasMonitor {
    # Devolve @{ Fontes = 'HWiNFO, MSI Afterburner'; Itens = lista de @{ Chave; Valor } }.
    $itens = New-Object System.Collections.Generic.List[object]
    $fontes = New-Object System.Collections.Generic.List[string]
    $usadas = @{}
    $add = {
        param($tipo, $fonte, $sensor, $rotulo, [double]$valor)
        $c = ('{0}|{1}|{2}|{3}' -f $tipo, $fonte, ($sensor -replace '[;\r\n]', ','), ($rotulo -replace '[;\r\n]', ','))
        if ($usadas.ContainsKey($c)) { $usadas[$c]++; $c = $c + '#' + $usadas[$c] } else { $usadas[$c] = 1 }
        $itens.Add(@{ Chave = $c; Valor = $valor })
    }

    $nFan = 0; $nClk = 0
    $linhas = $null
    try { if ($script:TesteSensoresBytes) { $linhas = [WDSensores]::LerBytes($script:TesteSensoresBytes) } elseif ($env:OS -eq 'Windows_NT') { $linhas = [WDSensores]::LerHWiNFO() } } catch { }
    if ($linhas -and $linhas.Count -gt 0) {
        $fontes.Add('HWiNFO')
        foreach ($l in $linhas) {
            $t = Get-TipoMonitor $l[0]
            $v = [double]::Parse($l[4], $script:MonInv)
            $rot = $l[2]
            $pula = $false
            if ($t -eq 'T') { $pula = ($rot -match 'Distance|TjMax|Limit|Margin|Distância' -or $v -le 0 -or $v -ge 150) }
            elseif ($t -eq 'F') { $nFan++; $pula = ($nFan -gt 8 -or $v -le 0) }
            elseif ($t -eq 'C') { $pula = ($rot -notmatch 'Core.*Clock|GPU.*Clock|Memory.*Clock|Effective|Bus' -or $nClk -ge 12); if (-not $pula) { $nClk++ } }
            elseif ($t -eq 'U') { $pula = ($rot -notmatch 'Total|GPU Core|Core.*Load|Memory.*(Load|Usage)|GPU D3D|Physical') }
            elseif ($t -in 'A', 'O') { $pula = $true }
            if ($pula) { continue }
            & $add $t 'H' $l[1] $rot $v
        }
    }

    $msi = $null
    try { Initialize-Msi } catch { }
    try { if ($script:TesteMsiBytes) { $msi = [WDMsi]::LerBytes($script:TesteMsiBytes) } elseif ($env:OS -eq 'Windows_NT') { $msi = [WDMsi]::Ler() } } catch { }
    if ($msi -and $msi.Count -gt 0) {
        $fontes.Add('MSI Afterburner')
        foreach ($m in $msi) {
            $nome = $m[0]; $un = $m[1]; $v = [double]::Parse($m[2], $script:MonInv)
            $t = 'O'
            if ($un -match '°C|C$' -or $nome -match 'temperature|temperatura') { $t = 'T' }
            elseif ($un -match '^V$|mV' -or $nome -match 'voltage|tens') { $t = 'V' }
            elseif ($un -match '^W$|%?TDP' -or $nome -match 'power|pot[eê]ncia') { $t = 'P' }
            elseif ($un -match 'RPM') { $t = 'F' }
            elseif ($un -match 'MHz') { $t = 'C' }
            elseif ($un -match '%') { $t = 'U' }
            & $add $t 'M' 'MSI Afterburner' $nome $v
        }
    }

    if ($fontes.Count -eq 0 -and $env:OS -eq 'Windows_NT') {
        foreach ($ns in 'root\LibreHardwareMonitor', 'root\OpenHardwareMonitor') {
            try {
                $s = @(Get-CimInstance -Namespace $ns -ClassName Sensor -ErrorAction Stop)
                if ($s.Count -gt 0) {
                    $fontes.Add($(if ($ns -match 'Libre') { 'LibreHardwareMonitor' } else { 'OpenHardwareMonitor' }))
                    $tipos = @{ 'Temperature' = 'T'; 'Voltage' = 'V'; 'Fan' = 'F'; 'Power' = 'P'; 'Clock' = 'C'; 'Load' = 'U' }
                    foreach ($x in $s) {
                        if ($null -eq $x.Value -or -not $tipos.ContainsKey("$($x.SensorType)")) { continue }
                        $t = $tipos["$($x.SensorType)"]
                        if ($t -eq 'F' -and [double]$x.Value -le 0) { continue }
                        & $add $t 'L' "$($x.Parent)" "$($x.Name)" ([double]$x.Value)
                    }
                    break
                }
            } catch { }
        }
    }

    # Leituras próprias do WinDiag (não dependem de nenhum programa): uso do processador e da memória.
    try {
        if ($env:OS -eq 'Windows_NT') {
            $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Measure-Object -Property LoadPercentage -Average
            if ($null -ne $cpu.Average) { & $add 'U' 'W' 'WinDiag' 'Uso do processador (%)' ([double]$cpu.Average) }
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
            if ($os.TotalVisibleMemorySize -gt 0) { & $add 'U' 'W' 'WinDiag' 'Memória em uso (%)' ([math]::Round(100.0 * (1 - $os.FreePhysicalMemory / $os.TotalVisibleMemorySize), 1)) }
        }
    } catch { }
    # Placa de vídeo: se nenhum programa publicou a temperatura dela, pergunta ao driver (nvidia-smi / AMD).
    $temGpu = @($itens | Where-Object { $_.Chave -match '^T\|' -and $_.Chave -match 'GPU|Radeon|GeForce|NVIDIA' }).Count -gt 0
    if (-not $temGpu -and (Get-Command Get-TempGpu -ErrorAction SilentlyContinue)) {
        try {
            $g = Get-TempGpu
            if ($g) {
                if ($null -ne $g.Temp) { & $add 'T' 'W' 'WinDiag' 'GPU (°C)' ([double]$g.Temp) }
                if ($null -ne $g.Hotspot) { & $add 'T' 'W' 'WinDiag' 'GPU ponto quente (°C)' ([double]$g.Hotspot) }
                if ($null -ne $g.Potencia) { & $add 'P' 'W' 'WinDiag' 'GPU potência (W)' ([double]$g.Potencia) }
                if ($null -ne $g.Clock) { & $add 'C' 'W' 'WinDiag' 'GPU clock (MHz)' ([double]$g.Clock) }
                $fontes.Add('driver da placa de vídeo')
            }
        } catch { }
    }
    return @{ Fontes = ($fontes -join ', '); Itens = $itens.ToArray() }
}
#endregion leitura dos sensores

#region gravação
function Invoke-Monitor {
    # Laço principal. Cada leitura é gravada e empurrada para o disco na hora (WriteThrough + Flush), para sobreviver a um desligamento súbito.
    param([int]$Intervalo = 2, [double]$MaxHoras = 12, [scriptblock]$Leitor, [int]$MaxAmostras = 0)
    if ($Intervalo -lt 1) { $Intervalo = 1 }
    if ($Intervalo -gt 30) { $Intervalo = 30 }
    $pasta = Get-PastaMonitor
    New-Item -ItemType Directory -Force -Path $pasta | Out-Null
    $flag = Join-Path $pasta 'parar.flag'
    Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
    Remove-AntigasSessoes
    $inicio = Get-Date
    $arq = Join-Path $pasta ('sessao-{0}.log' -f $inicio.ToString('yyyyMMdd-HHmmss'))
    $enc = New-Object System.Text.UTF8Encoding($false)
    $fs = New-Object System.IO.FileStream($arq, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite, 4096, [System.IO.FileOptions]::WriteThrough)
    $grava = {
        param([string]$txt)
        $b = $enc.GetBytes($txt + "`n")
        $fs.Write($b, 0, $b.Length)
        $fs.Flush($true)
    }
    $fmt = 'yyyy-MM-ddTHH:mm:ss'
    $motivo = 'erro'
    try {
        $estadoArq = Join-Path $pasta 'estado.json'
        $est = @{ Pid = $PID; Inicio = $inicio.ToString($fmt, $script:MonInv); Arquivo = $arq; Intervalo = $Intervalo }
        [IO.File]::WriteAllText($estadoArq, ($est | ConvertTo-Json -Compress))
        & $grava ('#inicio;{0};intervalo={1};pc={2}' -f $inicio.ToString($fmt, $script:MonInv), $Intervalo, $env:COMPUTERNAME)

        $cols = New-Object System.Collections.Generic.List[string]
        $idx = @{}
        $maximos = @{}
        $n = 0
        $prox = Get-Date
        while ($true) {
            if (Test-Path -LiteralPath $flag) { $motivo = 'usuario'; break }
            if (((Get-Date) - $inicio).TotalHours -ge $MaxHoras) { $motivo = 'limite'; break }
            $r = $null
            try { if ($Leitor) { $r = & $Leitor } else { $r = Get-LeiturasMonitor } } catch { $r = $null }
            $agora = Get-Date
            if ($r -and $r.Itens) {
                if ($n -eq 0) { & $grava ('#fontes;' + $r.Fontes) }
                $novas = $false
                foreach ($i in $r.Itens) { if (-not $idx.ContainsKey($i.Chave)) { $idx[$i.Chave] = $cols.Count; $cols.Add($i.Chave); $novas = $true } }
                if ($novas) { & $grava ('#cols;' + ($cols -join ';')) }
                $vals = New-Object string[] $cols.Count
                foreach ($i in $r.Itens) {
                    $k = $idx[$i.Chave]
                    $vals[$k] = ([double]$i.Valor).ToString('0.###', $script:MonInv)
                    if (-not $maximos.ContainsKey($i.Chave) -or $i.Valor -gt $maximos[$i.Chave]) { $maximos[$i.Chave] = [double]$i.Valor }
                }
                & $grava ($agora.ToString($fmt, $script:MonInv) + ';' + ($vals -join ';'))
                $n++
                if ($n % 30 -eq 0) {
                    $mx = New-Object string[] $cols.Count
                    for ($k = 0; $k -lt $cols.Count; $k++) { if ($maximos.ContainsKey($cols[$k])) { $mx[$k] = ([double]$maximos[$cols[$k]]).ToString('0.###', $script:MonInv) } }
                    & $grava ('#max;' + ($mx -join ';'))
                }
                if ($MaxAmostras -gt 0 -and $n -ge $MaxAmostras) { $motivo = 'teste'; break }
            }
            $prox = $prox.AddSeconds($Intervalo)
            if ($prox -lt (Get-Date)) { $prox = (Get-Date).AddSeconds($Intervalo) }
            while ((Get-Date) -lt $prox) {
                if (Test-Path -LiteralPath $flag) { break }
                Start-Sleep -Milliseconds 200
            }
        }
    } catch {
        $motivo = 'erro'
        try { & $grava ('#erro;' + ($_.Exception.Message -replace '[;\r\n]', ' ')) } catch { }
    } finally {
        try { & $grava ('#fim;{0};{1}' -f (Get-Date).ToString($fmt, $script:MonInv), $motivo) } catch { }
        try { $fs.Dispose() } catch { }
        Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath (Join-Path $pasta 'estado.json') -Force -ErrorAction SilentlyContinue
    }
    return $arq
}

function Remove-AntigasSessoes {
    param([int]$Manter = 15)
    try {
        $pasta = Get-PastaMonitor
        $l = @(Get-ChildItem -LiteralPath $pasta -Filter 'sessao-*.log' -File -ErrorAction Stop | Sort-Object Name -Descending)
        foreach ($f in ($l | Select-Object -Skip $Manter)) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
    } catch { }
}
#endregion gravação

#region análise
function Read-SessaoMonitor {
    # Lê um arquivo de sessão. Só as últimas amostras são convertidas em número (rápido mesmo com horas de registro).
    param([string]$Arquivo, [int]$UltimasN = 200)
    $txt = $null
    try {
        $fs = New-Object System.IO.FileStream($Arquivo, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        try { $sr = New-Object System.IO.StreamReader($fs, [Text.Encoding]::UTF8); $txt = $sr.ReadToEnd() } finally { $fs.Dispose() }
    } catch { return $null }
    $linhas = @($txt -split "`n" | ForEach-Object { $_.TrimEnd("`r") } | Where-Object { $_ })
    if ($linhas.Count -eq 0) { return $null }
    $r = @{ Arquivo = $Arquivo; Inicio = $null; Fim = $null; Motivo = $null; Intervalo = 2; Fontes = ''; Colunas = @(); Maximos = @{}; Amostras = @(); NAmostras = 0; Erro = $null; UltimoRegistro = $null }
    $cols = @()
    $amostrasTxt = New-Object System.Collections.Generic.List[string]
    $colsPorAmostra = New-Object System.Collections.Generic.List[object]
    $ultimoMax = $null; $colsMax = $null
    foreach ($l in $linhas) {
        if ($l[0] -eq '#') {
            $p = $l.Split(';')
            switch ($p[0]) {
                '#inicio' { try { $r.Inicio = [datetime]::Parse($p[1], $script:MonInv) } catch { }; foreach ($q in $p) { if ($q -match '^intervalo=(\d+)') { $r.Intervalo = [int]$Matches[1] } } }
                '#fontes' { $r.Fontes = ($l.Substring(8)) }
                '#cols'   { $cols = @($p[1..($p.Count - 1)]) }
                '#max'    { $ultimoMax = $p; $colsMax = $cols }
                '#fim'    { try { $r.Fim = [datetime]::Parse($p[1], $script:MonInv) } catch { }; if ($p.Count -gt 2) { $r.Motivo = $p[2] } }
                '#erro'   { $r.Erro = ($l.Substring(6)) }
            }
            continue
        }
        $amostrasTxt.Add($l)
        $colsPorAmostra.Add($cols)
    }
    $r.Colunas = $cols
    $r.NAmostras = $amostrasTxt.Count
    if ($ultimoMax -and $colsMax) {
        for ($k = 0; $k -lt $colsMax.Count; $k++) {
            $s = if ($k + 1 -lt $ultimoMax.Count) { $ultimoMax[$k + 1] } else { '' }
            $v = 0.0
            if ($s -and [double]::TryParse($s, 'Float', $script:MonInv, [ref]$v)) { $r.Maximos[$colsMax[$k]] = $v }
        }
    }
    $ini = [math]::Max(0, $amostrasTxt.Count - $UltimasN)
    $am = New-Object System.Collections.Generic.List[object]
    for ($j = $ini; $j -lt $amostrasTxt.Count; $j++) {
        $p = $amostrasTxt[$j].Split(';')
        $t = [datetime]::MinValue
        if (-not [datetime]::TryParse($p[0], $script:MonInv, 'None', [ref]$t)) { continue }
        $c = $colsPorAmostra[$j]
        $h = @{}
        for ($k = 0; $k -lt $c.Count; $k++) {
            if ($k + 1 -ge $p.Count) { break }
            $v = 0.0
            if ($p[$k + 1] -and [double]::TryParse($p[$k + 1], 'Float', $script:MonInv, [ref]$v)) { $h[$c[$k]] = $v }
        }
        $am.Add(@{ T = $t; V = $h })
    }
    $r.Amostras = $am.ToArray()
    if ($am.Count -gt 0) { $r.UltimoRegistro = $am[$am.Count - 1].T } elseif ($r.Inicio) { $r.UltimoRegistro = $r.Inicio }
    return $r
}

function Get-RotuloChave {
    param([string]$Chave)
    $p = $Chave.Split('|')
    if ($p.Count -ge 4) { $s = $p[2]; $rot = ($p[3] -replace '#\d+$', ''); if ($p[1] -eq 'W' -or $s -eq 'MSI Afterburner' -or -not $s) { return $rot } else { return ('{0} - {1}' -f $rot, ($s -replace '^\S+:\s*', '')) } }
    return $Chave
}

function Get-EventosSessao {
    # Procura no log do Windows como a sessão terminou: desligamento normal (1074) ou queda (Kernel-Power 41 / 6008).
    param([datetime]$Desde)
    $r = @{ Queda = $null; Normal = $null }
    try {
        $q = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Power'; Id = 41; StartTime = $Desde } -MaxEvents 5 -ErrorAction Stop | Sort-Object TimeCreated)
        if ($q.Count -gt 0) { $r.Queda = $q[0].TimeCreated }
    } catch { }
    try {
        $n = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 1074; StartTime = $Desde.AddMinutes(-3) } -MaxEvents 5 -ErrorAction Stop | Sort-Object TimeCreated)
        if ($n.Count -gt 0) { $r.Normal = $n[0].TimeCreated }
    } catch { }
    return $r
}

function Get-AnaliseSessao {
    # Resume uma sessão: o que estava acontecendo nos últimos segundos antes do último registro e um veredito em linguagem simples.
    param([string]$Arquivo, [int]$JanelaSeg = 90, $Eventos)
    $s = Read-SessaoMonitor $Arquivo
    if (-not $s) { return $null }
    $ativo = Get-EstadoMonitor
    $a = @{ Arquivo = $Arquivo; Inicio = $s.Inicio; UltimoRegistro = $s.UltimoRegistro; Encerrada = [bool]$s.Fim; Motivo = $s.Motivo; Fontes = $s.Fontes
            NAmostras = $s.NAmostras; Alertas = (New-Object System.Collections.Generic.List[string]); Linhas = (New-Object System.Collections.Generic.List[string])
            Veredito = ''; Quem = 'indefinido'; Gravidade = 'Info'; TemTemperatura = $false }
    if ($s.Amostras.Count -eq 0) { $a.Veredito = 'A sessão não chegou a gravar leituras (o monitor foi encerrado logo ao iniciar ou não encontrou sensores).'; return $a }
    $ult = $s.Amostras[$s.Amostras.Count - 1]
    $corte = $ult.T.AddSeconds(-$JanelaSeg)
    $jan = @($s.Amostras | Where-Object { $_.T -ge $corte })
    $dur = if ($s.Inicio) { $ult.T - $s.Inicio } else { [timespan]::Zero }

    # Como a sessão terminou
    if ($s.Fim) {
        $a.Quem = 'encerrada'
    } elseif ($ativo -and $ativo.Arquivo -eq $Arquivo) {
        $a.Quem = 'ativa'
    } else {
        $ev = $Eventos
        if (-not $ev) { $ev = Get-EventosSessao -Desde $ult.T.AddSeconds(-1) }
        if ($ev.Normal -and $ev.Normal -ge $ult.T.AddMinutes(-3) -and $ev.Normal -le $ult.T.AddMinutes(1)) { $a.Quem = 'normal' }
        elseif ($ev.Queda -and $ev.Queda -ge $ult.T) { $a.Quem = 'queda'; $a.QuedaEm = $ev.Queda }
        else { $a.Quem = 'indefinido' }
    }

    # Valores nos últimos segundos
    $chaves = @($s.Colunas)
    $max = @{}; $min = @{}; $ultimo = @{}
    foreach ($am in $jan) {
        foreach ($k in $am.V.Keys) {
            $v = $am.V[$k]
            if (-not $max.ContainsKey($k) -or $v -gt $max[$k]) { $max[$k] = $v }
            if (-not $min.ContainsKey($k) -or $v -lt $min[$k]) { $min[$k] = $v }
        }
    }
    foreach ($k in $ult.V.Keys) { $ultimo[$k] = $ult.V[$k] }

    $temps = @($chaves | Where-Object { $_ -match '^T\|' })
    $a.TemTemperatura = ($temps.Count -gt 0)
    $cpuT = @($temps | Where-Object { $_ -match 'CPU|Ryzen|Tctl|Tdie|Package|Core \d|Núcleo' -and $_ -notmatch 'GPU' })
    $gpuT = @($temps | Where-Object { $_ -match 'GPU|Radeon|GeForce|NVIDIA' })
    $hot = @($gpuT | Where-Object { $_ -match 'Hot|quente' })
    $maxDe = { param($lst) $m = $null; foreach ($k in $lst) { if ($max.ContainsKey($k) -and ($null -eq $m -or $max[$k] -gt $m.V)) { $m = @{ K = $k; V = $max[$k] } } }; $m }
    $c = & $maxDe $cpuT; $g = & $maxDe $gpuT; $h = & $maxDe $hot
    $calor = $false
    if ($c) { $a.Linhas.Add(('Processador: {0:N0} °C no máximo nos últimos {1} s ({2}).' -f $c.V, $JanelaSeg, (Get-RotuloChave $c.K))); if ($c.V -ge 92) { $calor = $true; $a.Alertas.Add(('Processador muito quente ({0:N0} °C).' -f $c.V)) } }
    if ($g) { $a.Linhas.Add(('Placa de vídeo: {0:N0} °C no máximo nos últimos {1} s ({2}).' -f $g.V, $JanelaSeg, (Get-RotuloChave $g.K))); if ($g.V -ge 88) { $calor = $true; $a.Alertas.Add(('Placa de vídeo muito quente ({0:N0} °C).' -f $g.V)) } }
    if ($h) { $a.Linhas.Add(('Ponto quente da placa de vídeo: {0:N0} °C.' -f $h.V)); if ($h.V -ge 100) { $calor = $true; $a.Alertas.Add(('Ponto quente da placa de vídeo em {0:N0} °C.' -f $h.V)) } }

    # Tensões da fonte (trilhos de 12 V, 5 V e 3,3 V lidos pela placa-mãe; erro típico de alguns %)
    $tensao = $false
    $trilhos = @(
        @{ Nome = '12 V'; Rx = '(^|[^0-9.])\+?12(\.0+)? ?V'; Min = 11.4; Max = 12.6 },
        @{ Nome = '5 V';  Rx = '(^|[^0-9.])\+?5(\.0+)? ?V(?!SB)'; Min = 4.75; Max = 5.25 },
        @{ Nome = '3,3 V'; Rx = '(^|[^0-9.])\+?3[.,]3 ?V|3V3'; Min = 3.13; Max = 3.47 }
    )
    foreach ($tr in $trilhos) {
        $ks = @($chaves | Where-Object { $_ -match '^V\|' -and ((Get-RotuloChave $_) -match $tr.Rx) -and $_ -notmatch 'GPU|Core|SoC|VDD|DRAM|CPU' } | Select-Object -First 1)
        if ($ks.Count -eq 0) { continue }
        $k = $ks[0]
        if (-not $min.ContainsKey($k)) { continue }
        $a.Linhas.Add(('Trilho de {0}: entre {1:N2} e {2:N2} V nos últimos {3} s; último valor {4:N2} V.' -f $tr.Nome, $min[$k], $max[$k], $JanelaSeg, $ultimo[$k]))
        if ($min[$k] -lt $tr.Min -or $max[$k] -gt $tr.Max) { $tensao = $true; $a.Alertas.Add(('Tensão de {0} fora do normal ({1:N2} a {2:N2} V).' -f $tr.Nome, $min[$k], $max[$k])) }
        elseif ($jan.Count -ge 6) {
            # queda brusca no final em relação ao valor estável de antes
            $antes = @($jan | Select-Object -First ($jan.Count - 2) | ForEach-Object { $_.V[$k] } | Where-Object { $null -ne $_ } | Sort-Object)
            if ($antes.Count -ge 4 -and $ultimo.ContainsKey($k)) {
                $med = $antes[[int]($antes.Count / 2)]
                if (($med - $ultimo[$k]) -gt (0.025 * $med)) { $tensao = $true; $a.Alertas.Add(('Tensão de {0} caiu no fim (de {1:N2} para {2:N2} V).' -f $tr.Nome, $med, $ultimo[$k])) }
            }
        }
    }
    foreach ($tp in 'Uso do processador \(%\)', 'GPU core load|GPU usage|GPU Core') {
        $kk = @($chaves | Where-Object { $_ -match '^U\|' -and $_ -match $tp } | Select-Object -First 1)
        if ($kk.Count -gt 0 -and $ultimo.ContainsKey($kk[0])) { $a.Linhas.Add(('{0}: {1:N0}% no último registro.' -f (Get-RotuloChave $kk[0]), $ultimo[$kk[0]])) }
    }
    $pk = @($chaves | Where-Object { $_ -match '^P\|' -and $_ -match 'GPU' } | Select-Object -First 1)
    if ($pk.Count -gt 0 -and $ultimo.ContainsKey($pk[0])) { $a.Linhas.Add(('Consumo da placa de vídeo no último registro: {0:N0} W (máximo da janela {1:N0} W).' -f $ultimo[$pk[0]], $max[$pk[0]])) }
    $fps = @($chaves | Where-Object { $_ -match '^O\|' -and $_ -match 'Framerate$|FPS' } | Select-Object -First 1)
    if ($fps.Count -gt 0 -and $ultimo.ContainsKey($fps[0])) { $a.Linhas.Add(('Jogo em execução (quadros por segundo no último registro): {0:N0}.' -f $ultimo[$fps[0]])) }

    # Cabeçalho
    $a.Linhas.Insert(0, ('Sessão de {0}, durou {1:N0} min com {2} leituras (a cada {3} s). Fontes: {4}.' -f $(if ($s.Inicio) { $s.Inicio.ToString('dd/MM/yyyy HH:mm') } else { '?' }), $dur.TotalMinutes, $s.NAmostras, $s.Intervalo, $(if ($s.Fontes) { $s.Fontes } else { 'nenhuma' })))
    $a.Linhas.Insert(1, ('Último registro: {0}.' -f $ult.T.ToString('dd/MM/yyyy HH:mm:ss')))

    # Veredito
    $fim = $ult.T.ToString('HH:mm:ss')
    if ($a.Quem -eq 'ativa') {
        $a.Veredito = 'O monitor ainda está ligado e gravando. Se o computador desligar, o último registro mostrará a situação do momento.'
    } elseif ($a.Quem -eq 'encerrada') {
        $a.Veredito = 'A sessão terminou normalmente (monitor parado por você).'
    } elseif ($a.Quem -eq 'normal') {
        $a.Veredito = 'O Windows foi desligado ou reiniciado normalmente nesse horário; não foi uma queda.'
    } else {
        $pref = if ($a.Quem -eq 'queda') { "O Windows registrou desligamento inesperado depois de $fim (Kernel-Power 41). " } else { "O monitor parou sem fechar a sessão às $fim (provável queda, mas o Windows ainda não confirmou). " }
        if ($calor) { $a.Veredito = $pref + 'Antes de parar, a temperatura estava muito alta: o mais provável é superaquecimento (proteção térmica desliga o PC). Limpe o cooler, troque a pasta térmica e confira a ventilação.'; $a.Gravidade = 'Critico' }
        elseif ($tensao) { $a.Veredito = $pref + 'Antes de parar, a tensão da fonte oscilou: indício de fonte fraca ou com defeito (ou sobrecarga quando a placa de vídeo puxa muita energia). Teste com outra fonte de qualidade.'; $a.Gravidade = 'Critico' }
        elseif (-not $a.TemTemperatura) { $a.Veredito = $pref + 'Nenhuma temperatura foi gravada: abra o HWiNFO (modo Sensores, com "Shared Memory Support" ligado) ou o MSI Afterburner antes de jogar, para o próximo registro mostrar calor e tensão.'; $a.Gravidade = 'Atencao' }
        else { $a.Veredito = $pref + 'Nenhuma temperatura ou tensão estava fora do normal até o último registro. Uma queda assim, sem aviso, costuma ser corte de energia (fonte, filtro de linha, tomada) ou falha elétrica da placa de vídeo/placa-mãe, e não calor. A leitura é a cada ' + $s.Intervalo + ' s e os sensores de tensão da placa-mãe têm erro de alguns %, então um pico mais curto pode não aparecer.'; $a.Gravidade = 'Atencao' }
    }
    return $a
}

function Get-UltimaSessaoMonitor {
    # Último arquivo de sessão (que não seja a que está rodando agora).
    try {
        $ativo = Get-EstadoMonitor
        $l = @(Get-ChildItem -LiteralPath (Get-PastaMonitor) -Filter 'sessao-*.log' -File -ErrorAction Stop | Sort-Object Name -Descending)
        foreach ($f in $l) { if ($ativo -and $ativo.Arquivo -eq $f.FullName) { continue }; return $f.FullName }
    } catch { }
    return $null
}

function Format-TextoSessao {
    param($Analise)
    if (-not $Analise) { return 'Nenhum registro do monitor foi encontrado ainda.' }
    $t = New-Object System.Collections.Generic.List[string]
    $t.Add('WinDiag - último registro do monitor')
    $t.Add('')
    foreach ($l in $Analise.Linhas) { $t.Add($l) }
    $t.Add('')
    if ($Analise.Alertas.Count -gt 0) { $t.Add('Alertas: ' + ($Analise.Alertas -join ' ')); $t.Add('') }
    $t.Add('Conclusão: ' + $Analise.Veredito)
    $t.Add('')
    $t.Add('Arquivo completo: ' + $Analise.Arquivo)
    return ($t -join "`r`n")
}

function Invoke-AnaliseMonitor {
    # Usado pela verificação: se a última sessão do monitor foi interrompida por uma queda, mostra o que ela registrou.
    $f = Get-UltimaSessaoMonitor
    if (-not $f) { return }
    $a = Get-AnaliseSessao -Arquivo $f
    if (-not $a -or $a.Encerrada -or $a.Quem -in 'normal', 'ativa') { return }
    if ($a.UltimoRegistro -and $a.UltimoRegistro -lt (Get-Date).AddDays(-14)) { return }
    $linhas = ($a.Linhas -join ' ')
    Add-Achado -Gravidade $a.Gravidade -Categoria 'Monitor' -Titulo ("O monitor em tempo real parou sem fechar a sessão ({0})" -f $a.UltimoRegistro.ToString('dd/MM HH:mm:ss')) `
        -Detalhe ($linhas + ' ' + $(if ($a.Alertas.Count -gt 0) { 'Alertas: ' + ($a.Alertas -join ' ') } else { '' })) `
        -Solucao $a.Veredito `
        -Explicacao 'O monitor grava os sensores a cada poucos segundos e força cada linha para o disco. Quando o computador desliga sozinho durante um jogo, o último registro mostra como estavam temperatura e tensão no momento da queda.' `
        -Veredito 'Depende'
}
#endregion análise

if ($Executar) {
    $dir = Split-Path -Parent $MyInvocation.MyCommand.Path
    . (Join-Path $dir 'WinDiag-Bench.ps1')
    [void](Invoke-Monitor -Intervalo $Intervalo)
}
