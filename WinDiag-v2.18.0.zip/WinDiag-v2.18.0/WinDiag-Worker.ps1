﻿# WinDiag-Worker.ps1
# Motor da interface gráfica. Roda em um runspace separado (a janela nunca trava) e conversa
# com a interface por meio de uma fila. Não é pensado para ser executado diretamente.
#
# Espera duas variáveis globais, criadas pela interface:
#   $WD_Sync : hashtable sincronizada com a chave Fila (ConcurrentQueue)
#   $WD_Opc  : hashtable com PastaScripts, PastaRelatorio, SomenteLeitura, SemWindowsUpdate,
#              PularScanVolumes, DiasEventos

$env:WINDIAG_TESTE = '1'
. (Join-Path $global:WD_Opc.PastaScripts 'WinDiag.ps1')
. (Join-Path $global:WD_Opc.PastaScripts 'WinDiag-Bench.ps1')

# ----------------------------------------------------------------------------
# Comunicação com a interface
# ----------------------------------------------------------------------------
function Send-GUI {
    param([hashtable]$Msg)
    $global:WD_Sync.Fila.Enqueue($Msg)
}

function Wait-GUI {
    # Envia uma pergunta e espera a resposta da interface.
    param([hashtable]$Msg)
    $req = [hashtable]::Synchronized(@{ Resp = $null; Evt = (New-Object System.Threading.ManualResetEvent $false) })
    $Msg.Req = $req
    Send-GUI $Msg
    [void]$req.Evt.WaitOne()
    return $req.Resp
}

$script:UltFaixaLog = -1

function Get-PctProgresso {
    # Reconhece linhas de progresso do DISM ("[====== 63,4% ====]") e do SFC ("Verification 45% complete").
    # Devolve o percentual (0 a 100) ou $null se a linha não for de progresso.
    param([string]$Linha)
    $t = "$Linha".Trim()
    if (-not $t) { return $null }
    $m = [regex]::Match($t, '(?<p>\d{1,3}(?:[.,]\d+)?)\s*%')
    if (-not $m.Success) { return $null }
    $dism = ($t -match '^\[[=\s\-]*\d{1,3}(?:[.,]\d+)?\s*%[=\s\-]*\]$')
    $sfc = ($t -match '(?i)(verification|verifica..o).*%|%.*(complete|conclu)')
    if (-not ($dism -or $sfc)) { return $null }
    $v = [double]::Parse($m.Groups['p'].Value.Replace(',', '.'), [System.Globalization.CultureInfo]::InvariantCulture)
    if ($v -lt 0 -or $v -gt 100) { return $null }
    return $v
}

function Write-Host {
    # Substitui o Write-Host: o texto vai para o painel de detalhes e para o arquivo de log.
    [CmdletBinding()]
    param(
        [Parameter(Position = 0, ValueFromPipeline = $true)][AllowNull()][AllowEmptyString()][object]$Object,
        [object]$ForegroundColor,
        [object]$BackgroundColor,
        [switch]$NoNewline,
        [object]$Separator
    )
    process {
        $t = ''
        if ($null -ne $Object) { $t = ("$Object" -replace "`0", '').TrimEnd("`r", "`n") }
        $pct = Get-PctProgresso $t
        if ($null -ne $pct) {
            # Progresso do DISM/SFC vira uma mensagem própria; no log aparece só a cada 10%.
            Send-GUI @{ T = 'prog'; Pct = $pct }
            $faixa = [int][Math]::Floor($pct / 10)
            if ($faixa -eq $script:UltFaixaLog) { return }
            $script:UltFaixaLog = $faixa
        } elseif ($t -match 'Deployment Image Servicing|Gerenciamento e Manuten') {
            $script:UltFaixaLog = -1
            Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Reparando a imagem do Windows (DISM)' }
        } elseif ($t -match '(?i)Beginning system scan|Iniciando a verifica') {
            $script:UltFaixaLog = -1
            Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Verificando os arquivos do sistema (SFC)' }
        }
        Send-GUI @{ T = 'log'; Texto = $t; Cor = "$ForegroundColor" }
        if ($script:ArquivoLog) {
            try { Add-Content -LiteralPath $script:ArquivoLog -Value $t -Encoding UTF8 -ErrorAction Stop } catch { }
        }
    }
}

function Read-Resposta {
    # Perguntas do WinDiag viram caixas de diálogo na interface.
    param([string]$Prompt)
    if ($global:WD_Opc.AceitarTudo) {
        # Modo "aceitar tudo": responde sozinho, sem interromper. Padrões seguros.
        if ($Prompt -match 'ponto de restaura') { return 's' }
        if ($Prompt -match 'Exportar uma c') { return 's' }
        if ($Prompt -match 'Continuar mesmo assim') { return 's' }
        return ''   # qualquer outra pergunta: resposta padrão (pular)
    }
    $r = Wait-GUI @{ T = 'ask'; Prompt = $Prompt }
    return [string]$r
}

function Confirm-Acao {
    param([string]$Mensagem, [switch]$Protecao, [switch]$Sensivel, [switch]$Desfaz, [switch]$MudaDriver, [string]$Aviso = '')
    if ($SomenteLeitura) { return $false }
    if ($global:WD_Sync.Cancelar) {
        # O usuário pediu para parar: a correção em andamento terminou e as próximas são puladas.
        if (-not $script:AvisouCancelamento) {
            $script:AvisouCancelamento = $true
            Write-Host '  Interrompido a pedido do usuário: as próximas correções foram puladas.' -ForegroundColor Yellow
        }
        return $false
    }
    if ($global:WD_Opc.AceitarTudo) {
        if ($Sensivel) {
            # Drivers internos do sistema nunca são alterados sem o usuário ver: ficam de fora.
            Write-Host "  Pulado (driver interno do sistema, exige confirmação manual): $Mensagem" -ForegroundColor Yellow
            return $false
        }
        if ($Desfaz) {
            # Remover proteções contradiz as correções aceitas acima: só com confirmação manual.
            Write-Host "  Pulado (desfaz uma proteção; só com confirmação manual): $Mensagem" -ForegroundColor Yellow
            return $false
        }
        Write-Host "  Aceito automaticamente: $Mensagem" -ForegroundColor DarkGray
        if ($Protecao) { if (-not (Invoke-Protecao -Backup:$MudaDriver)) { return $false } }
        return $true
    }
    $ok = Wait-GUI @{ T = 'confirm'; Mensagem = $Mensagem; Aviso = $Aviso; Sensivel = [bool]$Sensivel }
    if (-not $ok) { return $false }
    if ($Protecao) {
        if (-not (Invoke-Protecao -Backup:$MudaDriver)) { return $false }
    }
    return $true
}

# ----------------------------------------------------------------------------
# Fases
# ----------------------------------------------------------------------------
function Initialize-FaseGUI {
    # -Nova: começa uma verificação nova (pasta nova). Sem -Nova, reaproveita a pasta da verificação atual
    # (assim os reparos e o relatório atualizado ficam junto da verificação que os originou).
    param([switch]$Nova)
    $o = $global:WD_Opc
    $global:SomenteLeitura    = [bool]$o.SomenteLeitura
    $global:SemWindowsUpdate  = [bool]$o.SemWindowsUpdate
    $global:PularScanVolumes  = [bool]$o.PularScanVolumes
    $global:VerificacaoProfunda = [bool]$o.VerificacaoProfunda
    $global:DiasEventos       = [int]$o.DiasEventos
    $script:IsAdmin           = Test-Administrador
    $script:AvisouCancelamento = $false

    if (-not $Nova -and $script:ArquivoLog -and $script:PastaRelatorioFinal -and (Test-Path -LiteralPath $script:PastaRelatorioFinal)) { return }
    $script:Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $pasta = New-PastaVerificacao -Base $o.PastaRelatorio
    $script:PastaRelatorioFinal = $pasta
    $script:ArquivoLog  = Join-Path $pasta "WinDiag_$($script:Stamp).log"
    $script:ArquivoHtml = Join-Path $pasta "WinDiag_$($script:Stamp).html"
    $script:ArquivoJson = Join-Path $pasta "WinDiag_$($script:Stamp).json"
    $script:NotaAnteriorLida = $false; $script:NotaAnterior = $null; $script:NotaSaude = $null
}

function Invoke-EtapaGUI {
    param([int]$N, [int]$Total, [string]$Texto, [scriptblock]$Bloco)
    Send-GUI @{ T = 'etapa'; N = $N; Total = $Total; Texto = $Texto }
    Invoke-Secao $Texto $Bloco | Out-String -Stream | ForEach-Object { Write-Host $_ }
}

function Invoke-GuiScan {
    # Nova verificação começa do zero.
    $script:Achados.Clear()
    $script:Acoes.Clear()
    $script:Dados.Clear()
    $script:Alteracoes.Clear()
    $script:Sistema         = [ordered]@{}
    $script:ProtecaoFeita   = $false
    $script:BackupFeito     = $false
    $script:CachePnP        = $null
    $script:CacheAssinados  = $null
    $script:CachePacotes    = $null
    $script:ErroPacotes     = $null
    Initialize-FaseGUI -Nova

    if (-not (Test-Prerequisitos)) {
        return @{ Ok = $false; Erro = 'O Windows não está em condições de rodar a verificação (veja os detalhes técnicos).' }
    }

    $etapas = @(
        @{ Texto = 'Lendo as informações do sistema';             Bloco = { Get-InfoSistema } },
        @{ Texto = 'Analisando o hardware';                       Bloco = { Invoke-AnaliseHardware } },
        @{ Texto = 'Verificando a saúde dos discos';              Bloco = { Invoke-AnaliseDiscos } },
        @{ Texto = 'Verificando as unidades (pode demorar)';      Bloco = { Invoke-AnaliseVolumes } },
        @{ Texto = 'Procurando erros no histórico do Windows';    Bloco = { Invoke-AnaliseEventos } },
        @{ Texto = 'Analisando drivers e placa de vídeo';         Bloco = { Invoke-AnaliseDrivers } },
        @{ Texto = 'Segurança, manutenção e espaço em disco';     Bloco = { Invoke-AnaliseExtras } },
        @{ Texto = 'Gerando o relatório';                         Bloco = { $script:Comparacao = Get-ComparacaoVerificacoes; Export-Relatorios; Save-UltimaVerificacao } }
    )
    $i = 0
    foreach ($e in $etapas) {
        $i++
        Invoke-EtapaGUI -N $i -Total $etapas.Count -Texto $e.Texto -Bloco $e.Bloco
    }
    try { [void](Get-NotaAtual) } catch { }
    return @{
        Ok       = $true
        Achados  = $script:Achados.ToArray()
        # Só conta o que o "corrigir" realmente executa; remover proteções é opcional e só manual.
        NAcoes   = @($script:Acoes | Where-Object { -not $_.Desfaz }).Count
        NDesfaz  = @($script:Acoes | Where-Object { $_.Desfaz }).Count
        ResumoPC = (Get-ResumoPC)
        PC       = @(Get-DadosPC)
        Comparacao = (Format-TextoComparacao $script:Comparacao)
        NotaTexto  = (Format-TextoNota $script:NotaSaude $script:NotaAnterior)
        NotaValor  = $(if ($script:NotaSaude) { [int]$script:NotaSaude.Nota } else { -1 })
        NotaRotulo = $(if ($script:NotaSaude) { [string]$script:NotaSaude.Rotulo } else { '' })
        Html     = $script:ArquivoHtml
        Pasta    = $script:PastaRelatorioFinal
    }
}

function Invoke-GuiRepair {
    Initialize-FaseGUI
    Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Corrigindo (cada correção pede a sua confirmação)' }
    Invoke-Secao 'Reparos' { Invoke-FaseReparo } | Out-String -Stream | ForEach-Object { Write-Host $_ }
    return @{
        Ok         = $true
        Alteracoes = $script:Alteracoes.ToArray()
        Reiniciar  = [bool](Test-RebootPendente)
        Cancelado  = [bool]$global:WD_Sync.Cancelar
        TemCopia   = [bool](Get-PastaCopiaDrivers)
    }
}

function Get-PastaCopiaDrivers {
    # Cópia de drivers (DriversBackup_*) mais recente: a desta verificação ou, se não houver, a mais nova da pasta base.
    try {
        if ($script:PastaDrivers -and (Test-Path -LiteralPath $script:PastaDrivers)) { return $script:PastaDrivers }
        $base = $global:WD_Opc.PastaRelatorio
        if ($base -and (Test-Path -LiteralPath $base)) {
            $p = Get-ChildItem -LiteralPath $base -Directory -Recurse -Filter 'DriversBackup_*' -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($p) { return $p.FullName }
        }
    } catch { }
    return $null
}

function Invoke-GuiRestore {
    Initialize-FaseGUI
    $script:RestauradoOk = $false
    Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Restaurando a cópia dos drivers' }
    $pasta = Get-PastaCopiaDrivers
    if (-not $pasta) {
        return @{ Ok = $true; Restaurado = $false; Aviso = 'Não encontrei nenhuma cópia de drivers feita pelo WinDiag. A cópia só existe se você aceitou criá-la antes de uma correção.' }
    }
    $feito = $false
    Invoke-Secao 'Restaurar drivers' {
        Write-Host "  Cópia encontrada: $pasta"
        if (Confirm-Acao "Reinstalar os drivers guardados em '$pasta'? (reverte drivers atualizados depois da cópia)") {
            Write-Host '  Restaurando (pode levar alguns minutos)...'
            $saida = & pnputil.exe /add-driver (Join-Path $pasta '*.inf') /subdirs /install 2>&1
            $saida | Out-String -Stream | ForEach-Object { if ($_.Trim()) { Write-Host "  $_" } }
            Add-Alteracao -Acao "Restaurar cópia de drivers ($pasta)" -Resultado 'executado'
            $script:RestauradoOk = $true
        } else {
            Write-Host '  Nada foi restaurado.'
        }
    } | Out-String -Stream | ForEach-Object { Write-Host $_ }
    if ($script:RestauradoOk) { $feito = $true }
    return @{ Ok = $true; Restaurado = $feito; Pasta = $pasta }
}

function Invoke-GuiUnblock {
    Initialize-FaseGUI
    Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Removendo os bloqueios de driver criados pelo WinDiag' }
    Invoke-Secao 'Desfazer bloqueios' {
        Remove-BloqueiosWinDiag
        Remove-ExclusaoDriversWU
    } | Out-String -Stream | ForEach-Object { Write-Host $_ }
    return @{ Ok = $true }
}

function Invoke-GuiBench {
    Initialize-FaseGUI -Nova
    $etapa = { param($n, $total, $texto) Send-GUI @{ T = 'etapa'; N = $n; Total = $total; Texto = $texto } }
    $itens = @(Invoke-BenchCompleto -Etapa $etapa -Longo:([bool]$global:WD_Opc.BenchLongo) -Estresse:([bool]$global:WD_Opc.BenchEstresse) -Transicao:([bool]$global:WD_Opc.BenchTransicao) -TransicaoPesado:([bool]$global:WD_Opc.BenchTransicaoPesado) -EstresseProlongado:([bool]$global:WD_Opc.BenchEstresseProlongado) -PastaMonitor $PSScriptRoot)
    $arq = $null
    try { $arq = Export-RelatorioBench -Itens $itens -Pasta $script:PastaRelatorioFinal -Stamp $script:Stamp } catch { Write-Host "Não consegui salvar o relatório: $($_.Exception.Message)" -ForegroundColor Yellow }
    $texto = Format-TextoBench $itens
    foreach ($l in ($texto -split "`r`n")) { Write-Host $l }
    return @{
        Ok        = $true
        Texto     = $texto
        Pior      = (Get-PiorEstadoBench $itens)
        Html      = $arq
        Pasta     = $script:PastaRelatorioFinal
        Cancelado = [bool](Test-BenchCancelado)
    }
}

function Invoke-GuiTool {
    Initialize-FaseGUI
    $nome = [string]$global:WD_Opc.Ferramenta
    Send-GUI @{ T = 'etapa'; N = 0; Total = 0; Texto = 'Executando a ferramenta escolhida' }
    $r = Invoke-Ferramenta -Nome $nome -Destino ([string]$global:WD_Opc.DestinoBackup) -Dia ([string]$global:WD_Opc.AgendaDia) -Hora ([string]$global:WD_Opc.AgendaHora)
    if (-not $r.Ok) { return @{ Ok = $false; Erro = [string]$r.Erro } }
    foreach ($l in ([string]$r.Texto -split "`r`n")) { Write-Host $l }
    return @{ Ok = $true; Titulo = [string]$r.Titulo; Texto = [string]$r.Texto; Html = $null; Cancelado = [bool](Test-BenchCancelado) }
}

function Invoke-FaseGUI {
    param([ValidateSet('scan', 'repair', 'unblock', 'restore', 'bench', 'tool')][string]$Fase)
    $res = $null
    try {
        switch ($Fase) {
            'scan'    { $res = Invoke-GuiScan }
            'repair'  { $res = Invoke-GuiRepair }
            'unblock' { $res = Invoke-GuiUnblock }
            'restore' { $res = Invoke-GuiRestore }
            'bench'   { $res = Invoke-GuiBench }
            'tool'    { $res = Invoke-GuiTool }
        }
    } catch {
        $res = @{ Ok = $false; Erro = $_.Exception.Message }
        Write-Host "Erro inesperado: $($_.Exception.Message)" -ForegroundColor Red
    }
    # Só o último hashtable é o resultado; qualquer outra saída solta é ignorada.
    $res = @($res) | Where-Object { $_ -is [hashtable] } | Select-Object -Last 1
    if ($null -eq $res) { $res = @{ Ok = $false; Erro = 'A etapa terminou sem resultado.' } }
    $res.T = 'fim'
    $res.Fase = $Fase
    Send-GUI $res
}
