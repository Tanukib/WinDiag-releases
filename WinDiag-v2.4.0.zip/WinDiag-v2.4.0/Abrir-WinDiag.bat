@echo off
title WinDiag
rem Abre a interface grafica do WinDiag (sem janela preta). O Windows pedira permissao de administrador.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0WinDiag-GUI.ps1"
