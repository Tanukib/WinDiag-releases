@echo off
title Desinstalar o WinDiag
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Desinstalar-WinDiag.ps1"
echo.
pause
