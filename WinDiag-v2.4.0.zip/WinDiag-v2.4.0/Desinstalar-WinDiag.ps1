﻿<#
.SYNOPSIS
    Desinstala o WinDiag (programa, atalhos e registro em "Aplicativos e recursos").

.DESCRIPTION
    Não apaga os relatórios (pasta WinDiag na Área de Trabalho) nem desfaz alterações feitas no Windows.
    Se você ativou a proteção do driver de vídeo, use antes, no WinDiag, "Desfazer bloqueios de driver do WinDiag".
#>
param([switch]$SemPerguntas, [switch]$ApagarDados)

$ErrorActionPreference = 'Continue'
$pasta = $PSScriptRoot
Write-Host 'Desinstalando o WinDiag...' -ForegroundColor Cyan
if (-not $SemPerguntas) {
    Write-Host 'Atenção: isto NÃO desfaz alterações já feitas no Windows (por exemplo, a proteção do driver de vídeo).' -ForegroundColor Yellow
    Write-Host 'Se quiser desfazê-las, cancele agora e use, no WinDiag, "Desfazer bloqueios de driver do WinDiag".'
    $r = Read-Host 'Continuar com a desinstalação? [s/N]'
    if ($r -notmatch '^\s*[sSyY]') { Write-Host 'Nada foi feito.'; exit 0 }
    $d = Read-Host 'Apagar também os dados do WinDiag (estimativas de tempo, histórico de alterações e do teste de desempenho)? Os relatórios da Área de Trabalho são mantidos. [s/N]'
    $ApagarDados = ($d -match '^\s*[sSyY]')
}

foreach ($atalho in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'WinDiag.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'WinDiag.lnk'))) {
    if (Test-Path -LiteralPath $atalho) { Remove-Item -LiteralPath $atalho -Force -ErrorAction SilentlyContinue; Write-Host "  Atalho removido: $atalho" }
}
try { Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WinDiag' -Recurse -Force -ErrorAction SilentlyContinue } catch { }
if ($ApagarDados) {
    $dados = Join-Path $env:LOCALAPPDATA 'WinDiag'
    if (Test-Path -LiteralPath $dados) { Remove-Item -LiteralPath $dados -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  Dados removidos: $dados" }
}

# A própria pasta só pode ser apagada depois que este script terminar: um comando separado faz isso.
if ((Split-Path -Leaf $pasta) -eq 'WinDiag' -and $pasta -like "*\Programs\WinDiag") {
    $cmd = 'ping 127.0.0.1 -n 3 >nul & rd /s /q "{0}"' -f $pasta
    Start-Process -FilePath 'cmd.exe' -ArgumentList "/c $cmd" -WindowStyle Hidden
    Write-Host "  A pasta $pasta será apagada em instantes."
} else {
    Write-Host "  Esta cópia não está na pasta de instalação padrão; apague a pasta manualmente: $pasta" -ForegroundColor Yellow
}
Write-Host 'WinDiag desinstalado.' -ForegroundColor Green
