﻿# WinDiag-Bench.ps1
# Testes de desempenho e saúde: processador, memória RAM e placa de vídeo.
# Carregado pelo WinDiag-Worker.ps1. As funções devolvem tabelas (hashtables) simples; quem chama decide como exibir.
# Honestidade: estes testes dão uma boa indicação, mas NÃO substituem MemTest86 (memória) nem testes longos de estresse.

if (-not ('WDBench' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

public static class WDBench
{
    public static ulong Sink;

    // Roda "seconds" segundos de cálculo em "threads" threads e devolve quantos blocos de trabalho cada segundo concluiu.
    public static long[] Cpu(int seconds, int threads)
    {
        long[] b = new long[seconds];
        Stopwatch sw = Stopwatch.StartNew();
        Thread[] t = new Thread[threads];
        for (int i = 0; i < threads; i++)
        {
            int id = i;
            t[i] = new Thread(delegate ()
            {
                ulong x = 88172645463325252UL + (ulong)id;
                double d = 1.0001;
                while (true)
                {
                    long s = sw.ElapsedMilliseconds / 1000;
                    if (s >= seconds) break;
                    for (int k = 0; k < 100000; k++)
                    {
                        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
                        d = d * 1.0000001 + (x & 255) * 1e-9;
                        if (d > 1e6) d = 1.0001;
                    }
                    Interlocked.Add(ref b[s], 1L);
                }
                Sink ^= x ^ (ulong)d;
            });
            t[i].IsBackground = true;
            t[i].Start();
        }
        for (int i = 0; i < threads; i++) t[i].Join();
        return b;
    }
}

public class WDRamTest
{
    List<ulong[]> chunks = new List<ulong[]>();
    const int ChunkElems = 8 * 1024 * 1024;   // 64 MB por bloco
    public int Blocos { get { return chunks.Count; } }
    public long MBAlocados { get { return (long)chunks.Count * 64; } }
    public double WriteMBs, ReadMBs, CopyMBs;

    public int Alocar(int mb)
    {
        int n = Math.Max(1, mb / 64);
        for (int i = 0; i < n; i++)
        {
            try { chunks.Add(new ulong[ChunkElems]); }
            catch (OutOfMemoryException) { break; }
        }
        return chunks.Count;
    }

    // Escreve um padrão em toda a memória alocada e confere. Devolve o número de posições com erro.
    // padrao: 0=zeros, 1=uns, 2=1010..., 3=0101..., 4=padrão por endereço
    public long Padrao(int padrao, bool medir)
    {
        ulong v = 0;
        if (padrao == 1) v = ulong.MaxValue;
        else if (padrao == 2) v = 0xAAAAAAAAAAAAAAAAUL;
        else if (padrao == 3) v = 0x5555555555555555UL;
        Stopwatch sw = Stopwatch.StartNew();
        for (int c = 0; c < chunks.Count; c++)
        {
            ulong[] a = chunks[c];
            if (padrao == 4) { ulong basev = (ulong)c * (ulong)ChunkElems; for (int i = 0; i < a.Length; i++) a[i] = (basev + (ulong)i) * 0x9E3779B97F4A7C15UL; }
            else { for (int i = 0; i < a.Length; i++) a[i] = v; }
        }
        double tw = sw.Elapsed.TotalSeconds;
        sw.Restart();
        long erros = 0;
        for (int c = 0; c < chunks.Count; c++)
        {
            ulong[] a = chunks[c];
            if (padrao == 4)
            {
                ulong basev = (ulong)c * (ulong)ChunkElems;
                for (int i = 0; i < a.Length; i++) if (a[i] != (basev + (ulong)i) * 0x9E3779B97F4A7C15UL) erros++;
            }
            else { for (int i = 0; i < a.Length; i++) if (a[i] != v) erros++; }
        }
        double tr = sw.Elapsed.TotalSeconds;
        if (medir && tw > 0 && tr > 0)
        {
            double mb = (double)chunks.Count * 64;
            WriteMBs = mb / tw; ReadMBs = mb / tr;
        }
        return erros;
    }

    public void Copia()
    {
        if (chunks.Count < 2) return;
        Stopwatch sw = Stopwatch.StartNew();
        int rep = 4;
        for (int r = 0; r < rep; r++) Buffer.BlockCopy(chunks[0], 0, chunks[1], 0, ChunkElems * 8);
        double t = sw.Elapsed.TotalSeconds;
        if (t > 0) CopyMBs = (64.0 * rep) / t;
    }

    public void Liberar() { chunks.Clear(); GC.Collect(); }
}

public static class WDGpuTemp
{
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    struct OPENADAPTER
    {
        [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        public uint hAdapter; public int LuidLow; public int LuidHigh; public uint VidPnSourceId;
    }
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct QUERYINFO { public uint hAdapter; public int Type; public IntPtr pData; public int Size; }
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct CLOSEADAPTER { public uint hAdapter; }

    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTOpenAdapterFromGdiDisplayName(ref OPENADAPTER d);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTQueryAdapterInfo(ref QUERYINFO d);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern int D3DKMTCloseAdapter(ref CLOSEADAPTER d);

    // Lê (via driver gráfico, KMTQAITYPE_ADAPTERPERFDATA = 62) a temperatura em décimos de grau e a rotação do ventilador.
    // Devolve {status, tempDeciC, fanRpm}; status 0 = leitura obtida.
    public static long[] Ler(string dispositivo)
    {
        long[] r = new long[] { -1, 0, 0 };
        try
        {
            OPENADAPTER o = new OPENADAPTER(); o.DeviceName = dispositivo;
            int st = D3DKMTOpenAdapterFromGdiDisplayName(ref o);
            if (st != 0) { r[0] = st; return r; }
            IntPtr buf = System.Runtime.InteropServices.Marshal.AllocHGlobal(256);
            try
            {
                for (int i = 0; i < 256; i += 8) System.Runtime.InteropServices.Marshal.WriteInt64(buf, i, 0);
                int[] tamanhos = new int[] { 64, 72, 80, 56 };
                foreach (int tam in tamanhos)
                {
                    for (int i = 0; i < 256; i += 8) System.Runtime.InteropServices.Marshal.WriteInt64(buf, i, 0);
                    QUERYINFO q = new QUERYINFO(); q.hAdapter = o.hAdapter; q.Type = 62; q.pData = buf; q.Size = tam;
                    st = D3DKMTQueryAdapterInfo(ref q);
                    if (st == 0) break;
                }
                r[0] = st;
                if (st == 0)
                {
                    r[2] = (uint)System.Runtime.InteropServices.Marshal.ReadInt32(buf, 48);
                    r[1] = (uint)System.Runtime.InteropServices.Marshal.ReadInt32(buf, 56);
                }
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.FreeHGlobal(buf);
                CLOSEADAPTER c = new CLOSEADAPTER(); c.hAdapter = o.hAdapter; D3DKMTCloseAdapter(ref c);
            }
        }
        catch (Exception) { r[0] = -2; }
        return r;
    }
}
'@
}

# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
function Get-ArquivoBench {
    if ($env:WD_BENCH_ARQ) { return $env:WD_BENCH_ARQ }
    $base = $env:LOCALAPPDATA
    if (-not $base) { $base = [IO.Path]::GetTempPath() }
    return (Join-Path $base 'WinDiag\bench.json')
}

function Read-HistoricoBench {
    try {
        $f = Get-ArquivoBench
        if (Test-Path -LiteralPath $f) {
            return (Get-Content -LiteralPath $f -Raw -ErrorAction Stop | ConvertFrom-Json)
        }
    } catch { }
    return $null
}

function Save-HistoricoBench {
    param([hashtable]$Dados)
    try {
        $f = Get-ArquivoBench
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        ($Dados | ConvertTo-Json) | Set-Content -LiteralPath $f -Encoding UTF8
    } catch { }
}

function Get-TempCpuAprox {
    # Zona térmica ACPI: leitura aproximada, nem todo computador informa.
    try {
        $z = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop)
        $t = @($z | ForEach-Object { [math]::Round(($_.CurrentTemperature / 10) - 273.15, 1) } | Where-Object { $_ -gt 0 -and $_ -lt 150 })
        if ($t.Count -gt 0) { return ($t | Measure-Object -Maximum).Maximum }
    } catch { }
    return $null
}

function Test-BenchCancelado {
    try { return [bool]$global:WD_Sync.Cancelar } catch { return $false }
}

function New-ResultadoBench {
    param([string]$Nome, [string]$Estado, [string]$Resumo, [string[]]$Linhas)
    return @{ Nome = $Nome; Estado = $Estado; Resumo = $Resumo; Linhas = @($Linhas) }
}

# ----------------------------------------------------------------------------
# Processador
# ----------------------------------------------------------------------------
function Invoke-BenchCpu {
    param([int]$SegUnico = 5, [int]$SegMulti = 12)
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'Desempenho dentro do esperado.'
    $nome = 'Processador'
    $logicos = [Environment]::ProcessorCount
    try {
        $p = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
        $nome = "Processador ($(("$($p.Name)" -replace '\s+', ' ').Trim()))"
    } catch { }

    # Um núcleo
    $u = [WDBench]::Cpu($SegUnico, 1)
    $mediaU = ($u | Select-Object -Skip 1 | Measure-Object -Average).Average
    if (-not $mediaU) { $mediaU = ($u | Measure-Object -Average).Average }
    $unico = [math]::Round([double]$mediaU)

    # Todos os núcleos, em fatias de 1 s para poder cancelar e medir a queda
    $porSeg = New-Object System.Collections.Generic.List[double]
    for ($i = 0; $i -lt $SegMulti; $i++) {
        if (Test-BenchCancelado) { break }
        $r = [WDBench]::Cpu(1, $logicos)
        $porSeg.Add([double]$r[0])
    }
    $multi = 0
    if ($porSeg.Count -ge 3) {
        $multi = [math]::Round((($porSeg | Select-Object -Skip 1 | Measure-Object -Average).Average))
    } elseif ($porSeg.Count -gt 0) { $multi = [math]::Round(($porSeg | Measure-Object -Average).Average) }

    $linhas.Add("Um núcleo: $unico pontos")
    $linhas.Add("Todos os núcleos ($logicos threads): $multi pontos")
    if ($unico -gt 0 -and $multi -gt 0) {
        $escala = $multi / ($unico * $logicos)
        $linhas.Add(("Aproveitamento dos núcleos: {0:P0} do ideal (com hyper-threading/SMT, 60% a 90% é normal)" -f $escala))
        if ($escala -lt 0.35) {
            $estado = 'atencao'
            $resumo = 'Os núcleos renderam bem menos do que o esperado.'
            $linhas.Add('Isso pode indicar outro programa usando o processador durante o teste, plano de energia econômico ou limite de energia/temperatura.')
        }
    }

    # Queda ao longo do teste: sinal de superaquecimento ou limite de energia
    if ($porSeg.Count -ge 8) {
        $ini = ($porSeg | Select-Object -Skip 1 -First 3 | Measure-Object -Average).Average
        $fim = ($porSeg | Select-Object -Last 3 | Measure-Object -Average).Average
        if ($ini -gt 0) {
            $queda = 1 - ($fim / $ini)
            $quedaTxt = [math]::Max(0, $queda)
            $linhas.Add(("Estabilidade sob carga: {0:P0} de queda entre o início e o fim do teste" -f $quedaTxt))
            if ($queda -gt 0.15) {
                $estado = 'atencao'
                $resumo = 'O desempenho caiu durante o teste (possível superaquecimento ou limite de energia).'
                $linhas.Add('Se o computador também trava ou desliga sozinho, limpe o cooler/saídas de ar e confira a pasta térmica.')
            }
        }
    }
    $linhas.Add('Temperatura do processador: o Windows não informa a temperatura real deste tipo de processador (a leitura da placa-mãe é pouco confiável e foi ignorada). Confira no AMD Ryzen Master, HWiNFO ou no aplicativo da fabricante.')

    # Comparação com o teste anterior
    $h = Read-HistoricoBench
    if ($h -and $h.CpuMulti -and $multi -gt 0 -and [double]$h.CpuMulti -gt 0) {
        $dif = ($multi / [double]$h.CpuMulti) - 1
        $linhas.Add(("Comparado ao teste anterior ({0}): {1:+0%;-0%;0%}" -f $h.Data, $dif))
        if ($dif -lt -0.2 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = 'Desempenho bem abaixo do teste anterior.' }
    }
    $linhas.Add('Os pontos servem para comparar este computador com ele mesmo ao longo do tempo (não são comparáveis com outros programas).')
    $r = New-ResultadoBench -Nome $nome -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    $r.CpuUnico = $unico
    $r.CpuMulti = $multi
    return $r
}

# ----------------------------------------------------------------------------
# Memória RAM
# ----------------------------------------------------------------------------
function Get-LivreMB {
    try {
        $o = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        return [int]([double]$o.FreePhysicalMemory / 1024)
    } catch { return 0 }
}

function Invoke-BenchRam {
    param([int]$LimiteMB = 2048)
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'Nenhum erro encontrado na parte testada.'
    $totalMB = 0
    $mods = @()
    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $totalMB = [int](($mods | Measure-Object Capacity -Sum).Sum / 1MB)
    } catch { }
    $livre = Get-LivreMB
    if ($livre -le 0) { $livre = 1024 }
    $alvo = [int][math]::Min($LimiteMB, [math]::Floor($livre * 0.4 / 64) * 64)
    if ($alvo -lt 128) {
        return (New-ResultadoBench -Nome 'Memória RAM' -Estado 'nd' -Resumo 'Pouca memória livre para testar agora.' -Linhas @("Memória livre: $livre MB. Feche programas e tente de novo."))
    }
    $t = New-Object WDRamTest
    $blocos = $t.Alocar($alvo)
    $mb = $t.MBAlocados
    $erros = [long]0
    try {
        for ($p = 0; $p -lt 5; $p++) {
            if (Test-BenchCancelado) { break }
            $erros += $t.Padrao($p, ($p -eq 4))
        }
        if (-not (Test-BenchCancelado)) { $t.Copia() }
    } finally { $bw = @{ W = $t.WriteMBs; R = $t.ReadMBs; C = $t.CopyMBs }; $t.Liberar() }
    if ($totalMB -gt 0) { $linhas.Add("Testado: $mb MB de $([math]::Round($totalMB / 1024, 1)) GB instalados (5 padrões de escrita e leitura).") }
    else { $linhas.Add("Testado: $mb MB (5 padrões de escrita e leitura).") }
    $linhas.Add('O Windows não deixa testar a memória que ele mesmo está usando; por isso é uma amostra da parte livre.')
    if ($erros -gt 0) {
        $estado = 'problema'
        $resumo = "$erros erro(s) de memória encontrados."
        $linhas.Add("ERROS: $erros posições leram um valor diferente do que foi gravado.")
        $linhas.Add('Isso indica memória defeituosa, módulo mal encaixado, ou memória/XMP/EXPO instável. Desative o XMP/EXPO na BIOS, reencaixe os pentes e teste um de cada vez.')
    } else {
        $linhas.Add('Erros: nenhum.')
    }
    if ($bw.R -gt 0) {
        $linhas.Add(("Velocidade (um núcleo): escrita {0:N1} GB/s, leitura {1:N1} GB/s, cópia {2:N1} GB/s" -f ($bw.W / 1024), ($bw.R / 1024), ($bw.C / 1024)))
    }
    if ($mods.Count -gt 0) {
        $v = $mods[0].Speed; $c = $mods[0].ConfiguredClockSpeed
        if ($c) { $linhas.Add("Frequência: configurada $c MHz (nominal do módulo: $v MHz)") }
        if ($mods.Count -eq 1) {
            $linhas.Add('Há apenas 1 módulo de memória: ela trabalha em canal simples (mais lenta). Dois módulos iguais costumam dar mais desempenho.')
        }
        if ($c -and $v -and [int]$c -lt [int]$v -and $estado -eq 'ok') {
            $estado = 'atencao'; $resumo = 'Memória rodando abaixo da velocidade do módulo.'
            $linhas.Add('A memória está abaixo da velocidade nominal. Ative o XMP/EXPO na BIOS para usar a velocidade anunciada (se ficar instável, volte ao padrão).')
        }
    }
    $linhas.Add('Para um teste completo e demorado, use o "Diagnóstico de Memória do Windows" ou o MemTest86 (a partir de um pendrive).')
    $r = New-ResultadoBench -Nome 'Memória RAM' -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    $r.RamLeituraMBs = [math]::Round($bw.R)
    $r.RamErros = $erros
    return $r
}

# ----------------------------------------------------------------------------
# Placa de vídeo
# ----------------------------------------------------------------------------
function Get-TempGpu {
    $script:DiagGpu = ''
    # Devolve @{ Temp; Fan; Fonte } ou $null. NVIDIA: nvidia-smi. Outras (AMD, Intel): leitura do driver via D3DKMT (best-effort).
    $caminhos = @('nvidia-smi.exe', (Join-Path $env:SystemRoot 'System32\nvidia-smi.exe'), (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVSMI\nvidia-smi.exe'))
    foreach ($c in $caminhos) {
        try {
            if (-not $c) { continue }
            $cmd = Get-Command $c -ErrorAction SilentlyContinue
            if (-not $cmd) { continue }
            $o = & $cmd.Source --query-gpu=temperature.gpu,fan.speed --format=csv,noheader,nounits 2>$null | Select-Object -First 1
            if ($o -match '^\s*(\d+)\s*,\s*([\d\.]+|\[N/A\]|N/A)') {
                $fan = $null
                if ($matches[2] -match '^[\d\.]+$') { $fan = $matches[2] + '%' }
                return @{ Temp = [int]$matches[1]; Fan = $fan; Fonte = 'nvidia-smi' }
            }
        } catch { }
    }
    if ($env:OS -eq 'Windows_NT') {
        $melhor = $null
        for ($i = 1; $i -le 6; $i++) {
            try {
                $r = [WDGpuTemp]::Ler("\\.\DISPLAY$i")
                $script:DiagGpu += "DISPLAY$i=0x{0:X} " -f ([int]$r[0])
                if ($r[0] -eq 0 -and $r[1] -ge 100 -and $r[1] -le 1300) {
                    $t = [math]::Round($r[1] / 10.0)
                    if ($null -eq $melhor -or $t -gt $melhor.Temp) {
                        $fan = $null
                        if ($r[2] -gt 0 -and $r[2] -lt 20000) { $fan = "$($r[2]) rpm" }
                        $melhor = @{ Temp = [int]$t; Fan = $fan; Fonte = 'driver gráfico (D3DKMT)' }
                    }
                }
            } catch { }
        }
        return $melhor
    }
    return $null
}

function Get-UsoGpu3D {
    try {
        $s = (Get-Counter '\GPU Engine(*engtype_3D*)\Utilization Percentage' -ErrorAction Stop).CounterSamples
        $soma = ($s | Measure-Object CookedValue -Sum).Sum
        return [math]::Min(100, [math]::Round($soma))
    } catch { return $null }
}

$script:ScriptGpu = @'
param([string]$Saida, [int]$Seg = 6)
$ErrorActionPreference = 'Stop'
$res = @{ Ok = $false; Tier = -1; Niveis = @() }
try {
    Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
    $NS = 'System.Windows.Media.Media3D'
    $res.Tier = [int]([System.Windows.Media.RenderCapability]::Tier -shr 16)
    # esfera
    $mesh = New-Object "$NS.MeshGeometry3D"
    $n = 20
    for ($i = 0; $i -le $n; $i++) {
        $phi = [math]::PI * $i / $n
        for ($j = 0; $j -le $n; $j++) {
            $th = 2 * [math]::PI * $j / $n
            $x = [math]::Sin($phi) * [math]::Cos($th); $y = [math]::Cos($phi); $z = [math]::Sin($phi) * [math]::Sin($th)
            $mesh.Positions.Add((New-Object "$NS.Point3D" -ArgumentList $x, $y, $z))
            $mesh.Normals.Add((New-Object "$NS.Vector3D" -ArgumentList $x, $y, $z))
        }
    }
    for ($i = 0; $i -lt $n; $i++) { for ($j = 0; $j -lt $n; $j++) {
        $a = $i * ($n + 1) + $j; $b = $a + $n + 1
        foreach ($k in @($a, $b, ($a + 1), ($a + 1), $b, ($b + 1))) { $mesh.TriangleIndices.Add($k) }
    } }
    $mesh.Freeze()
    $cores = @('#E15759', '#4E79A7', '#59A14F', '#F28E2B')
    $mats = @()
    foreach ($c in $cores) { $m = New-Object System.Windows.Media.Media3D.DiffuseMaterial ([System.Windows.Media.SolidColorBrush][System.Windows.Media.ColorConverter]::ConvertFromString($c)); $m.Freeze(); $mats += $m }

    $grupo = New-Object "$NS.Model3DGroup"
    $rot = New-Object "$NS.AxisAngleRotation3D" -ArgumentList (New-Object "$NS.Vector3D" -ArgumentList 0, 1, 0.3), 0
    $grupo.Transform = New-Object "$NS.RotateTransform3D" -ArgumentList $rot
    $mv = New-Object "$NS.ModelVisual3D"; $mv.Content = $grupo
    $vp = New-Object System.Windows.Controls.Viewport3D
    $vp.Camera = New-Object "$NS.PerspectiveCamera" -ArgumentList (New-Object "$NS.Point3D" -ArgumentList 0, 0, 14), (New-Object "$NS.Vector3D" -ArgumentList 0, 0, -1), (New-Object "$NS.Vector3D" -ArgumentList 0, 1, 0), 50
    $vp.Children.Add($mv)
    $win = New-Object System.Windows.Window
    $win.Title = 'WinDiag - teste 3D (aguarde, fecha sozinho)'
    $win.Width = 900; $win.Height = 600; $win.WindowStartupLocation = 'CenterScreen'; $win.Topmost = $true
    $win.Background = [System.Windows.Media.Brushes]::Black
    $win.Content = $vp

    $niveis = @(15, 60, 180, 450)
    $script:nivel = -1; $script:quadros = 0; $script:ultT = -1.0; $script:sw = New-Object System.Diagnostics.Stopwatch
    $script:tickN = 0
    function Montar([int]$count) {
        $grupo.Children.Clear()
        $l = New-Object "$NS.DirectionalLight" -ArgumentList ([System.Windows.Media.Colors]::White), (New-Object "$NS.Vector3D" -ArgumentList -1, -1, -1)
        $grupo.Children.Add($l)
        $grupo.Children.Add((New-Object "$NS.AmbientLight" -ArgumentList ([System.Windows.Media.Color]::FromRgb(70, 70, 70))))
        $rnd = New-Object System.Random 7
        for ($i = 0; $i -lt $count; $i++) {
            $g = New-Object "$NS.GeometryModel3D"
            $g.Geometry = $mesh; $g.Material = $mats[$i % 4]
            $tg = New-Object "$NS.Transform3DGroup"
            $tg.Children.Add((New-Object "$NS.ScaleTransform3D" -ArgumentList 0.35, 0.35, 0.35))
            $tg.Children.Add((New-Object "$NS.TranslateTransform3D" -ArgumentList (($rnd.NextDouble() - 0.5) * 12), (($rnd.NextDouble() - 0.5) * 7), (($rnd.NextDouble() - 0.5) * 8)))
            $g.Transform = $tg
            $grupo.Children.Add($g)
        }
    }
    $proximo = {
        $script:nivel++
        if ($script:nivel -ge $niveis.Count) { $win.Close(); return }
        Montar $niveis[$script:nivel]
        $script:quadros = 0; $script:sw.Restart(); $script:tickN = 0
    }
    [System.Windows.Media.CompositionTarget]::add_Rendering({
        param($s, $e)
        $t = $e.RenderingTime.TotalMilliseconds
        if ($t -ne $script:ultT) { $script:ultT = $t; $script:quadros++; $rot.Angle = ($rot.Angle + 1.2) % 360 }
    })
    $tm = New-Object System.Windows.Threading.DispatcherTimer
    $tm.Interval = [TimeSpan]::FromSeconds(1)
    $tm.Add_Tick({
        $script:tickN++
        if ($script:tickN -eq 1) { $script:quadros = 0; $script:sw.Restart(); return }   # aquecimento de 1 s
        if ($script:tickN -ge ($Seg + 1)) {
            $fps = $script:quadros / [math]::Max(0.001, $script:sw.Elapsed.TotalSeconds)
            $res.Niveis += @{ Esferas = $niveis[$script:nivel]; Triangulos = $niveis[$script:nivel] * 800; Fps = [math]::Round($fps, 1) }
            & $proximo
        }
    })
    $win.Add_ContentRendered({ & $proximo; $tm.Start() })
    [void]$win.ShowDialog()
    $res.Ok = ($res.Niveis.Count -eq $niveis.Count)
} catch { $res.Erro = $_.Exception.Message }
($res | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $Saida -Encoding UTF8
'@

function Invoke-BenchGpu {
    param([int]$SegPorNivel = 6, [int]$TimeoutSeg = 90)
    $linhas = New-Object System.Collections.Generic.List[string]
    $estado = 'ok'
    $resumo = 'A placa de vídeo desenhou a animação 3D normalmente.'
    $nome = 'Placa de vídeo'
    try {
        $v = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -and $_.Name -notmatch 'Basic|Remote|Virtual' })
        if ($v.Count -gt 0) { $nome = 'Placa de vídeo (' + (($v | ForEach-Object { $_.Name }) -join ' / ') + ')' }
    } catch { }

    if ($env:OS -ne 'Windows_NT') {
        return (New-ResultadoBench -Nome $nome -Estado 'nd' -Resumo 'O teste 3D só roda no Windows.' -Linhas @())
    }
    $dir = Join-Path ([IO.Path]::GetTempPath()) ('WinDiag-gpu-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $arqScript = Join-Path $dir 'gpu.ps1'
    $arqSaida = Join-Path $dir 'saida.json'
    [IO.File]::WriteAllText($arqScript, $script:ScriptGpu, (New-Object System.Text.UTF8Encoding $true))

    $t0 = Get-TempGpu
    $tMax = $null; $usoMax = $null; $fonte = $null; $fan = $null
    if ($t0) { $tMax = $t0.Temp; $fonte = $t0.Fonte; $fan = $t0.Fan }
    $proc = $null
    $terminou = $false
    try {
        $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $argsPs = @('-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-File', $arqScript, '-Saida', $arqSaida, '-Seg', "$SegPorNivel")
        $proc = Start-Process -FilePath $ps51 -ArgumentList $argsPs -PassThru -WindowStyle Normal
        $limite = (Get-Date).AddSeconds($TimeoutSeg)
        while (-not $proc.HasExited -and (Get-Date) -lt $limite) {
            Start-Sleep -Milliseconds 2000
            if (Test-BenchCancelado) { break }
            $tt = Get-TempGpu
            if ($tt) { if ($null -eq $tMax -or $tt.Temp -gt $tMax) { $tMax = $tt.Temp }; $fonte = $tt.Fonte; if ($tt.Fan) { $fan = $tt.Fan } }
            $u = Get-UsoGpu3D
            if ($null -ne $u -and ($null -eq $usoMax -or $u -gt $usoMax)) { $usoMax = $u }
        }
        $terminou = $proc.HasExited
    } finally {
        try { if ($proc -and -not $proc.HasExited) { $proc.Kill() } } catch { }
    }
    $res = $null
    try { if (Test-Path -LiteralPath $arqSaida) { $res = Get-Content -LiteralPath $arqSaida -Raw | ConvertFrom-Json } } catch { }
    try { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue } catch { }

    $r = $null
    if (-not $terminou -and -not (Test-BenchCancelado)) {
        $estado = 'problema'
        $resumo = 'O teste 3D não terminou (travou ou demorou demais).'
        $linhas.Add('A animação não concluiu no tempo esperado. Se a tela piscou ou travou, pode ser driver de vídeo instável ou placa com problema.')
        $linhas.Add('Reinstale o driver de vídeo (site da AMD/NVIDIA/Intel) e teste de novo.')
    } elseif (-not $res -or -not $res.Ok) {
        $estado = 'nd'
        $resumo = 'Não foi possível concluir o teste 3D.'
        if ($res -and $res.Erro) { $linhas.Add("Motivo: $($res.Erro)") }
    } else {
        $tier = [int]$res.Tier
        $fpsLista = @($res.Niveis | ForEach-Object { [double]$_.Fps })
        foreach ($n in @($res.Niveis)) {
            $linhas.Add(("Cena com {0} esferas ({1:N0} mil triângulos): {2:N1} quadros por segundo" -f $n.Esferas, ($n.Triangulos / 1000), [double]$n.Fps))
        }
        $linhas.Add('(A animação é limitada pela taxa de atualização do monitor, em geral 60 quadros por segundo; o que importa é quando ela começa a cair.)')
        $fpsMax = ($fpsLista | Measure-Object -Maximum).Maximum
        $fpsPior = $fpsLista[$fpsLista.Count - 1]
        if ($tier -eq 0) {
            $estado = 'problema'; $resumo = 'O Windows está desenhando em modo por software (sem usar a placa de vídeo).'
            $linhas.Add('Isso costuma ocorrer com driver de vídeo ausente, incompatível ou com falha. Instale o driver oficial da placa.')
        } elseif ($fpsMax -lt 25) {
            $estado = 'atencao'; $resumo = 'Desempenho 3D muito baixo até na cena mais leve.'
            $linhas.Add('Verifique se o driver de vídeo é o do fabricante e se o monitor está ligado na placa de vídeo (e não na saída da placa-mãe).')
        } elseif ($fpsPior -lt 20) {
            $linhas.Add('A cena mais pesada ficou lenta; é esperado em placas simples ou integradas.')
        }
        $r = $res
    }
    if ($null -ne $usoMax) { $linhas.Add("Uso máximo da placa durante o teste: $usoMax%") }
    if ($null -ne $tMax) {
        $txt = "Temperatura máxima durante o teste: $tMax °C (fonte: $fonte)"
        if ($fan) { $txt += "; ventilador: $fan" }
        $linhas.Add($txt)
        if ($tMax -ge 95) { $estado = 'problema'; $resumo = "Temperatura muito alta ($tMax °C)."; $linhas.Add('Temperatura perigosa para uma carga leve: verifique ventoinhas, poeira e fluxo de ar do gabinete.') }
        elseif ($tMax -ge 85 -and $estado -eq 'ok') { $estado = 'atencao'; $resumo = "Temperatura alta ($tMax °C)." }
    } else {
        $linhas.Add('Temperatura da placa de vídeo: não foi possível ler neste computador (n/d). Nas placas NVIDIA a leitura usa o nvidia-smi; nas AMD/Intel depende do driver. Veja a temperatura no aplicativo da fabricante (ex.: AMD Software).')
        if ($script:DiagGpu) { $linhas.Add("Diagnóstico técnico da leitura: $($script:DiagGpu)") }
    }
    $linhas.Add('Este é um teste leve (não é um estresse de jogos): serve para ver se a placa e o driver respondem bem.')
    $out = New-ResultadoBench -Nome $nome -Estado $estado -Resumo $resumo -Linhas $linhas.ToArray()
    if ($r) { $out.GpuFpsMax = ($r.Niveis | ForEach-Object { [double]$_.Fps } | Measure-Object -Maximum).Maximum; $out.GpuFpsPesado = [double]$r.Niveis[$r.Niveis.Count - 1].Fps }
    if ($null -ne $tMax) { $out.GpuTemp = $tMax }
    return $out
}

# ----------------------------------------------------------------------------
# Texto e relatório
# ----------------------------------------------------------------------------
function Get-RotuloEstadoBench {
    param([string]$Estado)
    switch ($Estado) { 'ok' { return 'OK' } 'atencao' { return 'ATENÇÃO' } 'problema' { return 'PROBLEMA' } default { return 'NÃO AVALIADO' } }
}

function Get-PiorEstadoBench {
    param([object[]]$Itens)
    $ordem = @{ ok = 0; nd = 1; atencao = 2; problema = 3 }
    $pior = 'ok'
    foreach ($i in $Itens) { if ($i -and $ordem[$i.Estado] -gt $ordem[$pior]) { $pior = $i.Estado } }
    return $pior
}

function Format-TextoBench {
    param([object[]]$Itens)
    $sb = New-Object System.Collections.Generic.List[string]
    foreach ($i in $Itens) {
        if (-not $i) { continue }
        $sb.Add(("{0}  -  {1}" -f $i.Nome.ToUpper(), (Get-RotuloEstadoBench $i.Estado)))
        $sb.Add($i.Resumo)
        foreach ($l in @($i.Linhas)) { $sb.Add("   • $l") }
        $sb.Add('')
    }
    return ($sb -join "`r`n")
}

function Export-RelatorioBench {
    param([object[]]$Itens, [string]$Pasta, [string]$Stamp)
    $arq = Join-Path $Pasta "WinDiag_Desempenho_$Stamp.html"
    $cor = @{ ok = '#15803D'; atencao = '#B45309'; problema = '#B91C1C'; nd = '#475569' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><title>WinDiag - Desempenho</title><style>body{font-family:Segoe UI,Arial,sans-serif;max-width:860px;margin:30px auto;padding:0 16px;color:#1E293B}h1{font-size:22px}.item{border:1px solid #E2E8F0;border-radius:10px;padding:14px 18px;margin:14px 0}.est{font-weight:700}li{margin:4px 0}</style></head><body><h1>WinDiag - Teste de desempenho</h1><p>$(Get-Date -Format 'dd/MM/yyyy HH:mm')</p>")
    foreach ($i in $Itens) {
        if (-not $i) { continue }
        $c = $cor[$i.Estado]
        [void]$sb.Append("<div class='item'><h2>$([System.Net.WebUtility]::HtmlEncode($i.Nome))</h2><p class='est' style='color:$c'>$(Get-RotuloEstadoBench $i.Estado): $([System.Net.WebUtility]::HtmlEncode($i.Resumo))</p><ul>")
        foreach ($l in @($i.Linhas)) { [void]$sb.Append("<li>$([System.Net.WebUtility]::HtmlEncode($l))</li>") }
        [void]$sb.Append('</ul></div>')
    }
    [void]$sb.Append('</body></html>')
    [IO.File]::WriteAllText($arq, $sb.ToString(), (New-Object System.Text.UTF8Encoding $true))
    try { ($Itens | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath (Join-Path $Pasta "WinDiag_Desempenho_$Stamp.json") -Encoding UTF8 } catch { }
    return $arq
}

function Invoke-BenchCompleto {
    # Roda os testes escolhidos. $Etapa é um scriptblock opcional chamado com (N, Total, Texto) antes de cada teste.
    param([string[]]$Testes = @('cpu', 'ram', 'gpu'), [scriptblock]$Etapa)
    $itens = New-Object System.Collections.Generic.List[object]
    $rotulos = @{ cpu = 'Testando o processador'; ram = 'Testando a memória RAM'; gpu = 'Testando a placa de vídeo (uma janela com animação vai abrir)' }
    $n = 0
    foreach ($t in $Testes) {
        if (Test-BenchCancelado) { break }
        $n++
        if ($Etapa) { & $Etapa $n $Testes.Count $rotulos[$t] }
        try {
            switch ($t) {
                'cpu' { $itens.Add((Invoke-BenchCpu)) }
                'ram' { $itens.Add((Invoke-BenchRam)) }
                'gpu' { $itens.Add((Invoke-BenchGpu)) }
            }
        } catch {
            $itens.Add((New-ResultadoBench -Nome $rotulos[$t] -Estado 'nd' -Resumo 'O teste falhou.' -Linhas @($_.Exception.Message)))
        }
    }
    # histórico para comparar na próxima vez
    $h = @{ Data = (Get-Date -Format 'dd/MM/yyyy') }
    foreach ($i in $itens) {
        if ($i.CpuMulti) { $h.CpuMulti = $i.CpuMulti; $h.CpuUnico = $i.CpuUnico }
        if ($i.RamLeituraMBs) { $h.RamLeituraMBs = $i.RamLeituraMBs }
        if ($i.GpuFpsPesado) { $h.GpuFpsPesado = $i.GpuFpsPesado }
    }
    if ($h.Count -gt 1) {
        $ant = Read-HistoricoBench
        if ($ant) { foreach ($p in $ant.PSObject.Properties) { if (-not $h.ContainsKey($p.Name)) { $h[$p.Name] = $p.Value } } }
        Save-HistoricoBench $h
    }
    return $itens.ToArray()
}
