﻿<#
.SYNOPSIS
    Instala o WinDiag para o usuário atual (sem precisar de administrador).

.DESCRIPTION
    Copia o programa para %LOCALAPPDATA%\Programs\WinDiag, cria os atalhos (Área de Trabalho e Menu Iniciar)
    e registra o WinDiag em "Aplicativos e recursos" do Windows, para poder desinstalar por lá.
    Use o arquivo Instalar-WinDiag.bat (duplo clique).
#>
param([switch]$SemPerguntas, [switch]$ComoAdministrador, [string]$Destino)

$ErrorActionPreference = 'Stop'
$origem = $PSScriptRoot
if (-not $Destino) { $Destino = Join-Path $env:LOCALAPPDATA 'Programs\WinDiag' }

if (-not (Test-Path -LiteralPath (Join-Path $origem 'WinDiag-GUI.ps1'))) {
    Write-Host 'Não encontrei o WinDiag-GUI.ps1 ao lado deste instalador. Extraia o ZIP inteiro antes.' -ForegroundColor Red
    exit 1
}
function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

$versao = '?'
$m = [regex]::Match([IO.File]::ReadAllText((Join-Path $origem 'WinDiag.ps1')), "Versao\s*=\s*'([^']+)'")
if ($m.Success) { $versao = $m.Groups[1].Value }

Write-Host "Instalando o Telomera $versao em: $Destino" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$arquivos = @('WinDiag.ps1', 'WinDiag-GUI.ps1', 'WinDiag-Worker.ps1', 'WinDiag-Bench.ps1', 'WinDiag-Extras.ps1', 'WinDiag-Monitor.ps1',
              'Criar-Atalho.ps1', 'Criar-Atalho.bat', 'Abrir-WinDiag.bat', 'Executar-WinDiag.bat',
              'Desinstalar-WinDiag.ps1', 'Desinstalar-WinDiag.bat', 'Atualizar-WinDiag.ps1', 'README.md', 'LICENSE', 'windiag.ico', 'windiag-logo.png',
              'TelomeraLauncher.cs', 'app.manifest', 'Compilar-Telomera.ps1')
$copiados = 0
foreach ($a in $arquivos) {
    $src = Join-Path $origem $a
    if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $Destino $a) -Force; $copiados++ }
}
Write-Host "  $copiados arquivo(s) copiado(s)."
try { Get-ChildItem -LiteralPath $Destino -Recurse -File | Unblock-File -ErrorAction SilentlyContinue } catch { }

# Launcher nativo (Telomera.exe): compila com o csc.exe do .NET Framework (já vem com o Windows) e assina
# com um certificado de teste. Se não der certo por algum motivo, a instalação continua normalmente: os
# atalhos passam a apontar para o PowerShell, como antes.
$telomeraExe = $null
try {
    $compilador = Join-Path $Destino 'Compilar-Telomera.ps1'
    if (Test-Path -LiteralPath $compilador) {
        $rc = & $compilador -Origem $Destino -Destino $Destino -Silencioso
        if ($rc.Ok) { $telomeraExe = $rc.Exe; Write-Host '  Telomera.exe compilado e assinado (certificado de teste).' -ForegroundColor Cyan }
        else { Write-Host "  Não consegui compilar o Telomera.exe ($($rc.Erro)); vai abrir pelo PowerShell normalmente." -ForegroundColor Yellow }
    }
} catch { Write-Host "  Não consegui compilar o Telomera.exe ($($_.Exception.Message)); vai abrir pelo PowerShell normalmente." -ForegroundColor Yellow }

# Atalhos (usa o Criar-Atalho da pasta de destino, para que apontem para a cópia instalada)
if (-not $SemPerguntas -and -not $PSBoundParameters.ContainsKey('ComoAdministrador')) {
    $r = Read-Host 'Abrir sempre como administrador? Necessário para corrigir problemas (o Windows vai pedir permissão a cada abertura) [S/n]'
    $ComoAdministrador = ($r -notmatch '^\s*[nN]')
}
$criar = Join-Path $Destino 'Criar-Atalho.ps1'
if ($ComoAdministrador) { & $criar -SemPerguntas -ComoAdministrador -Silencioso | Out-Null }
else { & $criar -SemPerguntas -Silencioso | Out-Null }

# Registro em "Aplicativos e recursos"
try {
    $chave = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WinDiag'
    New-Item -Path $chave -Force | Out-Null
    $ico = Join-Path $env:LOCALAPPDATA 'WinDiag\windiag-app.ico'
    $hd = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f (Join-Path $Destino 'Desinstalar-WinDiag.ps1'))
    $desinst = ('"{0}" {1}' -f $hd.Exe, $hd.Args)
    $props = @{
        DisplayName     = 'Telomera'
        DisplayVersion  = $versao
        Publisher       = 'TANUKI'
        InstallLocation = $Destino
        UninstallString = $desinst
        NoModify        = 1
        NoRepair        = 1
    }
    if ($telomeraExe -and (Test-Path -LiteralPath $telomeraExe)) { $props.DisplayIcon = $telomeraExe }
    elseif (Test-Path -LiteralPath $ico) { $props.DisplayIcon = $ico }
    foreach ($k in $props.Keys) { New-ItemProperty -Path $chave -Name $k -Value $props[$k] -Force | Out-Null }
} catch { Write-Host "  Não consegui registrar em Aplicativos e recursos: $($_.Exception.Message)" -ForegroundColor Yellow }

Write-Host ''
Write-Host 'Pronto! O Telomera foi instalado. Abra-o pelo atalho "Telomera" na Área de Trabalho ou no Menu Iniciar.' -ForegroundColor Green
Write-Host 'Para desinstalar: Configurações > Aplicativos > Telomera, ou o arquivo Desinstalar-WinDiag.bat.'
