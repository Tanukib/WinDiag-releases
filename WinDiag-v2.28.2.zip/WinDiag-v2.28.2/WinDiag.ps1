﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Telomera - diagnóstico e reparo de discos e drivers do Windows.

.DESCRIPTION
    Vai além do diagnóstico padrão do Windows. Além de listar dispositivos com erro
    (o que o Gerenciador de Dispositivos já mostra), o Telomera:

      - lê a confiabilidade/SMART dos discos (desgaste, temperatura, erros não corrigidos)
      - analisa o histórico de eventos: falhas de I/O, corrupção NTFS, telas azuis,
        erros de hardware (WHEA), travamentos do driver de vídeo, drivers que não carregam
      - encontra drivers genéricos, não assinados, antigos ou que falharam ao iniciar
        e que o Windows NÃO sinaliza como problema
      - lê o hardware (CPU, memória, vídeo, placa-mãe/firmware, rede, áudio, monitores, bateria)
      - lê o log de instalação de drivers (setupapi) em busca de instalações que falharam
      - consulta o Windows Update por drivers pendentes
      - detecta driver de vídeo sobrescrito pelo Windows Update, restaura o driver do fabricante guardado
        no sistema e protege contra nova troca (sempre com a sua permissão)
      - gera links de download (Microsoft Update Catalog e site do fabricante)
      - gera relatórios em HTML, JSON e log

    Nada é alterado sem a sua confirmação. Com -SomenteLeitura nenhuma alteração é oferecida.
    Nenhum dado é enviado para a internet pelo script.

.PARAMETER SomenteLeitura
    Apenas diagnostica. Não oferece nem executa reparos.

.PARAMETER SemWindowsUpdate
    Não consulta o Windows Update por drivers pendentes (a consulta pode demorar).

.PARAMETER PularScanVolumes
    Não faz a varredura online de erros nos volumes (mais rápido em discos grandes).

.PARAMETER DiasEventos
    Quantos dias do histórico de eventos analisar. Padrão: 30.

.PARAMETER PastaRelatorio
    Pasta onde os relatórios serão salvos. Padrão: pasta Telomera na Área de Trabalho.

.PARAMETER NaoAbrirRelatorio
    Não abre o relatório HTML automaticamente ao terminar o diagnóstico.

.PARAMETER Agendada
    Uso interno da verificação semanal automática: somente leitura, sem internet e sem abrir o relatório.
    Se a saúde piorar em relação à verificação anterior, grava um aviso que o Telomera mostra na tela inicial.

.PARAMETER DesfazerBloqueios
    Remove os bloqueios de instalação de drivers e a exclusão de drivers do Windows Update criados
    pelo Telomera e sai. Use antes de atualizar manualmente o driver de um dispositivo bloqueado.

.EXAMPLE
    .\WinDiag.ps1

.EXAMPLE
    .\WinDiag.ps1 -SomenteLeitura -DiasEventos 60

.NOTES
    Licença: MIT. Versão 2.3.0.
    Salve este arquivo como UTF-8 com BOM para o Windows PowerShell 5.1 exibir os acentos.
#>
[CmdletBinding()]
param(
    [switch]$SomenteLeitura,
    [switch]$SemWindowsUpdate,
    [switch]$PularScanVolumes,
    [switch]$VerificacaoProfunda,
    [ValidateRange(1, 365)][int]$DiasEventos = 30,
    [string]$PastaRelatorio,
    [switch]$NaoAbrirRelatorio,
    [switch]$DesfazerBloqueios,
    [switch]$Agendada
)

$ErrorActionPreference = 'Continue'

# ----------------------------------------------------------------------------
# Estado global
# ----------------------------------------------------------------------------
$script:Versao        = '2.28.2'
$script:Achados       = New-Object System.Collections.Generic.List[object]
$script:Acoes         = New-Object System.Collections.Generic.List[object]
$script:Dados         = [ordered]@{}
$script:Sistema       = [ordered]@{}
$script:ProtecaoFeita = $false
$script:BackupFeito = $false
$script:Stamp         = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:PastaDrivers  = $null
$script:CachePnP        = $null
$script:CacheAssinados  = $null
$script:CachePacotes    = $null
$script:ErroPacotes     = $null
$script:Alteracoes      = New-Object System.Collections.Generic.List[object]
$script:ChaveRestricoes = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions'
$script:ChaveDeny       = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions\DenyDeviceIDs'
$script:ChaveWinDiag    = 'HKLM:\SOFTWARE\WinDiag'
# Classes de driver "internas": restaurar exige digitar RESTAURAR
$script:ClassesInternas = @('System', 'HDC', 'SCSIAdapter', 'DiskDrive', 'Processor', 'Computer', 'Volume', 'USB', 'Firmware', 'SecurityDevices')

# ----------------------------------------------------------------------------
# Tabelas de conhecimento
# ----------------------------------------------------------------------------
# Fabricante pelo ID PCI/USB -> página oficial de downloads
$script:Fabricantes = @{
    '8086' = @{ Nome = 'Intel';            Url = 'https://www.intel.com/content/www/us/en/support/detect.html' }
    '8087' = @{ Nome = 'Intel';            Url = 'https://www.intel.com/content/www/us/en/support/detect.html' }
    '10DE' = @{ Nome = 'NVIDIA';           Url = 'https://www.nvidia.com/Download/index.aspx' }
    '1002' = @{ Nome = 'AMD';              Url = 'https://www.amd.com/en/support/download/drivers.html' }
    '1022' = @{ Nome = 'AMD';              Url = 'https://www.amd.com/en/support/download/drivers.html' }
    '10EC' = @{ Nome = 'Realtek';          Url = 'https://www.realtek.com/Download' }
    '0BDA' = @{ Nome = 'Realtek';          Url = 'https://www.realtek.com/Download' }
    '14E4' = @{ Nome = 'Broadcom';         Url = 'https://www.broadcom.com/support/download-search' }
    '168C' = @{ Nome = 'Qualcomm Atheros'; Url = 'https://www.qualcomm.com/support' }
    '17CB' = @{ Nome = 'Qualcomm';         Url = 'https://www.qualcomm.com/support' }
    '144D' = @{ Nome = 'Samsung (SSD)';    Url = 'https://semiconductor.samsung.com/consumer-storage/support/tools/' }
    '046D' = @{ Nome = 'Logitech';         Url = 'https://support.logi.com' }
}

# Fabricante do computador (Win32_ComputerSystem.Manufacturer) -> suporte oficial
$script:LinksOEM = @(
    @{ Padrao = 'Dell';                 Nome = 'Dell';     Url = 'https://www.dell.com/support/home' }
    @{ Padrao = 'HP|Hewlett';           Nome = 'HP';       Url = 'https://support.hp.com/drivers' }
    @{ Padrao = 'LENOVO';               Nome = 'Lenovo';   Url = 'https://support.lenovo.com/' }
    @{ Padrao = 'ASUS';                 Nome = 'ASUS';     Url = 'https://www.asus.com/support/' }
    @{ Padrao = 'Acer';                 Nome = 'Acer';     Url = 'https://www.acer.com/support' }
    @{ Padrao = 'Micro-Star|MSI';       Nome = 'MSI';      Url = 'https://www.msi.com/support' }
    @{ Padrao = 'Gigabyte';             Nome = 'Gigabyte'; Url = 'https://www.gigabyte.com/Support' }
    @{ Padrao = 'SAMSUNG';              Nome = 'Samsung';  Url = 'https://www.samsung.com/br/support/' }
)

# Códigos de erro do Gerenciador de Dispositivos
$script:CodigosPnP = @{
    1  = 'Dispositivo mal configurado'
    3  = 'Driver corrompido ou memória insuficiente'
    10 = 'O dispositivo não consegue iniciar'
    12 = 'Conflito de recursos (IRQ/memória)'
    14 = 'Precisa reiniciar o computador'
    18 = 'Reinstale os drivers do dispositivo'
    19 = 'Registro do Windows corrompido'
    21 = 'O Windows está removendo o dispositivo'
    22 = 'Dispositivo desativado'
    24 = 'Dispositivo ausente, com defeito ou drivers não instalados'
    28 = 'Drivers não instalados'
    29 = 'Desativado pelo firmware/BIOS'
    31 = 'O Windows não consegue carregar os drivers'
    32 = 'Serviço do driver desativado'
    33 = 'O Windows não consegue determinar os recursos do dispositivo'
    34 = 'Configuração manual necessária'
    35 = 'Firmware/BIOS sem informação de recursos'
    37 = 'Falha ao inicializar o driver'
    38 = 'Driver anterior ainda na memória'
    39 = 'Driver corrompido ou ausente'
    40 = 'Informação de serviço no registro inválida'
    41 = 'Driver carregou mas o dispositivo não foi encontrado'
    42 = 'Dispositivo duplicado'
    43 = 'O dispositivo reportou um problema e foi parado'
    44 = 'Parado por um aplicativo ou serviço'
    45 = 'Dispositivo não está mais conectado'
    47 = 'Preparado para remoção segura'
    48 = 'Driver bloqueado por problemas de compatibilidade'
    49 = 'Limite do registro (hive) excedido'
    52 = 'Assinatura digital do driver inválida'
}

# Códigos de tela azul mais comuns
$script:Bugchecks = @{
    '0x0000000A' = 'IRQL_NOT_LESS_OR_EQUAL - quase sempre driver ou memória'
    '0x0000001A' = 'MEMORY_MANAGEMENT - memória RAM ou driver'
    '0x0000001E' = 'KMODE_EXCEPTION_NOT_HANDLED - driver ou software de baixo nível'
    '0x00000050' = 'PAGE_FAULT_IN_NONPAGED_AREA - RAM, disco ou driver'
    '0x00000077' = 'KERNEL_STACK_INPAGE_ERROR - disco ou controlador'
    '0x0000007A' = 'KERNEL_DATA_INPAGE_ERROR - disco, cabo ou controlador'
    '0x0000007E' = 'SYSTEM_THREAD_EXCEPTION_NOT_HANDLED - driver'
    '0x0000009F' = 'DRIVER_POWER_STATE_FAILURE - driver e gerenciamento de energia'
    '0x000000BE' = 'ATTEMPTED_WRITE_TO_READONLY_MEMORY - driver'
    '0x000000C2' = 'BAD_POOL_CALLER - driver'
    '0x000000C5' = 'DRIVER_CORRUPTED_EXPOOL - driver'
    '0x000000D1' = 'DRIVER_IRQL_NOT_LESS_OR_EQUAL - driver (rede, vídeo, áudio)'
    '0x000000EF' = 'CRITICAL_PROCESS_DIED - disco, arquivos do sistema ou driver'
    '0x000000F4' = 'CRITICAL_OBJECT_TERMINATION - disco ou controlador'
    '0x00000101' = 'CLOCK_WATCHDOG_TIMEOUT - CPU, BIOS ou overclock'
    '0x00000116' = 'VIDEO_TDR_FAILURE - driver de vídeo ou GPU'
    '0x00000119' = 'VIDEO_SCHEDULER_INTERNAL_ERROR - driver de vídeo ou GPU'
    '0x00000124' = 'WHEA_UNCORRECTABLE_ERROR - hardware (CPU, RAM, PCIe), temperatura ou overclock'
    '0x00000133' = 'DPC_WATCHDOG_VIOLATION - driver (frequente com SSD/NVMe e rede)'
    '0x00000139' = 'KERNEL_SECURITY_CHECK_FAILURE - driver ou memória'
}

# Regras de análise do histórico de eventos
$script:RegrasEventos = @(
    @{ Nome = 'Erros de leitura/escrita no disco'; Log = 'System'; Provedores = @('disk'); Ids = @(7, 11, 51, 52, 153); Gravidade = 'Critico'
       Solucao = 'Faça backup agora. Verifique cabo/porta SATA, o SMART acima e considere trocar o disco se os erros se repetirem.' },
    @{ Nome = 'Corrupção ou falha de gravação no sistema de arquivos (NTFS)'; Log = 'System'; Provedores = @('Ntfs'); Ids = @(50, 55, 57, 140); Gravidade = 'Atencao'
       Solucao = 'Rode a verificação de volume na fase de reparo e, na unidade do sistema, um chkdsk /f (exige reiniciar).' },
    @{ Nome = 'Reset/timeout do controlador de armazenamento'; Log = 'System'; Provedores = @('stornvme', 'storahci', 'iaStorA', 'iaStorAC'); Ids = @(129); Gravidade = 'Atencao'
       Solucao = 'Atualize BIOS, firmware do SSD e o driver do controlador (NVMe/SATA/Intel RST). Cabo ou porta com mau contato também causam isso.' },
    @{ Nome = 'Erros de hardware reportados pela CPU/PCIe (WHEA)'; Log = 'System'; Provedores = @('Microsoft-Windows-WHEA-Logger'); Gravidade = 'Critico'
       Solucao = 'Verifique temperatura, desative overclock/XMP para testar, atualize a BIOS e teste a memória (mdsched.exe).' },
    @{ Nome = 'Telas azuis (BugCheck)'; Log = 'System'; Provedores = @('Microsoft-Windows-WER-SystemErrorReporting'); Ids = @(1001); Gravidade = 'Critico'; Bugcheck = $true
       Solucao = 'Analise o arquivo de dump com o WinDbg (Microsoft Store) usando !analyze -v: o campo MODULE_NAME/IMAGE_NAME aponta o driver culpado.' },
    @{ Nome = 'Desligamentos inesperados (Kernel-Power 41)'; Log = 'System'; Provedores = @('Microsoft-Windows-Kernel-Power'); Ids = @(41); Gravidade = 'Atencao'
       Solucao = 'Causas comuns: queda de energia, superaquecimento, fonte fraca ou travamento por driver. Cruze com as telas azuis acima.' },
    @{ Nome = 'Driver de vídeo parou de responder (TDR)'; Log = 'System'; Provedores = @('Display'); Ids = @(4101); Gravidade = 'Atencao'
       Solucao = 'Atualize o driver de vídeo pelo site do fabricante usando a opção de instalação limpa e verifique a temperatura da GPU.' },
    @{ Nome = 'Erros do driver de vídeo (NVIDIA/AMD)'; Log = 'System'; Provedores = @('nvlddmkm', 'amdkmdag', 'amdwddmg', 'amdkmpfd'); Niveis = @(1, 2, 3); Gravidade = 'Atencao'
       Solucao = 'Reinstale o driver de vídeo com instalação limpa (opção do instalador da NVIDIA/AMD) e teste sem overclock.' },
    @{ Nome = 'Serviços/drivers que falharam ao iniciar'; Log = 'System'; Provedores = @('Service Control Manager'); Ids = @(7000, 7026); Gravidade = 'Atencao'
       Solucao = 'Veja a lista de drivers que falharam ao iniciar na seção de drivers e reinstale ou atualize o driver citado.' },
    @{ Nome = 'Driver não carregou para um dispositivo (PnP)'; Log = 'System'; Provedores = @('Microsoft-Windows-Kernel-PnP'); Ids = @(219); Gravidade = 'Atencao'
       Solucao = 'Reinstale o driver do dispositivo citado no evento ou use a versão do fabricante.' },
    @{ Nome = 'Driver bloqueado pela integridade de código'; Log = 'Microsoft-Windows-CodeIntegrity/Operational'; Ids = @(3033, 3063); Gravidade = 'Atencao'
       Solucao = 'Um driver sem assinatura válida ou incompatível foi bloqueado. Use a versão oficial e assinada do fabricante.' }
)

# Drivers/serviços de sistema conhecidos: o que são e se é normal falharem.
# Veredito: Normal (pode ignorar), Depende (só vale corrigir com sintomas), Corrigir.
$script:ConhecimentoDrivers = @{
    'hwpolicy' = @{
        Funcao = 'Componente interno do Windows (assinado pela Microsoft) ligado a políticas de hardware e segurança. Não é de um aparelho que você use no dia a dia, como placa de vídeo, som ou rede.'
        Normal = 'Se o computador está estável (sem telas azuis, travamentos ou lentidão), pode ignorar. Se quiser conferir a integridade do Windows, use o SFC na fase de correção.'
        Veredito = 'Normal' }
    'dam' = @{
        Funcao = 'Desktop Activity Moderator: componente da Microsoft que ajuda a economizar energia limitando a atividade de aplicativos em segundo plano (mais usado em notebooks e PCs com suspensão moderna).'
        Normal = 'Em computadores que não usam esse modo de energia é comum ele não iniciar, sem nenhuma consequência. Só vale investigar se aparecerem telas azuis citando dam.sys.'
        Veredito = 'Normal' }
    'vgk' = @{
        Funcao = 'Riot Vanguard: o sistema anti-cheat da Riot Games (VALORANT e League of Legends). Roda dentro do Windows desde a inicialização para vigiar trapaças.'
        Normal = 'Se você joga VALORANT ou LoL, vale corrigir: sem ele o jogo não abre. Costuma resolver reiniciando o PC; se continuar, desinstale e reinstale o Vanguard pelo Riot Client. No Windows 11 ele costuma exigir TPM 2.0 e Inicialização Segura ativados. Se você não joga mais, pode desinstalar o Riot Vanguard em Configurações > Aplicativos.'
        Veredito = 'Normal' }
    'bedaisy' = @{
        Funcao = 'BattlEye: sistema anti-cheat usado por vários jogos. Só é carregado enquanto o jogo está aberto.'
        Normal = 'É normal ele não estar rodando fora do jogo. Só vale corrigir se o jogo reclamar do BattlEye ao abrir (reinstale o BattlEye pelo jogo).'
        Veredito = 'Normal' }
    'easyanticheat' = @{
        Funcao = 'Easy Anti-Cheat: sistema anti-cheat usado por vários jogos. Só é carregado quando o jogo abre.'
        Normal = 'É normal ele não estar rodando fora do jogo. Só vale corrigir se o jogo reclamar do Easy Anti-Cheat ao abrir (use a opção de reparar dentro do jogo).'
        Veredito = 'Normal' }
    'easyanticheat_eos' = @{
        Funcao = 'Easy Anti-Cheat (versão EOS): anti-cheat usado por vários jogos. Só é carregado quando o jogo abre.'
        Normal = 'É normal ele não estar rodando fora do jogo. Só vale corrigir se o jogo reclamar do Easy Anti-Cheat ao abrir.'
        Veredito = 'Normal' }
}

# Explicação das regras de eventos (pelo nome da regra).
$script:ExplicacaoEventos = @{
    'Erros de leitura/escrita no disco' = @{ Veredito = 'Corrigir'
        Texto = 'O Windows não conseguiu ler ou gravar no disco. Isso pode indicar disco com defeito, cabo ou porta ruim, ou desligamento brusco. Como o disco guarda todos os seus arquivos, é o tipo de aviso que não vale a pena ignorar: faça backup primeiro.' }
    'Corrupção ou falha de gravação no sistema de arquivos (NTFS)' = @{ Veredito = 'Depende'
        Texto = 'O sistema de arquivos registrou uma falha ao gravar ou ler informações internas. Costuma acontecer depois de um desligamento brusco ou por um problema no disco. Um evento isolado e antigo é comum; se se repete, verifique o disco.' }
    'Reset/timeout do controlador de armazenamento' = @{ Veredito = 'Depende'
        Texto = 'O Windows precisou reiniciar o controlador do SSD ou HD porque ele demorou a responder. Uma ocorrência isolada pode ser normal; se se repete, costuma ser firmware, driver ou cabo/porta com mau contato.' }
    'Erros de hardware reportados pela CPU/PCIe (WHEA)' = @{ Veredito = 'Corrigir'
        Texto = 'O processador ou o barramento PCIe reportou um erro de hardware. Mesmo quando foi corrigido sozinho, repetição pode indicar overclock, temperatura alta ou componente instável.' }
    'Telas azuis (BugCheck)' = @{ Veredito = 'Corrigir'
        Texto = 'Tela azul: o Windows parou de propósito para evitar danos. Uma única tela azul pode ser acaso; se são recorrentes, vale investigar o driver citado.' }
    'Desligamentos inesperados (Kernel-Power 41)' = @{ Veredito = 'Depende'
        Texto = 'O computador foi desligado ou reiniciado sem o Windows ter fechado normalmente. Acontece quando falta energia, quando se segura o botão de ligar, em travamentos ou em telas azuis. Poucas vezes e com motivo conhecido é normal; se acontece sozinho e se repete, vale investigar temperatura, fonte e drivers.' }
    'Driver de vídeo parou de responder (TDR)' = @{ Veredito = 'Depende'
        Texto = 'A placa de vídeo demorou demais e o Windows reiniciou o driver dela (a tela pode ter piscado). Uma ocorrência isolada é comum; se se repete em jogos, vale atualizar o driver, checar a temperatura e desligar overclock.' }
    'Erros do driver de vídeo (NVIDIA/AMD)' = @{ Veredito = 'Depende'
        Texto = 'O driver da placa de vídeo registrou erros. Se não há travamentos, artefatos na tela ou fechamentos de jogos, pode ser passageiro; se há, reinstale o driver com instalação limpa.' }
    'Serviços/drivers que falharam ao iniciar' = @{ Veredito = 'Normal'
        Texto = 'Um serviço ou driver não iniciou durante a inicialização do Windows. É muito comum, por causa de restos de programas desinstalados e de anti-cheats de jogos. Só importa se algo que você usa deixou de funcionar. Os drivers que falharam estão listados na seção de Drivers.' }
    'Driver não carregou para um dispositivo (PnP)' = @{ Veredito = 'Depende'
        Texto = 'O Windows não conseguiu carregar o driver de um dispositivo. É comum com aparelhos USB ou Bluetooth desconectados ou sem uso; só vale corrigir se o dispositivo deveria estar funcionando.' }
    'Driver bloqueado pela integridade de código' = @{ Veredito = 'Depende'
        Texto = 'O Windows bloqueou um driver por segurança (sem assinatura válida ou incompatível). Isso protege o sistema, mas pode impedir o funcionamento de programas antigos de hardware. Se o programa é seu e importante, procure a versão atual do fabricante.' }
}

# ----------------------------------------------------------------------------
# Utilitários
# ----------------------------------------------------------------------------
function Test-Administrador {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Write-Titulo {
    param([string]$Texto)
    Write-Host ''
    Write-Host ('=' * 72) -ForegroundColor Cyan
    Write-Host " $Texto" -ForegroundColor Cyan
    Write-Host ('=' * 72) -ForegroundColor Cyan
}

function Get-TextoGrupoReparo {
    # Títulos e explicações dos dois grupos de avisos (usados na interface, no relatório e no resumo copiado).
    param([ValidateSet('Auto', 'Manual')][string]$Grupo)
    if ($Grupo -eq 'Auto') {
        return @{
            Titulo = 'O Telomera consegue corrigir'
            Texto  = 'Para estes itens existe uma correção automática. Clique em "Corrigir automaticamente" (como administrador): o Telomera cria um ponto de restauração antes de mexer.'
        }
    }
    return @{
        Titulo = 'Precisa de você: o Telomera não conserta sozinho'
        Texto  = 'Aqui estão eventos que já aconteceram (o Windows guarda o histórico por 30 dias, então eles continuam aparecendo depois de corrigir), programas de terceiros como jogos e anti-cheat, peças de hardware e avisos informativos. Siga o "O que fazer" de cada item.'
    }
}

function Get-RotuloVeredito {
    param([string]$Veredito)
    switch ($Veredito) {
        'Normal'   { return 'Provavelmente normal' }
        'Depende'  { return 'Depende' }
        'Corrigir' { return 'Vale corrigir' }
        'Opcional' { return 'Opcional' }
        default    { return '' }
    }
}

function Get-ExplicacaoPadrao {
    # Explicação geral (o que é e se importa) para achados que não têm texto próprio.
    param([string]$Categoria, [string]$Gravidade, [string]$Titulo)
    $t = $null
    $v = ''
    if ($Titulo -like 'Vídeo usando driver genérico*') {
        $t = 'O Windows está usando um driver básico no lugar do driver da placa de vídeo. Funciona para uso simples, mas sem desempenho nem recursos completos (jogos lentos, resolução limitada, sem aceleração de vídeo). Vale instalar o driver do fabricante.'
        $v = 'Corrigir'
    } elseif ($Titulo -like 'Usando driver padrão da Microsoft*') {
        $t = 'Para muitos dispositivos (teclado, mouse, USB, áudio simples) o driver da própria Microsoft é suficiente e estável. Só vale trocar pelo do fabricante se o dispositivo não funcionar bem ou faltarem recursos.'
        $v = 'Normal'
    } elseif ($Titulo -like 'Driver sem assinatura digital*') {
        $t = 'Driver sem assinatura digital não foi verificado pela Microsoft. Pode ser de um programa legítimo antigo ou de origem duvidosa. Confira se você reconhece o programa que o instalou.'
        $v = 'Depende'
    } elseif ($Titulo -like 'Driver antigo*') {
        $t = 'Drivers antigos costumam continuar funcionando. Atualizar traz correções de segurança e estabilidade, principalmente para a placa de vídeo, mas não é urgente se tudo funciona bem.'
        $v = 'Opcional'
    } elseif ($Titulo -like 'Falha na instalação de driver*') {
        $t = 'O Windows registrou uma tentativa de instalar um driver que não deu certo. Só importa se o dispositivo correspondente não está funcionando; caso contrário, costuma ser tentativa antiga sem efeito.'
        $v = 'Depende'
    } elseif ($Titulo -match '\(código \d+') {
        $t = 'Este dispositivo está com erro no Gerenciador de Dispositivos. Se você não usa o aparelho (por exemplo, Bluetooth ou câmera) ou ele nem existe mais, pode ignorar. Se algo que depende dele não funciona (som, rede, USB, vídeo), vale corrigir.'
        $v = 'Depende'
    } elseif ($Titulo -like '*Windows Update instalou driver de vídeo*') {
        $t = 'O Windows Update pode trocar o driver da placa de vídeo por outro que ele considera adequado, às vezes mais antigo ou genérico. Isso só importa se você notou queda de desempenho ou problemas depois de uma atualização.'
        $v = 'Opcional'
    } elseif ($Titulo -like '*não é o mais recente do fabricante*' -or $Titulo -like '*usa driver da Microsoft e não há driver do fabricante*') {
        $t = 'O driver em uso na placa de vídeo não é o do fabricante, ou não é o mais novo. Funciona, mas pode render menos em jogos e programas gráficos. Use a restauração oferecida pelo Telomera ou baixe o driver no site do fabricante.'
        $v = 'Depende'
    } else {
        switch ($Categoria) {
            'Disco'          { $t = 'O disco guarda todos os seus arquivos. Avisos de saúde, erros não corrigidos ou previsão de falha são sérios: faça backup. Temperatura alta ocasional sob uso intenso e muitas horas de uso são mais brandos.' }
            'Volume'         { $t = 'Uma unidade (como C:) tem pouco espaço livre ou erros no sistema de arquivos. Pouco espaço deixa o Windows lento e impede atualizações; erros de sistema de arquivos pedem verificação.' }
            'Hardware'       { $t = 'Um componente do computador (memória, processador, bateria, temperatura...) merece atenção. Veja o detalhe: avisos de desempenho abaixo do ideal não são urgentes; temperatura alta e erros de hardware são.' }
            'Sistema'        { $t = 'Informação geral sobre o estado do Windows (tempo ligado, reinicialização pendente, BIOS antiga). Raramente é urgente, mas reiniciar e manter o sistema atualizado evita vários problemas.' }
            'Windows Update' { $t = 'Há drivers pendentes no Windows Update. Instalá-los costuma ser seguro, mas para a placa de vídeo costuma ser melhor usar o driver do fabricante.' ; $v = 'Opcional' }
            'Telomera'        { $t = 'Uma etapa da verificação não pôde ser feita neste computador e foi pulada. O restante da verificação não foi afetado.'; $v = 'Normal' }
        }
    }
    if (-not $t) { return $null }
    if (-not $v) {
        switch ($Gravidade) {
            'Critico' { $v = 'Corrigir' }
            'Atencao' { $v = 'Depende' }
            default   { $v = 'Opcional' }
        }
    }
    return @{ Texto = $t; Veredito = $v }
}

function Resolve-CaminhoDriver {
    param([string]$Caminho)
    $p = "$Caminho".Trim().Trim('"')
    $p = $p -replace '^\\\?\?\\', ''
    if ($p -match '^\\SystemRoot\\') { $p = $env:SystemRoot + $p.Substring(11) }
    elseif ($p -match '^system32\\') { $p = Join-Path $env:SystemRoot $p }
    return $p
}

function Get-ExplicacaoDriverSistema {
    # Explica um driver de sistema que falhou ao iniciar: o que é, e se importa.
    param([string]$Servico, [string]$Arquivo, [string]$StartMode)
    $L = New-Object System.Collections.Generic.List[string]
    $chave = "$Servico".ToLower()
    $caminho = Resolve-CaminhoDriver $Arquivo
    $existe = $true
    if ($caminho) { $existe = [bool](Test-Path -LiteralPath $caminho -ErrorAction SilentlyContinue) }

    if ($script:ConhecimentoDrivers.ContainsKey($chave)) {
        $c = $script:ConhecimentoDrivers[$chave]
        $v = $c.Veredito
        $L.Add("O que é: $($c.Funcao)")
        $L.Add("É normal dar erro? $($c.Normal)")
        if ($caminho -and -not $existe) { $L.Add('Observação: o arquivo do driver não foi encontrado neste computador.') }
    } else {
        $L.Add("O que é: um driver de sistema ($Servico) que o Windows tenta carregar durante a inicialização. O Telomera não tem uma descrição pronta para ele; o nome do arquivo e o programa instalado costumam indicar de quem ele é.")
        if ($caminho -and -not $existe) {
            $v = 'Normal'
            $L.Add('É normal dar erro? O arquivo do driver não existe mais neste computador: é resto de um programa desinstalado. Pode ignorar com segurança.')
        } elseif ($StartMode -in 'Boot', 'System') {
            $v = 'Depende'
            $L.Add('É normal dar erro? Ele é configurado para carregar bem cedo na inicialização. Se há lentidão, travamentos ou telas azuis, vale corrigir; se o computador está estável, costuma ser inofensivo.')
        } else {
            $v = 'Depende'
            $L.Add('É normal dar erro? Depende do programa que o instalou: se esse programa funciona (ou você nem o usa), pode ignorar. Se ele deixou de funcionar, reinstale-o.')
        }
    }
    $L.Add('Regra prática: se o computador está estável e nada que você usa deixou de funcionar, não é preciso mexer.')
    return @{ Texto = ($L -join "`r`n`r`n"); Veredito = $v }
}

function Add-Achado {
    param(
        [Parameter(Mandatory)][ValidateSet('Critico', 'Atencao', 'Info')][string]$Gravidade,
        [Parameter(Mandatory)][string]$Categoria,
        [Parameter(Mandatory)][string]$Titulo,
        [string]$Detalhe = '',
        [string]$Solucao = '',
        [object[]]$Links = @(),
        [string]$Explicacao = '',
        [ValidateSet('', 'Normal', 'Depende', 'Corrigir', 'Opcional')][string]$Veredito = ''
    )
    if (-not $Explicacao) {
        $pad = Get-ExplicacaoPadrao -Categoria $Categoria -Gravidade $Gravidade -Titulo $Titulo
        if ($pad) { $Explicacao = $pad.Texto; if (-not $Veredito) { $Veredito = $pad.Veredito } }
    }
    if ($Explicacao -and -not $Veredito) { $Veredito = 'Depende' }
    # O mesmo aviso vindo de duas verificações aparece uma vez só (aproveita a explicação da segunda se a primeira não tinha).
    $repetido = @($script:Achados | Where-Object { $_.Titulo -eq $Titulo }) | Select-Object -First 1
    if ($repetido) {
        if (-not $repetido.Explicacao -and $Explicacao) { $repetido.Explicacao = $Explicacao; $repetido.Veredito = $Veredito }
        return
    }
    # Algo "provavelmente normal" não deve alarmar: vira informativo (continua no relatório e na lista de avisos informativos).
    if ($Veredito -eq 'Normal' -and $Gravidade -eq 'Atencao') { $Gravidade = 'Info' }
    $script:Achados.Add([pscustomobject]@{
        Gravidade = $Gravidade
        Categoria = $Categoria
        Titulo    = $Titulo
        Detalhe   = $Detalhe
        Solucao   = $Solucao
        Links     = @($Links)
        Explicacao = $Explicacao
        Veredito   = $Veredito
        Reparo     = 'Manual'
    })
    $rotulo = @{ Critico = 'CRÍTICO'; Atencao = 'ATENÇÃO'; Info = 'INFO' }[$Gravidade]
    $cor    = @{ Critico = 'Red'; Atencao = 'Yellow'; Info = 'Gray' }[$Gravidade]
    Write-Host ('  [{0}] {1}' -f $rotulo, $Titulo) -ForegroundColor $cor
    if ($Detalhe) { Write-Host "         $Detalhe" -ForegroundColor DarkGray }
}

function Add-Acao {
    param(
        [Parameter(Mandatory)][string]$Descricao,
        [Parameter(Mandatory)][scriptblock]$Acao,
        [object]$Arg = $null,
        [switch]$Protecao,
        [switch]$Sensivel,
        [switch]$Desfaz,
        [switch]$Geral,
        [switch]$MudaDriver,
        [string]$Aviso = ''
    )
    # A correção vem logo depois do achado que a motivou: marca esse achado como reparável pelo Telomera.
    if (-not $Desfaz -and -not $Geral -and $script:Achados.Count -gt 0) { $script:Achados[$script:Achados.Count - 1].Reparo = 'Auto' }
    $script:Acoes.Add([pscustomobject]@{
        Descricao = $Descricao
        Acao      = $Acao
        Arg       = $Arg
        Protecao  = [bool]$Protecao
        Sensivel  = [bool]$Sensivel
        Desfaz    = [bool]$Desfaz
        MudaDriver = [bool]$MudaDriver
        Aviso     = $Aviso
    })
}

function Invoke-Protecao {
    # Ponto de restauração (uma vez) e, só quando a ação mexe em drivers (-Backup), a cópia dos drivers (uma vez).
    # A cópia leva alguns minutos, então não é feita para ações que só mudam configurações.
    param([switch]$Backup)
    if (-not $script:ProtecaoFeita) {
    $script:ProtecaoFeita = $true

    Write-Host ''
    Write-Host '  Antes de alterar drivers ou volumes, vale ter um ponto de volta.' -ForegroundColor Cyan
    $r = Read-Resposta '  Criar um ponto de restauração do sistema? (pode ativar a Proteção do Sistema na unidade do Windows) [S/n]'
    if ($r -notmatch '^\s*[nN]') {
        try {
            Enable-ComputerRestore -Drive "$($env:SystemDrive)\" -ErrorAction Stop
            Checkpoint-Computer -Description "Telomera $($script:Stamp)" -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
            Write-Host '  Ponto de restauração criado.' -ForegroundColor Green
        } catch {
            Write-Host "  Não foi possível criar o ponto de restauração: $($_.Exception.Message)" -ForegroundColor Yellow
            Write-Host '  (O Windows limita a um ponto a cada 24 horas por padrão.)' -ForegroundColor DarkGray
            $c = Read-Resposta '  Continuar mesmo assim? [s/N]'
            if ($c -notmatch '^\s*[sSyY]') { return $false }
        }
    }
    }

    if (-not $Backup -or $script:BackupFeito) { return $true }
    $script:BackupFeito = $true
    $r2 = Read-Resposta '  Exportar uma cópia dos drivers de terceiros instalados (útil para voltar atrás)? [s/N]'
    if ($r2 -match '^\s*[sSyY]') {
        $pasta = Join-Path $script:PastaRelatorioFinal "DriversBackup_$($script:Stamp)"
        try {
            New-Item -ItemType Directory -Force -Path $pasta | Out-Null
            Write-Host '  Exportando drivers (pode levar alguns minutos)...'
            Export-WindowsDriver -Online -Destination $pasta -ErrorAction Stop | Out-Null
            Write-Host "  Drivers exportados para: $pasta" -ForegroundColor Green
            $script:PastaDrivers = $pasta
        } catch {
            Write-Host "  Falha ao exportar os drivers: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    return $true
}

function Confirm-Acao {
    param([string]$Mensagem, [switch]$Protecao, [switch]$Sensivel, [switch]$Desfaz, [switch]$MudaDriver, [string]$Aviso = '')
    if ($SomenteLeitura) { return $false }
    if ($Aviso) { Write-Host "    Aviso: $Aviso" -ForegroundColor Yellow }
    if ($Sensivel) {
        Write-Host '    Este é um driver INTERNO do sistema (chipset, armazenamento, processador ou barramento).' -ForegroundColor Yellow
        $r = Read-Resposta "  $Mensagem`n    Para autorizar, digite RESTAURAR (ou Enter para pular)"
        if ("$r".Trim() -ne 'RESTAURAR') { return $false }
    } else {
        $r = Read-Resposta "  $Mensagem [s/N]"
        if ($r -notmatch '^\s*[sSyY]') { return $false }
    }
    if ($Protecao) {
        if (-not (Invoke-Protecao -Backup:$MudaDriver)) { return $false }
    }
    return $true
}

function Get-TextoErroWin32 {
    param([int]$Codigo)
    try { return (New-Object System.ComponentModel.Win32Exception($Codigo)).Message } catch { return "erro $Codigo" }
}

function Get-DescricaoBugcheck {
    param([string]$Codigo)
    if ($script:Bugchecks.ContainsKey($Codigo)) { return $script:Bugchecks[$Codigo] }
    return 'código sem descrição local; pesquise o código no site da Microsoft'
}

function Get-SolucaoCodigo {
    param([int]$Codigo)
    switch ($Codigo) {
        22 { return 'O dispositivo está desativado. Se não foi você quem desativou, reative-o na fase de reparo.' }
        28 { return 'Falta o driver. Instale o pacote do fabricante (links abaixo) ou tente o Windows Update.' }
        { $_ -in 10, 24 } { return 'O dispositivo não inicia ou não responde. Reinicie, teste outra porta/cabo (se for USB) e atualize BIOS e driver do fabricante.' }
        52 { return 'O Windows não conseguiu verificar a assinatura do driver. Use um driver oficial e assinado do fabricante.' }
        default { return 'Reinstale o driver (oferecido na fase de reparo). Se persistir, instale a versão do fabricante pelos links abaixo.' }
    }
}

function Get-LinksDriver {
    # Gera links de download confiáveis: Microsoft Update Catalog, página do fabricante do componente,
    # suporte do fabricante do computador e, para PCI, a identificação do dispositivo.
    param([string]$HardwareId = '', [string]$InstanceId = '')
    $texto = "$HardwareId $InstanceId"
    $ven = $null; $dev = $null; $pci = $false
    if ($texto -match 'PCI\\VEN_([0-9A-Fa-f]{4})&DEV_([0-9A-Fa-f]{4})') {
        $ven = $matches[1].ToUpper(); $dev = $matches[2].ToUpper(); $pci = $true
    } elseif ($texto -match 'USB\\VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})') {
        $ven = $matches[1].ToUpper(); $dev = $matches[2].ToUpper()
    } elseif ($texto -match 'VEN_([0-9A-Fa-f]{4})') {
        $ven = $matches[1].ToUpper()
    }

    $links = New-Object System.Collections.Generic.List[object]

    $base = if ($HardwareId) { $HardwareId } else { $InstanceId }
    if ($base) {
        $consulta = (($base -split '&SUBSYS')[0] -split '&REV')[0]
        $links.Add(@{ Texto = 'Microsoft Update Catalog (busca por este hardware)'; Url = 'https://www.catalog.update.microsoft.com/Search.aspx?q=' + [uri]::EscapeDataString($consulta) })
    }
    if ($ven -and $script:Fabricantes.ContainsKey($ven)) {
        $f = $script:Fabricantes[$ven]
        $links.Add(@{ Texto = "Downloads do fabricante ($($f.Nome))"; Url = $f.Url })
    }
    $fabPC = "$($script:Sistema.Fabricante)"
    foreach ($o in $script:LinksOEM) {
        if ($fabPC -match $o.Padrao) {
            $links.Add(@{ Texto = "Suporte do fabricante do computador ($($o.Nome))"; Url = $o.Url })
            break
        }
    }
    if ($pci -and $ven -and $dev) {
        $links.Add(@{ Texto = 'Identificar o dispositivo (pci-ids)'; Url = "https://pci-ids.ucw.cz/read/PC/$($ven.ToLower())/$($dev.ToLower())" })
    }
    return $links.ToArray()
}

# ----------------------------------------------------------------------------
# Sistema
# ----------------------------------------------------------------------------
function Test-RebootPendente {
    $chaves = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    )
    foreach ($c in $chaves) { if (Test-Path $c) { return $true } }
    $v = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    if ($v -and $v.PendingFileRenameOperations) { return $true }
    return $false
}

function Get-InfoSistema {
    Write-Titulo '0) SISTEMA'
    $os   = Get-CimInstance Win32_OperatingSystem
    $cs   = Get-CimInstance Win32_ComputerSystem
    $bios = Get-CimInstance Win32_BIOS | Select-Object -First 1
    $dias = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalDays, 1)
    $dataBios = if ($bios.ReleaseDate) { $bios.ReleaseDate.ToString('yyyy-MM-dd') } else { 'n/d' }

    $script:Sistema = [ordered]@{
        Computador          = $env:COMPUTERNAME
        Windows             = "$($os.Caption) (build $($os.BuildNumber))"
        Build               = [int]$os.BuildNumber
        Arquitetura         = $os.OSArchitecture
        Fabricante          = $cs.Manufacturer
        Modelo              = $cs.Model
        BIOS                = "$($bios.SMBIOSBIOSVersion) ($dataBios)"
        MemoriaRAM_GB       = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        UltimaInicializacao = $os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm')
        DiasLigado          = $dias
    }
    $script:Dados['Sistema'] = $script:Sistema
    foreach ($k in $script:Sistema.Keys) { Write-Host ('  {0,-20} {1}' -f $k, $script:Sistema[$k]) }

    if ($dias -ge 7) {
        Add-Achado -Gravidade Info -Categoria 'Sistema' -Titulo "O computador está ligado há $dias dias sem reiniciar" `
            -Detalhe 'Com a Inicialização Rápida, "Desligar" não reinicia o Windows de verdade; só "Reiniciar" recarrega os drivers.' `
            -Solucao 'Use Iniciar > Reiniciar e rode o Telomera de novo se os problemas persistirem.'
    }
    if (Test-RebootPendente) {
        Add-Achado -Gravidade Atencao -Categoria 'Sistema' -Titulo 'Há uma reinicialização pendente' `
            -Detalhe 'Atualizações ou instalações de driver aguardam reinício. Isso pode fazer SFC/DISM e instalações de driver falharem.' `
            -Solucao 'Reinicie o computador e execute o Telomera novamente. Use o botão "Reiniciar o PC agora" abaixo (reinicia em 30 segundos, dá para cancelar).'
    }
    if ($bios.ReleaseDate -and $bios.ReleaseDate -lt (Get-Date).AddYears(-4)) {
        Add-Achado -Gravidade Info -Categoria 'Sistema' -Titulo "A BIOS/UEFI tem mais de 4 anos ($dataBios)" `
            -Detalhe 'Atualizações de BIOS corrigem problemas de USB, energia, NVMe e compatibilidade de drivers.' `
            -Solucao 'Confira a página de suporte do fabricante do computador/placa-mãe.' `
            -Links @(Get-LinksDriver)
    }
}

# ----------------------------------------------------------------------------
# 1) Discos
# ----------------------------------------------------------------------------
function Invoke-AnaliseDiscos {
    Write-Titulo '1) DISCOS FÍSICOS E SMART'
    $lista = New-Object System.Collections.Generic.List[object]
    $discos = @(Get-PhysicalDisk -ErrorAction SilentlyContinue)
    if ($discos.Count -eq 0) { Write-Host '  Nenhum disco físico retornado (máquina virtual ou falta de permissão).' -ForegroundColor Yellow }

    foreach ($d in $discos) {
        $rel = $null
        try { $rel = $d | Get-StorageReliabilityCounter -ErrorAction Stop } catch { }
        $item = [pscustomobject]@{
            Nome               = $d.FriendlyName
            Tipo               = "$($d.MediaType)"
            Barramento         = "$($d.BusType)"
            TamanhoGB          = [math]::Round($d.Size / 1GB, 1)
            Saude              = "$($d.HealthStatus)"
            Status             = "$($d.OperationalStatus)"
            TemperaturaC       = if ($rel) { $rel.Temperature } else { $null }
            DesgasteSSD_Pct    = if ($rel) { $rel.Wear } else { $null }
            HorasLigado        = if ($rel) { $rel.PowerOnHours } else { $null }
            ErrosLeituraNaoCorrigidos  = if ($rel) { $rel.ReadErrorsUncorrected } else { $null }
            ErrosEscritaNaoCorrigidos  = if ($rel) { $rel.WriteErrorsUncorrected } else { $null }
        }
        $lista.Add($item)

        $nome = "$($d.FriendlyName)"
        if ($item.Saude -eq 'Unhealthy') {
            Add-Achado -Gravidade Critico -Categoria 'Disco' -Titulo "O disco '$nome' está com saúde 'Unhealthy'" `
                -Detalhe 'O Windows considera este disco com falha.' -Solucao 'Faça backup imediatamente e substitua o disco.'
        } elseif ($item.Saude -eq 'Warning') {
            Add-Achado -Gravidade Atencao -Categoria 'Disco' -Titulo "O disco '$nome' está com aviso de saúde" `
                -Detalhe 'O Windows reportou degradação neste disco.' -Solucao 'Faça backup e acompanhe o SMART; planeje a troca.'
        }
        if ($item.Status -and $item.Status -notmatch '^(OK|)$') {
            Add-Achado -Gravidade Atencao -Categoria 'Disco' -Titulo "O disco '$nome' tem status operacional '$($item.Status)'" `
                -Solucao 'Verifique cabos/conexão e o Gerenciamento de Disco (diskmgmt.msc).'
        }
        if ($null -ne $item.DesgasteSSD_Pct) {
            if ($item.DesgasteSSD_Pct -ge 90) {
                Add-Achado -Gravidade Critico -Categoria 'Disco' -Titulo "SSD '$nome' com $($item.DesgasteSSD_Pct)% de desgaste" `
                    -Solucao 'Faça backup e troque o SSD em breve.'
            } elseif ($item.DesgasteSSD_Pct -ge 70) {
                Add-Achado -Gravidade Atencao -Categoria 'Disco' -Titulo "SSD '$nome' com $($item.DesgasteSSD_Pct)% de desgaste" `
                    -Solucao 'Mantenha backups em dia e planeje a troca.'
            }
        }
        if ($null -ne $item.TemperaturaC -and $item.TemperaturaC -gt 0) {
            if ($item.TemperaturaC -ge 75) {
                Add-Achado -Gravidade Critico -Categoria 'Disco' -Titulo "Disco '$nome' a $($item.TemperaturaC) °C" `
                    -Solucao 'Melhore a ventilação do gabinete e verifique o dissipador (NVMe).'
            } elseif ($item.TemperaturaC -ge 65) {
                Add-Achado -Gravidade Atencao -Categoria 'Disco' -Titulo "Disco '$nome' a $($item.TemperaturaC) °C" `
                    -Solucao 'Temperatura alta; melhore a ventilação.'
            }
        }
        $naoCorr = [int]($item.ErrosLeituraNaoCorrigidos) + [int]($item.ErrosEscritaNaoCorrigidos)
        if ($naoCorr -gt 0) {
            Add-Achado -Gravidade Critico -Categoria 'Disco' -Titulo "Disco '$nome' com $naoCorr erro(s) de leitura/escrita não corrigidos" `
                -Detalhe 'Erros que o próprio disco não conseguiu corrigir indicam setores com problema.' `
                -Solucao 'Faça backup agora e considere trocar o disco.'
        }
        if ($null -ne $item.HorasLigado -and $item.HorasLigado -ge 35000) {
            Add-Achado -Gravidade Info -Categoria 'Disco' -Titulo "Disco '$nome' com $($item.HorasLigado) horas de uso" `
                -Solucao 'Discos com muitas horas de uso têm maior chance de falha; mantenha backups.'
        }
    }

    if ($lista.Count -gt 0) {
        $lista | Format-Table Nome, Tipo, TamanhoGB, Saude, TemperaturaC, DesgasteSSD_Pct, HorasLigado -AutoSize | Out-String -Width 200 | Write-Host
    }

    # Previsão de falha do firmware (SMART)
    try {
        $pf = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction Stop)
        foreach ($p in $pf) {
            if ($p.PredictFailure) {
                Add-Achado -Gravidade Critico -Categoria 'Disco' -Titulo 'O firmware de um disco PREVÊ FALHA (SMART)' `
                    -Detalhe "Instância: $($p.InstanceName)" -Solucao 'Faça backup imediatamente e troque o disco.'
            }
        }
    } catch {
        Write-Host '  (A previsão de falha SMART via WMI não está disponível neste equipamento.)' -ForegroundColor DarkGray
    }

    $script:Dados['Discos'] = $lista.ToArray()
}

# ----------------------------------------------------------------------------
# 2) Volumes
# ----------------------------------------------------------------------------
function Invoke-AnaliseVolumes {
    Write-Titulo '2) VOLUMES E SISTEMA DE ARQUIVOS'
    $vols = @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })
    $lista = New-Object System.Collections.Generic.List[object]

    foreach ($v in $vols) {
        $pct = if ($v.Size -gt 0) { [math]::Round(100 * $v.SizeRemaining / $v.Size, 1) } else { $null }
        $lista.Add([pscustomobject]@{
            Unidade    = "$($v.DriveLetter):"
            Rotulo     = $v.FileSystemLabel
            Sistema    = "$($v.FileSystem)"
            Tipo       = "$($v.DriveType)"
            Saude      = "$($v.HealthStatus)"
            TotalGB    = [math]::Round($v.Size / 1GB, 1)
            LivreGB    = [math]::Round($v.SizeRemaining / 1GB, 1)
            LivrePct   = $pct
            Varredura  = 'não executada'
        })
    }

    foreach ($x in $lista) {
        $letra = $x.Unidade.TrimEnd(':')
        if ($x.Tipo -eq 'Fixed' -and $null -ne $x.LivrePct) {
            if ($x.LivrePct -lt 5) {
                Add-Achado -Gravidade Critico -Categoria 'Volume' -Titulo "A unidade $($x.Unidade) tem só $($x.LivrePct)% livre" `
                    -Detalhe 'Pouco espaço faz atualizações e instalações de driver falharem e deixa o sistema lento.' `
                    -Solucao 'Libere espaço (Configurações > Sistema > Armazenamento).'
                Add-Acao -Descricao 'Liberar espaço: apagar arquivos temporários com mais de 2 dias' -Acao { $l = Clear-Temporarios; Write-Host ('    Liberado: ' + (Format-Tamanho $l)) -ForegroundColor Green; Add-Alteracao -Acao 'Apagar arquivos temporários antigos' -Resultado ('liberado ' + (Format-Tamanho $l)) }
            } elseif ($x.LivrePct -lt 10 -and $x.LivreGB -lt 50) {
                Add-Achado -Gravidade Atencao -Categoria 'Volume' -Titulo "A unidade $($x.Unidade) tem $($x.LivrePct)% livre" `
                    -Solucao 'Libere espaço para manter o desempenho e permitir atualizações.' `
                    -Explicacao ("Neste computador: a unidade $($x.Unidade) tem $($x.LivreGB) GB livres de $($x.TotalGB) GB ($($x.LivrePct)%).`r`n`r`nPreciso me preocupar? Abaixo de uns 10% (ou 50 GB) o Windows pode falhar ao instalar atualizações e ficar lento.`r`n`r`nO que fazer: o botão Corrigir apaga só temporários com mais de 2 dias. Para ganhar mais, use Configurações > Sistema > Armazenamento.") -Veredito Depende
                Add-Acao -Descricao 'Liberar espaço: apagar arquivos temporários com mais de 2 dias' -Acao { $l = Clear-Temporarios; Write-Host ('    Liberado: ' + (Format-Tamanho $l)) -ForegroundColor Green; Add-Alteracao -Acao 'Apagar arquivos temporários antigos' -Resultado ('liberado ' + (Format-Tamanho $l)) }
            }
        }
        if ($x.Tipo -eq 'Fixed' -and $x.Saude -and $x.Saude -ne 'Healthy') {
            Add-Achado -Gravidade Atencao -Categoria 'Volume' -Titulo "O volume $($x.Unidade) está com saúde '$($x.Saude)'" `
                -Solucao 'Execute a verificação de volume na fase de reparo.'
        }

        if (-not $PularScanVolumes -and $x.Tipo -eq 'Fixed' -and $x.Sistema -in 'NTFS', 'ReFS' -and -not (Test-Administrador)) {
            $x.Varredura = 'requer administrador'
        } elseif (-not $PularScanVolumes -and $x.Tipo -eq 'Fixed' -and $x.Sistema -in 'NTFS', 'ReFS') {
            Write-Host "  Verificando ${letra}: (varredura online, não altera nada)..." -ForegroundColor DarkGray
            try {
                $res = Repair-Volume -DriveLetter $letra -Scan -ErrorAction Stop
                $x.Varredura = "$res"
                if ("$res" -ne 'NoErrorsFound') {
                    Add-Achado -Gravidade Atencao -Categoria 'Volume' -Titulo "Erros encontrados no volume $($x.Unidade) (resultado: $res)" `
                        -Solucao 'Execute o reparo do volume na fase de reparo; na unidade do sistema o ideal é também um chkdsk /f com reinício.'
                    Add-Acao -Descricao "Reparar erros do volume $($x.Unidade) (Repair-Volume -SpotFix)" -Protecao -Arg $letra -Acao {
                        param($l)
                        $r = Repair-Volume -DriveLetter $l -SpotFix -ErrorAction Stop
                        Write-Host "    Resultado: $r" -ForegroundColor Green
                        Write-Host '    Se for a unidade do Windows, o reparo pode ser concluído após reiniciar.' -ForegroundColor DarkGray
                    }
                }
            } catch {
                $x.Varredura = 'falhou'
                Write-Host "  Não foi possível verificar ${letra}: $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
    }

    if ($lista.Count -gt 0) {
        $lista | Format-Table Unidade, Rotulo, Sistema, Tipo, Saude, TotalGB, LivreGB, LivrePct, Varredura -AutoSize | Out-String -Width 200 | Write-Host
    }
    $script:Dados['Volumes'] = $lista.ToArray()
}

# ----------------------------------------------------------------------------
# 3) Eventos
# ----------------------------------------------------------------------------
function Get-DadosEvento {
    # Lê os campos do evento direto do XML: funciona mesmo quando o Windows não consegue montar o texto da mensagem
    # (é o caso de vários erros da NVIDIA, que chegavam em branco no relatório).
    param($Evento)
    $d = [ordered]@{}
    try {
        $x = [xml]$Evento.ToXml()
        $i = 0
        foreach ($n in @($x.Event.EventData.Data)) {
            if ($null -eq $n) { continue }
            if ($n -is [string]) { $nome = ''; $val = $n }
            else { $nome = "$($n.GetAttribute('Name'))"; $val = "$($n.InnerText)" }
            if (-not $nome) { $nome = "Dado$i" }
            $d[$nome] = $val
            $i++
        }
    } catch { }
    return $d
}

function Get-MensagemEvento {
    # Ler .Message pode lançar erro em eventos com texto/provedor corrompido; nesse caso usa os campos do XML.
    param($Evento)
    $m = ''
    try { $m = "$($Evento.Message)" } catch { $m = '' }
    if ($m.Trim()) { return $m }
    try {
        $d = Get-DadosEvento $Evento
        $partes = @($d.GetEnumerator() | Where-Object { "$($_.Value)".Trim() } | Select-Object -First 6 | ForEach-Object { '{0}={1}' -f $_.Key, $_.Value })
        if ($partes.Count -gt 0) { return '(sem texto do Windows) ' + ($partes -join ', ') }
    } catch { }
    return ''
}

function Get-ResumoQuedas {
    # Detalha os eventos Kernel-Power 41: quantos em cada período, se houve tela azul ou botão de ligar, e a que horas costumam ocorrer.
    param($Eventos)
    $agora = Get-Date
    $lista = @($Eventos | Sort-Object TimeCreated -Descending)
    if ($lista.Count -eq 0) { return '' }
    $n24 = @($lista | Where-Object { $_.TimeCreated -gt $agora.AddHours(-24) }).Count
    $n7  = @($lista | Where-Object { $_.TimeCreated -gt $agora.AddDays(-7) }).Count
    $semAzul = 0; $botao = 0; $codigos = @{}; $horas = @{}
    foreach ($e in $lista) {
        $d = Get-DadosEvento $e
        $bc = 0; $pb = 0
        try { if ($d['BugcheckCode']) { $bc = [int64]$d['BugcheckCode'] } } catch { }
        try { if ($d['PowerButtonTimestamp']) { $pb = [int64]$d['PowerButtonTimestamp'] } } catch { }
        if ($bc -ne 0) { $c = '0x{0:X8}' -f $bc; if ($codigos.ContainsKey($c)) { $codigos[$c]++ } else { $codigos[$c] = 1 } }
        elseif ($pb -ne 0) { $botao++ }
        else { $semAzul++ }
        $h = $e.TimeCreated.Hour
        if ($horas.ContainsKey($h)) { $horas[$h]++ } else { $horas[$h] = 1 }
    }
    $t = New-Object System.Collections.Generic.List[string]
    $t.Add(('Contagem: últimas 24 h = {0}, 7 dias = {1}, período todo = {2}.' -f $n24, $n7, $lista.Count))
    $t.Add(('Sem tela azul e sem botão de ligar (corte de energia, travamento total ou desligamento seco): {0}.' -f $semAzul))
    if ($codigos.Count -gt 0) { $t.Add('Com tela azul: ' + ((@($codigos.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 4 | ForEach-Object { '{0} {1} (x{2})' -f $_.Key, (Get-DescricaoBugcheck $_.Key), $_.Value })) -join '; ') + '.') }
    if ($botao -gt 0) { $t.Add("Botão de ligar segurado: $botao.") }
    if ($lista.Count -ge 5) {
        $top = @($horas.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { '{0:00}h (x{1})' -f $_.Key, $_.Value })
        $t.Add('Horários mais comuns: ' + ($top -join ', ') + '.')
    }
    $t.Add('Mais recentes: ' + ((@($lista | Select-Object -First 5 | ForEach-Object { $_.TimeCreated.ToString('dd/MM HH:mm') })) -join ', ') + '.')
    try {
        $script:Dados['Quedas'] = @{ Total = $lista.Count; Ultimas24h = $n24; Ultimos7d = $n7; SemTelaAzul = $semAzul; ComTelaAzul = ($lista.Count - $semAzul - $botao); Botao = $botao; Ultima = $lista[0].TimeCreated.ToString('yyyy-MM-dd HH:mm') }
    } catch { }
    return ($t -join ' ')
}

function Get-ResumoWhea {
    # WHEA = erros de hardware (processador, memória, PCIe). Separa os já corrigidos dos fatais e mostra a origem quando o evento informa.
    param($Eventos)
    $lista = @($Eventos | Sort-Object TimeCreated -Descending)
    if ($lista.Count -eq 0) { return '' }
    $fatal = @($lista | Where-Object { $_.Level -le 2 })
    $corr = @($lista | Where-Object { $_.Level -gt 2 })
    $t = New-Object System.Collections.Generic.List[string]
    $t.Add(('Fatais/não corrigidos: {0}; corrigidos sozinhos: {1}.' -f $fatal.Count, $corr.Count))
    $porId = @($lista | Group-Object Id | Sort-Object Count -Descending | Select-Object -First 3 | ForEach-Object {
        $d = Get-DadosEvento $_.Group[0]
        $extra = @($d.GetEnumerator() | Where-Object { $_.Key -match 'Source|Type|Component|Origem' -and "$($_.Value)".Trim() } | Select-Object -First 2 | ForEach-Object { '{0}={1}' -f $_.Key, $_.Value }) -join ' '
        'ID {0} x{1}{2}' -f $_.Name, $_.Count, $(if ($extra) { " ($extra)" } else { '' })
    })
    if ($porId.Count -gt 0) { $t.Add('Tipos: ' + ($porId -join '; ') + '.') }
    $t.Add('Erro fatal de hardware pode derrubar o PC sem tela azul; verifique temperatura, fonte, overclock/XMP e a BIOS.')
    return ($t -join ' ')
}

# ---------------------------------------------------------------------------
# Explicações detalhadas (2.26): o texto do "Ver mais" de cada driver e de cada evento diz o que é, o que significa
# NESTE computador, se é para se preocupar e o que fazer. Funções puras (recebem os dados, devolvem texto).
# ---------------------------------------------------------------------------
$script:SignificadoIdEvento = @{
    '7'    = 'setor ruim (bad block) encontrado no disco'
    '11'   = 'o controlador do disco reportou erro ao acessar o dispositivo'
    '15'   = 'o disco não estava pronto para acesso'
    '41'   = 'o Windows foi reiniciado sem desligar direito (queda de energia, travamento total ou desligamento forçado)'
    '50'   = 'o sistema de arquivos NTFS não conseguiu gravar dados em cache'
    '51'   = 'erro durante uma operação de paginação (memória virtual) no disco'
    '52'   = 'o disco previu uma falha própria (alerta SMART)'
    '55'   = 'o NTFS achou uma estrutura corrompida no volume'
    '129'  = 'o controlador de armazenamento foi reiniciado porque o disco demorou a responder'
    '153'  = 'uma operação de leitura/gravação no disco precisou ser repetida'
    '17'   = 'erro de hardware corrigido pela plataforma (WHEA), em geral PCIe'
    '18'   = 'erro de hardware fatal reportado pelo processador (WHEA)'
    '19'   = 'erro de hardware corrigido reportado pelo processador (WHEA)'
    '20'   = 'erro de hardware corrigido no barramento PCI Express (WHEA)'
    '219'  = 'o Windows não conseguiu carregar o driver de um dispositivo'
    '1001' = 'o Windows se recuperou de uma tela azul (BugCheck) e registrou o código do erro'
    '3033' = 'a integridade de código impediu o carregamento de um driver sem assinatura aceita'
    '3063' = 'a integridade de código bloqueou um driver por problema de assinatura'
    '4101' = 'o driver de vídeo parou de responder e foi reiniciado pelo Windows (TDR)'
    '7000' = 'um serviço não conseguiu iniciar'
    '7001' = 'um serviço não iniciou porque outro serviço de que ele depende falhou'
    '7026' = 'um driver de inicialização não foi carregado'
    '7031' = 'um serviço terminou de forma inesperada e o Windows tentou reiniciá-lo'
    '7034' = 'um serviço terminou de forma inesperada'
}

function Get-IdadeTexto {
    # Pura: "há 3 dia(s)", "há 2 hora(s)", "há 5 mês(es)", "há 2,4 ano(s)".
    param([datetime]$Data, [datetime]$Agora = (Get-Date))
    $d = $Agora - $Data
    if ($d.TotalHours -lt 1) { return 'há menos de 1 hora' }
    if ($d.TotalHours -lt 48) { return ('há {0} hora(s)' -f [int][math]::Floor($d.TotalHours)) }
    if ($d.TotalDays -lt 60) { return ('há {0} dia(s)' -f [int][math]::Floor($d.TotalDays)) }
    if ($d.TotalDays -lt 730) { return ('há {0} mês(es)' -f [int][math]::Floor($d.TotalDays / 30.4)) }
    return ('há {0} ano(s)' -f ([math]::Round($d.TotalDays / 365.25, 1)).ToString('0.#', [Globalization.CultureInfo]::GetCultureInfo('pt-BR')))
}

function Get-ExplicacaoEventoCaso {
    # Pura. $Datas = lista de datas das ocorrências; $Ids = hashtable id -> quantidade. Devolve as seções "Neste computador / Códigos / Preciso me preocupar? / O que fazer".
    param([string]$Nome, [datetime[]]$Datas, [hashtable]$Ids, [string]$Solucao = '', [string]$Gravidade = 'Atencao', [datetime]$Agora = (Get-Date), [int]$DiasJanela = 30)
    $L = New-Object System.Collections.Generic.List[string]
    $Datas = @($Datas | Sort-Object -Descending)
    $n = $Datas.Count
    if ($n -eq 0) { return '' }
    $h24 = @($Datas | Where-Object { $_ -gt $Agora.AddHours(-24) }).Count
    $d7  = @($Datas | Where-Object { $_ -gt $Agora.AddDays(-7) }).Count
    $ult = $Datas[0]
    $L.Add(('Neste computador: {0} ocorrência(s) nos últimos {1} dias. A mais recente foi em {2} ({3}). Nas últimas 24 horas: {4}; nos últimos 7 dias: {5}.' -f $n, $DiasJanela, $ult.ToString('dd/MM/yyyy HH:mm'), (Get-IdadeTexto $ult $Agora), $h24, $d7))
    if ($Ids -and $Ids.Count -gt 0) {
        $itens = @($Ids.Keys | Sort-Object { [int]$_ } | ForEach-Object {
            $sig = $script:SignificadoIdEvento["$_"]; if (-not $sig) { $sig = 'sem descrição pronta; veja o texto do evento no Visualizador de Eventos' }
            ('ID {0} (x{1}): {2}' -f $_, $Ids[$_], $sig)
        })
        $L.Add('O que cada código quer dizer: ' + ($itens -join '; ') + '.')
    }
    $grave = ($Gravidade -eq 'Critico')
    if ($n -le 1 -and $ult -lt $Agora.AddDays(-7)) {
        $L.Add('Preciso me preocupar? Provavelmente não. Foi um evento isolado, há mais de 7 dias, e o Windows já se recuperou. Só volte a olhar se o problema reaparecer ou se o computador estiver instável.')
    } elseif ($d7 -ge 3 -or $h24 -ge 2) {
        $L.Add('Preciso me preocupar? Sim. O evento está se repetindo (várias vezes na última semana), o que indica um problema ainda ativo, e não um registro do passado.')
    } elseif ($d7 -ge 1 -and $grave) {
        $L.Add('Preciso me preocupar? Sim, com atenção. É um tipo de evento sério e aconteceu na última semana. Faça backup do que é importante e acompanhe se volta.')
    } elseif ($d7 -ge 1) {
        $L.Add('Preciso me preocupar? Um pouco. Aconteceu na última semana. Se foi uma vez só e o computador está estável, acompanhe; se voltar, siga as ações abaixo.')
    } else {
        $L.Add('Preciso me preocupar? Pouco. Aconteceu nos últimos 30 dias mas não na última semana. O Windows guarda o histórico por 30 dias, então o item continua aparecendo mesmo depois de resolvido. Acompanhe se volta.')
    }
    $f = New-Object System.Collections.Generic.List[string]
    if ($Solucao) { $f.Add($Solucao.TrimEnd('.') + '.') }
    $f.Add('Se repetir, rode a verificação de novo depois de 2 ou 3 dias de uso: se o número de ocorrências não subir, o problema parou.')
    $L.Add('O que fazer: ' + ($f -join ' '))
    return ($L -join "`r`n`r`n")
}

function Get-SignificadoCodigoInstalacao {
    # Pura: significado dos códigos de erro mais comuns no log de instalação de drivers (setupapi).
    param([string]$Codigo)
    switch -Regex ("$Codigo".ToLower()) {
        '^0x0*103$' { return 'nenhum dispositivo compatível com o pacote foi encontrado neste computador, ou o driver já estava instalado' }
        '^0x0*50$'  { return 'o pacote já existia no repositório de drivers (arquivo já presente)' }
        '^0x0*5$'   { return 'acesso negado: faltou permissão de administrador ou o arquivo estava em uso' }
        '^0x0*2$'   { return 'arquivo não encontrado: o instalador apontou para um arquivo que não existe' }
        '^0x0*57$'  { return 'parâmetro inválido enviado ao instalador' }
        '^0x0*32$'  { return 'a operação não é suportada por este tipo de pacote ou dispositivo' }
        default     { return 'código sem descrição pronta; procure o código no log C:\Windows\INF\setupapi.dev.log' }
    }
}

function Get-ExplicacaoDriverCaso {
    # Pura. Situacao: antigo | generico | semAssinatura | erro | falhaIniciar | falhaInstalar | pacote.
    param([string]$Situacao, [string]$Classe = '', [string]$Nome = '', [string]$Provedor = '', [string]$Versao = '', $Data = $null, [string]$Codigo = '', [int]$Tentativas = 0, [datetime]$Agora = (Get-Date))
    $L = New-Object System.Collections.Generic.List[string]
    $c = "$Classe".ToUpper()
    $critica = ($c -in 'DISPLAY', 'NET', 'HDC', 'SCSIADAPTER', 'DISKDRIVE')
    $quem = "$Nome"; if ($Provedor) { $quem += " (fabricante: $Provedor)" }
    $ver = ''; if ($Versao) { $ver = "versão $Versao" }
    $dtx = ''
    if ($Data -is [datetime]) { $dtx = ('de {0}, {1}' -f $Data.ToString('dd/MM/yyyy'), (Get-IdadeTexto $Data $Agora)) }
    $info = @($ver, $dtx | Where-Object { $_ }) -join ' ' 
    $L.Add(('Neste computador: {0}{1}.' -f $quem, $(if ($info) { ', ' + $info } else { '' })))
    switch ($Situacao) {
        'antigo' {
            if ($critica) { $L.Add('Preciso me preocupar? Um pouco. Este tipo de driver (vídeo, rede ou armazenamento) recebe correções de estabilidade e segurança com frequência, e um muito antigo pode perder desempenho ou causar instabilidade com programas novos. Se tudo funciona bem, não é urgente.') }
            else { $L.Add('Preciso me preocupar? Em geral não. Drivers de som, câmera, impressora e dispositivos virtuais mudam pouco; se o aparelho funciona, a data antiga sozinha não é problema.') }
            $L.Add('O que fazer: abra Ferramentas > Drivers > "Instalar drivers pelo Windows Update" (cria ponto de restauração antes). Se não houver versão nova lá, use "Baixar drivers novos: abrir as páginas oficiais" e compare a versão instalada com a do site do fabricante. Só atualize se o dispositivo falha ou se a versão do site for bem mais nova.')
        }
        'generico' {
            $L.Add('Preciso me preocupar? Só se houver sintoma. O driver da Microsoft funciona, mas é básico: falta o painel do fabricante, recursos extras e, às vezes, desempenho ou estabilidade (quedas de Wi-Fi, áudio falhando, Bluetooth instável).')
            $L.Add('O que fazer: se tudo funciona, pode deixar assim. Se houver sintoma, use Ferramentas > Drivers > "Baixar drivers novos: abrir as páginas oficiais" e instale o do fabricante.')
        }
        'semAssinatura' {
            $L.Add('Preciso me preocupar? Sim, com cuidado. Driver sem assinatura digital válida não foi verificado pela Microsoft: pode ser de um programa legítimo antigo, mas também pode ser adulterado ou causar telas azuis.')
            $L.Add('O que fazer: confirme se você reconhece o programa que o instalou. Se reconhece e é de um fabricante conhecido, procure uma versão assinada no site dele. Se não reconhece, use Ferramentas > Drivers para restaurar o driver anterior ou voltar ao nativo do Windows.')
        }
        'erro' {
            $L.Add(('Preciso me preocupar? Depende do aparelho{0}. Um dispositivo com erro no Gerenciador de Dispositivos não funciona direito. Se você não usa esse aparelho (ou ele nem existe mais), pode ignorar.' -f $(if ($Codigo) { " (código $Codigo)" } else { '' })))
            $L.Add('O que fazer: use o botão "Corrigir automaticamente" para tentar reativar ou reinstalar o driver (com ponto de restauração). Se continuar com erro, instale o driver do fabricante pelas páginas oficiais em Ferramentas > Drivers.')
        }
        'falhaIniciar' {
            $L.Add('Preciso me preocupar? Só se o computador tiver sintomas (lentidão ao ligar, telas azuis, travamentos). Muitos drivers de sistema falham ao iniciar por serem resto de programa desinstalado, por dependerem de um recurso desligado (como virtualização) ou por pertencerem a um anticheat que só carrega com o jogo aberto.')
            $L.Add('O que fazer: se o computador está estável, ignore. Se o programa que instalou o driver ainda é usado, reinstale-o; se não é mais usado, desinstale o programa em Aplicativos e recursos.')
        }
        'falhaInstalar' {
            $sig = Get-SignificadoCodigoInstalacao $Codigo
            $L.Add(('O que o código {0} quer dizer: {1}.' -f $(if ($Codigo) { $Codigo } else { '?' }), $sig))
            $ok = ("$Codigo" -match '^0x0*(103|50)$')
            if ($ok) { $L.Add('Preciso me preocupar? Normalmente não. Esse código aparece quando o instalador tenta um pacote que não se aplica a este hardware ou que já estava presente. Só importa se o dispositivo correspondente não funciona.') }
            else { $L.Add('Preciso me preocupar? Só se o dispositivo correspondente não funciona. Uma tentativa isolada que falhou, com o aparelho funcionando, costuma ser inofensiva.') }
            $L.Add('O que fazer: se o aparelho funciona, ignore. Se não funciona, instale o driver do fabricante (Ferramentas > Drivers > páginas oficiais) com o programa de instalação completo, aberto como administrador.')
        }
        'pacote' {
            $L.Add('Preciso me preocupar? Um pouco. O pacote deste driver está danificado no repositório do Windows, então o Windows não consegue reinstalar nem atualizar o driver desse aparelho a partir dele. O aparelho pode continuar funcionando com o driver já carregado.')
            $L.Add('O que fazer: a correção sugerida guarda uma cópia do pacote, remove-o e deixa o Windows voltar ao driver nativo ou ao do Windows Update. Se você usa o aparelho, reinstale depois o pacote completo do fabricante.')
        }
        default { }
    }
    return ($L -join "`r`n`r`n")
}

$script:ScannerEventosOk = $null  # $null = não tentado ainda; $true/$false = resultado
function Initialize-ScannerEventos {
    # Compila, uma única vez, um leitor de Log de Eventos em C# (System.Diagnostics.Eventing.Reader) que lê
    # cada log citado nas regras em UMA passagem, em vez de uma consulta Get-WinEvent por regra (hoje até 9
    # consultas separadas ao log System). Mesma origem de dados (o próprio Log de Eventos do Windows), só que
    # lida uma vez só: mais rápido e permite olhar mais eventos no mesmo tempo.
    # Só existe no Windows. Se falhar por qualquer motivo (inclusive no Linux, onde a classe nem existe), o
    # código volta sozinho ao Get-WinEvent de sempre — nenhum comportamento muda, só a velocidade.
    if ($null -ne $script:ScannerEventosOk) { return $script:ScannerEventosOk }
    if ($env:OS -ne 'Windows_NT') { $script:ScannerEventosOk = $false; return $false }
    try {
        if (-not ('WinDiagNativo.ScannerEventos' -as [type])) {
            Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;

namespace WinDiagNativo {
    public class RegistroEvento {
        public int Id;
        public string ProviderName;
        public int Level;
        public DateTime TimeCreated;
        public string Message;
    }

    public static class ScannerEventos {
        // Lê um log do Windows inteiro em uma única passagem, do mais recente para o mais antigo, dentro do
        // período pedido. O filtro por provedor/ID/nível de cada regra é aplicado depois, no PowerShell,
        // sobre essa mesma leitura — exatamente como o Get-WinEvent já fazia por regra, só que sem repetir
        // a consulta ao serviço do Log de Eventos para cada regra do mesmo log.
        public static List<RegistroEvento> Ler(string nomeLog, DateTime inicio, int maximo) {
            var r = new List<RegistroEvento>();
            string xpath = string.Format(
                "*[System[TimeCreated[@SystemTime>='{0}']]]",
                inicio.ToUniversalTime().ToString("o"));
            var consulta = new EventLogQuery(nomeLog, PathType.LogName, xpath);
            consulta.ReverseDirection = true;
            using (var leitor = new EventLogReader(consulta)) {
                EventRecord ev;
                while (r.Count < maximo && (ev = leitor.ReadEvent()) != null) {
                    using (ev) {
                        string msg;
                        try { msg = ev.FormatDescription(); } catch { msg = null; }
                        r.Add(new RegistroEvento {
                            Id = ev.Id.HasValue ? ev.Id.Value : 0,
                            ProviderName = ev.ProviderName,
                            Level = ev.Level.HasValue ? ev.Level.Value : 0,
                            TimeCreated = ev.TimeCreated.HasValue ? ev.TimeCreated.Value : DateTime.MinValue,
                            Message = msg
                        });
                    }
                }
            }
            return r;
        }
    }
}
'@ -ErrorAction Stop
        }
        $script:ScannerEventosOk = $true
    } catch {
        Write-Host "  (Leitor rápido de eventos indisponível, usando o modo padrão: $($_.Exception.Message))" -ForegroundColor DarkGray
        $script:ScannerEventosOk = $false
    }
    return $script:ScannerEventosOk
}

function Get-EventosLogUnico {
    # Lê um log inteiro de uma vez com o scanner em C# e devolve objetos com as mesmas propriedades que o
    # resto do código já espera de Get-WinEvent (Id, ProviderName, Level, TimeCreated, Message).
    param([string]$NomeLog, [datetime]$Inicio, [int]$Maximo = 4000)
    $brutos = [WinDiagNativo.ScannerEventos]::Ler($NomeLog, $Inicio, $Maximo)
    return @($brutos | ForEach-Object {
        [pscustomobject]@{ Id = $_.Id; ProviderName = $_.ProviderName; Level = $_.Level; TimeCreated = $_.TimeCreated; Message = $_.Message }
    })
}

function Invoke-AnaliseEventos {
    Write-Titulo "3) HISTÓRICO DE EVENTOS (últimos $DiasEventos dias)"
    $inicio = (Get-Date).AddDays(-$DiasEventos)
    $resumo = New-Object System.Collections.Generic.List[object]

    # Com o leitor rápido disponível, cada log citado nas regras é lido uma única vez e reaproveitado por
    # todas as regras daquele log (ex.: as 9 regras do log System viram 1 leitura, não 9).
    $script:CacheLogEventos = @{}
    if (Initialize-ScannerEventos) {
        foreach ($nomeLog in @($script:RegrasEventos | ForEach-Object { $_.Log } | Select-Object -Unique)) {
            try { $script:CacheLogEventos[$nomeLog] = Get-EventosLogUnico -NomeLog $nomeLog -Inicio $inicio } catch { }
        }
    }

    foreach ($r in $script:RegrasEventos) {
        try {
            $eventos = @()
            if ($script:CacheLogEventos.ContainsKey($r.Log)) {
                $eventos = @($script:CacheLogEventos[$r.Log] | Where-Object {
                    ((-not $r.Provedores) -or ($r.Provedores -contains $_.ProviderName)) -and
                    ((-not $r.Ids)        -or ($r.Ids -contains $_.Id)) -and
                    ((-not $r.Niveis)     -or ($r.Niveis -contains $_.Level))
                } | Select-Object -First 500)
            } else {
                # Leitor rápido indisponível (ou falhou para este log): volta ao Get-WinEvent de sempre.
                $filtro = @{ LogName = $r.Log; StartTime = $inicio }
                if ($r.Provedores) { $filtro['ProviderName'] = $r.Provedores }
                if ($r.Ids)        { $filtro['Id'] = $r.Ids }
                if ($r.Niveis)     { $filtro['Level'] = $r.Niveis }
                try {
                    $eventos = @(Get-WinEvent -FilterHashtable $filtro -MaxEvents 500 -ErrorAction Stop)
                } catch {
                    if ("$($_.FullyQualifiedErrorId)" -match 'NoMatchingEventsFound' -or "$($_.Exception.Message)" -match 'No events were found') {
                        $eventos = @()
                    } else {
                        # A consulta filtrada falhou (ex.: 'Parâmetro incorreto'): refaz filtrando dentro do PowerShell.
                        try {
                            $todos = @(Get-WinEvent -FilterHashtable @{ LogName = $r.Log; StartTime = $inicio } -MaxEvents 5000 -ErrorAction Stop)
                            $eventos = @($todos | Where-Object {
                                ((-not $r.Provedores) -or ($r.Provedores -contains $_.ProviderName)) -and
                                ((-not $r.Ids)        -or ($r.Ids -contains $_.Id)) -and
                                ((-not $r.Niveis)     -or ($r.Niveis -contains $_.Level))
                            } | Select-Object -First 500)
                        } catch { $eventos = @() }
                    }
                }
            }
            if ($eventos.Count -eq 0) { continue }

            $total  = if ($eventos.Count -ge 500) { '500+' } else { "$($eventos.Count)" }
            $ultimo = $eventos[0].TimeCreated

            if ($r.Bugcheck) {
                $codigos = @(foreach ($e in $eventos) {
                    $m = [regex]::Match((Get-MensagemEvento $e), '0x[0-9A-Fa-f]{8}')
                    if ($m.Success) { '0x' + $m.Value.Substring(2).ToUpper() }
                })
                $partes = @($codigos | Group-Object | Sort-Object Count -Descending | Select-Object -First 4 | ForEach-Object {
                    '{0} {1} (x{2})' -f $_.Name, (Get-DescricaoBugcheck $_.Name), $_.Count
                })
                $detalhe = "Última em $($ultimo.ToString('yyyy-MM-dd HH:mm')). " + ($partes -join ' | ')
            } else {
                $partes = @($eventos | Group-Object Id | Sort-Object Count -Descending | Select-Object -First 3 | ForEach-Object {
                    $amostra = ((Get-MensagemEvento $_.Group[0]) -split '\r?\n')[0]
                    if ($amostra.Length -gt 220) { $amostra = $amostra.Substring(0, 220) + '...' }
                    'ID {0} x{1}: {2}' -f $_.Name, $_.Count, $amostra
                })
                $detalhe = "Última em $($ultimo.ToString('yyyy-MM-dd HH:mm')). " + ($partes -join ' | ')
                try {
                    if ($r.Nome -like 'Desligamentos inesperados*') { $detalhe += ' | ' + (Get-ResumoQuedas $eventos) }
                    elseif ($r.Nome -like '*(WHEA)') { $detalhe += ' | ' + (Get-ResumoWhea $eventos) }
                } catch { }
            }

            $expEv = $script:ExplicacaoEventos[$r.Nome]
            $vedEv = $(if ($expEv) { $expEv.Veredito } else { '' })
            # Um evento isolado (no máximo 1 ocorrência) com mais de 7 dias, já recuperado, é histórico e não pede ação.
            if ($eventos.Count -le 1 -and $ultimo -lt (Get-Date).AddDays(-7)) { $vedEv = 'Normal' }
            # Explicação detalhada: o texto geral do tipo de evento + o caso deste computador (contagens, códigos, se importa e o que fazer).
            $caso = ''
            try {
                $idsEv = @{}; foreach ($g in ($eventos | Group-Object Id)) { $idsEv["$($g.Name)"] = $g.Count }
                $janEv = 30; try { if ($global:DiasEventos) { $janEv = [int]$global:DiasEventos } } catch { }
                $caso = Get-ExplicacaoEventoCaso -Nome $r.Nome -Datas @($eventos | ForEach-Object { $_.TimeCreated }) -Ids $idsEv -Solucao "$($r.Solucao)" -Gravidade "$($r.Gravidade)" -DiasJanela $janEv
            } catch { }
            if ($expEv) {
                $txtEv = $expEv.Texto; if ($caso) { $txtEv = $txtEv + "`r`n`r`n" + $caso }
                Add-Achado -Gravidade $r.Gravidade -Categoria 'Eventos' -Titulo "$($r.Nome): $total ocorrência(s)" -Detalhe $detalhe -Solucao $r.Solucao -Explicacao $txtEv -Veredito $vedEv
            } else {
                Add-Achado -Gravidade $r.Gravidade -Categoria 'Eventos' -Titulo "$($r.Nome): $total ocorrência(s)" -Detalhe $detalhe -Solucao $r.Solucao -Explicacao $caso -Veredito $vedEv
            }
            $resumo.Add([pscustomobject]@{
                Regra       = $r.Nome
                Gravidade   = $r.Gravidade
                Ocorrencias = $total
                Ultima      = $ultimo.ToString('yyyy-MM-dd HH:mm')
                Detalhe     = $detalhe
            })
        } catch {
            # Uma regra com problema não pode derrubar as outras.
            Write-Host "  Não consegui analisar '$($r.Nome)': $($_.Exception.Message)" -ForegroundColor DarkGray
        }
    }

    # Arquivos de despejo de memória (telas azuis)
    $dumps = @(Get-ChildItem -Path (Join-Path $env:windir 'Minidump') -Filter '*.dmp' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($dumps.Count -gt 0) {
        $ultimos = ($dumps | Select-Object -First 3 | ForEach-Object { "$($_.Name) ($($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" }) -join '; '
        Add-Achado -Gravidade Info -Categoria 'Eventos' -Titulo "$($dumps.Count) arquivo(s) de despejo de tela azul em C:\Windows\Minidump" `
            -Detalhe "Mais recentes: $ultimos" `
            -Solucao 'Abra o dump no WinDbg (Microsoft Store) e rode !analyze -v para ver o driver responsável.'
    }

    if ($resumo.Count -eq 0) {
        Write-Host "  Nenhum evento relevante nos últimos $DiasEventos dias." -ForegroundColor Green
    }
    $script:Dados['Eventos'] = $resumo.ToArray()
}

# ----------------------------------------------------------------------------
# 4) Drivers
# ----------------------------------------------------------------------------
function Get-FalhasInstalacaoDriver {
    $arquivo = Join-Path $env:windir 'INF\setupapi.dev.log'
    if (-not (Test-Path $arquivo)) { return @() }
    $limite = (Get-Date).AddDays(-$DiasEventos)
    $alvo = $null; $quando = $null
    $falhas = New-Object System.Collections.Generic.List[object]
    foreach ($linha in (Get-Content -Path $arquivo -Tail 8000 -ErrorAction SilentlyContinue)) {
        if ($linha -match '^>>>\s+\[(?<t>.+)\]\s*$') {
            $alvo = $matches['t']; $quando = $null
        } elseif ($linha -match '^>>>\s+Section start\s+(?<d>\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})') {
            try { $quando = [datetime]::ParseExact($matches['d'], 'yyyy/MM/dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture) } catch { $quando = $null }
        } elseif ($linha -match '^<<<\s+\[Exit status:\s*FAILURE(?:\((?<c>0x[0-9A-Fa-f]+)\))?') {
            if ($alvo -and $quando -and $quando -ge $limite) {
                $falhas.Add([pscustomobject]@{ Quando = $quando; Alvo = $alvo; Codigo = $matches['c'] })
            }
        }
    }
    return $falhas.ToArray()
}

function Get-AtualizacoesDriverWU {
    # A consulta roda em um job com tempo limite, porque o Windows Update às vezes trava.
    $job = Start-Job -ScriptBlock {
        try {
            $sessao = New-Object -ComObject Microsoft.Update.Session
            $res = $sessao.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
            $lista = @()
            for ($i = 0; $i -lt $res.Updates.Count; $i++) {
                $u = $res.Updates.Item($i)
                $dataDrv = ''
                try { if ($u.DriverVerDate) { $dataDrv = ([datetime]$u.DriverVerDate).ToString('yyyy-MM-dd') } } catch { }
                $lista += [pscustomobject]@{
                    Titulo     = "$($u.Title)"
                    Fabricante = "$($u.DriverManufacturer)"
                    Modelo     = "$($u.DriverModel)"
                    Classe     = "$($u.DriverClass)"
                    Data       = $dataDrv
                    HardwareId = "$($u.DriverHardwareID)"
                }
            }
            [pscustomobject]@{ Erro = $null; Itens = $lista }
        } catch {
            [pscustomobject]@{ Erro = $_.Exception.Message; Itens = @() }
        }
    }
    if (-not (Wait-Job -Job $job -Timeout 240)) {
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        return @{ Erro = 'o Windows Update não respondeu em 4 minutos'; Itens = @() }
    }
    $r = @(Receive-Job -Job $job)[0]
    Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    if (-not $r) { return @{ Erro = 'resposta vazia do Windows Update'; Itens = @() } }
    return @{ Erro = $r.Erro; Itens = @($r.Itens) }
}

function Install-DriversWU {
    Write-Host '    Buscando os drivers pendentes no Windows Update...' -ForegroundColor DarkGray
    $sessao = New-Object -ComObject Microsoft.Update.Session
    $res = $sessao.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
    $ups = @()
    for ($i = 0; $i -lt $res.Updates.Count; $i++) { $ups += $res.Updates.Item($i) }
    if ($ups.Count -eq 0) { Write-Host '    Nenhum driver pendente no momento.' -ForegroundColor Green; return }

    for ($i = 0; $i -lt $ups.Count; $i++) {
        Write-Host ('    [{0}] {1}' -f ($i + 1), $ups[$i].Title)
    }
    # No modo "corrigir tudo automaticamente" (worker com AceitarTudo) ninguém está digitando: pedir a
    # resposta por Read-Resposta cai sempre em "Enter" (cancelar) e o driver nunca é instalado, mesmo
    # clicando em corrigir. Nesse modo, instala todos os pendentes direto, sem perguntar.
    $auto = $false
    try { $auto = [bool]$global:WD_Opc.AceitarTudo } catch { $auto = $false }
    if ($auto) {
        Write-Host '    Modo automático: instalando todos os pendentes.' -ForegroundColor DarkGray
        $indices = 0..($ups.Count - 1)
    } else {
        $sel = Read-Resposta '    Instalar quais? (todos / números separados por vírgula / Enter para cancelar)'
        if ([string]::IsNullOrWhiteSpace($sel)) { Write-Host '    Cancelado.'; return }

        $indices = @()
        if ($sel -match '^\s*(t|todos|a|all)\s*$') {
            $indices = 0..($ups.Count - 1)
        } else {
            foreach ($p in ($sel -split '[,; ]+')) {
                $n = 0
                if ([int]::TryParse($p, [ref]$n) -and $n -ge 1 -and $n -le $ups.Count) { $indices += ($n - 1) }
            }
        }
        $indices = @($indices | Select-Object -Unique)
    }
    if ($indices.Count -eq 0) { Write-Host '    Nenhuma seleção válida.' -ForegroundColor Yellow; return }

    $colecao = New-Object -ComObject Microsoft.Update.UpdateColl
    foreach ($idx in $indices) {
        $u = $ups[$idx]
        if (-not $u.EulaAccepted) { $u.AcceptEula() }
        [void]$colecao.Add($u)
    }
    $baixador = $sessao.CreateUpdateDownloader()
    $baixador.Updates = $colecao
    Write-Host '    Baixando...'
    $rb = $baixador.Download()
    if ($rb.ResultCode -ne 2) { Write-Host "    Falha no download (código $($rb.ResultCode))." -ForegroundColor Red; return }

    $instalador = $sessao.CreateUpdateInstaller()
    $instalador.Updates = $colecao
    Write-Host '    Instalando...'
    $ri = $instalador.Install()
    $texto = switch ([int]$ri.ResultCode) { 2 { 'concluída com sucesso' } 3 { 'concluída com erros' } 4 { 'falhou' } default { "código $($ri.ResultCode)" } }
    Write-Host "    Instalação $texto." -ForegroundColor Green
    if ($ri.RebootRequired) { Write-Host '    É necessário reiniciar o computador.' -ForegroundColor Yellow }
}

function Install-AtualizacoesWU {
    # Busca e instala as atualizações de segurança/qualidade pelo Windows Update (API COM), sem abrir as Configurações.
    # Não instala drivers (outra ação) nem upgrades de versão do Windows (ex.: Windows 10 -> 11): esses o usuário decide.
    # Devolve $true se concluiu a busca (mesmo sem nada a instalar); $false se o serviço não respondeu (aí o chamador abre as Configurações).
    Write-Host '    Buscando atualizações no Windows Update (pode levar alguns minutos)...' -ForegroundColor DarkGray
    $idUpgrades = '3689bdc8-b205-4af4-8d4a-a63924c5e9d5'
    try {
        $sessao = New-Object -ComObject Microsoft.Update.Session
        $res = $sessao.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Software' and IsHidden=0")
    } catch {
        Write-Host "    Não consegui consultar o Windows Update: $($_.Exception.Message)" -ForegroundColor Yellow
        Add-Alteracao -Acao 'Atualizações do Windows Update' -Resultado "falhou ao consultar: $($_.Exception.Message)"
        return $false
    }
    $colecao = New-Object -ComObject Microsoft.Update.UpdateColl
    $upgrades = 0
    for ($i = 0; $i -lt $res.Updates.Count; $i++) {
        $u = $res.Updates.Item($i)
        $ehUpgrade = $false
        for ($c = 0; $c -lt $u.Categories.Count; $c++) { if ("$($u.Categories.Item($c).CategoryID)" -eq $idUpgrades) { $ehUpgrade = $true } }
        if ($ehUpgrade) { $upgrades++; Write-Host "    (não instalo automaticamente, é troca de versão do Windows: $($u.Title))" -ForegroundColor DarkGray; continue }
        Write-Host "    - $($u.Title)"
        if (-not $u.EulaAccepted) { $u.AcceptEula() }
        [void]$colecao.Add($u)
    }
    if ($colecao.Count -eq 0) {
        Write-Host '    Nenhuma atualização de segurança ou qualidade pendente.' -ForegroundColor Green
        return $true
    }
    Write-Host '    Baixando...'
    $baixador = $sessao.CreateUpdateDownloader(); $baixador.Updates = $colecao
    $rb = $baixador.Download()
    if ($rb.ResultCode -ne 2) { Write-Host "    Falha no download (código $($rb.ResultCode))." -ForegroundColor Red; return $true }
    Write-Host '    Instalando...'
    $instalador = $sessao.CreateUpdateInstaller(); $instalador.Updates = $colecao
    $ri = $instalador.Install()
    $texto = switch ([int]$ri.ResultCode) { 2 { 'concluída com sucesso' } 3 { 'concluída com erros' } 4 { 'falhou' } default { "código $($ri.ResultCode)" } }
    Write-Host "    Instalação $texto." -ForegroundColor Green
    Add-Alteracao -Acao 'Atualizações do Windows Update' -Resultado $texto
    if ($ri.RebootRequired) { Write-Host '    É necessário reiniciar o computador para concluir.' -ForegroundColor Yellow }
    return $true
}

function Invoke-AnaliseDrivers {
    Write-Titulo '4) DRIVERS'
    Write-Host '  Lendo dispositivos e drivers (pode levar até um minuto)...' -ForegroundColor DarkGray
    $pnp       = @(Get-PnPCache)
    $assinados = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue)
    $script:CacheAssinados = $assinados
    $classesProtegidas = 'DiskDrive', 'SCSIAdapter', 'HDC', 'System', 'Processor', 'Computer', 'Volume', 'VolumeSnapshot', 'Battery', 'Firmware'
    $classesCriticas   = 'Display', 'Net', 'HDC', 'SCSIAdapter', 'DiskDrive'

    # --- A) O que o Windows já sinaliza (com explicação, links e correção) -------
    Write-Host ''
    Write-Host '  A) Dispositivos com erro no Gerenciador de Dispositivos' -ForegroundColor White
    $comErro = @($pnp | Where-Object { [int]$_.ConfigManagerErrorCode -ne 0 })
    $listaErro = New-Object System.Collections.Generic.List[object]
    if ($comErro.Count -eq 0) { Write-Host '     Nenhum.' -ForegroundColor Green }
    foreach ($b in $comErro) {
        $codigo = [int]$b.ConfigManagerErrorCode
        $desc   = if ($script:CodigosPnP.ContainsKey($codigo)) { $script:CodigosPnP[$codigo] } else { 'Erro desconhecido' }
        $nome   = if ($b.Name) { $b.Name } else { $b.PNPDeviceID }
        $hw     = @($b.HardwareID)[0]
        $grav   = if ($codigo -eq 22) { 'Info' } elseif ($b.PNPClass -in $classesCriticas) { 'Critico' } else { 'Atencao' }
        Add-Achado -Gravidade $grav -Categoria 'Driver' -Titulo "$nome (código $codigo - $desc)" `
            -Detalhe "ID: $($b.PNPDeviceID)" -Solucao (Get-SolucaoCodigo $codigo) `
            -Explicacao ((Get-ExplicacaoClasseDriver -Classe "$($b.PNPClass)" -Nome "$nome") + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'erro' -Classe "$($b.PNPClass)" -Nome "$nome" -Codigo "$codigo")) -Veredito $(if ($grav -eq 'Info') { 'Normal' } else { 'Corrigir' }) `
            -Links @(Get-LinksDriver -HardwareId $hw -InstanceId $b.PNPDeviceID)
        $listaErro.Add([pscustomobject]@{ Dispositivo = $nome; Classe = "$($b.PNPClass)"; Codigo = $codigo; Descricao = $desc; Id = $b.PNPDeviceID })

        if ($codigo -ne 22) {
            try { Add-AcoesRestauracao -Nome $nome -InstanceId $b.PNPDeviceID -HardwareIds @($b.HardwareID) -Classe "$($b.PNPClass)" }
            catch { Write-Host "     (Restauração não avaliada para '$nome': $($_.Exception.Message))" -ForegroundColor DarkGray }
        }

        if ($codigo -eq 22) {
            Add-Acao -Descricao "Reativar o dispositivo '$nome'" -Protecao -Arg $b.PNPDeviceID -Acao {
                param($id)
                Enable-PnpDevice -InstanceId $id -Confirm:$false -ErrorAction Stop
                Write-Host '    Dispositivo reativado.' -ForegroundColor Green
            }
        } elseif ($b.PNPClass -notin $classesProtegidas) {
            Add-Acao -Descricao "Reinstalar o driver de '$nome' (remove o dispositivo e pede ao Windows para reinstalar)" -Protecao -MudaDriver -Arg $b.PNPDeviceID -Acao {
                param($id)
                if ([int]$script:Sistema.Build -ge 19041) { pnputil /remove-device "$id" | Out-Host }
                pnputil /scan-devices | Out-Host
                Write-Host '    Se o dispositivo ficar sem driver, instale o pacote do fabricante (links no relatório).' -ForegroundColor DarkGray
            }
        }
    }
    $script:Dados['DispositivosComErro'] = $listaErro.ToArray()

    # --- B) O que o Windows NÃO sinaliza ------------------------------------------
    Write-Host ''
    Write-Host '  B) Problemas que o Windows não sinaliza' -ForegroundColor White
    $achouB = $false

    # B1) Driver de vídeo genérico (sem aceleração) mesmo com GPU presente
    foreach ($x in ($assinados | Where-Object { $_.DeviceClass -eq 'DISPLAY' -and $_.DeviceName -match 'Basic Display|v.deo b.sico|Basic Render' })) {
        $achouB = $true
        $hw = @($x.HardWareID)[0]
        Add-Achado -Gravidade Atencao -Categoria 'Driver' -Titulo "Vídeo usando driver genérico da Microsoft: $($x.DeviceName)" `
            -Detalhe 'Sem o driver do fabricante da GPU você perde aceleração 3D, resoluções e economia de energia. O Windows não marca isso como erro.' `
            -Solucao 'Instale o driver do fabricante da GPU (links abaixo).' `
            -Explicacao ((Get-ExplicacaoClasseDriver -Classe 'DISPLAY' -Nome "$($x.DeviceName)") + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'generico' -Classe 'DISPLAY' -Nome "$($x.DeviceName)" -Provedor "$($x.DriverProviderName)" -Versao "$($x.DriverVersion)" -Data $x.DriverDate)) -Veredito 'Corrigir' `
            -Links @(Get-LinksDriver -HardwareId $hw -InstanceId $x.DeviceID)
    }

    # B2) Drivers de rede/áudio/Bluetooth de fabricante conhecido rodando com driver genérico da Microsoft
    $genericos = @($assinados | Where-Object {
        $_.DeviceName -and $_.DriverProviderName -eq 'Microsoft' -and
        $_.DeviceClass -in 'NET', 'MEDIA', 'BLUETOOTH' -and
        (@($_.HardWareID)[0] -match '^(PCI|USB|HDAUDIO)\\.*VEN_(8086|10EC|14E4|168C|17CB)|^USB\\VID_(0BDA|8087)')
    } | Sort-Object DeviceName -Unique | Select-Object -First 10)
    foreach ($x in $genericos) {
        $achouB = $true
        $hw = @($x.HardWareID)[0]
        Add-Achado -Gravidade Info -Categoria 'Driver' -Titulo "Usando driver padrão da Microsoft: $($x.DeviceName)" `
            -Detalhe 'Funciona, mas o driver do fabricante costuma trazer correções de estabilidade, desempenho e recursos extras.' `
            -Solucao 'Se houver instabilidade (queda de Wi-Fi, áudio falhando, Bluetooth), instale o driver do fabricante.' `
            -Explicacao ((Get-ExplicacaoClasseDriver -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)") + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'generico' -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)" -Provedor "$($x.DriverProviderName)" -Versao "$($x.DriverVersion)" -Data $x.DriverDate)) -Veredito 'Opcional' `
            -Links @(Get-LinksDriver -HardwareId $hw -InstanceId $x.DeviceID)
    }

    # B3) Drivers sem assinatura digital válida
    $naoAssinados = @($assinados | Where-Object { $_.DeviceName -and $_.IsSigned -eq $false } | Sort-Object DeviceName -Unique | Select-Object -First 15)
    foreach ($x in $naoAssinados) {
        $achouB = $true
        $hw = @($x.HardWareID)[0]
        Add-Achado -Gravidade Atencao -Categoria 'Driver' -Titulo "Driver sem assinatura digital: $($x.DeviceName)" `
            -Detalhe "Provedor: $($x.DriverProviderName) | versão $($x.DriverVersion)" `
            -Solucao 'Drivers sem assinatura podem ser bloqueados, causar telas azuis ou ser adulterados. Prefira a versão oficial assinada.' `
            -Explicacao ((Get-ExplicacaoClasseDriver -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)") + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'semAssinatura' -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)" -Provedor "$($x.DriverProviderName)" -Versao "$($x.DriverVersion)" -Data $x.DriverDate)) -Veredito 'Depende' `
            -Links @(Get-LinksDriver -HardwareId $hw -InstanceId $x.DeviceID)
        try { Add-AcoesRestauracao -Nome "$($x.DeviceName)" -InstanceId "$($x.DeviceID)" -HardwareIds @($x.HardWareID) -Classe "$($x.DeviceClass)" } catch { }
    }

    # B4) Drivers de terceiros antigos em classes críticas (drivers nativos da Microsoft são ignorados)
    $classesChave = 'DISPLAY', 'NET', 'MEDIA', 'BLUETOOTH', 'HDC', 'SCSIADAPTER', 'IMAGE', 'CAMERA'
    $limiteVideo = (Get-Date).AddYears(-2)
    $limiteGeral = (Get-Date).AddYears(-3)
    $antigos = @($assinados | Where-Object {
        $_.DeviceName -and $_.DriverDate -and $_.DriverProviderName -and $_.DriverProviderName -ne 'Microsoft' -and
        $_.DeviceClass -in $classesChave -and
        (($_.DeviceClass -eq 'DISPLAY' -and $_.DriverDate -lt $limiteVideo) -or $_.DriverDate -lt $limiteGeral)
    } | Sort-Object DeviceName -Unique | Select-Object -First 15)
    foreach ($x in $antigos) {
        $achouB = $true
        $hw = @($x.HardWareID)[0]
        $grav = if ($x.DeviceClass -eq 'DISPLAY') { 'Atencao' } else { 'Info' }
        Add-Achado -Gravidade $grav -Categoria 'Driver' -Titulo "Driver antigo ($($x.DriverDate.ToString('yyyy-MM-dd'))): $($x.DeviceName)" `
            -Detalhe "Provedor: $($x.DriverProviderName) | versão $($x.DriverVersion)" `
            -Solucao 'Verifique no site do fabricante se existe versão mais nova (correções de segurança e estabilidade).' `
            -Explicacao ((Get-ExplicacaoClasseDriver -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)") + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'antigo' -Classe "$($x.DeviceClass)" -Nome "$($x.DeviceName)" -Provedor "$($x.DriverProviderName)" -Versao "$($x.DriverVersion)" -Data $x.DriverDate)) -Veredito 'Opcional' `
            -Links @(Get-LinksDriver -HardwareId $hw -InstanceId $x.DeviceID)
    }

    # B5) Drivers de sistema que tentaram iniciar e falharam
    try {
    $falhos = @(Get-CimInstance Win32_SystemDriver -ErrorAction SilentlyContinue | Where-Object {
        -not $_.Started -and $_.StartMode -in 'Boot', 'System', 'Auto' -and
        $null -ne $_.ExitCode -and $_.ExitCode -notin 0, 1077
    } | Select-Object -First 15)
    foreach ($x in $falhos) {
        $achouB = $true
        $cod = [int]$x.ExitCode
        $expD = Get-ExplicacaoDriverSistema -Servico "$($x.Name)" -Arquivo "$($x.PathName)" -StartMode "$($x.StartMode)"
        Add-Achado -Gravidade Atencao -Categoria 'Driver' -Titulo "Driver de sistema falhou ao iniciar: $($x.DisplayName) [$($x.Name)]" `
            -Detalhe "Erro $cod - $(Get-TextoErroWin32 $cod). Arquivo: $($x.PathName)" `
            -Solucao 'Reinstale ou atualize o software/driver que instalou este componente; se for um driver antigo e sem uso, desinstale o programa correspondente.' `
            -Explicacao ($expD.Texto + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'falhaIniciar' -Nome "$($x.DisplayName)" -Codigo "Erro $cod")) -Veredito $expD.Veredito
    }

    } catch { Write-Host "     B5 ignorado: $($_.Exception.Message)" -ForegroundColor Yellow }

    # B6) Instalações de driver que falharam (log do Windows)
    try {
    $falhasInst = @(Get-FalhasInstalacaoDriver)
    if ($falhasInst.Count -gt 0) {
        $achouB = $true
        $grupos = @($falhasInst | Group-Object Alvo | Sort-Object { ($_.Group | Select-Object -Last 1).Quando } -Descending | Select-Object -First 8)
        foreach ($g in $grupos) {
            $ult = $g.Group | Select-Object -Last 1
            $hw = $null
            if ($g.Name -match '((?:PCI|USB|HDAUDIO|ACPI|BTH|HID)\\[^\s\]]+)') { $hw = $matches[1] }
            $soSemDispositivo = (@($g.Group | Where-Object { "$($_.Codigo)" -ne '0x00000103' }).Count -eq 0)
            $expInst = ''; $vedInst = ''
            if ($soSemDispositivo) {
                $expInst = 'Código 0x103 significa que o pacote não encontrou nenhum dispositivo compatível neste computador (ou o driver já estava instalado). É comum em instaladores de chipset e de impressora, que trazem drivers para vários modelos de uma vez. Não indica defeito e não há nada a corrigir.'
                $vedInst = 'Normal'
            }
            Add-Achado -Gravidade Info -Categoria 'Driver' -Titulo "Falha na instalação de driver: $($g.Name)" `
                -Detalhe "$($g.Count) tentativa(s); última em $($ult.Quando.ToString('yyyy-MM-dd HH:mm')) (código $($ult.Codigo)). Pode ser normal quando não existe driver para o dispositivo." `
                -Solucao 'Se o dispositivo não funciona, instale o driver do fabricante.' -Explicacao (($expInst + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'falhaInstalar' -Nome "$($g.Name)" -Codigo "$($ult.Codigo)" -Tentativas $g.Count)).Trim()) -Veredito $vedInst `
                -Links $(if ($hw) { @(Get-LinksDriver -HardwareId $hw) } else { @() })
        }
    }
    $script:Dados['FalhasInstalacaoDriver'] = @($falhasInst | ForEach-Object { [pscustomobject]@{ Quando = $_.Quando.ToString('yyyy-MM-dd HH:mm'); Alvo = $_.Alvo; Codigo = $_.Codigo } })

    } catch { Write-Host "     B6 ignorado: $($_.Exception.Message)" -ForegroundColor Yellow }

    if (-not $achouB) { Write-Host '     Nada suspeito encontrado.' -ForegroundColor Green }

    # --- C) Windows Update ---------------------------------------------------------
    Write-Host ''
    Write-Host '  C) Drivers pendentes no Windows Update' -ForegroundColor White
    $pendentes = New-Object System.Collections.Generic.List[object]
    if ($SemWindowsUpdate) {
        Write-Host '     Pulado (-SemWindowsUpdate).' -ForegroundColor DarkGray
    } else {
        try {
            Write-Host '     Consultando (até 4 minutos)...' -ForegroundColor DarkGray
            $wu = Get-AtualizacoesDriverWU
            if ($wu.Erro) {
                Write-Host "     Não foi possível consultar o Windows Update: $($wu.Erro)" -ForegroundColor Yellow
            } elseif (@($wu.Itens).Count -eq 0) {
                Write-Host '     Nenhum driver pendente.' -ForegroundColor Green
            } else {
                foreach ($u in $wu.Itens) { $pendentes.Add($u) }
                Add-Achado -Gravidade Atencao -Categoria 'Windows Update' -Titulo "$($pendentes.Count) atualização(ões) de driver disponível(is) no Windows Update" `
                    -Detalhe (($pendentes | Select-Object -First 5 | ForEach-Object { $_.Titulo }) -join ' | ') `
                    -Solucao 'Instale pela fase de reparo (você escolhe quais) ou em Configurações > Windows Update > Opções avançadas > Atualizações opcionais. Atenção: para a placa de vídeo, prefira o driver do fabricante.' `
                    -Explicacao ("Neste computador, o Windows Update oferece:`r`n" + ((@($pendentes.ToArray()) | ForEach-Object { '  - ' + $_.Titulo }) -join "`r`n") + "`r`n`r`nPreciso me preocupar? Não é urgente. Se algum item for um driver que o Telomera removeu por estar corrompido, ele volta aqui: é a versão limpa oferecida pela Microsoft.`r`n`r`nO que fazer: clique em Corrigir automaticamente para instalar. Para placa de vídeo, prefira o driver do fabricante.") -Veredito Corrigir
                Add-Acao -Descricao "Instalar drivers pendentes pelo Windows Update ($($pendentes.Count) disponível(is))" -Protecao -MudaDriver -Acao { Install-DriversWU }
            }
        } catch {
            Write-Host "     Etapa ignorada: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
    $script:Dados['DriversPendentesWindowsUpdate'] = $pendentes.ToArray()

    # --- D) Proteção do driver de vídeo --------------------------------------------
    try {
        Invoke-AnaliseProtecaoVideo -Assinados $assinados -Pnp $pnp
    } catch {
        Write-Host "     Etapa de proteção do vídeo ignorada: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    if ($script:ErroPacotes) {
        Write-Host "     (Não consegui ler o DriverStore: $($script:ErroPacotes). As ações de restauração ficam indisponíveis.)" -ForegroundColor DarkGray
    }

    # --- Tabela dos drivers principais -------------------------------------------
    $tabela = @($assinados | Where-Object { $_.DeviceName -and $_.DeviceClass -in $classesChave } | Sort-Object DeviceClass, DeviceName | ForEach-Object {
        [pscustomobject]@{
            Classe      = "$($_.DeviceClass)"
            Dispositivo = "$($_.DeviceName)"
            Provedor    = "$($_.DriverProviderName)"
            Versao      = "$($_.DriverVersion)"
            Data        = if ($_.DriverDate) { $_.DriverDate.ToString('yyyy-MM-dd') } else { 'n/d' }
            Assinado    = if ($null -eq $_.IsSigned) { 'n/d' } elseif ($_.IsSigned) { 'sim' } else { 'NÃO' }
        }
    })
    $script:Dados['DriversPrincipais'] = $tabela
    if ($tabela.Count -gt 0) {
        Write-Host ''
        Write-Host '  Drivers principais (vídeo, rede, áudio, Bluetooth, armazenamento, câmera):' -ForegroundColor White
        $tabela | Format-Table Classe, Dispositivo, Provedor, Versao, Data, Assinado -AutoSize | Out-String -Width 220 | Write-Host
    }
}

# ----------------------------------------------------------------------------
# Blindagem: leitura segura, etapas isoladas, pré-requisitos e trava de segurança
# ----------------------------------------------------------------------------
function Read-Resposta {
    # Read-Host que nunca derruba o script (ex.: sem console interativo = resposta vazia = "não").
    param([string]$Prompt)
    if ($script:Agendada) { return '' }   # verificação automática: nunca espera resposta
    try { return [string](Read-Host $Prompt) } catch { return '' }
}

function Invoke-Secao {
    # Executa uma etapa isolada: se ela falhar, o resto do diagnóstico continua.
    param([string]$Nome, [scriptblock]$Bloco)
    try {
        & $Bloco
    } catch {
        $msg = $_.Exception.Message
        Write-Host "  A etapa '$Nome' falhou e foi ignorada: $msg" -ForegroundColor Yellow
        Add-Achado -Gravidade Info -Categoria 'Telomera' -Titulo "A etapa '$Nome' não pôde ser concluída" `
            -Detalhe $msg -Solucao 'O restante do diagnóstico continuou normalmente. Se isso se repetir, abra uma issue anexando o arquivo de log.'
    }
}

function Test-Prerequisitos {
    if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
        Write-Host 'O PowerShell está em modo restrito (ConstrainedLanguage), normalmente por política da empresa ou escola.' -ForegroundColor Red
        Write-Host 'O Telomera não consegue rodar assim.' -ForegroundColor Red
        return $false
    }
    $build = 0
    try { $build = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).BuildNumber } catch { }
    if ($build -eq 0) {
        Write-Host 'Não consegui consultar o Windows via WMI. Tentando iniciar o serviço Winmgmt...' -ForegroundColor Yellow
        try {
            Start-Service -Name winmgmt -ErrorAction Stop
            Start-Sleep -Seconds 3
            $build = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).BuildNumber
        } catch {
            Write-Host "O WMI não responde: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host 'Em um prompt de administrador, tente: winmgmt /verifyrepository' -ForegroundColor Red
            return $false
        }
    }
    if ($build -lt 17763) {
        Write-Host "Windows build $build é anterior ao Windows 10 1809: algumas leituras e reparos podem falhar." -ForegroundColor Yellow
    }
    $ev = Get-Service -Name EventLog -ErrorAction SilentlyContinue
    if ($ev -and $ev.Status -ne 'Running') {
        Write-Host 'O serviço Log de Eventos do Windows não está em execução; a análise de eventos ficará vazia.' -ForegroundColor Yellow
    }
    try {
        $letra = ([IO.Path]::GetPathRoot($script:PastaRelatorioFinal)).TrimEnd('\').TrimEnd(':')
        $vol = Get-Volume -DriveLetter $letra -ErrorAction Stop
        if ($vol.SizeRemaining -lt 200MB) { Write-Host "Pouco espaço (menos de 200 MB) na unidade dos relatórios ($letra`:)." -ForegroundColor Yellow }
    } catch { }
    return $true
}

function Test-SeguroParaAlterar {
    # Antes de qualquer alteração: avisa sobre situações que costumam fazer instalações de driver e reparos falharem.
    $avisos = @()
    if (Test-RebootPendente) { $avisos += 'há uma reinicialização pendente (reinicie antes de reparar)' }
    try {
        $bat = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
        if ($bat.Count -gt 0 -and $bat[0].BatteryStatus -eq 1 -and [int]$bat[0].EstimatedChargeRemaining -lt 40) {
            $avisos += "o notebook está na bateria ($($bat[0].EstimatedChargeRemaining)%): conecte o carregador"
        }
    } catch { }
    $ocupado = @(Get-Process -Name TiWorker, TrustedInstaller -ErrorAction SilentlyContinue)
    if ($ocupado.Count -gt 0) { $avisos += 'o Windows está instalando atualizações neste momento' }

    if ($avisos.Count -eq 0) { return $true }
    Write-Host ''
    Write-Host '  Antes de alterar qualquer coisa, repare que:' -ForegroundColor Yellow
    foreach ($a in $avisos) { Write-Host "   - $a" -ForegroundColor Yellow }
    $r = Read-Resposta '  Continuar mesmo assim? [s/N]'
    return ($r -match '^\s*[sSyY]')
}

function Add-Alteracao {
    param([string]$Acao, [string]$Resultado)
    $quando = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $script:Alteracoes.Add([pscustomobject]@{
        Quando    = $quando
        Acao      = $Acao
        Resultado = $Resultado
    })
    # Histórico permanente de tudo que o WinDiag já mudou neste computador (WinDiag-Extras.ps1)
    if (Get-Command Save-LogAlteracao -ErrorAction SilentlyContinue) { Save-LogAlteracao -Acao $Acao -Resultado $Resultado -Quando $quando }
}

function Get-PnPCache {
    if ($null -eq $script:CachePnP) {
        $script:CachePnP = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue)
    }
    return $script:CachePnP
}

function ConvertTo-VersaoSegura {
    param($Texto)
    try { return [version]"$Texto" } catch { return $null }
}

function Get-IdGenerico {
    # PCI\VEN_10DE&DEV_1C82&SUBSYS_xxxx&REV_a1 -> PCI\VEN_10DE&DEV_1C82
    param([string]$Id)
    if (-not $Id) { return '' }
    $r = ($Id -split '&SUBSYS')[0]
    $r = ($r -split '&REV')[0]
    $r = ($r -split '&CC_')[0]
    return $r
}

function ConvertFrom-CodigoMonitor {
    param($Dados)
    if (-not $Dados) { return '' }
    $chars = @($Dados | Where-Object { $_ -ne 0 } | ForEach-Object { [char][int]$_ })
    return (-join $chars).Trim()
}

# ----------------------------------------------------------------------------
# 0b) Hardware
# ----------------------------------------------------------------------------
function Invoke-AnaliseHardware {
    Write-Titulo '0b) HARDWARE'
    $hw = [ordered]@{}
    $tiposMem = @{ 20 = 'DDR'; 21 = 'DDR2'; 24 = 'DDR3'; 26 = 'DDR4'; 27 = 'LPDDR'; 28 = 'LPDDR2'; 29 = 'LPDDR3'; 30 = 'LPDDR4'; 34 = 'DDR5'; 35 = 'LPDDR5' }

    # --- Processador ----------------------------------------------------------
    try {
        $cpus = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
        $tab = @(foreach ($c in $cpus) {
            [pscustomobject]@{
                Nome          = (("$($c.Name)") -replace '\s+', ' ').Trim()
                Nucleos       = $c.NumberOfCores
                Threads       = $c.NumberOfLogicalProcessors
                ClockMaxMHz   = $c.MaxClockSpeed
                CargaPct      = $c.LoadPercentage
                Virtualizacao = if ($c.VirtualizationFirmwareEnabled) { 'ativada' } else { 'desativada' }
            }
        })
        $hw['Processador'] = $tab
        Write-Host '  Processador' -ForegroundColor White
        $tab | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
    } catch { Write-Host "  Processador: leitura falhou ($($_.Exception.Message))" -ForegroundColor Yellow }

    try {
        $zonas = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop)
        $temps = @($zonas | ForEach-Object { [math]::Round(($_.CurrentTemperature / 10) - 273.15, 1) } | Where-Object { $_ -gt 0 -and $_ -lt 150 })
        if ($temps.Count -gt 0) {
            $maxT = ($temps | Measure-Object -Maximum).Maximum
            $hw['TemperaturaZonaTermicaC'] = $maxT
            Write-Host "  Temperatura (zona térmica ACPI; costuma NÃO refletir o processador, compare com o aplicativo da fabricante): $maxT °C"
            if ($maxT -ge 90) {
                Add-Achado -Gravidade Critico -Categoria 'Hardware' -Titulo "Zona térmica a $maxT °C" `
                    -Solucao 'Limpe as saídas de ar e o cooler, troque a pasta térmica e verifique o plano de energia.'
            } elseif ($maxT -ge 80) {
                Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Zona térmica a $maxT °C" `
                    -Solucao 'Temperatura alta em repouso/uso leve: verifique a ventilação e a poeira.'
            }
        }
    } catch { }

    # --- Memória RAM ----------------------------------------------------------
    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $arr  = @(Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue)
        $slots = 0
        foreach ($a in $arr) { $slots += [int]$a.MemoryDevices }
        $instaladoGB = 0.0
        foreach ($m in $mods) { $instaladoGB += [double]$m.Capacity / 1GB }
        $usavelGB = [double]$script:Sistema.MemoriaRAM_GB

        $nomesSlot = @($mods | ForEach-Object { "$($_.DeviceLocator)" })
        $slotsDup = (@($nomesSlot | Select-Object -Unique)).Count -lt $nomesSlot.Count
        $idxSlot = 0
        $tab = @(foreach ($m in $mods) {
            $tipo = [int]$m.SMBIOSMemoryType
            $idxSlot++
            [pscustomobject]@{
                Slot           = $(if ($slotsDup) { "Módulo $idxSlot" } else { "$($m.DeviceLocator)" })
                CapacidadeGB   = [math]::Round([double]$m.Capacity / 1GB, 1)
                Tipo           = if ($tiposMem.ContainsKey($tipo)) { $tiposMem[$tipo] } else { "tipo $tipo" }
                NominalMHz     = $m.Speed
                ConfiguradaMHz = $m.ConfiguredClockSpeed
                Fabricante     = ("$($m.Manufacturer)").Trim()
            }
        })
        $hw['Memoria'] = $tab
        $hw['MemoriaSlots'] = $slots
        Write-Host ("  Memória: {0} módulo(s), {1} GB instalados, {2} GB utilizáveis, {3} slot(s)" -f $mods.Count, [math]::Round($instaladoGB, 1), $usavelGB, $slots) -ForegroundColor White
        $tab | Format-Table -AutoSize | Out-String -Width 200 | Write-Host

        if ($instaladoGB -gt 0 -and $usavelGB -gt 0 -and $usavelGB -lt ($instaladoGB * 0.7)) {
            Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Só $usavelGB GB de $([math]::Round($instaladoGB, 1)) GB de RAM estão utilizáveis" `
                -Detalhe 'Parte grande da memória está reservada ou não foi reconhecida.' `
                -Solucao 'Causas comuns: Windows de 32 bits, memória de vídeo integrado reservada, módulo mal encaixado ou BIOS com remapeamento desativado. Reencaixe os módulos e confira a BIOS.'
        }
        if ($slots -ge 2 -and $mods.Count -eq 1) {
            Add-Achado -Gravidade Info -Categoria 'Hardware' -Titulo 'Memória em canal único (1 módulo para 2 ou mais slots)' `
                -Solucao 'Dois módulos iguais em dual-channel melhoram o desempenho, principalmente com vídeo integrado.'
        }
        $lenta = @($mods | Where-Object { $_.Speed -gt 0 -and $_.ConfiguredClockSpeed -gt 0 -and $_.ConfiguredClockSpeed -lt ($_.Speed * 0.9) })
        if ($lenta.Count -gt 0) {
            Add-Achado -Gravidade Info -Categoria 'Hardware' -Titulo 'A memória está rodando abaixo da velocidade nominal' `
                -Detalhe "Nominal $($lenta[0].Speed) MHz, configurada $($lenta[0].ConfiguredClockSpeed) MHz." `
                -Solucao 'Se o módulo suporta perfil XMP/EXPO, ative na BIOS (se estável no seu equipamento).'
        }
    } catch { Write-Host "  Memória: leitura falhou ($($_.Exception.Message))" -ForegroundColor Yellow }

    # --- Placa de vídeo -------------------------------------------------------
    try {
        $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction Stop)
        $tab = @(foreach ($g in $gpus) {
            $dataDrv = ''
            try { if ($g.DriverDate) { $dataDrv = ([datetime]$g.DriverDate).ToString('yyyy-MM-dd') } } catch { }
            [pscustomobject]@{
                Nome       = "$($g.Name)"
                Fabricante = "$($g.AdapterCompatibility)"
                Driver     = "$($g.DriverVersion)"
                DataDriver = $dataDrv
                Resolucao  = if ($g.CurrentHorizontalResolution) { "$($g.CurrentHorizontalResolution)x$($g.CurrentVerticalResolution)" } else { 'n/d' }
                Hz         = $g.CurrentRefreshRate
                Status     = "$($g.Status)"
            }
        })
        $hw['PlacaDeVideo'] = $tab
        Write-Host '  Placa(s) de vídeo' -ForegroundColor White
        $tab | Format-Table -AutoSize | Out-String -Width 200 | Write-Host

        foreach ($g in $gpus) {
            if ($g.Status -and "$($g.Status)" -ne 'OK') {
                Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Placa de vídeo '$($g.Name)' com status '$($g.Status)'" `
                    -Solucao 'Reinstale o driver de vídeo (veja a seção de drivers) e confira o encaixe/alimentação da placa.'
            }
            if ("$($g.Name)" -match 'Basic' -and $g.CurrentHorizontalResolution -and [int]$g.CurrentHorizontalResolution -le 1024) {
                Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Resolução baixa ($($g.CurrentHorizontalResolution)x$($g.CurrentVerticalResolution)) com driver de vídeo genérico" `
                    -Solucao 'Instale o driver do fabricante da placa de vídeo.'
            }
        }
        $reais = @($gpus | Where-Object { "$($_.Name)" -notmatch 'Basic|Remote|Virtual|Mirror|Parsec|Meta ' })
        if ($reais.Count -ge 2) {
            Add-Achado -Gravidade Info -Categoria 'Hardware' -Titulo "Duas ou mais placas de vídeo detectadas: $((($reais | ForEach-Object { $_.Name }) -join ' + '))" `
                -Detalhe 'Típico de notebook com vídeo integrado + dedicado.' `
                -Solucao 'Mantenha os drivers dos dois adaptadores atualizados; o Windows Update costuma sobrescrever o da placa integrada ou o da dedicada.'
        }

        $smi = @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe") |
            Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        if ($smi) {
            $linhas = @(& $smi --query-gpu=name,driver_version,temperature.gpu,utilization.gpu,memory.total,memory.used --format=csv,noheader,nounits 2>$null)
            $tabN = @(foreach ($l in $linhas) {
                $p = "$l" -split ',\s*'
                if ($p.Count -ge 6) {
                    [pscustomobject]@{ Nome = $p[0]; DriverNVIDIA = $p[1]; TemperaturaC = $p[2]; UsoGPU_Pct = $p[3]; VRAM_MB = $p[4]; VRAMUsada_MB = $p[5] }
                }
            })
            if ($tabN.Count -gt 0) {
                $hw['NvidiaSMI'] = $tabN
                Write-Host '  NVIDIA (nvidia-smi)' -ForegroundColor White
                $tabN | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
                foreach ($n in $tabN) {
                    $t = 0
                    if ([int]::TryParse($n.TemperaturaC, [ref]$t) -and $t -ge 85) {
                        Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "GPU NVIDIA a $t °C" `
                            -Solucao 'Verifique ventoinhas, poeira e curva de ventilação da placa de vídeo.'
                    }
                }
            }
        }
    } catch { Write-Host "  Vídeo: leitura falhou ($($_.Exception.Message))" -ForegroundColor Yellow }

    # --- Placa-mãe, firmware, Secure Boot e TPM -------------------------------
    try {
        $bb = Get-CimInstance Win32_BaseBoard -ErrorAction Stop | Select-Object -First 1
        $modoFw = 'n/d'
        $secureBoot = 'n/d'
        try {
            $pe = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name PEFirmwareType -ErrorAction Stop).PEFirmwareType
            if ($pe -eq 2) { $modoFw = 'UEFI' } elseif ($pe -eq 1) { $modoFw = 'Legacy BIOS' }
        } catch { }
        try {
            $st = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction Stop).UEFISecureBootEnabled
            $secureBoot = if ($st -eq 1) { 'ativado' } else { 'desativado' }
        } catch { }
        try {
            $sb = Confirm-SecureBootUEFI -ErrorAction Stop
            $modoFw = 'UEFI'
            $secureBoot = if ($sb) { 'ativado' } else { 'desativado' }
        } catch { }
        $tpm = 'n/d'
        try {
            $t = Get-Tpm -ErrorAction Stop
            if ($t.TpmPresent) { $tpm = if ($t.TpmReady) { 'presente e pronto' } else { 'presente, não pronto' } }
            elseif (Test-Administrador) { $tpm = 'ausente' }
            else { $tpm = 'n/d (precisa de administrador)' }
        } catch { }
        $hw['PlacaMae'] = [ordered]@{
            Fabricante   = "$($bb.Manufacturer)"
            Modelo       = "$($bb.Product)"
            Versao       = "$($bb.Version)"
            ModoFirmware = $modoFw
            SecureBoot   = $secureBoot
            TPM          = $tpm
        }
        Write-Host '  Placa-mãe e firmware' -ForegroundColor White
        foreach ($k in $hw['PlacaMae'].Keys) { Write-Host ('    {0,-14} {1}' -f $k, $hw['PlacaMae'][$k]) }
    } catch { Write-Host "  Placa-mãe: leitura falhou ($($_.Exception.Message))" -ForegroundColor Yellow }

    # --- Rede -----------------------------------------------------------------
    try {
        $nics = @(Get-NetAdapter -Physical -ErrorAction Stop)
        $tab = @(foreach ($n in $nics) {
            $dataDrv = ''
            try { if ($n.DriverDate) { $dataDrv = ([datetime]$n.DriverDate).ToString('yyyy-MM-dd') } } catch { }
            [pscustomobject]@{
                Nome            = "$($n.Name)"
                Descricao       = "$($n.InterfaceDescription)"
                Status          = "$($n.Status)"
                Velocidade      = "$($n.LinkSpeed)"
                DriverVersao    = "$($n.DriverVersionString)"
                DriverData      = $dataDrv
                DriverProvedor  = "$($n.DriverProvider)"
            }
        })
        $hw['Rede'] = $tab
        Write-Host '  Adaptadores de rede físicos' -ForegroundColor White
        $tab | Format-Table -AutoSize | Out-String -Width 220 | Write-Host
        foreach ($n in $nics) {
            if ("$($n.Status)" -eq 'Up' -and "$($n.PhysicalMediaType)" -eq '802.3' -and [uint64]$n.Speed -gt 0 -and [uint64]$n.Speed -le 100000000) {
                Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Rede cabeada '$($n.Name)' conectada a apenas $($n.LinkSpeed)" `
                    -Detalhe 'Uma conexão Ethernet moderna deveria negociar 1 Gbps ou mais.' `
                    -Solucao 'Troque o cabo, teste outra porta do roteador/switch e confira o driver da placa de rede.'
            }
        }
    } catch { Write-Host '  Rede: leitura não disponível neste equipamento.' -ForegroundColor DarkGray }

    # --- Áudio ----------------------------------------------------------------
    try {
        $sons = @(Get-CimInstance Win32_SoundDevice -ErrorAction Stop)
        $hw['Audio'] = @(foreach ($s in $sons) { [pscustomobject]@{ Nome = "$($s.Name)"; Fabricante = "$($s.Manufacturer)"; Status = "$($s.Status)" } })
        foreach ($s in $sons) {
            if ($s.Status -and "$($s.Status)" -ne 'OK') {
                Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Dispositivo de áudio '$($s.Name)' com status '$($s.Status)'" `
                    -Solucao 'Reinstale o driver de áudio (Realtek/fabricante do notebook) pela seção de drivers.'
            }
        }
    } catch { }

    # --- Monitores ------------------------------------------------------------
    try {
        $mons = @(Get-CimInstance -Namespace 'root\wmi' -ClassName WmiMonitorID -ErrorAction Stop)
        $hw['Monitores'] = @(foreach ($m in $mons) {
            [pscustomobject]@{
                Fabricante = ConvertFrom-CodigoMonitor $m.ManufacturerName
                Modelo     = ConvertFrom-CodigoMonitor $m.UserFriendlyName
                Ano        = $m.YearOfManufacture
            }
        })
    } catch { }

    # --- Bateria --------------------------------------------------------------
    try {
        $baterias = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
        if ($baterias.Count -gt 0) {
            $info = [ordered]@{ CargaAtual_Pct = $baterias[0].EstimatedChargeRemaining; CapacidadeProjeto_mWh = $null; CapacidadeAtual_mWh = $null; Saude_Pct = $null; Ciclos = $null }
            $xmlPath = Join-Path ([IO.Path]::GetTempPath()) ('windiag_bateria_{0}.xml' -f $script:Stamp)
            & powercfg.exe /batteryreport /xml /output "$xmlPath" 2>&1 | Out-Null
            if (Test-Path -LiteralPath $xmlPath) {
                try {
                    [xml]$rel = Get-Content -LiteralPath $xmlPath -Raw
                    $bat = @($rel.BatteryReport.Batteries.Battery)[0]
                    $proj = [double]$bat.DesignCapacity
                    $cheia = [double]$bat.FullChargeCapacity
                    if ($proj -gt 0 -and $cheia -gt 0) {
                        $info['CapacidadeProjeto_mWh'] = [int]$proj
                        $info['CapacidadeAtual_mWh'] = [int]$cheia
                        $info['Saude_Pct'] = [math]::Round(100 * $cheia / $proj, 0)
                        $info['Ciclos'] = $bat.CycleCount
                    }
                } catch { } finally { Remove-Item -LiteralPath $xmlPath -Force -ErrorAction SilentlyContinue }
            }
            $hw['Bateria'] = @([pscustomobject]$info)
            Write-Host '  Bateria' -ForegroundColor White
            $hw['Bateria'] | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
            if ($null -ne $info['Saude_Pct']) {
                if ($info['Saude_Pct'] -lt 60) {
                    Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Bateria com apenas $($info['Saude_Pct'])% da capacidade original" `
                        -Solucao 'A autonomia está bem reduzida; considere trocar a bateria.'
                } elseif ($info['Saude_Pct'] -lt 80) {
                    Add-Achado -Gravidade Info -Categoria 'Hardware' -Titulo "Bateria com $($info['Saude_Pct'])% da capacidade original" `
                        -Solucao 'Desgaste normal; acompanhe a evolução.'
                }
            }
        }
    } catch { }

    # --- Inventário de dispositivos por classe --------------------------------
    try {
        $todos = @(Get-PnPCache | Where-Object { $_.Present -ne $false })
        $hw['Inventario'] = @($todos | Group-Object PNPClass | Sort-Object Count -Descending | ForEach-Object {
            [pscustomobject]@{ Classe = $(if ($_.Name) { $_.Name } else { '(sem classe)' }); Quantidade = $_.Count }
        })
        Write-Host ("  Dispositivos presentes: {0} em {1} classes (lista completa no relatório)." -f $todos.Count, @($hw['Inventario']).Count) -ForegroundColor DarkGray
    } catch { }

    $script:Dados['Hardware'] = $hw
}

function ConvertTo-HtmlHardware {
    $hw = $script:Dados['Hardware']
    if (-not $hw) { return '' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<h2>Hardware</h2>')
    if ($hw['PlacaMae']) {
        [void]$sb.Append('<h3>Placa-mãe e firmware</h3><dl>')
        foreach ($k in $hw['PlacaMae'].Keys) {
            [void]$sb.Append('<div><dt>' + (ConvertTo-HtmlSeguro $k) + '</dt><dd>' + (ConvertTo-HtmlSeguro $hw['PlacaMae'][$k]) + '</dd></div>')
        }
        [void]$sb.Append('</dl>')
    }
    $secoes = @(
        @{ Chave = 'Processador';  Titulo = 'Processador';          Colunas = @('Nome', 'Nucleos', 'Threads', 'ClockMaxMHz', 'CargaPct', 'Virtualizacao') },
        @{ Chave = 'Memoria';      Titulo = 'Memória RAM';          Colunas = @('Slot', 'CapacidadeGB', 'Tipo', 'NominalMHz', 'ConfiguradaMHz', 'Fabricante') },
        @{ Chave = 'PlacaDeVideo'; Titulo = 'Placa(s) de vídeo';    Colunas = @('Nome', 'Fabricante', 'Driver', 'DataDriver', 'Resolucao', 'Hz', 'Status') },
        @{ Chave = 'NvidiaSMI';    Titulo = 'NVIDIA (nvidia-smi)';  Colunas = @('Nome', 'DriverNVIDIA', 'TemperaturaC', 'UsoGPU_Pct', 'VRAM_MB', 'VRAMUsada_MB') },
        @{ Chave = 'Rede';         Titulo = 'Rede';                 Colunas = @('Nome', 'Descricao', 'Status', 'Velocidade', 'DriverVersao', 'DriverData', 'DriverProvedor') },
        @{ Chave = 'Audio';        Titulo = 'Áudio';                Colunas = @('Nome', 'Fabricante', 'Status') },
        @{ Chave = 'Monitores';    Titulo = 'Monitores';            Colunas = @('Fabricante', 'Modelo', 'Ano') },
        @{ Chave = 'Bateria';      Titulo = 'Bateria';              Colunas = @('CargaAtual_Pct', 'CapacidadeProjeto_mWh', 'CapacidadeAtual_mWh', 'Saude_Pct', 'Ciclos') },
        @{ Chave = 'Inventario';   Titulo = 'Dispositivos por classe'; Colunas = @('Classe', 'Quantidade') }
    )
    foreach ($s in $secoes) {
        $itens = @($hw[$s.Chave])
        if ($itens.Count -gt 0 -and $null -ne $itens[0]) {
            [void]$sb.Append('<h3>' + (ConvertTo-HtmlSeguro $s.Titulo) + '</h3>')
            [void]$sb.Append((ConvertTo-HtmlTabela $itens $s.Colunas))
        }
    }
    return $sb.ToString()
}

# ----------------------------------------------------------------------------
# Bloqueios de instalação (ID de hardware) e exclusão de drivers do Windows Update
# ----------------------------------------------------------------------------
function Get-IdsBloqueados {
    $ids = @()
    if (Test-Path $script:ChaveDeny) {
        $k = Get-Item $script:ChaveDeny
        foreach ($n in $k.GetValueNames()) {
            $v = "$($k.GetValue($n))"
            if ($v) { $ids += $v }
        }
    }
    return $ids
}

function Test-IdBloqueado {
    param([string[]]$Ids)
    try {
        $p = Get-ItemProperty -Path $script:ChaveRestricoes -Name DenyDeviceIDs -ErrorAction Stop
        if ([int]$p.DenyDeviceIDs -ne 1) { return $false }
    } catch { return $false }
    $lista = @(Get-IdsBloqueados | ForEach-Object { $_.ToUpper() })
    foreach ($i in $Ids) {
        if ($i -and ($lista -contains "$i".ToUpper())) { return $true }
    }
    return $false
}

function Set-BloqueioDispositivo {
    param([string]$IdHardware, [string]$Nome)
    if (-not $IdHardware) { throw 'ID de hardware vazio.' }
    if (-not (Test-Path $script:ChaveRestricoes)) { New-Item -Path $script:ChaveRestricoes -Force | Out-Null }
    if (-not (Test-Path $script:ChaveDeny)) { New-Item -Path $script:ChaveDeny -Force | Out-Null }
    New-ItemProperty -Path $script:ChaveRestricoes -Name 'DenyDeviceIDs' -Value 1 -PropertyType DWord -Force | Out-Null
    # IMPORTANTE: o valor retroativo precisa ficar 0. Com 1, o Windows DESINSTALARIA o dispositivo que já está instalado.
    New-ItemProperty -Path $script:ChaveRestricoes -Name 'DenyDeviceIDsRetroactive' -Value 0 -PropertyType DWord -Force | Out-Null

    if (@(Get-IdsBloqueados) -contains $IdHardware) {
        Write-Host "    Este ID já estava bloqueado: $IdHardware" -ForegroundColor DarkGray
        return
    }
    $nomes = @((Get-Item $script:ChaveDeny).GetValueNames())
    $n = 1
    while ($nomes -contains "$n") { $n++ }
    New-ItemProperty -Path $script:ChaveDeny -Name "$n" -Value $IdHardware -PropertyType String -Force | Out-Null

    $reg = "$($script:ChaveWinDiag)\Bloqueios"
    if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
    New-ItemProperty -Path $reg -Name ([guid]::NewGuid().ToString('N')) -Value $IdHardware -PropertyType String -Force | Out-Null
    Write-Host "    Bloqueio criado para '$Nome' ($IdHardware). Reinicie o computador para garantir o efeito." -ForegroundColor Green
    Write-Host '    Para desfazer: execute o Telomera com -DesfazerBloqueios.' -ForegroundColor DarkGray
}

function Remove-BloqueiosWinDiag {
    $reg = "$($script:ChaveWinDiag)\Bloqueios"
    if (-not (Test-Path $reg)) {
        Write-Host '  Nenhum bloqueio de dispositivo criado pelo Telomera foi encontrado.' -ForegroundColor DarkGray
        return
    }
    $k = Get-Item $reg
    $meus = @()
    foreach ($n in $k.GetValueNames()) { $meus += "$($k.GetValue($n))".ToUpper() }
    if (Test-Path $script:ChaveDeny) {
        $deny = Get-Item $script:ChaveDeny
        foreach ($n in $deny.GetValueNames()) {
            if ($meus -contains "$($deny.GetValue($n))".ToUpper()) {
                Remove-ItemProperty -Path $script:ChaveDeny -Name $n -ErrorAction SilentlyContinue
            }
        }
        if (@((Get-Item $script:ChaveDeny).GetValueNames()).Count -eq 0) {
            Remove-Item -Path $script:ChaveDeny -Force -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $script:ChaveRestricoes -Name 'DenyDeviceIDs' -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $script:ChaveRestricoes -Name 'DenyDeviceIDsRetroactive' -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -Path $reg -Force -Recurse -ErrorAction SilentlyContinue
    Write-Host '  Bloqueios de dispositivo criados pelo Telomera foram removidos.' -ForegroundColor Green
}

function Suspend-BloqueiosDoDispositivo {
    # Retira temporariamente os bloqueios que atingem este dispositivo (para permitir a instalação).
    param([string[]]$Ids)
    $removidos = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path $script:ChaveDeny)) { return @() }
    $idsMaiusculos = @($Ids | ForEach-Object { "$_".ToUpper() })
    $chave = Get-Item $script:ChaveDeny
    foreach ($n in $chave.GetValueNames()) {
        $v = "$($chave.GetValue($n))"
        if ($idsMaiusculos -contains $v.ToUpper()) { $removidos.Add(@{ Nome = $n; Valor = $v }) }
    }
    if ($removidos.Count -gt 0) {
        Write-Host '    Há um bloqueio de instalação para este dispositivo; vou suspendê-lo só durante a instalação e reativá-lo logo depois.' -ForegroundColor Yellow
        foreach ($r in $removidos) { Remove-ItemProperty -Path $script:ChaveDeny -Name $r.Nome -ErrorAction SilentlyContinue }
    }
    return $removidos.ToArray()
}

function Resume-Bloqueios {
    param([object[]]$Itens)
    foreach ($r in @($Itens)) {
        if (-not $r) { continue }
        if (-not (Test-Path $script:ChaveDeny)) { New-Item -Path $script:ChaveDeny -Force | Out-Null }
        New-ItemProperty -Path $script:ChaveDeny -Name $r.Nome -Value $r.Valor -PropertyType String -Force | Out-Null
    }
    if (@($Itens).Count -gt 0) { Write-Host '    Bloqueio reativado.' -ForegroundColor DarkGray }
}

function Test-EdicaoHome {
    try {
        $sku = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).OperatingSystemSKU
        return ($sku -in 98, 99, 100, 101)
    } catch { return $false }
}

function Test-ExclusaoDriversWU {
    try {
        $p = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name ExcludeWUDriversInQualityUpdate -ErrorAction Stop
        return ([int]$p.ExcludeWUDriversInQualityUpdate -eq 1)
    } catch { return $false }
}

function Set-ExclusaoDriversWU {
    $k = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
    $jaEstava = Test-ExclusaoDriversWU
    if (-not (Test-Path $k)) { New-Item -Path $k -Force | Out-Null }
    New-ItemProperty -Path $k -Name 'ExcludeWUDriversInQualityUpdate' -Value 1 -PropertyType DWord -Force | Out-Null
    if (-not $jaEstava) {
        if (-not (Test-Path $script:ChaveWinDiag)) { New-Item -Path $script:ChaveWinDiag -Force | Out-Null }
        New-ItemProperty -Path $script:ChaveWinDiag -Name 'ExcluirDriversWU' -Value 1 -PropertyType DWord -Force | Out-Null
    }
    Write-Host '    Drivers excluídos das atualizações de qualidade do Windows Update. Reinicie para garantir o efeito.' -ForegroundColor Green
    Write-Host '    Para desfazer: execute o Telomera com -DesfazerBloqueios.' -ForegroundColor DarkGray
}

function Remove-ExclusaoDriversWU {
    $marca = $null
    try { $marca = (Get-ItemProperty -Path $script:ChaveWinDiag -Name ExcluirDriversWU -ErrorAction Stop).ExcluirDriversWU } catch { }
    if ($marca -eq 1) {
        Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path $script:ChaveWinDiag -Name 'ExcluirDriversWU' -ErrorAction SilentlyContinue
        Write-Host '  Exclusão de drivers do Windows Update removida.' -ForegroundColor Green
    } else {
        Write-Host '  Nenhuma exclusão global de drivers criada pelo Telomera foi encontrada.' -ForegroundColor DarkGray
    }
}

# ----------------------------------------------------------------------------
# Restauração de drivers (DriverStore) e drivers nativos
# ----------------------------------------------------------------------------
function Get-PacotesDriverStore {
    if ($null -eq $script:CachePacotes) {
        Write-Host '    Lendo os pacotes de driver guardados no sistema (DriverStore)...' -ForegroundColor DarkGray
        try {
            $script:CachePacotes = @(Get-WindowsDriver -Online -All -ErrorAction Stop)
        } catch {
            $script:CachePacotes = @()
            $script:ErroPacotes = $_.Exception.Message
        }
    }
    return $script:CachePacotes
}

function Test-InfContemId {
    param([string]$CaminhoInf, [string[]]$Ids)
    if (-not $CaminhoInf -or -not (Test-Path -LiteralPath $CaminhoInf)) { return $false }
    foreach ($id in $Ids) {
        if (-not $id) { continue }
        try {
            if (Select-String -LiteralPath $CaminhoInf -Pattern $id -SimpleMatch -Quiet -ErrorAction Stop) { return $true }
        } catch { }
    }
    return $false
}

function Find-DriversRestauraveis {
    # Pacotes de terceiros já guardados no sistema que servem para este hardware (mais novo primeiro).
    param([string[]]$HardwareIds, [string]$Classe)
    $ids = @($HardwareIds | ForEach-Object { Get-IdGenerico "$_" } | Where-Object { $_ } | Select-Object -Unique)
    if ($ids.Count -eq 0 -or -not $Classe) { return @() }
    $candidatos = @(Get-PacotesDriverStore | Where-Object { -not $_.Inbox -and "$($_.ClassName)" -eq $Classe })
    $achados = New-Object System.Collections.Generic.List[object]
    foreach ($p in $candidatos) {
        if (Test-InfContemId -CaminhoInf $p.OriginalFileName -Ids $ids) {
            $achados.Add([pscustomobject]@{
                Pacote       = "$($p.Driver)"
                Provedor     = "$($p.ProviderName)"
                Versao       = $p.Version
                Data         = $p.Date
                Inf          = "$($p.OriginalFileName)"
                BootCritical = [bool]$p.BootCritical
            })
        }
    }
    return @($achados.ToArray() | Sort-Object Versao -Descending)
}

function Test-DriverInstalado {
    param([string]$InstanceId, [string]$Versao)
    try {
        $v = (Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName 'DEVPKEY_Device_DriverVersion' -ErrorAction Stop).Data
        return ("$v" -eq "$Versao")
    } catch { return $false }
}

function Invoke-ForcarDriver {
    # Mesma API usada pelo Gerenciador de Dispositivos (Atualizar driver > Procurar no computador), com INSTALLFLAG_FORCE.
    param([string]$IdHardware, [string]$CaminhoInf)
    if (-not ('Telomera.NewDev' -as [type])) {
        $codigoCs = @'
[DllImport("newdev.dll", SetLastError = true, CharSet = CharSet.Unicode)]
public static extern bool UpdateDriverForPlugAndPlayDevicesW(IntPtr hwndParent, string HardwareId, string FullInfPath, uint InstallFlags, out bool RebootRequired);
'@
        Add-Type -Namespace Telomera -Name NewDev -MemberDefinition $codigoCs
    }
    $reboot = $false
    # 0x1 = INSTALLFLAG_FORCE, 0x4 = INSTALLFLAG_NONINTERACTIVE
    $ok = [Telomera.NewDev]::UpdateDriverForPlugAndPlayDevicesW([IntPtr]::Zero, $IdHardware, $CaminhoInf, 5, [ref]$reboot)
    if ($ok) {
        Write-Host '    Driver instalado à força.' -ForegroundColor Green
        if ($reboot) { Write-Host '    É necessário reiniciar o computador.' -ForegroundColor Yellow }
    } else {
        $erro = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        Write-Host "    Não foi possível forçar a instalação: $(Get-TextoErroWin32 $erro)" -ForegroundColor Red
    }
}

function Restore-DriverArmazenado {
    param($Ctx)
    if ([int]$script:Sistema.Build -gt 0 -and [int]$script:Sistema.Build -lt 14393) {
        Write-Host '    Esta ação exige Windows 10 1607 ou superior.' -ForegroundColor Yellow
        return
    }
    $suspensos = @(Suspend-BloqueiosDoDispositivo -Ids $Ctx.HardwareIds)
    try {
        Write-Host "    Instalando o pacote: $($Ctx.Inf)" -ForegroundColor DarkGray
        $saida = & pnputil.exe /add-driver "$($Ctx.Inf)" /install 2>&1 | Out-String
        $cod = $LASTEXITCODE
        if ($saida.Trim()) { Write-Host ($saida.Trim()) -ForegroundColor DarkGray }
        if (Test-DriverInstalado -InstanceId $Ctx.InstanceId -Versao $Ctx.VersaoAlvo) {
            Write-Host "    Driver restaurado (versão $($Ctx.VersaoAlvo))." -ForegroundColor Green
            if ($cod -eq 3010) { Write-Host '    É necessário reiniciar o computador.' -ForegroundColor Yellow }
            return
        }
        Write-Host "    O Windows manteve o driver atual (código $cod). Isso acontece quando ele considera o driver atual 'melhor ranqueado'." -ForegroundColor Yellow
        $r = Read-Resposta '    Forçar este driver mesmo assim? (o mesmo que "Atualizar driver > Procurar no computador > Permitir que eu escolha") [s/N]'
        if ($r -match '^\s*[sSyY]') {
            Invoke-ForcarDriver -IdHardware (@($Ctx.HardwareIds)[0]) -CaminhoInf $Ctx.Inf
        }
    } finally {
        Resume-Bloqueios -Itens $suspensos
    }
}

function Restore-DriverNativo {
    # Remove um pacote de terceiros para o Windows voltar a usar o driver nativo. Exporta o pacote antes (dá para desfazer).
    param($Ctx)
    $pastaPacote = Join-Path $script:PastaRelatorioFinal ("PacotesRemovidos_{0}\{1}" -f $script:Stamp, ($Ctx.Pacote -replace '\.inf$', ''))
    New-Item -ItemType Directory -Force -Path $pastaPacote | Out-Null
    Write-Host "    Guardando uma cópia do pacote $($Ctx.Pacote) em: $pastaPacote" -ForegroundColor DarkGray
    $exp = & pnputil.exe /export-driver "$($Ctx.Pacote)" "$pastaPacote" 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0 -or -not (Get-ChildItem -Path $pastaPacote -Filter '*.inf' -Recurse -ErrorAction SilentlyContinue)) {
        Write-Host '    Não consegui guardar a cópia do pacote; por segurança, nada foi removido.' -ForegroundColor Red
        if ($exp.Trim()) { Write-Host ($exp.Trim()) -ForegroundColor DarkGray }
        return
    }
    $saida = & pnputil.exe /delete-driver "$($Ctx.Pacote)" /uninstall 2>&1 | Out-String
    $cod = $LASTEXITCODE
    if ($saida.Trim()) { Write-Host ($saida.Trim()) -ForegroundColor DarkGray }
    & pnputil.exe /scan-devices 2>&1 | Out-Null
    if ($cod -eq 0 -or $cod -eq 3010) {
        Write-Host '    Pacote removido; o Windows vai usar o driver nativo (reinicie se ele pedir).' -ForegroundColor Green
        Write-Host "    Para desfazer: pnputil /add-driver `"$pastaPacote\*.inf`" /install" -ForegroundColor DarkGray
    } else {
        Write-Host "    O Windows não removeu o pacote (código $cod); provavelmente ainda está em uso." -ForegroundColor Yellow
    }
}

function Add-AcoesRestauracao {
    # Cria, para um dispositivo com problema, as ações de restauração que fizerem sentido.
    param([string]$Nome, [string]$InstanceId, [string[]]$HardwareIds, [string]$Classe)
    if (-not $Classe) { return }
    $atual = $null
    if ($script:CacheAssinados) { $atual = @($script:CacheAssinados | Where-Object { $_.DeviceID -eq $InstanceId }) | Select-Object -First 1 }
    $sensivel = ($Classe -in $script:ClassesInternas)
    $aviso = switch -Regex ($Classe) {
        '^Display$' { 'A tela pode piscar ou ficar preta por alguns segundos durante a instalação.'; break }
        '^Net$'     { 'A conexão de rede pode cair por alguns instantes.'; break }
        default     { '' }
    }

    $cands = @(Find-DriversRestauraveis -HardwareIds $HardwareIds -Classe $Classe)
    $melhor = $cands | Select-Object -First 1
    if ($melhor -and ((-not $atual) -or ("$($atual.InfName)" -ne $melhor.Pacote))) {
        $ctx = @{ Nome = $Nome; Inf = $melhor.Inf; InstanceId = $InstanceId; HardwareIds = @($HardwareIds); VersaoAlvo = "$($melhor.Versao)" }
        $dataTxt = if ($melhor.Data) { ([datetime]$melhor.Data).ToString('yyyy-MM-dd') } else { 'n/d' }
        Add-Acao -Descricao "Restaurar o driver guardado no sistema para '$Nome' ($($melhor.Provedor) $($melhor.Versao), $dataTxt)" `
            -Protecao -MudaDriver -Sensivel:$sensivel -Aviso $aviso -Arg $ctx -Acao { param($c) Restore-DriverArmazenado -Ctx $c }
    }

    if ($atual -and "$($atual.InfName)" -match '^oem\d+\.inf$' -and "$($atual.DriverProviderName)" -ne 'Microsoft') {
        $pacote = @(Get-PacotesDriverStore | Where-Object { "$($_.Driver)" -eq "$($atual.InfName)" }) | Select-Object -First 1
        if ($pacote -and -not $pacote.BootCritical) {
            $ctxN = @{ Nome = $Nome; Pacote = "$($atual.InfName)"; InstanceId = $InstanceId }
            Add-Acao -Descricao "Voltar '$Nome' ao driver nativo do Windows (remove o pacote $($atual.InfName) de '$($atual.DriverProviderName)'; uma cópia é guardada)" `
                -Protecao -MudaDriver -Sensivel:$sensivel -Aviso $aviso -Arg $ctxN -Acao { param($c) Restore-DriverNativo -Ctx $c }
        }
    }
}

# ----------------------------------------------------------------------------
# Proteção do driver de vídeo contra sobrescrita pelo Windows Update
# ----------------------------------------------------------------------------
function Get-HistoricoDriversWU {
    # Histórico do Windows Update (independente de idioma): drivers de vídeo instalados nos últimos 90 dias.
    try {
        $sessao = New-Object -ComObject Microsoft.Update.Session
        $busca  = $sessao.CreateUpdateSearcher()
        $total  = [int]$busca.GetTotalHistoryCount()
        if ($total -le 0) { return @() }
        $hist   = $busca.QueryHistory(0, [math]::Min($total, 300))
        $limite = (Get-Date).AddDays(-90)
        $saida  = New-Object System.Collections.Generic.List[object]
        for ($i = 0; $i -lt $hist.Count; $i++) {
            $e = $hist.Item($i)
            $titulo = "$($e.Title)"
            if ($e.Operation -eq 1 -and $e.ResultCode -eq 2 -and ([datetime]$e.Date) -ge $limite -and $titulo -match '\bDisplay\b|Graphics|Radeon|GeForce') {
                $saida.Add([pscustomobject]@{ Data = ([datetime]$e.Date); Titulo = $titulo })
            }
        }
        return @($saida.ToArray() | Sort-Object Data -Descending)
    } catch { return @() }
}

function Invoke-AnaliseProtecaoVideo {
    param($Assinados, $Pnp)
    Write-Host ''
    Write-Host '  D) Proteção do driver de vídeo contra sobrescrita pelo Windows Update' -ForegroundColor White

    $gpus = @($Assinados | Where-Object { $_.DeviceClass -eq 'DISPLAY' -and $_.DeviceName -and ("$(@($_.HardWareID)[0])" -match '^PCI\\') })
    if ($gpus.Count -eq 0) {
        Write-Host '     Nenhuma placa de vídeo PCI encontrada.' -ForegroundColor DarkGray
        return
    }

    $hist = @()
    if (-not $SemWindowsUpdate) { $hist = @(Get-HistoricoDriversWU) }
    if ($hist.Count -gt 0) {
        Add-Achado -Gravidade Info -Categoria 'Driver' -Titulo "O Windows Update instalou driver de vídeo nos últimos 90 dias ($($hist.Count)x)" `
            -Detalhe "Mais recente: $($hist[0].Titulo) em $($hist[0].Data.ToString('yyyy-MM-dd'))." `
            -Solucao 'O Windows Update pode trocar o driver instalado por você por outro que ele considera melhor. Se a placa passou a dar problema depois disso, restaure o driver e ative a proteção abaixo.'
    }

    $resumo = New-Object System.Collections.Generic.List[object]
    $algumBloqueado = $false
    foreach ($g in $gpus) {
        $dev = @($Pnp | Where-Object { $_.PNPDeviceID -eq $g.DeviceID }) | Select-Object -First 1
        $ids = if ($dev -and $dev.HardwareID) { @($dev.HardwareID) } else { @("$($g.HardWareID)") }
        $idBloqueio = if ($ids.Count -ge 2) { $ids[1] } else { $ids[0] }
        $bloqueado = Test-IdBloqueado -Ids $ids
        if ($bloqueado) { $algumBloqueado = $true }
        $basico = ("$($g.DeviceName)" -match 'Basic Display|v.deo b.sico|Basic Render')
        $provMs = ("$($g.DriverProviderName)" -eq 'Microsoft')
        $atualVer = ConvertTo-VersaoSegura $g.DriverVersion

        $cands = @(Find-DriversRestauraveis -HardwareIds $ids -Classe 'Display')
        $melhor = $cands | Select-Object -First 1
        $rebaixado = ($melhor -and $atualVer -and ($melhor.Versao -gt $atualVer))
        $estado = if ($bloqueado) { 'ATIVA' } else { 'não ativa' }
        Write-Host ('     {0}: driver {1} ({2}); proteção contra troca: {3}' -f $g.DeviceName, $g.DriverVersion, $g.DriverProviderName, $estado)

        $resumo.Add([pscustomobject]@{ Placa = "$($g.DeviceName)"; Driver = "$($g.DriverVersion)"; Provedor = "$($g.DriverProviderName)"; Protecao = $estado; MelhorGuardado = $(if ($melhor) { "$($melhor.Provedor) $($melhor.Versao)" } else { 'nenhum' }) })

        $links = @(Get-LinksDriver -HardwareId $ids[0] -InstanceId $g.DeviceID)
        if (($basico -or $provMs -or $rebaixado) -and $melhor) {
            $dataM = if ($melhor.Data) { ([datetime]$melhor.Data).ToString('yyyy-MM-dd') } else { 'n/d' }
            Add-Achado -Gravidade Atencao -Categoria 'Driver' -Titulo "O driver de vídeo em uso de '$($g.DeviceName)' não é o mais recente do fabricante guardado no sistema" `
                -Detalhe "Em uso: $($g.DriverProviderName) $($g.DriverVersion). Guardado: $($melhor.Provedor) $($melhor.Versao) ($dataM). Sinal típico de driver sobrescrito pelo Windows Update." `
                -Solucao 'Restaure o driver guardado (fase de reparo) e ative a proteção contra troca automática. Dica da Intel: se o Windows Update remover o driver no reinício, instale-o uma segunda vez.' `
                -Links $links
            $ctx = @{ Nome = "$($g.DeviceName)"; Inf = $melhor.Inf; InstanceId = "$($g.DeviceID)"; HardwareIds = @($ids); VersaoAlvo = "$($melhor.Versao)" }
            Add-Acao -Descricao "Restaurar o driver de vídeo do fabricante guardado no sistema ($($melhor.Provedor) $($melhor.Versao), $dataM) para '$($g.DeviceName)'" `
                -Protecao -MudaDriver -Aviso 'A tela pode piscar ou ficar preta por alguns segundos durante a instalação.' -Arg $ctx -Acao { param($c) Restore-DriverArmazenado -Ctx $c }
        } elseif (($basico -or $provMs) -and -not $melhor) {
            Add-Achado -Gravidade Atencao -Categoria 'Driver' -Titulo "'$($g.DeviceName)' usa driver da Microsoft e não há driver do fabricante guardado no sistema" `
                -Solucao 'Baixe o driver no site do fabricante (links abaixo) e use a instalação limpa. Depois, ative a proteção contra troca automática.' `
                -Links $links
        }

        if (-not $bloqueado) {
            $ctxB = @{ Id = $idBloqueio; Nome = "$($g.DeviceName)" }
            Add-Acao -Descricao "Impedir que o Windows Update troque o driver de '$($g.DeviceName)' (bloqueio por ID de hardware: $idBloqueio)" `
                -Geral -Protecao -Aviso 'Enquanto o bloqueio existir, o Windows também impede a instalação MANUAL de drivers para esta placa (inclusive o instalador do fabricante). Para atualizar depois, rode o Telomera com -DesfazerBloqueios.' `
                -Arg $ctxB -Acao { param($c) Set-BloqueioDispositivo -IdHardware $c.Id -Nome $c.Nome }
        }
    }
    $script:Dados['ProtecaoVideo'] = $resumo.ToArray()

    if (-not (Test-ExclusaoDriversWU)) {
        if (Test-EdicaoHome) {
            Write-Host '     (Windows Home: a política "não incluir drivers nas atualizações" pode não ter efeito; use o bloqueio por dispositivo.)' -ForegroundColor DarkGray
        } else {
            Add-Acao -Descricao 'Excluir TODOS os drivers das atualizações de qualidade do Windows Update (política ExcludeWUDriversInQualityUpdate)' `
                -Geral -Protecao -Aviso 'Isso afeta todos os dispositivos: nenhum driver virá pelo Windows Update. Você passará a atualizar drivers pelo site do fabricante.' `
                -Acao { Set-ExclusaoDriversWU }
        }
    }
    # Só é oferecido se há algo ativo para remover; nunca é aceito automaticamente (desfaz as proteções acima).
    if ($algumBloqueado -or (Test-ExclusaoDriversWU)) {
        Add-Acao -Descricao 'Remover os bloqueios e exclusões criados pelo Telomera' -Desfaz -Acao { Remove-BloqueiosWinDiag; Remove-ExclusaoDriversWU }
    }
}

# ----------------------------------------------------------------------------
# Resumo, relatórios e reparos
# ----------------------------------------------------------------------------
function Write-Resumo {
    Write-Titulo 'RESUMO'
    $c = @($script:Achados | Where-Object { $_.Gravidade -eq 'Critico' }).Count
    $a = @($script:Achados | Where-Object { $_.Gravidade -eq 'Atencao' }).Count
    $i = @($script:Achados | Where-Object { $_.Gravidade -eq 'Info' }).Count
    Write-Host ('  Críticos: {0}    Atenção: {1}    Informativos: {2}' -f $c, $a, $i)
    if (($c + $a) -eq 0) {
        Write-Host '  Nenhum problema relevante encontrado.' -ForegroundColor Green
    }
    foreach ($x in ($script:Achados | Where-Object { $_.Gravidade -eq 'Critico' } | Select-Object -First 8)) {
        Write-Host "   - $($x.Titulo)" -ForegroundColor Red
    }
    if (Get-Command Get-NotaAtual -ErrorAction SilentlyContinue) {
        try { [void](Get-NotaAtual); Write-Host ('  ' + (Format-TextoNota)) -ForegroundColor Cyan } catch { }
    }
}

function ConvertTo-HtmlSeguro {
    param($Valor)
    return [System.Net.WebUtility]::HtmlEncode("$Valor")
}

function ConvertTo-HtmlTabela {
    param([object[]]$Itens, [string[]]$Colunas)
    $Itens = @($Itens | Where-Object { $null -ne $_ })
    if ($Itens.Count -eq 0) { return '<p class="vazio">Nada para mostrar.</p>' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<div class="tabela"><table><thead><tr>')
    foreach ($c in $Colunas) { [void]$sb.Append('<th>' + (ConvertTo-HtmlSeguro $c) + '</th>') }
    [void]$sb.Append('</tr></thead><tbody>')
    foreach ($linha in $Itens) {
        [void]$sb.Append('<tr>')
        foreach ($c in $Colunas) { [void]$sb.Append('<td>' + (ConvertTo-HtmlSeguro $linha.$c) + '</td>') }
        [void]$sb.Append('</tr>')
    }
    [void]$sb.Append('</tbody></table></div>')
    return $sb.ToString()
}

function Export-Relatorios {
    $ordem   = @{ Critico = 0; Atencao = 1; Info = 2 }
    $rotulos = @{ Critico = 'Crítico'; Atencao = 'Atenção'; Info = 'Info' }
    $cont    = @{ Critico = 0; Atencao = 0; Info = 0 }
    foreach ($a in $script:Achados) { $cont[$a.Gravidade]++ }
    $ordenados = @($script:Achados | Sort-Object { if ($_.Reparo -eq 'Auto') { 0 } else { 1 } }, { $ordem[$_.Gravidade] })
    $grupoAtual = ''

    $sbA = New-Object System.Text.StringBuilder
    if ($ordenados.Count -eq 0) {
        [void]$sbA.Append('<p class="ok">Nenhum problema relevante foi encontrado.</p>')
    }
    foreach ($a in $ordenados) {
        $gr = if ($a.Reparo -eq 'Auto') { 'Auto' } else { 'Manual' }
        if ($gr -ne $grupoAtual) {
            $grupoAtual = $gr
            $tg = Get-TextoGrupoReparo $gr
            [void]$sbA.Append('<h3 class="grupo">' + (ConvertTo-HtmlSeguro $tg.Titulo) + '</h3><p class="sub">' + (ConvertTo-HtmlSeguro $tg.Texto) + '</p>')
        }
        [void]$sbA.Append('<article class="achado ' + $a.Gravidade + '">')
        [void]$sbA.Append('<header><span class="selo">' + (ConvertTo-HtmlSeguro $rotulos[$a.Gravidade]) + '</span><span class="cat">' + (ConvertTo-HtmlSeguro $a.Categoria) + '</span><span class="cat">· ' + $(if ($a.Reparo -eq 'Auto') { 'Corrigível pelo Telomera' } else { 'Não corrigível pelo Telomera' }) + '</span></header>')
        [void]$sbA.Append('<h3>' + (ConvertTo-HtmlSeguro $a.Titulo) + '</h3>')
        if ($a.Detalhe) { [void]$sbA.Append('<p class="det">' + (ConvertTo-HtmlSeguro $a.Detalhe) + '</p>') }
        if ($a.Solucao) { [void]$sbA.Append('<p class="sol"><b>O que fazer:</b> ' + (ConvertTo-HtmlSeguro $a.Solucao) + '</p>') }
        if ($a.Explicacao) {
            $corpoExp = (ConvertTo-HtmlSeguro $a.Explicacao) -replace '(\r?\n)+', '<br><br>'
            [void]$sbA.Append('<details class="mais"><summary>Ver mais: o que é isso e preciso me preocupar?</summary><p><b>' + (ConvertTo-HtmlSeguro (Get-RotuloVeredito $a.Veredito)) + '</b></p><p>' + $corpoExp + '</p></details>')
        }
        if ($a.Links -and @($a.Links).Count -gt 0) {
            [void]$sbA.Append('<ul class="links">')
            foreach ($l in $a.Links) {
                [void]$sbA.Append('<li><a href="' + (ConvertTo-HtmlSeguro $l.Url) + '" target="_blank" rel="noopener noreferrer">' + (ConvertTo-HtmlSeguro $l.Texto) + '</a></li>')
            }
            [void]$sbA.Append('</ul>')
        }
        [void]$sbA.Append('</article>')
    }

    $sbS = New-Object System.Text.StringBuilder
    foreach ($k in $script:Sistema.Keys) {
        [void]$sbS.Append('<div><dt>' + (ConvertTo-HtmlSeguro $k) + '</dt><dd>' + (ConvertTo-HtmlSeguro $script:Sistema[$k]) + '</dd></div>')
    }

    $tabDiscos  = ConvertTo-HtmlTabela @($script:Dados['Discos'])  @('Nome', 'Tipo', 'Barramento', 'TamanhoGB', 'Saude', 'TemperaturaC', 'DesgasteSSD_Pct', 'HorasLigado', 'ErrosLeituraNaoCorrigidos', 'ErrosEscritaNaoCorrigidos')
    $tabVols    = ConvertTo-HtmlTabela @($script:Dados['Volumes']) @('Unidade', 'Rotulo', 'Sistema', 'Tipo', 'Saude', 'TotalGB', 'LivreGB', 'LivrePct', 'Varredura')
    $tabEventos = ConvertTo-HtmlTabela @($script:Dados['Eventos']) @('Regra', 'Gravidade', 'Ocorrencias', 'Ultima', 'Detalhe')
    $tabDrivers = ConvertTo-HtmlTabela @($script:Dados['DriversPrincipais']) @('Classe', 'Dispositivo', 'Provedor', 'Versao', 'Data', 'Assinado')
    $tabWU      = ConvertTo-HtmlTabela @($script:Dados['DriversPendentesWindowsUpdate']) @('Titulo', 'Fabricante', 'Classe', 'Data', 'HardwareId')
    $htmlHw     = ConvertTo-HtmlHardware
    $tabProt    = ConvertTo-HtmlTabela @($script:Dados['ProtecaoVideo']) @('Placa', 'Driver', 'Provedor', 'Protecao', 'MelhorGuardado')
    $htmlComparacao = '<p class="vazio">Sem dados de comparação.</p>'
    if (Get-Command ConvertTo-HtmlComparacao -ErrorAction SilentlyContinue) { $htmlComparacao = ConvertTo-HtmlComparacao $script:Comparacao }
    if (Get-Command ConvertTo-HtmlNota -ErrorAction SilentlyContinue) { try { $htmlComparacao = (ConvertTo-HtmlNota) + $htmlComparacao } catch { } }
    $tabAlt     = ConvertTo-HtmlTabela @($script:Alteracoes.ToArray()) @('Quando', 'Acao', 'Resultado')

    $quando = Get-Date -Format 'dd/MM/yyyy HH:mm'
    $html = @"
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Relatório Telomera</title>
<style>
:root{--bg:#f5f6f8;--card:#ffffff;--txt:#1c2330;--mut:#5f6b7d;--bd:#dfe3ea;--crit:#b4232a;--aten:#9a5b00;--info:#2f6296;--critbg:#fdecec;--atenbg:#fff5e0;--infobg:#eaf2fb;--lnk:#1b5fb4}
@media (prefers-color-scheme:dark){:root{--bg:#12151a;--card:#1b2028;--txt:#e7ebf1;--mut:#9aa5b5;--bd:#2c3440;--crit:#ff7b82;--aten:#f2b653;--info:#86b8ea;--critbg:#3a1d20;--atenbg:#3a2f18;--infobg:#1b2b3d;--lnk:#7fb2f0}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font:15px/1.5 "Segoe UI",system-ui,Arial,sans-serif}
main{max-width:1000px;margin:0 auto;padding:24px 16px 56px}
h1{margin:0 0 4px;font-size:26px}
h2{margin:36px 0 12px;font-size:20px}
h3{margin:6px 0 4px;font-size:16px}
.sub{color:var(--mut);margin:0 0 20px}
.grupo{margin:28px 0 4px;font-size:17px}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:16px 0}
.card{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 16px}
.card b{display:block;font-size:30px;line-height:1.1}
.card.c b{color:var(--crit)}.card.a b{color:var(--aten)}.card.i b{color:var(--info)}
dl{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px;margin:0}
dt{color:var(--mut);font-size:12px;text-transform:uppercase;letter-spacing:.04em}
dd{margin:0;font-weight:600;word-break:break-word}
.achado{background:var(--card);border:1px solid var(--bd);border-left:5px solid var(--info);border-radius:8px;padding:12px 16px;margin:10px 0}
.achado.Critico{border-left-color:var(--crit)}.achado.Atencao{border-left-color:var(--aten)}
.achado header{display:flex;gap:8px;align-items:center;font-size:12px}
.selo{padding:2px 8px;border-radius:99px;font-weight:700;background:var(--infobg);color:var(--info)}
.Critico .selo{background:var(--critbg);color:var(--crit)}.Atencao .selo{background:var(--atenbg);color:var(--aten)}
.cat{color:var(--mut)}
.det{color:var(--mut);margin:2px 0;word-break:break-word}
.sol{margin:6px 0}
.links{margin:6px 0 0;padding-left:20px}
a{color:var(--lnk)}
.tabela{overflow-x:auto;background:var(--card);border:1px solid var(--bd);border-radius:8px}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--bd);vertical-align:top}
th{color:var(--mut);font-weight:600;white-space:nowrap}
.vazio,.ok{color:var(--mut)}
.ok{color:#1d7a46;font-weight:600}
footer{margin-top:40px;color:var(--mut);font-size:12px}
@media (max-width:600px){.cards{grid-template-columns:1fr}}
</style>
</head>
<body>
<main>
<h1>Relatório Telomera</h1>
<p class="sub">Gerado em $quando - Telomera v$($script:Versao)</p>

<div class="cards">
<div class="card c"><b>$($cont['Critico'])</b>Críticos</div>
<div class="card a"><b>$($cont['Atencao'])</b>Atenção</div>
<div class="card i"><b>$($cont['Info'])</b>Informativos</div>
</div>

<h2>Sistema</h2>
<dl>$($sbS.ToString())</dl>

$htmlHw

<h2>O que foi encontrado</h2>
$($sbA.ToString())

<h2>Comparação com a verificação anterior</h2>
$htmlComparacao

<h2>Discos</h2>
$tabDiscos
<h2>Volumes</h2>
$tabVols
<h2>Eventos relevantes ($DiasEventos dias)</h2>
$tabEventos
<h2>Drivers principais</h2>
$tabDrivers
<h2>Drivers pendentes no Windows Update</h2>
$tabWU
<h2>Proteção do driver de vídeo</h2>
$tabProt
<h2>Alterações feitas pelo Telomera nesta execução</h2>
$tabAlt

<footer>
Este relatório pode conter o nome do computador e IDs de hardware. Revise antes de compartilhar publicamente.
Os links apontam para páginas oficiais; baixe drivers apenas do site do fabricante ou do Microsoft Update Catalog.
</footer>
</main>
</body>
</html>
"@

    $script:Dados['Achados'] = $script:Achados.ToArray()
    $script:Dados['Alteracoes'] = $script:Alteracoes.ToArray()
    $json = $script:Dados | ConvertTo-Json -Depth 6

    $utf8 = New-Object System.Text.UTF8Encoding($true)
    [System.IO.File]::WriteAllText($script:ArquivoHtml, $html, $utf8)
    [System.IO.File]::WriteAllText($script:ArquivoJson, $json, $utf8)

    Write-Host ''
    Write-Host "  Relatório HTML: $($script:ArquivoHtml)" -ForegroundColor Green
    Write-Host "  Relatório JSON: $($script:ArquivoJson)" -ForegroundColor Green
    Write-Host "  Log completo:   $($script:ArquivoLog)" -ForegroundColor Green
}

function Get-EstadoImagem {
    # DISM /CheckHealth leva segundos e só lê um marcador: devolve ok, reparavel, irreparavel ou desconhecido.
    try {
        Write-Host '  Verificação rápida da imagem do Windows (DISM /CheckHealth)...' -ForegroundColor DarkGray
        $t = (DISM /Online /Cleanup-Image /CheckHealth 2>&1 | Out-String)
        if ($t -match 'Nenhuma corrup|No component store corruption') { return 'ok' }
        if ($t -match 'n[aã]o.{0,30}repar|not repairable|cannot be repaired') { return 'irreparavel' }
        if ($t -match 'repar[aá]vel|repairable') { return 'reparavel' }
    } catch { }
    return 'desconhecido'
}

function Test-MotivoVerificacaoProfunda {
    # Há sintomas que justificam o SFC: telas azuis, falhas do sistema de arquivos ou drivers bloqueados pela integridade.
    return [bool](@($script:Achados | Where-Object { $_.Categoria -eq 'Eventos' -and $_.Titulo -match 'Telas azuis|Corrupção ou falha|integridade de código' }).Count -gt 0)
}

function Invoke-Sfc {
    # O SFC escreve em ANSI (Windows-1252); o console decodifica como OEM e os acentos saem quebrados.
    $antes = $null
    try {
        $ansi = [int][Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage
        if ($ansi -gt 0) {
            $antes = [Console]::OutputEncoding
            [Console]::OutputEncoding = [Text.Encoding]::GetEncoding($ansi)
        }
    } catch { $antes = $null }
    try { sfc /scannow }
    finally { if ($antes) { try { [Console]::OutputEncoding = $antes } catch { } } }
}

function Invoke-FaseReparo {
    Write-Titulo '5) REPAROS E RESTAURAÇÃO'
    if ($SomenteLeitura) {
        Write-Host '  Modo somente leitura: nenhum reparo é oferecido.' -ForegroundColor DarkGray
        return
    }
    if (-not (Test-SeguroParaAlterar)) {
        Write-Host '  Reparos cancelados. Resolva os pontos acima e rode o Telomera novamente.' -ForegroundColor Yellow
        return
    }

    if ($script:Acoes.Count -eq 0) {
        Write-Host '  O diagnóstico não sugeriu ações específicas.' -ForegroundColor DarkGray
    } else {
        Write-Host '  Cada ação abaixo pede a sua confirmação. Responda N (ou Enter) para pular.' -ForegroundColor DarkGray
        Write-Host '  Drivers internos do sistema (chipset, armazenamento, processador) exigem digitar RESTAURAR.' -ForegroundColor DarkGray
    }
    foreach ($a in $script:Acoes) {
        if (Confirm-Acao -Mensagem $a.Descricao -Protecao:$a.Protecao -Sensivel:$a.Sensivel -Desfaz:$a.Desfaz -MudaDriver:$a.MudaDriver -Aviso $a.Aviso) {
            try {
                & $a.Acao $a.Arg
                Add-Alteracao -Acao $a.Descricao -Resultado 'executado'
            } catch {
                Write-Host "    Falhou: $($_.Exception.Message)" -ForegroundColor Red
                Add-Alteracao -Acao $a.Descricao -Resultado "falhou: $($_.Exception.Message)"
            }
        }
    }

    Write-Host ''
    Write-Host '  Reparos gerais do Windows (só quando há sinal de arquivos do sistema corrompidos):' -ForegroundColor White
    # Verificação rápida primeiro (segundos). O DISM /RestoreHealth e o SFC levam de 10 a 40 minutos e só valem a pena se há problema.
    $estadoImg = Get-EstadoImagem
    $motivoProf = (Test-MotivoVerificacaoProfunda)
    $rodarProfunda = ($VerificacaoProfunda -or $motivoProf -or ($estadoImg -ne 'ok'))
    if ($estadoImg -eq 'ok') {
        Write-Host '  A imagem do Windows está íntegra: o DISM /RestoreHealth, que é demorado, foi dispensado.' -ForegroundColor Green
    } elseif (Confirm-Acao 'Reparar a imagem do Windows com DISM /RestoreHealth (precisa de internet; pode demorar)?') {
        try { DISM /Online /Cleanup-Image /RestoreHealth; Add-Alteracao -Acao 'DISM /RestoreHealth' -Resultado "concluído (código $LASTEXITCODE)" }
        catch { Add-Alteracao -Acao 'DISM /RestoreHealth' -Resultado "falhou: $($_.Exception.Message)" }
    }
    if (-not $rodarProfunda) {
        Write-Host '  SFC dispensado: não há sinal de arquivos do Windows corrompidos (a verificação leva muitos minutos). Para rodar mesmo assim, marque a verificação profunda em Configurações.' -ForegroundColor DarkGray
    } elseif (Confirm-Acao 'Verificar e reparar arquivos do sistema com SFC /scannow (pode demorar)?') {
        try { Invoke-Sfc; Add-Alteracao -Acao 'SFC /scannow' -Resultado "concluído (código $LASTEXITCODE)" }
        catch { Add-Alteracao -Acao 'SFC /scannow' -Resultado "falhou: $($_.Exception.Message)" }
    }
    if (Confirm-Acao 'Buscar e instalar as atualizações do Windows agora (sem abrir as Configurações)?') {
        $feito = $false
        try { $feito = [bool](Install-AtualizacoesWU) } catch { Write-Host "    Falhou: $($_.Exception.Message)" -ForegroundColor Yellow }
        # Se o serviço não respondeu (ou uma política da organização bloqueia), abre a tela como último recurso.
        if (-not $feito) { Start-Process 'ms-settings:windowsupdate' }
    }

    if ($script:Alteracoes.Count -gt 0) {
        Write-Host ''
        Write-Host '  Atualizando o relatório com as alterações feitas...' -ForegroundColor DarkGray
        try { Export-Relatorios } catch { Write-Host "  Não consegui atualizar o relatório: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
    Write-Host ''
    Write-Host '  Se algo foi alterado, reinicie o computador e rode o Telomera novamente para conferir.' -ForegroundColor Cyan
}

function Get-ResumoPC {
    # Resumo em texto simples do computador (usado pela interface gráfica; não imprime nada).
    $L = New-Object System.Collections.Generic.List[string]
    $s = $script:Sistema
    if ($s -and $s.Count -gt 0) {
        $L.Add('COMPUTADOR')
        $L.Add(('  Nome:         {0}' -f $s['Computador']))
        $L.Add(('  Modelo:       {0} {1}' -f $s['Fabricante'], $s['Modelo']))
        $L.Add(('  Windows:      {0}' -f $s['Windows']))
        $L.Add(('  BIOS/UEFI:    {0}' -f $s['BIOS']))
        $L.Add(('  Ligado há:    {0} dia(s) desde a última inicialização' -f $s['DiasLigado']))
        $L.Add('')
    }
    $hw = $script:Dados['Hardware']
    if ($hw) {
        $cpu = @($hw['Processador'])
        if ($cpu.Count -gt 0 -and $null -ne $cpu[0]) {
            $L.Add('PROCESSADOR')
            foreach ($c in $cpu) { $L.Add(('  {0} - {1} núcleos, {2} threads' -f $c.Nome, $c.Nucleos, $c.Threads)) }
            $L.Add('')
        }
        $mem = @($hw['Memoria'])
        if ($mem.Count -gt 0 -and $null -ne $mem[0]) {
            $total = 0.0
            foreach ($m in $mem) { $total += [double]$m.CapacidadeGB }
            $L.Add('MEMÓRIA RAM')
            $L.Add(('  {0} GB instalados em {1} módulo(s)' -f [math]::Round($total, 1), $mem.Count))
            foreach ($m in $mem) { $L.Add(('  - {0}: {1} GB {2} a {3} MHz' -f $m.Slot, $m.CapacidadeGB, $m.Tipo, $m.ConfiguradaMHz)) }
            $L.Add('')
        }
        $gpu = @($hw['PlacaDeVideo'])
        if ($gpu.Count -gt 0 -and $null -ne $gpu[0]) {
            $L.Add('PLACA DE VÍDEO')
            foreach ($g in $gpu) { $L.Add(('  {0} - driver {1} ({2})' -f $g.Nome, $g.Driver, $g.DataDriver)) }
            $L.Add('')
        }
        $pm = $hw['PlacaMae']
        if ($pm) {
            $L.Add('PLACA-MÃE')
            $L.Add(('  {0} {1} - firmware {2}, Secure Boot: {3}, TPM: {4}' -f $pm['Fabricante'], $pm['Modelo'], $pm['ModoFirmware'], $pm['SecureBoot'], $pm['TPM']))
            $L.Add('')
        }
    }
    $dis = @($script:Dados['Discos'])
    if ($dis.Count -gt 0 -and $null -ne $dis[0]) {
        $L.Add('DISCOS')
        foreach ($d in $dis) { $L.Add(('  {0} - {1} {2} GB, saúde: {3}' -f $d.Nome, $d.Tipo, $d.TamanhoGB, $d.Saude)) }
        $L.Add('')
    }
    $vol = @($script:Dados['Volumes'])
    if ($vol.Count -gt 0 -and $null -ne $vol[0]) {
        $L.Add('UNIDADES')
        foreach ($v in $vol) { $L.Add(('  {0}: {1} GB livres de {2} GB' -f $v.Unidade, $v.LivreGB, $v.TotalGB)) }
        $L.Add('')
    }
    if ($hw) {
        $rede = @($hw['Rede'])
        if ($rede.Count -gt 0 -and $null -ne $rede[0]) {
            $L.Add('REDE')
            foreach ($r in $rede) { $L.Add(('  {0} - {1}, {2}' -f $r.Nome, $r.Status, $r.Velocidade)) }
            $L.Add('')
        }
        $mon = @($hw['Monitores'])
        if ($mon.Count -gt 0 -and $null -ne $mon[0]) {
            $L.Add('MONITORES')
            foreach ($m in $mon) { $L.Add(('  {0} {1}' -f $m.Fabricante, $m.Modelo)) }
            $L.Add('')
        }
        $bat = @($hw['Bateria'])
        if ($bat.Count -gt 0 -and $null -ne $bat[0]) {
            $L.Add('BATERIA')
            $L.Add(('  Carga: {0}%  Saúde: {1}%  Ciclos: {2}' -f $bat[0].CargaAtual_Pct, $bat[0].Saude_Pct, $bat[0].Ciclos))
            $L.Add('')
        }
    }
    return ($L -join "`r`n")
}

function Get-DadosPC {
    # Resumo estruturado do computador para a interface (cartões). Não imprime nada.
    # Cada seção: Chave, Titulo, Destaque, Sub, Itens (R/V/Nivel) e Barras (Rotulo/Texto/Fracao/Nivel).
    $secoes = New-Object System.Collections.Generic.List[object]
    function NovaSecao([string]$Chave, [string]$Titulo, [string]$Destaque = '', [string]$Sub = '') {
        return @{ Chave = $Chave; Titulo = $Titulo; Destaque = $Destaque; Sub = $Sub
                  Itens = [System.Collections.Generic.List[object]]::new(); Barras = [System.Collections.Generic.List[object]]::new() }
    }
    $s = $script:Sistema
    if ($s -and $s.Count -gt 0) {
        $x = NovaSecao 'pc' 'Computador' "$($s['Computador'])" ("{0} {1}" -f $s['Fabricante'], $s['Modelo']).Trim()
        $x.Itens.Add(@{ R = 'Windows'; V = "$($s['Windows'])" })
        $x.Itens.Add(@{ R = 'BIOS/UEFI'; V = "$($s['BIOS'])" })
        $x.Itens.Add(@{ R = 'Ligado há'; V = ("{0} dia(s) desde a última reinicialização" -f $s['DiasLigado']) })
        $secoes.Add($x)
    }
    $hw = $script:Dados['Hardware']
    if ($hw) {
        $cpu = @($hw['Processador'])
        if ($cpu.Count -gt 0 -and $null -ne $cpu[0]) {
            $x = NovaSecao 'cpu' 'Processador' "$($cpu[0].Nome)" ("{0} núcleos · {1} threads" -f $cpu[0].Nucleos, $cpu[0].Threads)
            for ($i = 1; $i -lt $cpu.Count; $i++) { $x.Itens.Add(@{ R = "Processador $($i + 1)"; V = "$($cpu[$i].Nome)" }) }
            $secoes.Add($x)
        }
        $mem = @($hw['Memoria'])
        if ($mem.Count -gt 0 -and $null -ne $mem[0]) {
            $tot = 0.0
            foreach ($m in $mem) { $tot += [double]$m.CapacidadeGB }
            $x = NovaSecao 'ram' 'Memória RAM' ("{0} GB" -f [math]::Round($tot, 1)) ("{0} módulo(s) · {1} a {2} MHz" -f $mem.Count, $mem[0].Tipo, $mem[0].ConfiguradaMHz)
            $n = 0
            foreach ($m in $mem) { $n++; $x.Itens.Add(@{ R = "Módulo $n"; V = ("{0} GB {1} a {2} MHz ({3})" -f $m.CapacidadeGB, $m.Tipo, $m.ConfiguradaMHz, $m.Slot) }) }
            $secoes.Add($x)
        }
        $gpu = @($hw['PlacaDeVideo'])
        if ($gpu.Count -gt 0 -and $null -ne $gpu[0]) {
            foreach ($g in $gpu) {
                $x = NovaSecao 'gpu' 'Placa de vídeo' "$($g.Nome)" ''
                $x.Itens.Add(@{ R = 'Driver'; V = "$($g.Driver)" })
                $x.Itens.Add(@{ R = 'Data do driver'; V = "$($g.DataDriver)" })
                $secoes.Add($x)
            }
        }
        $pm = $hw['PlacaMae']
        if ($pm) {
            $x = NovaSecao 'mb' 'Placa-mãe' ("{0} {1}" -f $pm['Fabricante'], $pm['Modelo']).Trim() ''
            $x.Itens.Add(@{ R = 'Firmware'; V = "$($pm['ModoFirmware'])" })
            $x.Itens.Add(@{ R = 'Secure Boot'; V = "$($pm['SecureBoot'])" })
            $x.Itens.Add(@{ R = 'TPM'; V = "$($pm['TPM'])" })
            $secoes.Add($x)
        }
    }
    $dis = @($script:Dados['Discos'])
    if ($dis.Count -gt 0 -and $null -ne $dis[0]) {
        $x = NovaSecao 'disk' 'Discos' '' ''
        foreach ($d in $dis) {
            $sd = "$($d.Saude)"; $nv = 'ok'; $rot = $sd
            switch ($sd) {
                'Healthy'   { $rot = 'Saudável' }
                'Warning'   { $rot = 'Atenção'; $nv = 'aviso' }
                'Unhealthy' { $rot = 'Com problemas'; $nv = 'perigo' }
                default     { if (-not $sd) { $rot = 'Sem informação'; $nv = '' } }
            }
            $x.Itens.Add(@{ R = "$($d.Nome)"; V = ("{0} {1} GB · {2}" -f $d.Tipo, $d.TamanhoGB, $rot); Nivel = $nv })
        }
        $secoes.Add($x)
    }
    $vol = @($script:Dados['Volumes'])
    if ($vol.Count -gt 0 -and $null -ne $vol[0]) {
        $x = NovaSecao 'vol' 'Espaço nas unidades' '' ''
        foreach ($v in $vol) {
            $tot = [double]$v.TotalGB; $liv = [double]$v.LivreGB
            if ($tot -le 0) { continue }
            $usado = [Math]::Min(1.0, [Math]::Max(0.0, 1.0 - ($liv / $tot)))
            $nv = 'ok'
            if (($liv / $tot) -lt 0.10) { $nv = 'perigo' } elseif (($liv / $tot) -lt 0.20) { $nv = 'aviso' }
            $x.Barras.Add(@{ Rotulo = ("{0}:" -f ("$($v.Unidade)" -replace ':', '')); Texto = ("{0} GB livres de {1} GB" -f $v.LivreGB, $v.TotalGB); Fracao = $usado; Nivel = $nv })
        }
        if ($x.Barras.Count -gt 0) { $secoes.Add($x) }
    }
    if ($hw) {
        $rede = @($hw['Rede'])
        if ($rede.Count -gt 0 -and $null -ne $rede[0]) {
            $x = NovaSecao 'net' 'Rede' '' ''
            foreach ($r in $rede) {
                $nv = ''; if ("$($r.Status)" -eq 'Up') { $nv = 'ok' }
                $x.Itens.Add(@{ R = "$($r.Nome)"; V = ("{0} · {1}" -f $r.Status, $r.Velocidade); Nivel = $nv })
            }
            $secoes.Add($x)
        }
        $mon = @($hw['Monitores'])
        if ($mon.Count -gt 0 -and $null -ne $mon[0]) {
            $x = NovaSecao 'mon' 'Monitores' '' ''
            $n = 0
            foreach ($m in $mon) { $n++; $x.Itens.Add(@{ R = "Monitor $n"; V = ("{0} {1}" -f $m.Fabricante, $m.Modelo).Trim() }) }
            $secoes.Add($x)
        }
        $bat = @($hw['Bateria'])
        if ($bat.Count -gt 0 -and $null -ne $bat[0]) {
            $x = NovaSecao 'bat' 'Bateria' '' ''
            if ($null -ne $bat[0].CargaAtual_Pct) {
                $x.Barras.Add(@{ Rotulo = 'Carga'; Texto = ("{0}%" -f $bat[0].CargaAtual_Pct); Fracao = ([double]$bat[0].CargaAtual_Pct / 100.0); Nivel = 'ok' })
            }
            if ($null -ne $bat[0].Saude_Pct) {
                $nv = 'ok'; if ($bat[0].Saude_Pct -lt 60) { $nv = 'perigo' } elseif ($bat[0].Saude_Pct -lt 80) { $nv = 'aviso' }
                $x.Barras.Add(@{ Rotulo = 'Saúde'; Texto = ("{0}% da capacidade original" -f $bat[0].Saude_Pct); Fracao = ([double]$bat[0].Saude_Pct / 100.0); Nivel = $nv })
            }
            if ($null -ne $bat[0].Ciclos) { $x.Itens.Add(@{ R = 'Ciclos de carga'; V = "$($bat[0].Ciclos)" }) }
            $secoes.Add($x)
        }
    }
    # Listas viram vetores simples (@() sobre List[object] falha em alguns ambientes).
    foreach ($sc in $secoes) {
        $sc['Itens'] = $sc['Itens'].ToArray()
        $sc['Barras'] = $sc['Barras'].ToArray()
    }
    # Drivers: um cartão por tipo (vídeo, rede, áudio...), com a situação de cada um em palavras simples.
    try {
        $lstDrv = @(Get-DriversParaLista)
        if ($lstDrv.Count -gt 0 -and (Get-Command Get-EstadoDriverItem -ErrorAction SilentlyContinue)) {
            $x = NovaSecao 'drivers' 'Drivers' '' 'O que está instalado e se precisa de atenção. Reparos e downloads: Ferramentas > Drivers.'
            $nBons = 0
            foreach ($d in ($lstDrv | Sort-Object -Property @{ Expression = { "$($_.Classe)" } }, @{ Expression = { "$($_.Nome)" } })) {
                $marcas = @(Get-EstadoDriverItem $d)
                $nome = $(if ($script:ClassesDriver.Contains("$($d.Classe)")) { $script:ClassesDriver["$($d.Classe)"].Nome } else { "$($d.Classe)" })
                $dt = $(if ($d.Data) { $d.Data.ToString('MM/yyyy') } else { '?' })
                $txt = "$($d.Nome) · v$($d.Versao) · $dt"
                if ($marcas.Count -gt 0) { $x.Itens.Add(@{ R = $nome; V = ($txt + ' · ' + ($marcas -join ', ').ToLower()); Nivel = $(if ([int]$d.Erro -ne 0 -or $d.Assinado -eq $false) { 'perigo' } else { 'aviso' }) }) }
                else { $nBons++; $x.Itens.Add(@{ R = $nome; V = ($txt + ' · ok'); Nivel = 'ok' }) }
            }
            $x.Destaque = $(if ($nBons -eq $lstDrv.Count) { 'Tudo em ordem' } else { "$($lstDrv.Count - $nBons) para olhar" })
            $secoes.Add($x)
        }
    } catch { }
    return $secoes.ToArray()
}

function New-PastaVerificacao {
    # Cada verificação ganha a sua própria pasta (Verificacao_AAAA-MM-DD_HH-mm-ss) dentro da pasta base.
    # Log, relatórios, cópia de drivers e pacotes removidos dessa verificação ficam todos lá dentro.
    param([string]$Base)
    if (-not $Base) { $Base = Join-Path ([Environment]::GetFolderPath('Desktop')) 'WinDiag' }
    $quando = "$($script:Stamp)" -replace '^(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})$', '$1-$2-$3_$4-$5-$6'
    $nome = "Verificacao_$quando"
    foreach ($b in @($Base, (Join-Path ([IO.Path]::GetTempPath()) 'WinDiag'))) {
        try {
            $p = Join-Path $b $nome
            New-Item -ItemType Directory -Force -Path $p -ErrorAction Stop | Out-Null
            return $p
        } catch { }
    }
    throw 'Não foi possível criar uma pasta para os relatórios.'
}

# Verificações extras, ferramentas de reparo, comparação e histórico
$arqExtras = Join-Path $PSScriptRoot 'WinDiag-Extras.ps1'
if (Test-Path -LiteralPath $arqExtras) { . $arqExtras }
$arqMonitor = Join-Path $PSScriptRoot 'WinDiag-Monitor.ps1'
if (Test-Path -LiteralPath $arqMonitor) { . $arqMonitor }

# Gancho para testes automatizados: carrega só as funções e sai.
if ($env:WINDIAG_TESTE -eq '1') { return }

# ----------------------------------------------------------------------------
# Execução principal
# ----------------------------------------------------------------------------
if ($env:OS -ne 'Windows_NT') {
    Write-Host 'O Telomera funciona apenas no Windows.' -ForegroundColor Red
    exit 1
}

$script:IsAdmin = Test-Administrador
if (-not $script:IsAdmin -and $PSCommandPath) {
    Write-Host 'Pedindo permissão de administrador (necessária para SMART, DISM e reparos)...' -ForegroundColor Yellow
    $argLista = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath))
    foreach ($chave in $PSBoundParameters.Keys) {
        $valor = $PSBoundParameters[$chave]
        if ($valor -is [switch]) {
            if ($valor.IsPresent) { $argLista += "-$chave" }
        } else {
            $argLista += "-$chave"
            $argLista += ('"{0}"' -f $valor)
        }
    }
    try {
        Start-Process -FilePath (Get-Process -Id $PID).Path -ArgumentList $argLista -Verb RunAs -ErrorAction Stop
        exit
    } catch {
        Write-Host 'Permissão de administrador não concedida. Seguindo em modo limitado e somente leitura.' -ForegroundColor Yellow
    }
}
if (-not $script:IsAdmin) { $SomenteLeitura = $true }

if ($Agendada) {
    # Verificação automática: só leitura, sem internet, sem abrir relatório, relatórios em %LOCALAPPDATA%\WinDiag\Agendadas.
    $script:Agendada = $true
    $SomenteLeitura = $true; $NaoAbrirRelatorio = $true; $SemWindowsUpdate = $true; $PularScanVolumes = $true
    if (-not $PastaRelatorio -and (Get-Command Get-ArquivoDados -ErrorAction SilentlyContinue)) { $PastaRelatorio = Get-ArquivoDados 'Agendadas' }
}

if ($DesfazerBloqueios) {
    if (-not $script:IsAdmin) {
        Write-Host 'É preciso executar como administrador para desfazer os bloqueios.' -ForegroundColor Red
        Read-Resposta 'Pressione Enter para sair' | Out-Null
        exit 1
    }
    Remove-BloqueiosWinDiag
    Remove-ExclusaoDriversWU
    Write-Host 'Pronto. Reinicie o computador para concluir.' -ForegroundColor Green
    Read-Resposta 'Pressione Enter para sair' | Out-Null
    exit 0
}

$PastaRelatorio = New-PastaVerificacao -Base $PastaRelatorio
$script:PastaRelatorioFinal = $PastaRelatorio
$script:ArquivoLog  = Join-Path $PastaRelatorio "WinDiag_$($script:Stamp).log"
$script:ArquivoHtml = Join-Path $PastaRelatorio "WinDiag_$($script:Stamp).html"
$script:ArquivoJson = Join-Path $PastaRelatorio "WinDiag_$($script:Stamp).json"

if (-not (Test-Prerequisitos)) {
    Read-Resposta 'Pressione Enter para sair' | Out-Null
    exit 1
}

$transcrito = $false
try { Start-Transcript -Path $script:ArquivoLog | Out-Null; $transcrito = $true } catch { }

Write-Host ''
Write-Host "Telomera v$($script:Versao) - diagnóstico de discos e drivers" -ForegroundColor Cyan
if ($SomenteLeitura) {
    Write-Host 'Modo: SOMENTE LEITURA (nenhuma alteração será feita)' -ForegroundColor Yellow
} else {
    Write-Host 'Modo: diagnóstico + reparos com confirmação' -ForegroundColor Green
}
Write-Host "Relatórios em: $PastaRelatorio" -ForegroundColor DarkGray

try {
    Invoke-Secao 'Informações do sistema' { Get-InfoSistema }
    Invoke-Secao 'Hardware' { Invoke-AnaliseHardware }
    Invoke-Secao 'Discos' { Invoke-AnaliseDiscos }
    Invoke-Secao 'Volumes' { Invoke-AnaliseVolumes }
    Invoke-Secao 'Eventos' { Invoke-AnaliseEventos }
    Invoke-Secao 'Drivers' { Invoke-AnaliseDrivers }
    Invoke-Secao 'Segurança e manutenção' { Invoke-AnaliseExtras }
    if ($VerificacaoProfunda) { Invoke-Secao 'Verificação profunda' { Invoke-AnaliseProfunda } }
    Write-Resumo
    $script:Comparacao = Get-ComparacaoVerificacoes
    Invoke-Secao 'Relatórios' { Export-Relatorios }
    Save-UltimaVerificacao
    if ($script:Agendada) { try { [void](Invoke-AvisoAgendado); Remove-VerificacoesAgendadasAntigas } catch { } }
    if (-not $NaoAbrirRelatorio -and (Test-Path -LiteralPath $script:ArquivoHtml)) {
        try { Start-Process $script:ArquivoHtml } catch { }
        Write-Host ''
        Write-Host '  O relatório foi aberto no navegador. Leia com calma e volte aqui para decidir os reparos.' -ForegroundColor Cyan
    }
    Invoke-Secao 'Reparos' { Invoke-FaseReparo }
} catch {
    Write-Host ''
    Write-Host "Erro inesperado: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
} finally {
    if ($transcrito) { try { Stop-Transcript | Out-Null } catch { } }
}

Write-Host ''
Read-Resposta 'Pressione Enter para sair' | Out-Null
