﻿<#
.SYNOPSIS
    Cria o atalho do WinDiag (com o ícone do escudo) na Área de Trabalho e no Menu Iniciar.

.DESCRIPTION
    Use o arquivo Criar-Atalho.bat (duplo clique). O atalho abre a interface gráfica sem a janela preta
    e, se você quiser, sempre como administrador (necessário para corrigir problemas).
    Também remove o "bloqueio da internet" dos arquivos do ZIP baixado, evitando avisos do Windows.
#>
param([switch]$SemPerguntas, [switch]$ComoAdministrador, [switch]$Silencioso)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$pasta = $PSScriptRoot
$gui = Join-Path $pasta 'WinDiag-GUI.ps1'
if (-not (Test-Path -LiteralPath $gui)) {
    if (-not $Silencioso) { Write-Host 'Não encontrei o WinDiag-GUI.ps1 nesta pasta. Extraia o ZIP inteiro antes.' -ForegroundColor Red }
    return $false
}

# Arquivos baixados da internet vêm "bloqueados" pelo Windows; isso gera avisos ao abrir. Aqui eles são liberados.
if (-not $Silencioso) { try { Get-ChildItem -LiteralPath $pasta -Recurse -File | Unblock-File -ErrorAction SilentlyContinue } catch { } }

if (-not $SemPerguntas -and -not $Silencioso) {
    $r = Read-Host 'Abrir sempre como administrador? Necessário para corrigir problemas (o Windows vai pedir permissão a cada abertura) [S/n]'
    $ComoAdministrador = ($r -notmatch '^\s*[nN]')
}

# Ícone do WinDiag (ou o escudo, se o arquivo faltar), gravado em uma pasta que não muda de lugar
$dados = Join-Path $env:LOCALAPPDATA 'WinDiag'
New-Item -ItemType Directory -Force -Path $dados | Out-Null
$ico = Join-Path $dados 'windiag-app.ico'   # nome novo: o Explorer guarda o ícone antigo em cache pelo caminho
$icoPacote = Join-Path $PSScriptRoot 'windiag.ico'
if (Test-Path -LiteralPath $icoPacote) {
    Copy-Item -LiteralPath $icoPacote -Destination $ico -Force
} else {
    $fs = [System.IO.File]::Create($ico)
    try { [System.Drawing.SystemIcons]::Shield.Save($fs) } finally { $fs.Dispose() }
}

$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

$h = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $gui)
$ps = $h.Exe
$argumentos = $h.Args

function New-Atalho {
    param([string]$Caminho)
    $ws = New-Object -ComObject WScript.Shell
    $l = $ws.CreateShortcut($Caminho)
    $l.TargetPath = $ps
    $l.Arguments = $argumentos
    $l.WorkingDirectory = $pasta
    $l.IconLocation = "$ico,0"
    $l.Description = 'Telomera - diagnóstico de drivers, discos e hardware'
    $l.WindowStyle = 7
    $l.Save()
    if ($ComoAdministrador) {
        # Liga a opção "Executar como administrador" do atalho (bit 0x20 do byte 0x15)
        $b = [System.IO.File]::ReadAllBytes($Caminho)
        $b[0x15] = $b[0x15] -bor 0x20
        [System.IO.File]::WriteAllBytes($Caminho, $b)
    }
}

$criados = New-Object System.Collections.Generic.List[string]
$destinos = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Telomera.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Telomera.lnk')
)
foreach ($d in $destinos) {
    try { New-Atalho -Caminho $d; $criados.Add($d) }
    catch { if (-not $Silencioso) { Write-Host ("Não foi possível criar {0}: {1}" -f $d, $_.Exception.Message) -ForegroundColor Yellow } }
}

if ($criados.Count -gt 0) {
    try { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden } catch { }   # atualiza o cache de ícones
    if (-not $Silencioso) {
        Write-Host ''
        Write-Host 'Pronto! Atalhos criados:' -ForegroundColor Green
        $criados | ForEach-Object { Write-Host "  $_" }
        Write-Host ''
        Write-Host 'Para fixar na barra de tarefas: abra o WinDiag pelo atalho, clique com o botão direito no ícone da barra e escolha "Fixar na barra de tarefas".'
    }
    return $true
}
if (-not $Silencioso) { exit 1 }
return $false
