@echo off
title Desinstalar o Telomera
rem Abre a janela de desinstalacao (sem janela preta). Para o modo texto: Desinstalar-Telomera.ps1 -SemPerguntas
rem No Windows 11 o Terminal do Windows ignora a janela oculta; "conhost --headless" abre sem nenhuma janela.
setlocal
set "BUILD=0"
for /f "tokens=3 delims=." %%a in ('ver') do set "BUILD=%%a"
set "PRE="
if %BUILD% GEQ 22000 if exist "%SystemRoot%\System32\conhost.exe" set "PRE=conhost.exe --headless "
start "" %PRE%powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0Desinstalar-Telomera.ps1"
