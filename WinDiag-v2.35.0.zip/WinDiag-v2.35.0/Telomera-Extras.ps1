﻿# Telomera-Extras.ps1
# Verificações extras (telas azuis, segurança, bateria, espaço, rede), ferramentas de reparo e restauração,
# comparação com a verificação anterior e histórico de alterações.
# Carregado pelo Telomera.ps1 (depois das funções principais). Usa Add-Achado, Add-Acao, Confirm-Acao e Add-Alteracao do motor.

# ----------------------------------------------------------------------------
# Dados persistentes (ficam em %LOCALAPPDATA%\Telomera)
# ----------------------------------------------------------------------------
function Get-ArquivoDados {
    param([string]$Nome)
    $base = $env:WD_DADOS_DIR
    if (-not $base) {
        $la = $env:LOCALAPPDATA
        if (-not $la) { $la = [IO.Path]::GetTempPath() }
        $base = Join-Path $la 'Telomera'
    }
    return (Join-Path $base $Nome)
}

function Save-LogAlteracao {
    # Acrescenta uma linha por alteração em alteracoes.jsonl: é o histórico de tudo que o Telomera já mudou neste computador.
    param([string]$Acao, [string]$Resultado, [string]$Quando)
    try {
        $f = Get-ArquivoDados 'alteracoes.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $linha = (@{ Quando = $Quando; Acao = $Acao; Resultado = $Resultado } | ConvertTo-Json -Compress)
        [IO.File]::AppendAllText($f, $linha + "`r`n", (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Get-HistoricoAlteracoes {
    $f = Get-ArquivoDados 'alteracoes.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-DicaDesfazer {
    # Como desfazer, conforme o tipo de alteração.
    param([string]$Acao)
    if ($Acao -match '(?i)bloqueio|exclus') { return 'Para desfazer: "Desfazer bloqueios de driver do Telomera" (Ferramentas de reparo > Desfazer o que o Telomera fez).' }
    if ($Acao -match '(?i)driver|pacote|restaurar c') { return 'Para desfazer: "Desfazer correções (restaurar drivers salvos)" ou a Restauração do Sistema.' }
    if ($Acao -match '(?i)tempor|limpeza') { return 'Não há como desfazer: eram arquivos temporários, que o Windows recria quando precisa.' }
    if ($Acao -match '(?i)backup|c.pia dos arquivos') { return 'Não altera nada no computador: é só uma cópia de arquivos.' }
    if ($Acao -match '(?i)rede|winsock|dns') { return 'Normalmente não precisa desfazer. Se perdeu uma configuração de rede fixa, refaça-a nas propriedades do adaptador.' }
    return 'Para desfazer: Restauração do Sistema, escolhendo o ponto criado antes da correção.'
}

function Format-TextoHistoricoAlteracoes {
    $itens = @(Get-HistoricoAlteracoes)
    if ($itens.Count -eq 0) { return 'O Telomera ainda não alterou nada neste computador.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("O Telomera fez $($itens.Count) alteração(ões) neste computador (da mais recente para a mais antiga):")
    $L.Add('')
    foreach ($i in ($itens | Sort-Object { "$($_.Quando)" } -Descending | Select-Object -First 200)) {
        $L.Add("$($i.Quando)  -  $($i.Acao)")
        $L.Add("    Resultado: $($i.Resultado)")
        $L.Add("    $(Get-DicaDesfazer $i.Acao)")
        $L.Add('')
    }
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Comparação com a verificação anterior
# ----------------------------------------------------------------------------
function Get-ChaveAchado {
    param([string]$Titulo)
    return ((("$Titulo" -replace '\d+', '#') -replace '\s+', ' ').Trim().ToLowerInvariant())
}

function Get-ComparacaoVerificacoes {
    # Compara os achados (atenção e críticos) desta verificação com os da anterior. $null se não há anterior.
    $f = Get-ArquivoDados 'ultima_verificacao.json'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { $ant = Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
    if (-not $ant -or -not $ant.Achados) { return $null }
    $atuais = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })
    $chavesAtuais = @{}
    foreach ($a in $atuais) { $chavesAtuais[(Get-ChaveAchado $a.Titulo)] = $a.Titulo }
    $chavesAnt = @{}
    foreach ($a in @($ant.Achados)) { $chavesAnt["$($a.Chave)"] = "$($a.Titulo)" }
    $novos = @($chavesAtuais.Keys | Where-Object { -not $chavesAnt.ContainsKey($_) } | ForEach-Object { $chavesAtuais[$_] })
    $resolvidos = @($chavesAnt.Keys | Where-Object { -not $chavesAtuais.ContainsKey($_) } | ForEach-Object { $chavesAnt[$_] })
    $persistem = @($chavesAtuais.Keys | Where-Object { $chavesAnt.ContainsKey($_) }).Count
    return @{ Data = "$($ant.Data)"; Novos = $novos; Resolvidos = $resolvidos; Persistem = $persistem }
}

function Save-UltimaVerificacao {
    try {
        $f = Get-ArquivoDados 'ultima_verificacao.json'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $lista = @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' } | ForEach-Object {
            @{ Chave = (Get-ChaveAchado $_.Titulo); Titulo = $_.Titulo; Gravidade = $_.Gravidade }
        })
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Achados = $lista }
        ($o | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $f -Encoding UTF8
    } catch { }
    Save-NotaSaude
}

function Format-TextoComparacao {
    param($C)
    if (-not $C) { return '' }
    $p = @()
    if (@($C.Novos).Count -gt 0) { $p += "$(@($C.Novos).Count) novo(s)" }
    if (@($C.Resolvidos).Count -gt 0) { $p += "$(@($C.Resolvidos).Count) resolvido(s)" }
    if ($C.Persistem -gt 0) { $p += "$($C.Persistem) continua(m)" }
    if ($p.Count -eq 0) { return "Em relação à verificação de $($C.Data): nenhum ponto de atenção, antes e agora." }
    return "Em relação à verificação de $($C.Data): " + ($p -join ', ') + '.'
}

function ConvertTo-HtmlComparacao {
    param($C)
    if (-not $C) { return '<p class="vazio">Esta é a primeira verificação guardada neste computador.</p>' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<p>' + [System.Net.WebUtility]::HtmlEncode((Format-TextoComparacao $C)) + '</p>')
    if (@($C.Novos).Count -gt 0) {
        [void]$sb.Append('<p><b>Novos:</b></p><ul>')
        foreach ($t in $C.Novos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    if (@($C.Resolvidos).Count -gt 0) {
        [void]$sb.Append('<p><b>Resolvidos:</b></p><ul>')
        foreach ($t in $C.Resolvidos) { [void]$sb.Append('<li>' + [System.Net.WebUtility]::HtmlEncode($t) + '</li>') }
        [void]$sb.Append('</ul>')
    }
    return $sb.ToString()
}

# ----------------------------------------------------------------------------
# Nota de saúde (0 a 100) e tendência ao longo das verificações
# ----------------------------------------------------------------------------
function Get-NotaSaude {
    # Nota simples a partir dos achados desta verificação. É um guia, não um laudo.
    # Crítico desconta 12 e atenção 4; se o achado é "provavelmente normal" ou opcional, desconta um quarto.
    # Cada categoria desconta no máximo 30, para que uma enxurrada de avisos do mesmo tipo não zere a nota.
    param()
    $porCat = @{}
    $nc = 0; $na = 0
    foreach ($a in @($script:Achados | Where-Object { $_.Gravidade -ne 'Info' })) {
        $p = if ($a.Gravidade -eq 'Critico') { 12 } else { 4 }
        if ($a.Gravidade -eq 'Critico') { $nc++ } else { $na++ }
        if ($a.Veredito -eq 'Normal' -or $a.Veredito -eq 'Opcional') { $p = [Math]::Ceiling($p / 4) }
        $cat = "$($a.Categoria)"
        if (-not $porCat.ContainsKey($cat)) { $porCat[$cat] = 0 }
        $porCat[$cat] += $p
    }
    $desc = 0
    foreach ($v in $porCat.Values) { $desc += [Math]::Min(30, [int]$v) }
    $nota = [int][Math]::Max(0, 100 - $desc)
    if ($nota -ge 90) { $rot = 'Ótima' } elseif ($nota -ge 75) { $rot = 'Boa' } elseif ($nota -ge 55) { $rot = 'Merece atenção' } else { $rot = 'Precisa de cuidado' }
    return @{ Nota = $nota; Rotulo = $rot; Criticos = $nc; Atencoes = $na }
}

function Get-HistoricoNotas {
    $f = Get-ArquivoDados 'saude.jsonl'
    $lista = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $f) {
        foreach ($l in (Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if (-not "$l".Trim()) { continue }
            try { $lista.Add(($l | ConvertFrom-Json)) } catch { }
        }
    }
    return $lista.ToArray()
}

function Get-NotaAtual {
    # Calcula a nota desta verificação e guarda a nota anterior (lida do histórico uma única vez por execução).
    $script:NotaSaude = Get-NotaSaude
    if (-not $script:NotaAnteriorLida) {
        $script:NotaAnteriorLida = $true
        $h = @(Get-HistoricoNotas)
        if ($h.Count -gt 0) { $script:NotaAnterior = $h[$h.Count - 1] } else { $script:NotaAnterior = $null }
    }
    return $script:NotaSaude
}

function Save-NotaSaude {
    try {
        $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
        $f = Get-ArquivoDados 'saude.jsonl'
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $origem = if ($script:Agendada) { 'agendada' } else { 'manual' }
        $linha = (@{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Nota = $n.Nota; Rotulo = $n.Rotulo; Criticos = $n.Criticos; Atencoes = $n.Atencoes; Origem = $origem } | ConvertTo-Json -Compress)
        $todas = @()
        if (Test-Path -LiteralPath $f) { $todas = @(Get-Content -LiteralPath $f -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { "$_".Trim() }) }
        $todas = @($todas + $linha)
        if ($todas.Count -gt 100) { $todas = $todas[($todas.Count - 100)..($todas.Count - 1)] }
        [IO.File]::WriteAllText($f, (($todas -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
}

function Format-TextoNota {
    # "Nota de saúde: 82/100 (Boa), 5 pontos acima da verificação anterior."
    param($N = $script:NotaSaude, $Anterior = $script:NotaAnterior)
    if (-not $N) { return '' }
    $t = "Nota de saúde do computador: $($N.Nota)/100 ($($N.Rotulo))"
    if ($Anterior -and $null -ne $Anterior.Nota) {
        $d = [int]$N.Nota - [int]$Anterior.Nota
        if ($d -gt 0) { $t += ", $d ponto(s) acima da verificação anterior" }
        elseif ($d -lt 0) { $t += ", $(-$d) ponto(s) abaixo da verificação anterior" }
        else { $t += ', igual à verificação anterior' }
    }
    return $t + '.'
}

function ConvertTo-HtmlNota {
    $n = Get-NotaAtual
    $txt = [System.Net.WebUtility]::HtmlEncode((Format-TextoNota))
    return "<p><b>$txt</b></p><p class=`"vazio`">A nota é só um guia: começa em 100 e perde pontos por problema encontrado (mais por críticos, menos por avisos que costumam ser normais). Não substitui a leitura dos itens.</p>"
}

function Get-BarraNota {
    param([int]$Nota)
    $n = [Math]::Max(0, [Math]::Min(100, $Nota))
    $cheio = [int][Math]::Round($n / 10)
    return ([string]([char]0x2588) * $cheio) + ([string]([char]0x2591) * (10 - $cheio))
}

function Format-TextoHistoricoNotas {
    $h = @(Get-HistoricoNotas)
    if ($h.Count -eq 0) { return 'Ainda não há verificações guardadas. Depois da primeira verificação, a nota aparece aqui.' }
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add("Nota de saúde do computador nas últimas verificações (da mais recente para a mais antiga):")
    $L.Add('')
    $ult = $h | Select-Object -Last 20
    $lista = @($ult)
    for ($i = $lista.Count - 1; $i -ge 0; $i--) {
        $x = $lista[$i]
        $seta = ''
        if ($i -gt 0) {
            $d = [int]$x.Nota - [int]$lista[$i - 1].Nota
            if ($d -gt 0) { $seta = "  (+$d)" } elseif ($d -lt 0) { $seta = "  ($d)" }
        }
        $orig = if ("$($x.Origem)" -eq 'agendada') { ' [automática]' } else { '' }
        $L.Add(("{0}   {1}  {2,3}/100  {3}{4}{5}" -f $x.Data, (Get-BarraNota ([int]$x.Nota)), [int]$x.Nota, $x.Rotulo, $seta, $orig))
    }
    $L.Add('')
    $L.Add('A nota começa em 100 e perde pontos por problema encontrado. É um guia para acompanhar a tendência, não um laudo.')
    return ($L -join "`r`n")
}

# ----------------------------------------------------------------------------
# Verificação semanal automática (somente leitura) e aviso quando a saúde piora
# ----------------------------------------------------------------------------
$script:NomeTarefa = 'Telomera - verificação semanal'

function Get-TarefaAgendada {
    try { return (Get-ScheduledTask -TaskName $script:NomeTarefa -ErrorAction Stop) } catch { return $null }
}

function Get-TextoTarefaAgendada {
    $t = Get-TarefaAgendada
    if (-not $t) { return 'A verificação semanal automática está desativada.' }
    $prox = ''
    try {
        $i = Get-ScheduledTaskInfo -TaskName $script:NomeTarefa -ErrorAction Stop
        if ($i.NextRunTime -and $i.NextRunTime.Year -gt 2000) { $prox = ' Próxima execução: ' + $i.NextRunTime.ToString('dd/MM/yyyy HH:mm') + '.' }
    } catch { }
    return 'A verificação semanal automática está ativada.' + $prox
}

function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

function Enable-VerificacaoAgendada {
    # Cria a tarefa semanal. Ela só lê informações (Telomera.ps1 -Agendada = somente leitura, sem internet, sem abrir relatório).
    param([string]$Dia = 'Sunday', [string]$Hora = '10:00')
    $dir = $PSScriptRoot
    if (-not $dir -and $global:WD_Opc) { $dir = [string]$global:WD_Opc.PastaScripts }
    $ps1 = Join-Path $dir 'Telomera.ps1'
    if (-not $dir -or -not (Test-Path -LiteralPath $ps1)) { throw 'Não encontrei o Telomera.ps1 para agendar.' }
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Agendada' -f $ps1
    $h = Get-ArgsOculto $arg
    $acao = New-ScheduledTaskAction -Execute $h.Exe -Argument $h.Args -WorkingDirectory $dir
    $gatilho = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $Dia -At $Hora
    $cfg = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    $usuario = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $prin = New-ScheduledTaskPrincipal -UserId $usuario -LogonType Interactive -RunLevel Highest
    [void](Register-ScheduledTask -TaskName $script:NomeTarefa -Action $acao -Trigger $gatilho -Settings $cfg -Principal $prin `
        -Description 'Telomera: verificação semanal somente leitura. Não altera nada no computador; avisa se a saúde piorar.' -Force -ErrorAction Stop)
}

function Disable-VerificacaoAgendada {
    if (Get-TarefaAgendada) { Unregister-ScheduledTask -TaskName $script:NomeTarefa -Confirm:$false -ErrorAction Stop }
}

function Get-ArquivoAviso { return (Get-ArquivoDados 'aviso.json') }

function Get-AvisoPendente {
    $f = Get-ArquivoAviso
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { return (Get-Content -LiteralPath $f -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json) } catch { return $null }
}

function Clear-AvisoPendente {
    try { $f = Get-ArquivoAviso; if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction Stop } } catch { }
}

function Show-AvisoBalao {
    param([string]$Titulo, [string]$Texto)
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ni.Icon = $(try { New-Object System.Drawing.Icon((Join-Path $PSScriptRoot 'telomera.ico')) } catch { [System.Drawing.SystemIcons]::Shield })
        $ni.Visible = $true
        $ni.BalloonTipTitle = $Titulo
        $ni.BalloonTipText = $Texto
        $ni.BalloonTipIcon = 'Warning'
        $ni.ShowBalloonTip(10000)
        Start-Sleep -Seconds 10
        $ni.Dispose()
    } catch { }
}

function Invoke-AvisoAgendado {
    # Depois da verificação automática: só avisa se a saúde piorou (nota caiu 5 pontos ou mais, ou há mais críticos).
    $n = if ($script:NotaSaude) { $script:NotaSaude } else { Get-NotaSaude }
    $ant = $script:NotaAnterior
    if (-not $ant -or $null -eq $ant.Nota) { return $false }
    $piorou = (([int]$n.Nota) -le ([int]$ant.Nota - 5)) -or (([int]$n.Criticos) -gt ([int]$ant.Criticos))
    if (-not $piorou) { return $false }
    $texto = "A verificação automática de hoje encontrou algo novo: a nota de saúde foi de $($ant.Nota) para $($n.Nota) ($($n.Rotulo)). Abra o Telomera e rode uma verificação para ver os detalhes."
    try {
        $f = Get-ArquivoAviso
        $dir = Split-Path -Parent $f
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $o = @{ Data = (Get-Date -Format 'dd/MM/yyyy HH:mm'); Texto = $texto; Nota = [int]$n.Nota; NotaAnterior = [int]$ant.Nota; Pasta = "$($script:PastaRelatorioFinal)" }
        [IO.File]::WriteAllText($f, ($o | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
    } catch { }
    Show-AvisoBalao -Titulo 'Telomera: a saúde do computador piorou' -Texto $texto
    return $true
}

function Remove-VerificacoesAgendadasAntigas {
    # As verificações automáticas ficam em %LOCALAPPDATA%\Telomera\Agendadas; só as 4 mais recentes são mantidas.
    param([int]$Manter = 4)
    try {
        $base = Get-ArquivoDados 'Agendadas'
        if (-not (Test-Path -LiteralPath $base)) { return }
        $pastas = @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction Stop | Where-Object { $_.Name -like 'Verificacao_*' } | Sort-Object Name -Descending)
        foreach ($p in ($pastas | Select-Object -Skip $Manter)) { Remove-Item -LiteralPath $p.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    } catch { }
}

# ----------------------------------------------------------------------------
# Telas azuis (arquivos de despejo)
# ----------------------------------------------------------------------------
function Read-DadosDump {
    # Lê, no cabeçalho do .dmp (Windows de 64 e de 32 bits), o código da tela azul e os 4 parâmetros dele.
    param([string]$Caminho)
    try {
        $fs = [IO.File]::Open($Caminho, 'Open', 'Read', 'ReadWrite')
        try {
            $b = New-Object byte[] 0x80
            $n = $fs.Read($b, 0, $b.Length)
            if ($n -lt 0x40) { return $null }
        } finally { $fs.Dispose() }
        $sig = [Text.Encoding]::ASCII.GetString($b, 0, 8)
        if ($sig -eq 'PAGEDU64' -and $n -ge 0x60) {
            return @{ Codigo = ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x38)); Parametros = @(0..3 | ForEach-Object { '0x{0:X}' -f [BitConverter]::ToUInt64($b, 0x40 + 8 * $_) }) }
        }
        if ($sig -eq 'PAGEDUMP' -and $n -ge 0x30) {
            return @{ Codigo = ('0x{0:X8}' -f [BitConverter]::ToUInt32($b, 0x20)); Parametros = @(0..3 | ForEach-Object { '0x{0:X}' -f [BitConverter]::ToUInt32($b, 0x24 + 4 * $_) }) }
        }
    } catch { }
    return $null
}

function Read-CodigoDump {
    param([string]$Caminho)
    $d = Read-DadosDump $Caminho
    if ($d) { return $d.Codigo }
    return $null
}

function Invoke-AnaliseTelasAzuis {
    if (-not $env:SystemRoot) { return }
    $pasta = Join-Path $env:SystemRoot 'Minidump'
    $arqs = @()
    try {
        if (Test-Path -LiteralPath $pasta) { $arqs = @(Get-ChildItem -LiteralPath $pasta -Filter *.dmp -File -ErrorAction Stop) }
    } catch {
        Write-Host '  Telas azuis: não consegui ler a pasta de despejos (precisa de administrador).' -ForegroundColor DarkGray
        return
    }
    if ($arqs.Count -eq 0) {
        Write-Host '  Telas azuis: nenhum arquivo de despejo.' -ForegroundColor Green
        return
    }
    $cont = @{}
    $cada = New-Object System.Collections.Generic.List[string]
    foreach ($a in ($arqs | Sort-Object LastWriteTime -Descending)) {
        $dd = Read-DadosDump $a.FullName
        $c = $null; if ($dd) { $c = $dd.Codigo }
        if (-not $c) { $c = 'desconhecido' }
        if ($cont.ContainsKey($c)) { $cont[$c]++ } else { $cont[$c] = 1 }
        if ($cada.Count -lt 12) {
            $pp = ''; if ($dd) { $pp = ' [' + ($dd.Parametros -join ', ') + ']' }
            $cada.Add(('{0} {1}{2}' -f $a.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), $c, $pp))
        }
    }
    $linhas = @($cont.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object {
        if ($_.Key -eq 'desconhecido') { "código não identificado (x$($_.Value))" }
        else { '{0} {1} (x{2})' -f $_.Key, (Get-DescricaoBugcheck $_.Key), $_.Value }
    })
    $ultimo = ($arqs | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    Add-Achado -Gravidade Atencao -Categoria 'Telas azuis' -Titulo "Telas azuis registradas: $($arqs.Count) arquivo(s) de despejo" `
        -Detalhe ("Última em $ultimo. " + ($linhas -join ' | ') + ' | Uma a uma (data, código e parâmetros): ' + ($cada -join '; ')) `
        -Solucao 'Anote o código. Os mais comuns são causados por driver (atualize o de vídeo e o de rede), memória RAM (use o teste de desempenho) ou disco. Para ver qual driver causou, abra o arquivo .dmp em C:\Windows\Minidump com o BlueScreenView (NirSoft) ou o WinDbg.' `
        -Explicacao 'Cada arquivo na pasta Minidump é uma tela azul que realmente aconteceu. Uma ou duas, com motivo conhecido (queda de energia, driver recém-instalado), costumam ser normais; se se repetem, vale investigar o código mostrado.' `
        -Veredito 'Depende'
}

# ----------------------------------------------------------------------------
# Segurança e manutenção
# ----------------------------------------------------------------------------
function Invoke-AnaliseSeguranca {
    $avDefenderOk = $null
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        $avDefenderOk = ([bool]$mp.AntivirusEnabled -and [bool]$mp.RealTimeProtectionEnabled)
        $idade = [int]$mp.AntivirusSignatureAge
        Write-Host ("  Windows Defender: {0}; assinaturas atualizadas há {1} dia(s)." -f $(if ($avDefenderOk) { 'ativo' } else { 'desativado' }), $idade)
        if ($avDefenderOk -and $idade -gt 7) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Assinaturas do antivírus com $idade dias" `
                -Solucao 'Abra a Segurança do Windows > Proteção contra vírus e ameaças > Atualizações de proteção e clique em Verificar atualizações.' -Veredito 'Corrigir' `
                -Explicacao 'O antivírus precisa de atualizações frequentes para reconhecer ameaças novas.'
        }
    } catch { }
    # Outro antivírus instalado?
    $outro = $null
    try {
        $av = @(Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop)
        $ativos = @($av | Where-Object { (([int]$_.productState -shr 12) -band 0xF) -eq 1 -and $_.displayName -notmatch 'Windows Defender' })
        if ($ativos.Count -gt 0) { $outro = ($ativos | Select-Object -First 1).displayName }
        if ($null -eq $avDefenderOk -and $av.Count -gt 0) {
            $dd = @($av | Where-Object { $_.displayName -match 'Windows Defender' } | Select-Object -First 1)
            if ($dd.Count -gt 0) { $avDefenderOk = ((([int]$dd[0].productState -shr 12) -band 0xF) -eq 1) }
        }
    } catch { }
    if ($outro) {
        Write-Host "  Antivírus em uso: $outro"
    } elseif ($avDefenderOk -eq $false) {
        Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo 'Nenhum antivírus está ativo' `
            -Solucao 'Ative a Segurança do Windows (Proteção contra vírus e ameaças > Ativar) ou instale um antivírus.' -Veredito 'Corrigir' `
            -Explicacao 'Sem antivírus ativo, o computador fica exposto a vírus e programas maliciosos.'
    } elseif ($null -eq $avDefenderOk) {
        Write-Host '  Antivírus: não consegui consultar o estado.' -ForegroundColor DarkGray
    }
    try {
        $fw = @(Get-NetFirewallProfile -ErrorAction Stop)
        $off = @($fw | Where-Object { -not $_.Enabled } | ForEach-Object { "$($_.Name)" })
        if ($off.Count -gt 0) {
            Add-Achado -Gravidade Atencao -Categoria 'Segurança' -Titulo "Firewall do Windows desativado ($($off -join ', '))" `
                -Solucao 'Ative o Firewall na Segurança do Windows > Firewall e proteção de rede, a menos que outro programa de segurança faça esse papel.' -Veredito 'Depende' `
                -Explicacao 'O firewall bloqueia acessos indesejados vindos da rede. Alguns pacotes de segurança de terceiros desligam o do Windows de propósito.'
        } else { Write-Host '  Firewall do Windows: ativo.' }
    } catch { }
}

function Invoke-AnaliseManutencao {
    if (Test-RebootPendente) {
        Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'Há uma reinicialização pendente' `
            -Solucao 'Reinicie o computador antes de instalar drivers ou fazer reparos.' -Veredito 'Corrigir' `
            -Explicacao 'O Windows já preparou uma atualização ou alteração que só termina depois de reiniciar. Enquanto isso, reparos e instalações podem falhar.'
    }
    try {
        $hf = @(Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop | Where-Object { $_.InstalledOn })
        if ($hf.Count -gt 0) {
            $ult = ($hf | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn
            $dias = [int]((Get-Date) - [datetime]$ult).TotalDays
            Write-Host ("  Última atualização do Windows instalada há {0} dia(s)." -f $dias)
            if ($dias -gt 90) {
                Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo "Nenhuma atualização do Windows instalada há $dias dias" `
                    -Solucao 'Abra Configurações > Atualização e Segurança e instale as atualizações pendentes.' -Veredito 'Corrigir' `
                    -Explicacao 'As atualizações trazem correções de segurança e de estabilidade. Ficar meses sem instalá-las deixa o computador vulnerável.'
            }
        }
    } catch { }
    try {
        $s = Get-Service -Name wuauserv -ErrorAction Stop
        if ($s.StartType -eq 'Disabled') {
            Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'O serviço do Windows Update está desativado' `
                -Solucao 'Use "Reparar o Windows Update" nas Ferramentas de reparo do Telomera.' -Veredito 'Corrigir' `
                -Explicacao 'Com o serviço desativado, o Windows não recebe atualizações nem drivers.'
        }
    } catch { }
}

function Test-ProgramaInstalado {
    # Procura um programa instalado pelo nome (DisplayName) nas visões de 64 e 32 bits do registro
    # de "Programas e Recursos", sem precisar saber o GUID/ProductCode de cada versão -- é a mesma
    # ideia usada por ferramentas conhecidas (como o módulo VcRedist) para achar redistribuíveis.
    param([Parameter(Mandatory)][string]$Padrao)
    $raizes = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($r in $raizes) {
        try {
            $ach = Get-ItemProperty -Path $r -ErrorAction Stop | Where-Object { $_.DisplayName -and $_.DisplayName -match $Padrao } | Select-Object -First 1
            if ($ach) { return $ach.DisplayName }
        } catch { }
    }
    return $null
}

function Get-DllsFaltandoDirectX {
    # Confere uma amostra dos componentes "legados" que o instalador do DirectX End-User Runtime
    # copia para System32/SysWOW64. O Windows moderno já traz o DirectX principal -- faltam só esses
    # componentes mais antigos que muitos jogos (até recentes) ainda empacotam e exigem.
    $dlls = @('d3dx9_43.dll', 'd3dx10_43.dll', 'd3dx11_43.dll', 'd3dcompiler_43.dll', 'xinput1_3.dll', 'xaudio2_7.dll', 'x3daudio1_7.dll', 'xactengine3_7.dll')
    $raiz = $env:SystemRoot
    if (-not $raiz) { $raiz = 'C:\Windows' }
    $pastas = @((Join-Path $raiz 'System32'))
    $wow = Join-Path $raiz 'SysWOW64'
    if (Test-Path -LiteralPath $wow) { $pastas += $wow }
    $faltando = New-Object System.Collections.Generic.List[string]
    foreach ($dll in $dlls) {
        $achou = $false
        foreach ($p in $pastas) { if (Test-Path -LiteralPath (Join-Path $p $dll)) { $achou = $true; break } }
        if (-not $achou) { $faltando.Add($dll) }
    }
    return $faltando.ToArray()
}

function Invoke-AnaliseRequisitosJogos {
    # "Pacote" de runtimes/redistribuíveis que a maioria dos jogos modernos empacota e exige para
    # abrir: não são drivers de hardware, são componentes da Microsoft/NVIDIA que o instalador do
    # próprio jogo normalmente já instala, mas que podem faltar (jogo copiado de outro PC, baixado
    # sem o instalador completo, componente removido por uma limpeza). Cada link abaixo é a página
    # oficial do fabricante -- nenhum link de terceiros.
    $linkVc = @(@{ Texto = 'Baixar (Microsoft, oficial)'; Url = 'https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist' })
    if (-not (Test-ProgramaInstalado -Padrao '^Microsoft Visual C\+\+ 20\d\d(-20\d\d)? Redistributable \(x64\)')) {
        Add-Achado -Gravidade Atencao -Categoria 'Requisitos de jogos' -Titulo 'Falta o Visual C++ Redistributável (x64) 2015-2022' `
            -Detalhe 'A maioria dos jogos de 64 bits (e motores como Unreal e Unity) precisa dele para abrir.' `
            -Solucao 'Baixe e instale o pacote oficial x64 da Microsoft (gratuito).' -Links $linkVc -Veredito 'Corrigir'
    }
    if (-not (Test-ProgramaInstalado -Padrao '^Microsoft Visual C\+\+ 20\d\d(-20\d\d)? Redistributable \(x86\)')) {
        Add-Achado -Gravidade Atencao -Categoria 'Requisitos de jogos' -Titulo 'Falta o Visual C++ Redistributável (x86) 2015-2022' `
            -Detalhe 'Jogos de 32 bits (ainda comuns, inclusive recentes) precisam dele mesmo em Windows de 64 bits.' `
            -Solucao 'Baixe e instale o pacote oficial x86 da Microsoft (gratuito) -- pode ter o x64 e o x86 instalados junto.' -Links $linkVc -Veredito 'Corrigir'
    }
    $faltaDx = Get-DllsFaltandoDirectX
    if ($faltaDx.Count -gt 0) {
        Add-Achado -Gravidade Atencao -Categoria 'Requisitos de jogos' -Titulo 'Faltam componentes do DirectX End-User Runtime' `
            -Detalhe ("Arquivos não encontrados: {0}. O Windows já traz o DirectX principal, mas muitos jogos empacotam esses componentes mais antigos separadamente." -f ($faltaDx -join ', ')) `
            -Solucao 'Baixe e instale o "DirectX End-User Runtime" oficial da Microsoft (gratuito) -- é o instalador clássico que a maioria dos jogos já roda sozinho na primeira instalação.' `
            -Links @(@{ Texto = 'Baixar (Microsoft, oficial)'; Url = 'https://www.microsoft.com/en-us/download/details.aspx?id=35' }) -Veredito 'Corrigir'
    }
    if (-not (Test-ProgramaInstalado -Padrao '(?i)PhysX')) {
        Add-Achado -Gravidade Info -Categoria 'Requisitos de jogos' -Titulo 'O NVIDIA PhysX System Software não está instalado' `
            -Detalhe 'Só é exigido por alguns jogos com física avançada (por exemplo, alguns títulos das séries Batman: Arkham, Mafia e Borderlands). Não afeta os demais jogos.' `
            -Solucao 'Normalmente já vem com o driver da NVIDIA (GeForce Experience/App NVIDIA). Só baixe separado se um jogo específico pedir e você não tiver placa NVIDIA.' `
            -Links @(@{ Texto = 'Baixar (NVIDIA, oficial)'; Url = 'https://www.nvidia.com/en-us/drivers/physx-system-software/' }) -Veredito 'Opcional'
    }
    if (-not (Test-ProgramaInstalado -Padrao '(?i)Microsoft XNA Framework Redistributable')) {
        Add-Achado -Gravidade Info -Categoria 'Requisitos de jogos' -Titulo 'O Microsoft XNA Framework 4.0 não está instalado' `
            -Detalhe 'Exigido por alguns jogos indie mais antigos (por exemplo, versões clássicas de Terraria, FEZ e Bastion). Não afeta jogos recentes.' `
            -Solucao 'Só instale se algum jogo específico pedir por ele.' `
            -Links @(@{ Texto = 'Baixar (Microsoft, oficial)'; Url = 'https://www.microsoft.com/en-us/download/details.aspx?id=20914' }) -Veredito 'Opcional'
    }
}

function Invoke-AnaliseBateria {
    try {
        $bat = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
        if ($bat.Count -eq 0) { return }
        $proj = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryStaticData -ErrorAction Stop)
        $cheia = @(Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryFullChargedCapacity -ErrorAction Stop)
        if ($proj.Count -eq 0 -or $cheia.Count -eq 0) { return }
        $d = [double]$proj[0].DesignedCapacity; $f = [double]$cheia[0].FullChargedCapacity
        if ($d -le 0 -or $f -le 0) { return }
        $saude = [math]::Round(100 * $f / $d)
        $script:Dados['Bateria'] = @{ CapacidadeProjetadaMWh = $d; CapacidadeAtualMWh = $f; SaudePct = $saude }
        Write-Host "  Bateria: $saude% da capacidade original."
        if ($saude -lt 50) {
            Add-Achado -Gravidade Atencao -Categoria 'Bateria' -Titulo "A bateria só guarda $saude% da carga original" `
                -Solucao 'Considere trocar a bateria. O notebook continua funcionando ligado na tomada.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso. Abaixo de 50% a duração cai bastante.'
        } elseif ($saude -lt 70) {
            Add-Achado -Gravidade Info -Categoria 'Bateria' -Titulo "A bateria guarda $saude% da carga original" `
                -Solucao 'Desgaste normal para uma bateria usada; se a duração incomoda, avalie trocá-la.' -Veredito 'Opcional' `
                -Explicacao 'Toda bateria perde capacidade com o uso.'
        }
    } catch { }
}

function Get-TamanhoPasta {
    # Soma dos arquivos de uma pasta, com limite de tempo para não demorar em pastas enormes.
    param([string]$Pasta, [int]$LimiteSeg = 20, [int]$DiasMinimos = 0)
    $total = [int64]0
    if (-not (Test-Path -LiteralPath $Pasta)) { return $total }
    $fim = (Get-Date).AddSeconds($LimiteSeg)
    $corte = (Get-Date).AddDays(-$DiasMinimos)
    try {
        foreach ($f in (Get-ChildItem -LiteralPath $Pasta -Recurse -File -Force -ErrorAction SilentlyContinue)) {
            if ($f.LastWriteTime -lt $corte) { $total += $f.Length }
            if ((Get-Date) -gt $fim) { break }
        }
    } catch { }
    return $total
}

function Get-PastasTemporarios {
    $l = @()
    if ($env:TEMP) { $l += $env:TEMP }
    if ($env:SystemRoot) { $l += (Join-Path $env:SystemRoot 'Temp') }
    return @($l | Select-Object -Unique)
}

function Clear-Temporarios {
    # Apaga arquivos temporários com mais de 2 dias (os mais novos podem estar em uso). Devolve os bytes liberados.
    $liberado = [int64]0
    $corte = (Get-Date).AddDays(-2)
    foreach ($p in (Get-PastasTemporarios)) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        foreach ($f in (Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $corte })) {
            try { $t = $f.Length; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $liberado += $t } catch { }
        }
    }
    return $liberado
}

function Format-Tamanho {
    param([int64]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N0} MB' -f ($Bytes / 1MB)) }
    return ('{0:N0} KB' -f ($Bytes / 1KB))
}

function Invoke-AnaliseEspaco {
    $total = [int64]0
    foreach ($p in (Get-PastasTemporarios)) { $total += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
    Write-Host ("  Arquivos temporários com mais de 2 dias: {0}" -f (Format-Tamanho $total))
    $script:Dados['TemporariosBytes'] = $total
    if ($total -ge 1GB) {
        Add-Achado -Gravidade Info -Categoria 'Espaço' -Titulo ("Arquivos temporários ocupam {0}" -f (Format-Tamanho $total)) `
            -Solucao 'O Telomera pode apagar os temporários antigos (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'Programas e o Windows deixam arquivos temporários que ninguém mais usa. Apagar os antigos é seguro e libera espaço.'
        Add-Acao -Descricao ("Apagar arquivos temporários antigos (cerca de {0})" -f (Format-Tamanho $total)) -Acao {
            $l = Clear-Temporarios
            Write-Host ("    Liberado: {0}" -f (Format-Tamanho $l)) -ForegroundColor Green
        }
    }
}

function Invoke-AnaliseInicializacao {
    try {
        $itens = @(Get-CimInstance Win32_StartupCommand -ErrorAction Stop)
        Write-Host "  Programas que iniciam com o Windows: $($itens.Count)"
        $script:Dados['Inicializacao'] = @($itens | ForEach-Object { [pscustomobject]@{ Nome = "$($_.Name)"; Comando = "$($_.Command)"; Local = "$($_.Location)" } })
        if ($itens.Count -gt 25) {
            Add-Achado -Gravidade Info -Categoria 'Desempenho' -Titulo "$($itens.Count) programas iniciam junto com o Windows" `
                -Solucao 'Abra o Gerenciador de Tarefas (Ctrl+Shift+Esc) > Inicializar e desative os que você não usa logo ao ligar.' -Veredito 'Opcional' `
                -Explicacao 'Muitos programas na inicialização deixam o computador mais lento para ligar. Desativar na inicialização não desinstala o programa.'
        }
    } catch { }
}

function Invoke-AnaliseRede {
    if ($SemWindowsUpdate) { Write-Host '  Teste de rede: pulado (opção de não usar a internet).' -ForegroundColor DarkGray; return }
    $ativos = @()
    try { $ativos = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' }) } catch { return }
    if ($ativos.Count -eq 0) {
        Add-Achado -Gravidade Info -Categoria 'Rede' -Titulo 'Nenhum adaptador de rede conectado' `
            -Solucao 'Se deveria haver internet, confira o cabo ou o Wi-Fi.' -Veredito 'Depende' -Explicacao 'O teste de rede só faz sentido com um adaptador conectado.'
        return
    }
    $ping = $false; $dns = $false
    try { $ping = [bool](Test-Connection -ComputerName 1.1.1.1 -Count 2 -Quiet -ErrorAction Stop) } catch { }
    try { $r = Resolve-DnsName -Name 'www.microsoft.com' -Type A -ErrorAction Stop; $dns = [bool]$r } catch { }
    Write-Host ("  Rede: conexão {0}; resolução de nomes (DNS) {1}." -f $(if ($ping) { 'ok' } else { 'falhou' }), $(if ($dns) { 'ok' } else { 'falhou' }))
    $script:Dados['Rede'] = @{ Ping = $ping; Dns = $dns }
    if ($ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'A internet responde, mas os nomes de sites não são resolvidos (DNS)' `
            -Solucao 'O Telomera pode limpar o cache e reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Corrigir' `
            -Explicacao 'O computador alcança a internet, mas não consegue traduzir endereços como www.site.com. Costuma ser cache de DNS corrompido ou configuração de rede com problema.'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    } elseif (-not $ping -and -not $dns) {
        Add-Achado -Gravidade Atencao -Categoria 'Rede' -Titulo 'Sem acesso à internet apesar do adaptador conectado' `
            -Solucao 'Reinicie o roteador e o computador. Se continuar, o Telomera pode reiniciar a configuração de rede (com a sua confirmação).' -Veredito 'Depende' `
            -Explicacao 'O adaptador está ligado, mas nada sai para a internet. Pode ser o provedor ou o roteador (fora do alcance do Telomera) ou a configuração de rede do Windows (que o Telomera corrige).'
        Add-Acao -Descricao 'Reiniciar a configuração de rede (DNS, Winsock e IP)' -Acao { Reset-RedeWindows }
    }
}

function Invoke-AnaliseVolumesChkdsk {
    # Oferece o CHKDSK completo (na reinicialização) quando a varredura online achou erros.
    $v = @($script:Dados['Volumes'])
    foreach ($x in $v) {
        if ($null -eq $x) { continue }
        if ($x.Tipo -eq 'Fixed' -and "$($x.Varredura)" -notin @('NoErrorsFound', 'não executada', 'requer administrador', 'falhou')) {
            $letra = "$($x.Unidade)"
            Add-Acao -Descricao "Agendar o CHKDSK completo ($letra /F /R) para a próxima reinicialização" -Geral -Arg $letra -Acao {
                param($l)
                Invoke-AgendarChkdsk -Unidade $l
            }
        }
    }
}

function Invoke-AgendarChkdsk {
    param([string]$Unidade)
    $saida = & cmd.exe /c "echo Y| chkdsk $Unidade /F /R" 2>&1
    @($saida) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "    $_" }
    Write-Host '    O CHKDSK roda sozinho na próxima vez que o computador for reiniciado (pode levar de minutos a horas).' -ForegroundColor Cyan
}

function Invoke-AnaliseExtras {
    Write-Titulo '4b) SEGURANÇA, MANUTENÇÃO E ESPAÇO'
    foreach ($par in @(
        @('Telas azuis', { Invoke-AnaliseTelasAzuis }),
        @('Monitor em tempo real', { if (Get-Command Invoke-AnaliseMonitor -ErrorAction SilentlyContinue) { Invoke-AnaliseMonitor } }),
        @('Configurações que influenciam travamentos', { if (Get-Command Invoke-AnaliseConfigTravamento -ErrorAction SilentlyContinue) { Invoke-AnaliseConfigTravamento } }),
        @('SMART detalhado', { Invoke-AnaliseSmartAtributos }),
        @('Drivers de som, rede e chipset', { Invoke-AnaliseDriversGerais }),
        @('Pacotes de driver corrompidos', { Invoke-AnalisePacotesCorrompidos }),
        @('Segurança', { Invoke-AnaliseSeguranca }),
        @('Manutenção do Windows', { Invoke-AnaliseManutencao }),
        @('Bateria', { Invoke-AnaliseBateria }),
        @('Espaço', { Invoke-AnaliseEspaco }),
        @('Inicialização', { Invoke-AnaliseInicializacao }),
        @('Rede', { Invoke-AnaliseRede }),
        @('CHKDSK', { Invoke-AnaliseVolumesChkdsk })
    )) {
        try { & $par[1] } catch { Write-Host "  Verificação '$($par[0])' falhou e foi ignorada: $($_.Exception.Message)" -ForegroundColor Yellow }
    }
}


# ----------------------------------------------------------------------------
# Verificação profunda (opcional, só leitura): confere os arquivos do Windows, o repositório WMI, o histórico de 90 dias,
# travamentos de programas, lentidão na inicialização, limitação do processador e falhas do Windows Update.
# Os leitores de saída abaixo são puros (recebem texto ou listas) para serem testados fora do Windows.
# ----------------------------------------------------------------------------
function Get-ResumoSaidaSfc {
    # SFC /verifyonly: ok, violacoes ou indeterminado. A saída vem em UTF-16 quando redirecionada; remove os nulos antes de ler.
    param([string]$Texto)
    $t = ("$Texto" -replace "`0", '')
    if ($t -match 'não encontrou (nenhuma )?viola|did not find any integrity violations') { return 'ok' }
    if ($t -match 'encontrou viola|found integrity violations') { return 'violacoes' }
    return 'indeterminado'
}

function Get-ResumoSaidaDism {
    # DISM /ScanHealth: ok, reparavel, irreparavel ou indeterminado.
    param([string]$Texto)
    $t = "$Texto"
    if ($t -match 'não é reparável|not repairable') { return 'irreparavel' }
    if ($t -match 'Nenhuma corrupção|No component store corruption detected') { return 'ok' }
    if ($t -match 'reparável|is repairable') { return 'reparavel' }
    return 'indeterminado'
}

function Get-ResumoSaidaWmi {
    # winmgmt /verifyrepository: ok, inconsistente ou indeterminado ("inconsistente" contém "consistente": testa primeiro).
    param([string]$Texto)
    $t = "$Texto"
    if ($t -match 'inconsistente|inconsistent') { return 'inconsistente' }
    if ($t -match 'consistente|is consistent') { return 'ok' }
    return 'indeterminado'
}

function Get-ResumoSaidaEnergia {
    # powercfg /energy: contagem de erros e avisos da análise de energia.
    param([string]$Texto)
    $t = "$Texto"
    $e = [regex]::Match($t, '(\d+)\s+(erros?|errors?)\b', 'IgnoreCase')
    $a = [regex]::Match($t, '(\d+)\s+(avisos?|warnings?)\b', 'IgnoreCase')
    return @{ Erros = $(if ($e.Success) { [int]$e.Groups[1].Value } else { -1 }); Avisos = $(if ($a.Success) { [int]$a.Groups[1].Value } else { -1 }) }
}

function Get-AvaliacaoTravamentosApps {
    # $Lista: @{ App; Modulo; Codigo; Quando } do log Aplicativo (evento 1000). Devolve @{ Gravidade; Titulo; Detalhe; Solucao; Veredito } por programa que travou 3+ vezes.
    param($Lista)
    $res = New-Object System.Collections.Generic.List[object]
    $gpu = '^(nvwgf2|nvlddmkm|nvd3d|atidxx|atiumd|amdxx|amdvlk|igd|ig9icd|d3d)'
    foreach ($g in @($Lista | Where-Object { $_ -and $_.App } | Group-Object { "$($_.App)".ToLower() } | Where-Object { $_.Count -ge 3 } | Sort-Object Count -Descending | Select-Object -First 6)) {
        $mods = @($g.Group | Group-Object { "$($_.Modulo)".ToLower() } | Sort-Object Count -Descending)
        $modTop = "$($mods[0].Name)"
        $cod = @($g.Group | Group-Object { "$($_.Codigo)" } | Sort-Object Count -Descending)
        $codTop = "$($cod[0].Name)"
        $nome = "$($g.Group[0].App)"
        $det = "Travou $($g.Count) vez(es) nos últimos 30 dias. Módulo que mais aparece: $modTop. Código de exceção mais comum: $codTop."
        $sol = 'Atualize ou reinstale o programa. Se travar sempre no mesmo ponto, procure o módulo no site do fabricante.'
        $ved = 'Depende'
        if ($modTop -match $gpu) { $sol = 'O travamento aponta para o driver de vídeo: atualize-o (instalação limpa) e, em jogos, teste sem overclock.' }
        elseif ($modTop -match '^(ntdll|kernelbase|kernel32|ucrtbase)') { $sol = 'O módulo é genérico do Windows (não aponta o culpado). Atualize o programa e verifique arquivos do sistema e memória RAM.' }
        elseif ($codTop -match 'c0000005') { $sol = 'Violação de acesso à memória: costuma ser defeito do programa, mas também aparece com memória RAM instável. Rode o teste de memória do Telomera.' }
        $res.Add(@{ Gravidade = 'Atencao'; Titulo = "Programa que trava com frequência: $nome ($($g.Count)x em 30 dias)"; Detalhe = $det; Solucao = $sol; Veredito = $ved })
    }
    return , $res.ToArray()
}

function Get-AvaliacaoInicializacao {
    # $Lista: @{ BootMs; Quando } do evento 100 de Diagnostics-Performance. Devolve @{ Amostras; MediaSeg; MaiorSeg; Lenta } ou $null sem dados.
    param($Lista)
    $v = @($Lista | Where-Object { $_ -and [double]$_.BootMs -gt 0 } | ForEach-Object { [double]$_.BootMs / 1000.0 })
    if ($v.Count -eq 0) { return $null }
    $media = ($v | Measure-Object -Average).Average
    $maior = ($v | Measure-Object -Maximum).Maximum
    return @{ Amostras = $v.Count; MediaSeg = [math]::Round($media, 0); MaiorSeg = [math]::Round($maior, 0); Lenta = ($media -gt 90) }
}

function Get-AvaliacaoFalhasUpdate {
    # $Lista: @{ Codigo; Titulo } do evento 20 do WindowsUpdateClient. Falhas repetidas com o mesmo código indicam um componente do Update com defeito.
    param($Lista)
    $itens = @($Lista | Where-Object { $_ })
    if ($itens.Count -eq 0) { return $null }
    $g = @($itens | Group-Object { "$($_.Codigo)" } | Sort-Object Count -Descending)
    return @{ Total = $itens.Count; CodigoTop = "$($g[0].Name)"; VezesTop = $g[0].Count; Repetida = ($g[0].Count -ge 3) }
}

function Get-DadosEventoXml {
    # Valor de um campo nomeado do XML de um evento do Windows (independe do idioma e da posição).
    param($Evento, [string]$Nome)
    try {
        $x = [xml]$Evento.ToXml()
        $n = @($x.Event.EventData.Data | Where-Object { $_.Name -eq $Nome }) | Select-Object -First 1
        if ($n) { return "$($n.'#text')" }
    } catch { }
    return ''
}

function Invoke-ComandoProfundo {
    # Roda um comando nativo e devolve o texto (sem nulos). Erros viram texto vazio.
    param([string]$Exe, [string[]]$Argumentos)
    try { return ((& $Exe @Argumentos 2>&1 | Out-String) -replace "`0", '') } catch { return '' }
}

function Get-ProgramasInstalados {
    # Lê os programas instalados pelo registro (64 bits, 32 bits em sistema 64 bits, e o do usuário atual).
    # Só devolve "programas" de verdade: ignora componentes internos do Windows e atualizações/patches de outro programa.
    $chaves = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $vistos = @{}
    $lista = New-Object System.Collections.Generic.List[object]
    foreach ($c in $chaves) {
        Get-ItemProperty -Path $c -ErrorAction SilentlyContinue | ForEach-Object {
            $nome = "$($_.DisplayName)".Trim()
            if (-not $nome) { return }
            if ("$($_.SystemComponent)" -eq '1') { return }
            if ($_.ParentDisplayName) { return }
            if ($vistos.ContainsKey($nome)) { return }
            $vistos[$nome] = $true
            $lista.Add([pscustomobject]@{
                Nome      = $nome
                Pasta     = "$($_.InstallLocation)".Trim().TrimEnd('\')
                Publisher = "$($_.Publisher)".Trim()
            })
        }
    }
    return $lista.ToArray()
}

function Invoke-AnaliseAplicativosInstalados {
    # Confere, por amostragem, se os .exe/.dll dos programas instalados batem com a assinatura digital deles
    # (quando "HashMismatch" aparece, o conteúdo do arquivo não é mais o que foi assinado - corrupção de disco
    # ou alteração indevida) e se a pasta de instalação registrada ainda existe. Não corrige nada sozinho:
    # reescrever executáveis de outro programa é arriscado, então o achado só orienta a reinstalar/reparar.
    # -Programas permite injetar a lista (em vez de ler do registro) nos testes automatizados.
    param([object[]]$Programas = $null)
    Write-Titulo '4d) APLICATIVOS INSTALADOS (arquivos corrompidos ou alterados)'
    $listaProgramas = @($(if ($null -ne $Programas) { $Programas } else { Get-ProgramasInstalados }))
    if ($listaProgramas.Count -eq 0) {
        Write-Host '  Nenhum programa com pasta de instalação no registro.' -ForegroundColor DarkGray
        return
    }

    $limiteArquivos     = 2000   # teto geral: nunca confere mais que isso, para não virar uma verificação de horas
    $limitePorPrograma  = 60     # no máximo por programa, para pastas gigantes (jogos, IDEs) não dominarem o tempo
    $limiteSegundos     = 90
    $inicio             = Get-Date
    $orcamento          = 0
    $corrompidos        = 0
    $ilegiveis          = 0
    $pastasAusentes     = New-Object System.Collections.Generic.List[string]
    $raizesPerigosas    = @($env:WINDIR, $env:SystemRoot, 'C:\', "$env:SystemDrive\")

    foreach ($p in $listaProgramas) {
        if ($orcamento -ge $limiteArquivos) { break }
        if (((Get-Date) - $inicio).TotalSeconds -ge $limiteSegundos) {
            Write-Host '  Tempo reservado para esta etapa esgotado; o restante dos programas fica para a próxima verificação profunda.' -ForegroundColor Yellow
            break
        }
        if (-not $p.Pasta) { continue }
        if ($raizesPerigosas -contains $p.Pasta) { continue }
        if (-not (Test-Path -LiteralPath $p.Pasta -PathType Container)) {
            $pastasAusentes.Add($p.Nome)
            continue
        }
        $arquivos = @()
        try {
            $arquivos = @(Get-ChildItem -LiteralPath $p.Pasta -Include '*.exe', '*.dll' -Recurse -Depth 2 -File -ErrorAction SilentlyContinue |
                Select-Object -First $limitePorPrograma)
        } catch { continue }

        foreach ($a in $arquivos) {
            if ($orcamento -ge $limiteArquivos) { break }
            $orcamento++
            try {
                $sig = Get-AuthenticodeSignature -LiteralPath $a.FullName -ErrorAction Stop
                if ($sig.Status -eq 'HashMismatch') {
                    $corrompidos++
                    Add-Achado -Gravidade Critico -Categoria 'Aplicativo' `
                        -Titulo "Arquivo alterado ou corrompido em '$($p.Nome)': $($a.Name)" `
                        -Detalhe "O conteúdo de '$($a.FullName)' não bate mais com a assinatura digital dele." `
                        -Solucao "Reinstale ou repare '$($p.Nome)' (Configurações > Aplicativos > $($p.Nome) > Opções avançadas > Reparar, quando disponível, ou o instalador original)." `
                        -Explicacao "Arquivos de programa costumam ser assinados digitalmente para garantir que ninguém os alterou depois. Esse arquivo foi: o conteúdo mudou desde a assinatura. As causas mais comuns são corrupção de disco (queda de energia ou setor com defeito durante uma gravação) ou alteração indevida (outro programa, ou malware, sobrescreveu o arquivo). O Telomera só leu o arquivo para conferir; ele não corrige isso sozinho, porque reescrever o executável de outro programa é arriscado - a forma seguro é reinstalar." `
                        -Veredito Corrigir
                }
            } catch {
                $ilegiveis++
                Add-Achado -Gravidade Atencao -Categoria 'Aplicativo' `
                    -Titulo "Não foi possível ler um arquivo de '$($p.Nome)': $($a.Name)" `
                    -Detalhe "Erro ao abrir '$($a.FullName)': $($_.Exception.Message)" `
                    -Solucao "Se '$($p.Nome)' parar de funcionar ou travar ao abrir, reinstale o programa." `
                    -Veredito Depende
            }
        }
    }

    if ($pastasAusentes.Count -gt 0) {
        $amostra = ($pastasAusentes | Select-Object -First 5) -join ', '
        $resto = if ($pastasAusentes.Count -gt 5) { " e mais $($pastasAusentes.Count - 5)" } else { '' }
        Add-Achado -Gravidade Info -Categoria 'Aplicativo' `
            -Titulo "$($pastasAusentes.Count) programa(s) registrado(s) sem a pasta de instalação" `
            -Detalhe "Exemplos: $amostra$resto." `
            -Solucao 'Normalmente é resquício de uma desinstalação incompleta: o atalho pode não abrir mais nada. Se for o caso, remova o registro pela lista "Aplicativos e recursos" do Windows.' `
            -Veredito Depende
    }

    Write-Host ("  Programas verificados: {0} | arquivos conferidos: {1} | corrompidos/alterados: {2} | ilegíveis: {3} | sem pasta: {4}" -f `
        $listaProgramas.Count, $orcamento, $corrompidos, $ilegiveis, $pastasAusentes.Count) -ForegroundColor DarkGray
}

function Invoke-AnaliseProfunda {
    Write-Titulo '4c) VERIFICAÇÃO PROFUNDA (somente leitura)'
    $admin = $true
    try { $admin = Test-Administrador } catch { }
    $agora = Get-Date

    # 1) Arquivos do Windows e imagem do sistema (precisam de administrador e levam vários minutos)
    if (-not $admin) {
        Write-Host '  SFC, DISM e análise de energia ignorados: abra o Telomera como administrador.' -ForegroundColor Yellow
        Add-Achado -Gravidade Info -Categoria 'Windows' -Titulo 'Verificação profunda parcial (sem administrador)' -Detalhe 'Os testes dos arquivos do Windows (SFC e DISM) e a análise de energia exigem administrador.' -Solucao 'Feche e abra o Telomera aceitando o pedido de permissão para rodar a verificação profunda completa.'
    } else {
        Write-Host '  Conferindo os arquivos do Windows (SFC /verifyonly; leva vários minutos, não altera nada)...' -ForegroundColor DarkGray
        $sfc = Get-ResumoSaidaSfc (Invoke-ComandoProfundo 'sfc.exe' @('/verifyonly'))
        switch ($sfc) {
            'violacoes' { Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'Arquivos do Windows com problema (SFC)' -Detalhe 'O verificador encontrou arquivos de sistema alterados ou danificados. Isso pode causar travamentos e erros estranhos.' -Solucao 'Use "Reparos e restauração" para reparar a imagem (DISM) e rodar o SFC /scannow, depois reinicie.' -Explicacao 'O SFC compara os arquivos protegidos do Windows com cópias originais. Violações indicam arquivos trocados ou corrompidos (disco com defeito, queda de energia, programa mal feito ou malware).' -Veredito Corrigir }
            'ok' { Write-Host '  Arquivos do Windows íntegros.' -ForegroundColor Green }
            default { Write-Host '  O SFC não deu um resultado claro (pode haver reinício pendente ou outra manutenção em andamento).' -ForegroundColor Yellow }
        }
        Write-Host '  Conferindo o repositório de componentes (DISM /ScanHealth; leva vários minutos, não altera nada)...' -ForegroundColor DarkGray
        $dism = Get-ResumoSaidaDism (Invoke-ComandoProfundo 'dism.exe' @('/Online', '/Cleanup-Image', '/ScanHealth'))
        switch ($dism) {
            'reparavel' { Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'A imagem do Windows tem corrupção reparável (DISM)' -Detalhe 'O repositório de componentes do Windows está danificado, mas dá para reparar.' -Solucao 'Use "Reparos e restauração" para rodar o DISM /RestoreHealth (precisa de internet) e depois o SFC /scannow.' -Veredito Corrigir }
            'irreparavel' { Add-Achado -Gravidade Critico -Categoria 'Windows' -Titulo 'A imagem do Windows não é reparável (DISM)' -Detalhe 'O repositório de componentes está danificado e o reparo automático não resolve.' -Solucao 'Faça cópia dos seus arquivos e considere reparar o Windows pela instalação (atualização in-loco) ou reinstalar.' -Veredito Corrigir }
            'ok' { Write-Host '  Imagem do Windows íntegra.' -ForegroundColor Green }
            default { Write-Host '  O DISM não deu um resultado claro.' -ForegroundColor Yellow }
        }
        Write-Host '  Conferindo a análise de energia (powercfg /energy, 20 segundos)...' -ForegroundColor DarkGray
        try {
            $arq = Join-Path $(if ($script:PastaRelatorioFinal) { $script:PastaRelatorioFinal } else { [IO.Path]::GetTempPath() }) 'energia.html'
            $en = Get-ResumoSaidaEnergia (Invoke-ComandoProfundo 'powercfg.exe' @('/energy', '/duration', '20', '/output', $arq))
            if ($en.Erros -gt 0) {
                Add-Achado -Gravidade Info -Categoria 'Energia' -Titulo "Análise de energia: $($en.Erros) erro(s) e $($en.Avisos) aviso(s)" -Detalhe "Relatório detalhado em: $arq" -Solucao 'Abra o relatório e veja os itens marcados como erro (suspensão de USB, drivers que impedem a economia de energia, etc.). Em desktops costuma ser inofensivo.' -Explicacao 'O powercfg observa o computador por 20 segundos e aponta configurações de energia que causam travamentos de suspensão ou gasto à toa.' -Veredito Depende
            }
        } catch { }
    }

    # 2) Repositório WMI (base de onde vêm quase todas as leituras do Telomera e de outros programas)
    try {
        $wmi = Get-ResumoSaidaWmi (Invoke-ComandoProfundo 'winmgmt.exe' @('/verifyrepository'))
        if ($wmi -eq 'inconsistente') {
            Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo 'O repositório WMI está inconsistente' -Detalhe 'A base de informações do Windows (WMI) está com defeito. Programas de diagnóstico, e até o Telomera, podem falhar ao ler hardware e drivers.' -Solucao 'Abra o Prompt de Comando como administrador e rode: winmgmt /salvagerepository' -Veredito Corrigir
        } elseif ($wmi -eq 'ok') { Write-Host '  Repositório WMI consistente.' -ForegroundColor Green }
    } catch { }

    # 3) Programas que travam (últimos 30 dias)
    try {
        $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = 'Application Error'; Id = 1000; StartTime = $agora.AddDays(-30) } -MaxEvents 1000 -ErrorAction Stop)
        $lista = @($ev | ForEach-Object { @{ App = "$($_.Properties[0].Value)"; Modulo = "$($_.Properties[3].Value)"; Codigo = "$($_.Properties[6].Value)"; Quando = $_.TimeCreated } })
        foreach ($f in (Get-AvaliacaoTravamentosApps $lista)) {
            Add-Achado -Gravidade $f.Gravidade -Categoria 'Eventos' -Titulo $f.Titulo -Detalhe $f.Detalhe -Solucao $f.Solucao -Veredito $f.Veredito
        }
        Write-Host ("  Travamentos de programas nos últimos 30 dias: {0}" -f $ev.Count) -ForegroundColor DarkGray
    } catch { Write-Host '  Nenhum travamento de programa registrado nos últimos 30 dias.' -ForegroundColor DarkGray }

    # 4) Inicialização (tempo e causas de lentidão)
    try {
        $bev = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'; Id = 100; StartTime = $agora.AddDays(-30) } -MaxEvents 60 -ErrorAction Stop)
        $bl = @($bev | ForEach-Object { @{ BootMs = (Get-DadosEventoXml $_ 'BootTime'); Quando = $_.TimeCreated } })
        $ini = Get-AvaliacaoInicializacao $bl
        if ($ini) {
            Write-Host ("  Inicialização: média de {0} s em {1} partida(s) (maior: {2} s)." -f $ini.MediaSeg, $ini.Amostras, $ini.MaiorSeg) -ForegroundColor DarkGray
            if ($ini.Lenta) {
                Add-Achado -Gravidade Info -Categoria 'Sistema' -Titulo "Inicialização lenta: média de $($ini.MediaSeg) segundos" -Detalhe "Em $($ini.Amostras) partidas dos últimos 30 dias o Windows levou em média $($ini.MediaSeg) s para ficar pronto (a maior foi $($ini.MaiorSeg) s)." -Solucao 'Desative programas desnecessários na inicialização (Gerenciador de Tarefas > Inicializar) e confira se o Windows está em um SSD.' -Explicacao 'Acima de 90 segundos costuma indicar disco lento (HDD), muitos programas iniciando junto ou um driver demorando para carregar.' -Veredito Opcional
            }
        }
    } catch { }

    # 5) Processador limitado pelo firmware (calor ou energia) - Kernel-Processor-Power, evento 37
    try {
        $th = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Processor-Power'; Id = 37; StartTime = $agora.AddDays(-30) } -MaxEvents 500 -ErrorAction Stop)
        if ($th.Count -gt 0) {
            Add-Achado -Gravidade Atencao -Categoria 'Hardware' -Titulo "Processador limitado pelo firmware: $($th.Count) vez(es) em 30 dias" -Detalhe "O Windows registrou que o processador teve a velocidade reduzida pela BIOS/firmware (evento 37). Última em $($th[0].TimeCreated.ToString('yyyy-MM-dd HH:mm'))." -Solucao 'Verifique a temperatura do processador, a ventilação, a pasta térmica e a fonte. Em notebooks, o modo de energia também influencia.' -Explicacao 'É o sinal mais direto de superaquecimento ou de falta de energia para o processador. Se o PC também trava em jogos, vale investigar refrigeração e fonte.' -Veredito Depende
        }
    } catch { }

    # 6) Falhas do Windows Update (90 dias)
    try {
        $wu = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-WindowsUpdateClient/Operational'; Id = 20; StartTime = $agora.AddDays(-90) } -MaxEvents 300 -ErrorAction Stop)
        $wl = @($wu | ForEach-Object { @{ Codigo = (Get-DadosEventoXml $_ 'errorCode'); Titulo = (Get-DadosEventoXml $_ 'updateTitle') } })
        $av = Get-AvaliacaoFalhasUpdate $wl
        if ($av -and $av.Repetida) {
            Add-Achado -Gravidade Atencao -Categoria 'Windows' -Titulo "O Windows Update falha sempre com o mesmo erro ($($av.CodigoTop))" -Detalhe "$($av.VezesTop) das $($av.Total) falhas de instalação dos últimos 90 dias têm o código $($av.CodigoTop)." -Solucao 'Use "Reparos e restauração" para reparar o Windows Update; se persistir, pesquise o código no site da Microsoft.' -Veredito Corrigir
        } elseif ($av) {
            Add-Achado -Gravidade Info -Categoria 'Windows' -Titulo "O Windows Update falhou $($av.Total) vez(es) em 90 dias" -Detalhe "Código mais comum: $($av.CodigoTop)." -Solucao 'Se as atualizações estão em dia, pode ignorar.' -Veredito Normal
        }
    } catch { }

    # 7) Inicialização segura e TPM (exigidos por anticheats como o Vanguard e pelo Windows 11)
    try {
        $sb = $null; try { $sb = Confirm-SecureBootUEFI -ErrorAction Stop } catch { $sb = $null }
        $tpm = $null; try { $tpm = Get-Tpm -ErrorAction Stop } catch { $tpm = $null }
        $linhas = @()
        if ($null -ne $sb) { $linhas += "Inicialização segura: $(if ($sb) { 'ativada' } else { 'DESATIVADA' })" } else { $linhas += 'Inicialização segura: não disponível (BIOS em modo legado/CSM?)' }
        if ($tpm) { $linhas += "TPM: $(if ($tpm.TpmPresent) { if ($tpm.TpmReady) { 'presente e pronto' } else { 'presente, não pronto' } } else { 'ausente' })" }
        Write-Host ('  ' + ($linhas -join ' | ')) -ForegroundColor DarkGray
        if ($sb -eq $false -or ($tpm -and -not $tpm.TpmPresent)) {
            Add-Achado -Gravidade Info -Categoria 'Segurança' -Titulo 'Inicialização segura ou TPM desativados' -Detalhe ($linhas -join '. ') -Solucao 'Se joga VALORANT/League of Legends (Vanguard) ou usa Windows 11, ative a Inicialização Segura e o TPM (fTPM/PTT) na BIOS.' -Explicacao 'O anticheat da Riot e o Windows 11 exigem esses recursos. Em PCs antigos sem suporte, não há o que fazer.' -Veredito Opcional
        }
    } catch { }

    # 8) Aplicativos instalados: arquivos corrompidos/alterados (assinatura digital) e pastas de instalação ausentes
    try { Invoke-AnaliseAplicativosInstalados } catch { Write-Host "  Não foi possível verificar os aplicativos instalados: $($_.Exception.Message)" -ForegroundColor Yellow }
}

# ----------------------------------------------------------------------------
# Reparos de configuração com confirmação e desfazer (agendamento de GPU, economia do PCIe, inicialização rápida)
# ----------------------------------------------------------------------------
function Get-ArquivoConfigAntes { return (Get-ArquivoDados 'config-antes.json') }

function Get-ConfigAntes {
    # Valores originais guardados antes de cada mudança: @{ Chave = Valor ('' = não existia) }.
    $f = Get-ArquivoConfigAntes
    $h = @{}
    try {
        if (Test-Path -LiteralPath $f) {
            $o = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value }
        }
    } catch { }
    return $h
}

function Save-ConfigAntes {
    # Guarda o valor original só na primeira mudança (assim "desfazer" sempre volta ao que era antes do Telomera).
    param([string]$Chave, $Valor)
    $h = Get-ConfigAntes
    if ($h.ContainsKey($Chave)) { return }
    $h[$Chave] = $(if ($null -eq $Valor) { '' } else { "$Valor" })
    $f = Get-ArquivoConfigAntes
    $dir = Split-Path -Parent $f
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [IO.File]::WriteAllText($f, ($h | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
}

function Clear-ConfigAntes {
    param([string]$Chave)
    $h = Get-ConfigAntes
    if ($h.ContainsKey($Chave)) { $h.Remove($Chave) }
    $f = Get-ArquivoConfigAntes
    if ($h.Count -eq 0) { try { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } catch { } }
    else { [IO.File]::WriteAllText($f, ($h | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false)) }
}

function Get-PlanoReparoCfg {
    # Descreve cada mudança (texto de confirmação, o que muda e se precisa reiniciar). Id: hags | pcie | fast.
    param([string]$Id)
    switch ($Id) {
        'hags' { return @{ Id = 'hags'; Chave = 'HwSchMode'; Titulo = 'Desligar o agendamento de GPU acelerado por hardware'; Reinicia = $true
            Pergunta = 'Desligar o "Agendamento de GPU acelerado por hardware"? É uma opção do Windows que, em alguns computadores, causa travamento de imagem em jogos. O Telomera guarda o valor atual para você poder desfazer, e é preciso reiniciar o computador para valer.' } }
        'pcie' { return @{ Id = 'pcie'; Chave = 'PcieAspmAc'; Titulo = 'Desligar a economia de energia do PCIe (na tomada)'; Reinicia = $false
            Pergunta = 'Desligar a economia de energia do PCIe (Link State Power Management) quando o computador está na tomada? Isso evita que a placa de vídeo seja colocada em repouso profundo e travar ao sair dele. O consumo em repouso sobe um pouco. O Telomera guarda o valor atual para você poder desfazer.' } }
        'usb' { return @{ Id = 'usb'; Chave = 'UsbSelectiveSuspendAc'; Titulo = 'Desligar a economia de energia do USB (na tomada)'; Reinicia = $false
            Pergunta = 'Desligar a suspensão seletiva do USB quando o computador está na tomada? Com ela ligada, o Windows corta a energia de portas USB paradas e teclado, mouse e headset podem desconectar no meio do jogo. O Telomera guarda o valor atual para você poder desfazer.' } }
        'fast' { return @{ Id = 'fast'; Chave = 'HiberbootEnabled'; Titulo = 'Desligar a inicialização rápida do Windows'; Reinicia = $true
            Pergunta = 'Desligar a inicialização rápida (Fast Startup)? Ela mantém o estado dos drivers entre desligamentos e pode manter um driver travado. O computador passa a demorar alguns segundos a mais para ligar. O Telomera guarda o valor atual para você poder desfazer.' } }
        'bgapps' { return @{ Id = 'bgapps'; Chave = 'BackgroundAppsDisabled'; Titulo = 'Impedir apps da Microsoft Store de rodar em segundo plano'; Reinicia = $false
            Pergunta = 'Impedir que os apps da Microsoft Store (não os programas comuns) continuem rodando em segundo plano quando fechados? Isso é a mesma opção de Configurações > Aplicativos > Apps em segundo plano. O Telomera guarda o valor atual para você poder desfazer.' } }
        'power' { return @{ Id = 'power'; Chave = 'PowerScheme'; Titulo = 'Mudar o plano de energia para Alto desempenho'; Reinicia = $false
            Pergunta = 'Mudar o plano de energia ativo para "Alto desempenho"? Em notebooks isso reduz a duração da bateria. O Telomera guarda o plano atual para você poder voltar.' } }
        'gamedvr' { return @{ Id = 'gamedvr'; Chave = 'GameDVR'; Titulo = 'Desligar a gravação em segundo plano (Game DVR/Game Bar)'; Reinicia = $false
            Pergunta = 'Desligar a gravação automática em segundo plano do Game Bar (Game DVR)? Em alguns jogos ela consome CPU/GPU e disco mesmo sem você estar gravando. Alguns jogos da Microsoft Store dependem dela para funcionar; se algum parar de abrir, desfaça este item. O Telomera guarda o valor atual para você poder desfazer.' } }
        'gamemode' { return @{ Id = 'gamemode'; Chave = 'GameMode'; Titulo = 'Ativar o Modo de Jogo do Windows'; Reinicia = $false
            Pergunta = 'Ativar o Modo de Jogo do Windows (prioriza o jogo em primeiro plano e reduz notificações durante ele)? Já vem ativado por padrão na maioria dos Windows; isto só garante que está ligado. O Telomera guarda o valor atual para você poder desfazer.' } }
        'netthrottle' { return @{ Id = 'netthrottle'; Chave = 'NetworkThrottlingIndex'; Titulo = 'Desligar o limite de rede para multimídia (Network Throttling)'; Reinicia = $true
            Pergunta = 'Desligar o limite que o Windows aplica ao tráfego de rede quando um programa de multimídia está em uso? Pode reduzir uma pequena espera extra em jogos online. Precisa reiniciar o computador para valer. O Telomera guarda o valor atual para você poder desfazer.' } }
        'transparency' { return @{ Id = 'transparency'; Chave = 'EnableTransparency'; Titulo = 'Desligar a transparência da interface'; Reinicia = $false
            Pergunta = 'Desligar os efeitos de transparência do Windows (barra de tarefas, menu Iniciar)? É só uma questão de gosto visual; o ganho de desempenho é pequeno. O Telomera guarda o valor atual para você poder desfazer.' } }
        'startsugg' { return @{ Id = 'startsugg'; Chave = 'SystemPaneSuggestionsEnabled'; Titulo = 'Desligar as sugestões no menu Iniciar'; Reinicia = $false
            Pergunta = 'Desligar as sugestões e anúncios de apps que o Windows mostra de vez em quando no menu Iniciar? O Telomera guarda o valor atual para você poder desfazer.' } }
        'delivopt' { return @{ Id = 'delivopt'; Chave = 'DODownloadMode'; Titulo = 'Impedir o Windows de compartilhar atualizações com outros PCs'; Reinicia = $false
            Pergunta = 'Impedir que o Windows envie e baixe atualizações de outros computadores da sua rede/internet (Delivery Optimization), baixando só da Microsoft? Reduz o uso da sua internet em segundo plano. O Telomera guarda o valor atual para você poder desfazer.' } }
        'vfx' { return @{ Id = 'vfx'; Chave = 'VFX'; Titulo = 'Ajustar os efeitos visuais para "melhor desempenho"'; Reinicia = $false
            Pergunta = 'Desligar animações de janela, sombras e outros efeitos visuais (o equivalente a "Ajustar para obter o melhor desempenho" nas Opções de Desempenho do Windows)? Ajuda mais em computadores com vídeo integrado fraco; em PCs modernos o efeito é pequeno. Fonte: conferido contra os valores usados por uma ferramenta de ajustes open source (WinUtil), não documentação oficial da Microsoft -- se alguma animação continuar diferente do esperado, desfaça este item. O Telomera guarda os valores atuais para você poder desfazer.' } }
    }
    return $null
}

function Set-ConfigValor {
    # Aplica uma mudança de configuração. $Valor $null = remover (voltar ao padrão do Windows). Devolve $true se aplicou.
    param([string]$Id, $Valor)
    switch ($Id) {
        'hags' {
            $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name HwSchMode -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $k -Name HwSchMode -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'fast' {
            $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name HiberbootEnabled -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $k -Name HiberbootEnabled -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'usb' {
            if ($null -eq $Valor -or "$Valor" -eq '') { $Valor = 1 }
            & powercfg.exe /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 ([int]$Valor) 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'O powercfg recusou a mudança.' }
            & powercfg.exe /setactive SCHEME_CURRENT 2>&1 | Out-Null
            return $true
        }
        'pcie' {
            if ($null -eq $Valor -or "$Valor" -eq '') { $Valor = 1 }
            & powercfg.exe /setacvalueindex SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 ([int]$Valor) 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'O powercfg recusou a mudança.' }
            & powercfg.exe /setactive SCHEME_CURRENT 2>&1 | Out-Null
            return $true
        }
        'bgapps' {
            $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name GlobalUserDisabled -ErrorAction SilentlyContinue }
            else {
                if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }
                Set-ItemProperty -Path $k -Name GlobalUserDisabled -Value ([int]$Valor) -Type DWord -ErrorAction Stop
            }
            return $true
        }
        'power' {
            # $Valor aqui é o GUID do plano de energia a ativar (string), não 0/1 como os demais.
            $alvo = "$Valor"
            if (-not $alvo) { $alvo = '381b4222-f694-41f0-9685-ff5bb260df2e' }   # Equilibrado (padrão de fábrica do Windows)
            & powercfg.exe /setactive $alvo 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'O powercfg recusou trocar o plano de energia.' }
            return $true
        }
        'gamedvr' {
            # $Valor é sempre um texto JSON (estado a aplicar OU valores guardados para desfazer), nunca 0/1.
            $o = $null; try { $o = "$Valor" | ConvertFrom-Json } catch { }
            $k = 'HKCU:\System\GameConfigStore'
            if (-not $o -or $null -eq $o.Enabled) { Remove-ItemProperty -Path $k -Name GameDVR_Enabled -ErrorAction SilentlyContinue }
            else { if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }; Set-ItemProperty -Path $k -Name GameDVR_Enabled -Value ([int]$o.Enabled) -Type DWord -ErrorAction Stop }
            $kp = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR'
            if (-not $o -or $null -eq $o.Policy) { Remove-ItemProperty -Path $kp -Name AllowGameDVR -ErrorAction SilentlyContinue }
            else { if (-not (Test-Path -LiteralPath $kp)) { New-Item -Path $kp -Force | Out-Null }; Set-ItemProperty -Path $kp -Name AllowGameDVR -Value ([int]$o.Policy) -Type DWord -ErrorAction Stop }
            return $true
        }
        'gamemode' {
            $o = $null; try { $o = "$Valor" | ConvertFrom-Json } catch { }
            $k = 'HKCU:\Software\Microsoft\GameBar'
            if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }
            if (-not $o -or $null -eq $o.Allow) { Remove-ItemProperty -Path $k -Name AllowAutoGameMode -ErrorAction SilentlyContinue } else { Set-ItemProperty -Path $k -Name AllowAutoGameMode -Value ([int]$o.Allow) -Type DWord -ErrorAction Stop }
            if (-not $o -or $null -eq $o.Enabled) { Remove-ItemProperty -Path $k -Name AutoGameModeEnabled -ErrorAction SilentlyContinue } else { Set-ItemProperty -Path $k -Name AutoGameModeEnabled -Value ([int]$o.Enabled) -Type DWord -ErrorAction Stop }
            return $true
        }
        'netthrottle' {
            $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name NetworkThrottlingIndex -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $k -Name NetworkThrottlingIndex -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'transparency' {
            $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name EnableTransparency -ErrorAction SilentlyContinue }
            else { if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }; Set-ItemProperty -Path $k -Name EnableTransparency -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'startsugg' {
            $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name SystemPaneSuggestionsEnabled -ErrorAction SilentlyContinue }
            else { if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }; Set-ItemProperty -Path $k -Name SystemPaneSuggestionsEnabled -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            return $true
        }
        'delivopt' {
            $k = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
            if ($null -eq $Valor -or "$Valor" -eq '') { Remove-ItemProperty -Path $k -Name DODownloadMode -ErrorAction SilentlyContinue }
            else { if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }; Set-ItemProperty -Path $k -Name DODownloadMode -Value ([int]$Valor) -Type DWord -ErrorAction Stop }
            try { Restart-Service -Name DoSvc -Force -ErrorAction Stop } catch { }
            return $true
        }
        'vfx' {
            $o = $null; try { $o = "$Valor" | ConvertFrom-Json } catch { }
            Set-ValoresVfx -Valores $o
            return $true
        }
    }
    return $false
}

function Get-ConfigAtual {
    # Valor atual da configuração (para guardar antes de mudar).
    param([string]$Id)
    try {
        switch ($Id) {
            'hags' { return (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction Stop).HwSchMode }
            'fast' { return (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -ErrorAction Stop).HiberbootEnabled }
            'usb' { $o = & powercfg.exe /query SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 2>$null | Out-String; $v = ConvertFrom-SaidaPowercfg $o; if ($v) { return $v.Tomada } }
            'pcie' { $o = & powercfg.exe /query SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 2>$null | Out-String; $v = ConvertFrom-SaidaPowercfg $o; if ($v) { return $v.Tomada } }
            'bgapps' { return (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name GlobalUserDisabled -ErrorAction Stop).GlobalUserDisabled }
            'power' { $o = & powercfg.exe /getactivescheme 2>$null | Out-String; if ($o -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $Matches[1] } }
            'gamedvr' {
                $en = $null; try { $en = (Get-ItemProperty -Path 'HKCU:\System\GameConfigStore' -Name GameDVR_Enabled -ErrorAction Stop).GameDVR_Enabled } catch { }
                $pol = $null; try { $pol = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' -Name AllowGameDVR -ErrorAction Stop).AllowGameDVR } catch { }
                return (@{ Enabled = $en; Policy = $pol } | ConvertTo-Json -Compress)
            }
            'gamemode' {
                $a = $null; try { $a = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\GameBar' -Name AllowAutoGameMode -ErrorAction Stop).AllowAutoGameMode } catch { }
                $b = $null; try { $b = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\GameBar' -Name AutoGameModeEnabled -ErrorAction Stop).AutoGameModeEnabled } catch { }
                return (@{ Allow = $a; Enabled = $b } | ConvertTo-Json -Compress)
            }
            'netthrottle' { return (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name NetworkThrottlingIndex -ErrorAction Stop).NetworkThrottlingIndex }
            'transparency' { return (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name EnableTransparency -ErrorAction Stop).EnableTransparency }
            'startsugg' { return (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name SystemPaneSuggestionsEnabled -ErrorAction Stop).SystemPaneSuggestionsEnabled }
            'delivopt' { return (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name DODownloadMode -ErrorAction Stop).DODownloadMode }
            'vfx' { return (Get-ValoresVfxAtuais | ConvertTo-Json -Compress) }
        }
    } catch { }
    return $null
}

function Get-ValoresVfxAtuais {
    # Lê os valores atuais dos efeitos visuais que o item "vfx" muda, para poder desfazer depois.
    # Fonte da lista: conferida contra os valores usados por uma ferramenta de ajustes open source
    # (WinUtil), não documentação oficial da Microsoft para cada valor individual.
    $itens = @(
        @{ K = 'HKCU:\Control Panel\Desktop'; N = 'DragFullWindows' }
        @{ K = 'HKCU:\Control Panel\Desktop'; N = 'MenuShowDelay' }
        @{ K = 'HKCU:\Control Panel\Desktop\WindowMetrics'; N = 'MinAnimate' }
        @{ K = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N = 'ListviewAlphaSelect' }
        @{ K = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N = 'ListviewShadow' }
        @{ K = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; N = 'TaskbarAnimations' }
        @{ K = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'; N = 'VisualFXSetting' }
        @{ K = 'HKCU:\Software\Microsoft\Windows\DWM'; N = 'EnableAeroPeek' }
    )
    $h = [ordered]@{}
    foreach ($it in $itens) {
        $v = $null
        try { $v = (Get-ItemProperty -Path $it.K -Name $it.N -ErrorAction Stop).($it.N) } catch { }
        $h[$it.N] = $v
    }
    return $h
}

function Set-ValoresVfx {
    # $Valores = objeto/hashtable Nome -> valor ($null ou ausente = remover, volta ao padrão do Windows).
    param($Valores)
    $tipos = @{ DragFullWindows = 'String'; MenuShowDelay = 'String'; MinAnimate = 'String'; ListviewAlphaSelect = 'DWord'; ListviewShadow = 'DWord'; TaskbarAnimations = 'DWord'; VisualFXSetting = 'DWord'; EnableAeroPeek = 'DWord' }
    $chaves = @{ DragFullWindows = 'HKCU:\Control Panel\Desktop'; MenuShowDelay = 'HKCU:\Control Panel\Desktop'; MinAnimate = 'HKCU:\Control Panel\Desktop\WindowMetrics'; ListviewAlphaSelect = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; ListviewShadow = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; TaskbarAnimations = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; VisualFXSetting = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'; EnableAeroPeek = 'HKCU:\Software\Microsoft\Windows\DWM' }
    foreach ($nome in @($chaves.Keys)) {
        $k = $chaves[$nome]
        $v = $null
        if ($Valores) { $v = $Valores.$nome }
        if ($null -eq $v -or "$v" -eq '') { Remove-ItemProperty -Path $k -Name $nome -ErrorAction SilentlyContinue }
        else {
            if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }
            if ($tipos[$nome] -eq 'String') { Set-ItemProperty -Path $k -Name $nome -Value "$v" -Type String -ErrorAction Stop }
            else { Set-ItemProperty -Path $k -Name $nome -Value ([int]$v) -Type DWord -ErrorAction Stop }
        }
    }
}

function Invoke-ReparoCfg {
    # Executa uma mudança de configuração com confirmação, histórico e valor original guardado. Devolve as linhas de texto.
    param([string]$Id)
    $feito = New-Object System.Collections.Generic.List[string]
    $pl = Get-PlanoReparoCfg $Id
    if (-not $pl) { $feito.Add('Mudança desconhecida.'); return $feito.ToArray() }
    if (-not (Confirm-Acao $pl.Pergunta)) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    try {
        $antes = Get-ConfigAtual $Id
        Save-ConfigAntes -Chave $pl.Chave -Valor $antes
        $novo = 0
        [void](Set-ConfigValor -Id $Id -Valor $novo)
        Add-Alteracao -Acao $pl.Titulo -Resultado ("executado (valor anterior: {0})" -f $(if ($null -eq $antes) { 'não definido' } else { $antes }))
        $feito.Add($pl.Titulo + ': feito.')
        if ($pl.Reinicia) { $feito.Add('Reinicie o computador para a mudança valer.') }
        $feito.Add('Para voltar ao que era antes: Ferramentas de reparo > Desfazer o que o Telomera fez > "Desfazer as mudanças de configuração".')
    } catch {
        Add-Alteracao -Acao $pl.Titulo -Resultado "falhou: $($_.Exception.Message)"
        $feito.Add("Falhou: $($_.Exception.Message)")
    }
    return $feito.ToArray()
}

function Invoke-DesfazerCfg {
    # Volta todas as configurações mudadas pelo Telomera ao valor que tinham antes.
    $feito = New-Object System.Collections.Generic.List[string]
    $h = Get-ConfigAntes
    if ($h.Count -eq 0) { $feito.Add('O Telomera não mudou nenhuma configuração neste computador (ou já foram desfeitas).'); return $feito.ToArray() }
    $nomes = @{ HwSchMode = 'Agendamento de GPU acelerado por hardware'; PcieAspmAc = 'Economia de energia do PCIe (na tomada)'; UsbSelectiveSuspendAc = 'Economia de energia do USB (na tomada)'; HiberbootEnabled = 'Inicialização rápida'; BackgroundAppsDisabled = 'Apps da Microsoft Store em segundo plano'; PowerScheme = 'Plano de energia'
        GameDVR = 'Gravação em segundo plano (Game DVR/Game Bar)'; GameMode = 'Modo de Jogo'; NetworkThrottlingIndex = 'Limite de rede para multimídia'; EnableTransparency = 'Transparência da interface'; SystemPaneSuggestionsEnabled = 'Sugestões no menu Iniciar'; DODownloadMode = 'Compartilhamento de atualizações com outros PCs'; VFX = 'Efeitos visuais em "melhor desempenho"' }
    $lista = ($h.Keys | ForEach-Object { $nomes[$_] }) -join ', '
    if (-not (Confirm-Acao ("Voltar estas configurações ao valor que tinham antes do Telomera: {0}?" -f $lista))) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    $ids = @{ HwSchMode = 'hags'; PcieAspmAc = 'pcie'; UsbSelectiveSuspendAc = 'usb'; HiberbootEnabled = 'fast'; BackgroundAppsDisabled = 'bgapps'; PowerScheme = 'power'
        GameDVR = 'gamedvr'; GameMode = 'gamemode'; NetworkThrottlingIndex = 'netthrottle'; EnableTransparency = 'transparency'; SystemPaneSuggestionsEnabled = 'startsugg'; DODownloadMode = 'delivopt'; VFX = 'vfx' }
    $semTexto = @('GameDVR', 'GameMode', 'VFX')   # valor guardado é um texto JSON, não um número/GUID
    foreach ($k in @($h.Keys)) {
        try {
            $v = $h[$k]
            $valorDesfazer = if ($semTexto -contains $k) { "$v" } elseif ($k -eq 'PowerScheme') { $(if ("$v" -eq '') { $null } else { "$v" }) } else { $(if ("$v" -eq '') { $null } else { [int]$v }) }
            [void](Set-ConfigValor -Id $ids[$k] -Valor $valorDesfazer)
            Clear-ConfigAntes -Chave $k
            Add-Alteracao -Acao ("Desfazer: " + $nomes[$k]) -Resultado 'executado'
            $feito.Add($nomes[$k] + ': voltou ao valor anterior.')
        } catch { Add-Alteracao -Acao ("Desfazer: " + $nomes[$k]) -Resultado "falhou: $($_.Exception.Message)"; $feito.Add($nomes[$k] + ": falhou ($($_.Exception.Message)).") }
    }
    $feito.Add('Reinicie o computador para concluir.')
    return $feito.ToArray()
}

# ----------------------------------------------------------------------------
# Otimização: ajustes conhecidos, reversíveis e com fonte conferida (nenhum hack de
# tutorial de internet sem explicação -- ver README para a lista completa e as fontes).
# ----------------------------------------------------------------------------
function Get-PlanoOtimizacao {
    # Itens fixos (fora os programas de inicialização, que são dinâmicos e listados à parte
    # por Get-ItensInicializacaoParaOtimizar). PadraoMarcado é só a sugestão inicial da tela.
    $ehNotebook = $false
    try { $ehNotebook = ((@(Get-CimInstance Win32_Battery -ErrorAction Stop)).Count -gt 0) } catch { }
    return @(
        @{ Id = 'hags'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar o agendamento de GPU por hardware'; Desc = 'Evita travamento de imagem em jogos em alguns computadores. Precisa reiniciar.'; PadraoMarcado = $true }
        @{ Id = 'pcie'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar a economia de energia do PCIe'; Desc = 'Evita a placa de vídeo entrar em repouso profundo e travar ao sair dele.'; PadraoMarcado = $true }
        @{ Id = 'usb'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar a economia de energia do USB'; Desc = 'Evita teclado, mouse e headset desconectando no meio do jogo.'; PadraoMarcado = $true }
        @{ Id = 'fast'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar a inicialização rápida do Windows'; Desc = 'Evita manter um driver travado de uma ligada para a outra. Liga alguns segundos mais devagar. Precisa reiniciar.'; PadraoMarcado = $false }
        @{ Id = 'gamedvr'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar a gravação em segundo plano (Game DVR/Game Bar)'; Desc = 'Libera CPU/GPU/disco que a gravação automática usa mesmo sem você gravar nada. Alguns jogos da Microsoft Store dependem dela; se algum parar de abrir, desfaça este item.'; PadraoMarcado = $false }
        @{ Id = 'gamemode'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Ativar o Modo de Jogo do Windows'; Desc = 'Já vem ativado por padrão na maioria dos Windows; isto só confere e garante que está ligado.'; PadraoMarcado = $true }
        @{ Id = 'netthrottle'; Categoria = 'Desempenho em jogos e vídeo'; Titulo = 'Desligar o limite de rede para multimídia'; Desc = 'Pode reduzir uma pequena espera extra em jogos online. Precisa reiniciar.'; PadraoMarcado = $false }
        @{ Id = 'power'; Categoria = 'Energia e segundo plano'; Titulo = 'Plano de energia em "Alto desempenho"'; Desc = $(if ($ehNotebook) { 'Reduz a duração da bateria -- este computador parece ser um notebook, por isso vem desmarcado.' } else { 'Sem efeito relevante na conta de luz de um desktop ligado na tomada.' }); PadraoMarcado = (-not $ehNotebook) }
        @{ Id = 'bgapps'; Categoria = 'Energia e segundo plano'; Titulo = 'Impedir apps da Microsoft Store de rodar em segundo plano'; Desc = 'Só afeta apps baixados da Microsoft Store (não os programas comuns instalados por fora dela).'; PadraoMarcado = $true }
        @{ Id = 'delivopt'; Categoria = 'Energia e segundo plano'; Titulo = 'Impedir o Windows de compartilhar atualizações com outros PCs'; Desc = 'Reduz o uso da sua internet em segundo plano; baixa atualizações só da Microsoft.'; PadraoMarcado = $true }
        @{ Id = 'transparency'; Categoria = 'Inicialização e interface'; Titulo = 'Desligar a transparência da interface'; Desc = 'Questão de gosto visual; o ganho de desempenho é pequeno.'; PadraoMarcado = $false }
        @{ Id = 'startsugg'; Categoria = 'Inicialização e interface'; Titulo = 'Desligar as sugestões no menu Iniciar'; Desc = 'Remove os anúncios e sugestões de apps que aparecem de vez em quando no menu Iniciar.'; PadraoMarcado = $false }
        @{ Id = 'vfx'; Categoria = 'Inicialização e interface'; Titulo = 'Ajustar os efeitos visuais para "melhor desempenho"'; Desc = 'Desliga animações de janela e sombras (como "Ajustar para obter o melhor desempenho" do Windows). Ajuda mais em vídeo integrado fraco. Fonte conferida contra uma ferramenta de ajustes open source, não documentação oficial da Microsoft para cada valor.'; PadraoMarcado = $false }
        @{ Id = 'temp'; Categoria = 'Limpeza e manutenção'; Titulo = 'Limpar arquivos temporários (mais de 2 dias)'; Desc = 'Mesma limpeza de "Ferramentas de reparo"; nada que esteja em uso é apagado.'; PadraoMarcado = $true }
        @{ Id = 'lixeira'; Categoria = 'Limpeza e manutenção'; Titulo = 'Esvaziar a Lixeira'; Desc = 'Apaga os arquivos que já estão na Lixeira (não dá para desfazer este item específico).'; PadraoMarcado = $false }
        @{ Id = 'wu-cache'; Categoria = 'Limpeza e manutenção'; Titulo = 'Limpar o cache do Windows Update'; Desc = 'Só vale a pena se o Windows Update estiver lento ou falhando. Reinicia os serviços de atualização.'; PadraoMarcado = $false }
        @{ Id = 'cache-icones'; Categoria = 'Limpeza e manutenção'; Titulo = 'Limpar o cache de ícones e miniaturas'; Desc = 'Corrige ícones errados ou miniaturas que não aparecem. O Windows reconstrói na hora; não apaga nenhum arquivo seu (não dá para desfazer este item específico, mas também não há nada a desfazer).'; PadraoMarcado = $false }
        @{ Id = 'cache-fontes'; Categoria = 'Limpeza e manutenção'; Titulo = 'Limpar o cache de fontes'; Desc = 'Corrige fontes borradas ou com aparência errada depois de instalar/remover uma fonte. O Windows reconstrói na hora.'; PadraoMarcado = $false }
        @{ Id = 'loja-cache'; Categoria = 'Limpeza e manutenção'; Titulo = 'Limpar o cache da Microsoft Store'; Desc = 'Usa o reparador oficial do Windows (wsreset). Ajuda quando a Store trava, não atualiza ou não faz login -- diferente de "Reparar a Microsoft Store", que reinstala o app em si.'; PadraoMarcado = $false }
    )
}

function Get-ItensInicializacaoParaOtimizar {
    # Só os programas ligados pela chave de registro "Run" podem ser ativados/desativados com segurança
    # pelo Telomera, do mesmo jeito que o Gerenciador de Tarefas faz (chave StartupApproved\Run). Os da
    # pasta Inicializar (atalhos) ficam de fora por enquanto: exigiriam mover arquivo, não só registro.
    $itens = @()
    try {
        foreach ($c in @(Get-CimInstance Win32_StartupCommand -ErrorAction Stop)) {
            $loc = "$($c.Location)"
            $hive = $null
            if ($loc -match '^HKLM.*\\Run$') { $hive = 'HKLM' } elseif ($loc -match '^HKCU.*\\Run$') { $hive = 'HKCU' }
            if (-not $hive -or -not "$($c.Name)") { continue }
            $aprov = if ($hive -eq 'HKLM') { 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' } else { 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
            $ativado = $true
            try { $v = (Get-ItemProperty -Path $aprov -Name $c.Name -ErrorAction Stop).($c.Name); if ($v -and $v.Count -ge 1 -and [int]$v[0] -eq 3) { $ativado = $false } } catch { }
            $itens += [pscustomobject]@{ Id = "$hive|$($c.Name)"; Nome = "$($c.Name)"; Hive = $hive; Ativado = $ativado }
        }
    } catch { }
    return @($itens | Sort-Object Nome)
}

function Set-ItemInicializacao {
    # Liga/desliga um programa de inicialização pela mesma chave que o Gerenciador de Tarefas usa
    # (StartupApproved\Run): primeiro byte 02 = ativado, 03 = desativado, resto zerado.
    param([string]$Hive, [string]$Nome, [bool]$Ativar)
    $aprov = if ($Hive -eq 'HKLM') { 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' } else { 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
    if (-not (Test-Path -LiteralPath $aprov)) { New-Item -Path $aprov -Force | Out-Null }
    $bytes = New-Object byte[] 12
    $bytes[0] = [byte]$(if ($Ativar) { 2 } else { 3 })
    Set-ItemProperty -Path $aprov -Name $Nome -Value $bytes -Type Binary -ErrorAction Stop
}

function Get-ArquivoIniDesativadaPeloTelomera { return (Get-ArquivoDados 'inicializacao-desativada.json') }

function Get-ItensIniDesativadosPeloTelomera {
    $f = Get-ArquivoIniDesativadaPeloTelomera
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    try { return @((Get-Content -LiteralPath $f -Raw | ConvertFrom-Json)) } catch { return @() }
}

function Save-ItemIniDesativadoPeloTelomera {
    param([string]$Id)
    $lista = @(Get-ItensIniDesativadosPeloTelomera)
    if ($lista -contains $Id) { return }
    $lista += $Id
    $f = Get-ArquivoIniDesativadaPeloTelomera
    $dir = Split-Path -Parent $f
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [IO.File]::WriteAllText($f, ($lista | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
}

function Invoke-OtimizacaoWindows {
    # Aplica os itens fixos escolhidos (por Id, de Get-PlanoOtimizacao) e os programas de inicialização
    # escolhidos para desativar (por Id "Hive|Nome", de Get-ItensInicializacaoParaOtimizar). Sem pergunta
    # por item: a lista inteira já foi mostrada e confirmada de uma vez na tela.
    param([string[]]$Ids = @(), [string[]]$IdsInicializacao = @())
    $feito = New-Object System.Collections.Generic.List[string]
    $cfgIds = @('hags', 'pcie', 'usb', 'fast', 'bgapps', 'power', 'gamedvr', 'gamemode', 'netthrottle', 'transparency', 'startsugg', 'delivopt', 'vfx')
    foreach ($id in $Ids) {
        try {
            if ($cfgIds -contains $id) {
                $pl = Get-PlanoReparoCfg $id
                $antes = Get-ConfigAtual $id
                Save-ConfigAntes -Chave $pl.Chave -Valor $antes
                # O valor "ligado"/otimizado de cada item -- igual ao que Invoke-ReparoCfg já usa para
                # hags/pcie/usb/fast (sempre 0 = desligado). Corrigido em 2.34.0: antes esta função usava
                # 1 para todos (exceto power), o que LIGAVA a economia de energia do PCIe/USB e a
                # inicialização rápida em vez de desligar -- o oposto do que a tela de otimização promete.
                $novo = switch ($id) {
                    'power' { '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }   # GUID = Alto desempenho (plano padrão do Windows)
                    'bgapps' { 1 }
                    'gamedvr' { '{"Enabled":0,"Policy":0}' }
                    'gamemode' { '{"Allow":1,"Enabled":1}' }
                    'netthrottle' { -1 }   # 0xFFFFFFFF como Int32: desativa o limite de rede para multimídia
                    'transparency' { 0 }
                    'startsugg' { 0 }
                    'delivopt' { 0 }   # DownloadMode_CdnOnly: só baixa da Microsoft, nunca de outros PCs
                    'vfx' { '{"DragFullWindows":"0","MenuShowDelay":"200","MinAnimate":"0","ListviewAlphaSelect":0,"ListviewShadow":0,"TaskbarAnimations":0,"VisualFXSetting":3,"EnableAeroPeek":0}' }
                    default { 0 }   # hags, pcie, usb, fast
                }
                [void](Set-ConfigValor -Id $id -Valor $novo)
                Add-Alteracao -Acao ('Otimização: ' + $pl.Titulo) -Resultado 'executado'
                $feito.Add($pl.Titulo + ': feito.' + $(if ($pl.Reinicia) { ' (vale depois de reiniciar)' } else { '' }))
            } elseif ($id -eq 'temp') {
                $l = Clear-Temporarios
                Add-Alteracao -Acao 'Otimização: limpar temporários' -Resultado ("liberado {0}" -f (Format-Tamanho $l))
                $feito.Add(("Temporários: liberado {0}." -f (Format-Tamanho $l)))
            } elseif ($id -eq 'lixeira') {
                Clear-RecycleBin -Force -ErrorAction Stop
                Add-Alteracao -Acao 'Otimização: esvaziar a Lixeira' -Resultado 'executado'
                $feito.Add('Lixeira esvaziada.')
            } elseif ($id -eq 'wu-cache') {
                Reset-WindowsUpdate
                Add-Alteracao -Acao 'Otimização: limpar cache do Windows Update' -Resultado 'executado'
                $feito.Add('Cache do Windows Update limpo. Reinicie e procure atualizações de novo.')
            } elseif ($id -eq 'cache-icones') {
                Clear-CacheIcones
                Add-Alteracao -Acao 'Otimização: limpar cache de ícones e miniaturas' -Resultado 'executado'
                $feito.Add('Cache de ícones e miniaturas limpo.')
            } elseif ($id -eq 'cache-fontes') {
                Clear-CacheFontes
                Add-Alteracao -Acao 'Otimização: limpar cache de fontes' -Resultado 'executado'
                $feito.Add('Cache de fontes limpo.')
            } elseif ($id -eq 'loja-cache') {
                Reset-CacheLoja
                Add-Alteracao -Acao 'Otimização: limpar cache da Microsoft Store' -Resultado 'executado'
                $feito.Add('Cache da Microsoft Store limpo (wsreset).')
            }
        } catch { Add-Alteracao -Acao "Otimização: $id" -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("$id`: falhou ($($_.Exception.Message))." ) }
    }
    foreach ($idIni in $IdsInicializacao) {
        $p = $idIni -split '\|', 2
        if ($p.Count -ne 2) { continue }
        try {
            Set-ItemInicializacao -Hive $p[0] -Nome $p[1] -Ativar $false
            Save-ItemIniDesativadoPeloTelomera -Id $idIni
            Add-Alteracao -Acao ("Otimização: desativar na inicialização ({0})" -f $p[1]) -Resultado 'executado'
            $feito.Add(("{0}: removido da inicialização." -f $p[1]))
        } catch { Add-Alteracao -Acao ("Otimização: desativar na inicialização ({0})" -f $p[1]) -Resultado "falhou: $($_.Exception.Message)"; $feito.Add(("{0}: falhou ({1})." -f $p[1], $_.Exception.Message)) }
    }
    return $feito.ToArray()
}

function Invoke-DesfazerOtimizacaoInicializacao {
    # Reativa só os programas de inicialização que o PRÓPRIO Telomera desativou (nunca um que o usuário
    # já tinha desativado antes, por fora).
    $feito = New-Object System.Collections.Generic.List[string]
    $lista = @(Get-ItensIniDesativadosPeloTelomera)
    if ($lista.Count -eq 0) { $feito.Add('O Telomera não desativou nenhum programa de inicialização neste computador (ou já foram reativados).'); return $feito.ToArray() }
    foreach ($idIni in $lista) {
        $p = $idIni -split '\|', 2
        if ($p.Count -ne 2) { continue }
        try { Set-ItemInicializacao -Hive $p[0] -Nome $p[1] -Ativar $true; Add-Alteracao -Acao ("Reativar na inicialização ({0})" -f $p[1]) -Resultado 'executado'; $feito.Add(("{0}: reativado." -f $p[1])) }
        catch { $feito.Add(("{0}: falhou ({1})." -f $p[1], $_.Exception.Message)) }
    }
    $f = Get-ArquivoIniDesativadaPeloTelomera
    try { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } catch { }
    return $feito.ToArray()
}

# ----------------------------------------------------------------------------
# Guias passo a passo (texto)
# ----------------------------------------------------------------------------
function Get-TextoGuia {
    param([string]$Id)
    switch ($Id) {
        'guia-fonte' { return @(
            'Guia: testar com outra fonte de alimentação',
            '',
            'Para que serve: separar "fonte" de "placa de vídeo" e "memória" quando o computador trava ou desliga sob carga. Nenhum programa mede a fonte de verdade; a troca é o teste.',
            '',
            'Antes de começar',
            '  1. Salve tudo, desligue o Windows e depois a chave atrás da fonte. Tire o cabo da tomada e segure o botão de ligar por 5 segundos para descarregar.',
            '  2. Tire uma foto de como os cabos estão ligados (placa-mãe, placa de vídeo, discos).',
            '  3. Anote o modelo e a potência da fonte atual (está na etiqueta lateral).',
            '',
            'Trocando',
            '  4. Desligue os cabos: o grande de 24 pinos na placa-mãe, o de 4+4 pinos perto do processador, os de 6 ou 8 pinos da placa de vídeo e os dos discos.',
            '  5. Tire os 4 parafusos atrás do gabinete e retire a fonte.',
            '  6. Encaixe a fonte emprestada e use SÓ os cabos dela: nunca misture cabos de modelos diferentes (o encaixe é igual, mas os fios não).',
            '  7. Ligue o 24 pinos, o 4+4 do processador, o 6/8 pinos da placa de vídeo e os discos. Ligue na tomada e a chave atrás da fonte.',
            '',
            'Para o teste valer',
            '  8. Use uma fonte de marca conhecida, de pelo menos 450 W para uma placa como a GTX 1650 com um Ryzen 3.',
            '  9. Ligue o monitor do Telomera (Ferramentas de reparo > Monitor em tempo real) e jogue por 20 a 30 minutos o jogo que travava.',
            ' 10. Se NÃO travar por vários dias, a fonte antiga é a causa. Se travar do mesmo jeito, a fonte está descartada: passe para a memória e a placa de vídeo.',
            '',
            'Cuidado: a fonte guarda carga mesmo desligada. Não abra a fonte e não mexa com o computador ligado na tomada.') -join "`r`n" }
        'guia-driver-video' { return @(
            'Guia: instalar o driver de vídeo do zero (instalação limpa)',
            '',
            'Para que serve: quando o driver de vídeo está corrompido, tem sobras de versões antigas ou a última versão trouxe defeitos (imagem congelada, tela preta, jogo fechando), uma instalação limpa costuma resolver. O Telomera faz a limpeza; a instalação do driver é feita com o instalador do próprio fabricante.',
            '',
            'Antes',
            '  1. Baixe ANTES o instalador do driver em nvidia.com/drivers (ou amd.com/support, ou intel.com). Se o problema começou depois de uma atualização, escolha uma versão mais antiga e estável (uma ou duas versões atrás). Guarde o arquivo na Área de Trabalho.',
            '  2. Salve tudo e feche os jogos.',
            '',
            'Limpeza',
            '  3. Em Drivers > "Limpeza do driver de vídeo", confirme. O Telomera cria um ponto de restauração, guarda uma cópia do driver atual e remove o driver de vídeo do fabricante.',
            '  4. Reinicie o computador. A tela fica em baixa resolução: é normal (driver genérico).',
            '',
            'Instalação',
            '  5. Desconecte a internet para o Windows Update não instalar outro driver por cima (tire o cabo de rede ou desligue o Wi-Fi).',
            '  6. Execute o instalador. Na NVIDIA: "Instalação personalizada" > marque "Executar instalação limpa". Instale só o driver gráfico (não precisa do GeForce Experience).',
            '  7. Reinicie. Em seguida, em Drivers, use "Impedir o Windows Update de trocar o driver de vídeo" na verificação do Telomera para o Windows não sobrescrever.',
            '  8. Reconecte a internet e teste o jogo com o monitor do Telomera ligado.',
            '',
            'Se algo der errado: o Telomera guardou o driver anterior; o comando de volta aparece na ferramenta e no histórico ("Ver o que o Telomera já mudou").') -join "`r`n" }
        'guia-energia' { return @(
            'Guia: limitar a energia da placa de vídeo (para testar picos de consumo)',
            '',
            'Para que serve: se a placa consome menos, os picos de energia ficam menores. Se o travamento some com o limite, o problema está no pico de consumo (fonte ou a própria placa). Nada é danificado: o limite volta ao normal ao reiniciar o computador (no nvidia-smi) ou quando você desfaz (no Afterburner).',
            '',
            'Opção A - MSI Afterburner (a mais fácil)',
            '  1. Baixe o MSI Afterburner no site oficial (msi.com/Landing/afterburner).',
            '  2. Abra o programa e arraste o controle "Power Limit (%)" para 60% (ou 70%).',
            '  3. Clique no botão de confirmar (o "V") e deixe o programa aberto.',
            '  4. Jogue o jogo que travava por 20 a 30 minutos com o monitor do Telomera ligado.',
            '',
            'Opção B - nvidia-smi (sem instalar nada, precisa de administrador)',
            '  1. Abra o Prompt de Comando como administrador.',
            '  2. Veja os limites aceitos pela placa: nvidia-smi -q -d POWER (procure Min Power Limit e Max Power Limit).',
            '  3. Defina o limite, por exemplo 50 W para uma GTX 1650 de 75 W: nvidia-smi -pl 50',
            '  4. Jogue com o monitor ligado. Ao reiniciar o computador o limite volta ao padrão.',
            '',
            'Como ler o resultado',
            '  - Não travou depois de muito tempo (mais que o tempo em que travava antes): o problema é o pico de consumo. Teste outra fonte.',
            '  - Travou igual: o consumo não é a causa. Passe para memória (teste de memória do Telomera) e para o driver.',
            '',
            'Dica: limitar os quadros por segundo a 60 no NVIDIA Control Panel (Configurações 3D > Taxa de quadros máxima) também reduz o consumo.') -join "`r`n" }
    }
    return ''
}

# ----------------------------------------------------------------------------
# SMART detalhado (erros de CRC do cabo, setores com problema)
# ----------------------------------------------------------------------------
function ConvertFrom-SmartVendor {
    # Lê os bytes "VendorSpecific" do SMART (12 bytes por atributo a partir do byte 2). Devolve lista de @{ Id; Valor; Pior; Raw }.
    param([byte[]]$Bytes)
    $r = New-Object System.Collections.Generic.List[object]
    if (-not $Bytes -or $Bytes.Length -lt 14) { return @() }
    for ($o = 2; $o + 11 -lt $Bytes.Length -and $o -lt 2 + 30 * 12; $o += 12) {
        $id = $Bytes[$o]
        if ($id -eq 0) { continue }
        $raw = [uint64]0
        for ($k = 5; $k -ge 0; $k--) { $raw = ($raw -shl 8) -bor [uint64]$Bytes[$o + 5 + $k] }
        $r.Add(@{ Id = [int]$id; Valor = [int]$Bytes[$o + 3]; Pior = [int]$Bytes[$o + 4]; Raw = [uint64]$raw })
    }
    return $r.ToArray()
}

function Get-AvaliacaoSmart {
    # Avalia os atributos SMART (lista de @{ Id; Valor; Pior; Raw }). Devolve @{ Linhas; Gravidade; Resumo }.
    param($Atributos, [string]$Nome = 'Disco')
    $l = New-Object System.Collections.Generic.List[string]
    $grav = 'Info'
    $at = @{}; foreach ($a in @($Atributos)) { $at[[int]$a.Id] = $a }
    $g = 'Info'
    if ($at.ContainsKey(199) -and [uint64]$at[199].Raw -gt 0) {
        $n = [uint64]$at[199].Raw
        $l.Add(("{0}: {1} erro(s) de CRC na transferência de dados (SMART 199). Isso quase sempre é o cabo SATA ruim, mal encaixado ou a porta, e não o disco." -f $Nome, $n))
        if ($g -eq 'Info') { $g = 'Atencao' }
        $l.Add('Troque o cabo SATA por um novo (e teste outra porta). Esse contador não zera: se continuar subindo depois da troca, o problema é outro.')
    }
    if ($at.ContainsKey(197) -and [uint64]$at[197].Raw -gt 0) { $l.Add(("{0}: {1} setor(es) pendentes de remapeamento (SMART 197): o disco encontrou áreas que não consegue ler. Faça backup agora." -f $Nome, [uint64]$at[197].Raw)); $g = 'Critico' }
    if ($at.ContainsKey(198) -and [uint64]$at[198].Raw -gt 0) { $l.Add(("{0}: {1} setor(es) incorrigíveis offline (SMART 198). Faça backup agora." -f $Nome, [uint64]$at[198].Raw)); $g = 'Critico' }
    if ($at.ContainsKey(5) -and [uint64]$at[5].Raw -gt 0) {
        $n5 = [uint64]$at[5].Raw
        $l.Add(("{0}: {1} setor(es) já remapeado(s) (SMART 5)." -f $Nome, $n5))
        if ($n5 -ge 50) { $g = 'Critico'; $l.Add('Muitos setores remapeados: o disco está falhando. Faça backup e troque.') } elseif ($g -eq 'Info') { $g = 'Atencao' }
    }
    if ($at.ContainsKey(10) -and [uint64]$at[10].Raw -gt 0) { $l.Add(("{0}: o motor do HD precisou de {1} nova(s) tentativa(s) para girar (SMART 10): sinal de problema de alimentação ou do motor." -f $Nome, [uint64]$at[10].Raw)); if ($g -eq 'Info') { $g = 'Atencao' } }
    if ($at.ContainsKey(188) -and ([uint64]$at[188].Raw -band 0xFFFF) -gt 0) { $l.Add(("{0}: o disco registrou {1} esgotamento(s) de tempo em comandos (SMART 188): costuma ser cabo ou fonte." -f $Nome, ([uint64]$at[188].Raw -band 0xFFFF))); if ($g -eq 'Info') { $g = 'Atencao' } }
    if ($at.ContainsKey(9)) { $l.Add(("{0}: {1:N0} horas ligado (SMART 9)." -f $Nome, [uint64]$at[9].Raw)) }
    return @{ Linhas = $l.ToArray(); Gravidade = $g }
}

function Get-SmartAtributos {
    # Lê os atributos SMART de todos os discos pelo WMI (precisa de administrador). Devolve lista de @{ Instancia; Atributos }.
    if ($env:OS -ne 'Windows_NT') { return @() }
    $r = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($d in @(Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictData -ErrorAction Stop)) {
            $r.Add(@{ Instancia = "$($d.InstanceName)"; Atributos = @(ConvertFrom-SmartVendor ([byte[]]$d.VendorSpecific)) })
        }
    } catch { }
    return $r.ToArray()
}

function Invoke-AnaliseSmartAtributos {
    $discos = @(Get-SmartAtributos)
    if ($discos.Count -eq 0) { return }
    $nomes = @{}
    try { foreach ($pd in @(Get-PhysicalDisk -ErrorAction Stop)) { $nomes[[string]$pd.DeviceId] = "$($pd.FriendlyName)" } } catch { }
    $i = 0
    foreach ($d in $discos) {
        $nome = $(if ($nomes.Count -gt $i) { @($nomes.Values)[$i] } else { "Disco $($i + 1)" })
        $i++
        $av = Get-AvaliacaoSmart -Atributos $d.Atributos -Nome $nome
        $achados = @($av.Linhas | Where-Object { $_ -notmatch 'horas ligado' })
        if ($achados.Count -eq 0) { continue }
        Add-Achado -Gravidade $av.Gravidade -Categoria 'Disco' -Titulo ("SMART detalhado: {0}" -f $nome) -Detalhe ($av.Linhas -join ' | ') `
            -Solucao 'Faça backup dos arquivos importantes. Se for erro de CRC, troque o cabo SATA e a porta antes de pensar em trocar o disco.' `
            -Explicacao 'O SMART é o registro que o próprio disco guarda de erros e de setores com problema. Erros de CRC acontecem na transferência (cabo/porta); setores pendentes e remapeados são defeitos da superfície do disco.' `
            -Veredito $(if ($av.Gravidade -eq 'Critico') { 'Corrigir' } else { 'Depende' })
    }
}

# ----------------------------------------------------------------------------
# Drivers de som, rede, Wi-Fi e chipset; link do fabricante da placa-mãe
# ----------------------------------------------------------------------------
function Get-AvaliacaoDriversGerais {
    # Lista os drivers por tipo, com a idade. $Lista: @{ Classe; Nome; Fabricante; Versao; Data }. Devolve @{ Linhas; Atencao }.
    param($Lista, [datetime]$Agora = (Get-Date))
    $l = New-Object System.Collections.Generic.List[string]
    $atencao = $false
    $tipos = [ordered]@{ MEDIA = 'Som'; NET = 'Rede e Wi-Fi'; SYSTEM = 'Chipset e placa-mãe' }
    foreach ($c in $tipos.Keys) {
        $itens = @($Lista | Where-Object { $_.Classe -eq $c -and $_.Data } | Sort-Object { $_.Data })
        if ($c -eq 'NET') { $itens = @($itens | Where-Object { $_.Nome -notmatch 'Virtual|Miniport|WAN|Bluetooth|Tunnel|Kernel Debug|Loopback|Wi-Fi Direct|VPN' }) }
        if ($c -eq 'SYSTEM') { $itens = @($itens | Where-Object { $_.Nome -match 'AMD|Intel|Chipset|SMBus|PSP|Management Engine|GPIO|I2C|Serial IO' -and $_.Nome -notmatch 'Microsoft' }) }
        if ($c -eq 'MEDIA') { $itens = @($itens | Where-Object { $_.Nome -notmatch 'NVIDIA|AMD High Definition Audio|Intel.*Display Audio|Virtual|Remote' }) }
        foreach ($i in ($itens | Select-Object -First 4)) {
            $anos = ($Agora - $i.Data).TotalDays / 365.25
            $idade = if ($anos -ge 1) { ('{0:N1} anos' -f $anos) } else { 'menos de 1 ano' }
            $fab = if ($i.Fabricante) { $i.Fabricante } else { '?' }
            $l.Add(('{0}: {1} ({2}), versão {3}, de {4} (idade: {5}).' -f $tipos[$c], $i.Nome, $fab, $i.Versao, $i.Data.ToString('MM/yyyy'), $idade))
            if ($anos -ge 5 -and ($c -ne 'MEDIA')) { $atencao = $true }
        }
    }
    if ($atencao) { $l.Add('Há driver de rede ou chipset com mais de 5 anos: baixe a versão atual no site do fabricante da placa-mãe ou do dispositivo (não use programas "atualizadores de driver").') }
    return @{ Linhas = $l.ToArray(); Atencao = $atencao }
}

# ---------------------------------------------------------------------------
# Pacotes de driver corrompidos (2.25): INF ou catálogo ausente, ou catálogo com a
# assinatura adulterada. Só avalia pacotes de terceiros (oem*.inf) fora das classes críticas.
# ---------------------------------------------------------------------------
function Get-AvaliacaoPacoteDriver {
    # Pura: recebe o que foi observado e devolve @{ Estado = 'ok'|'ausente'|'adulterado'|'indeterminado'; Motivo }
    param([bool]$InfExiste, [bool]$CatExiste, [string]$StatusAssinatura)
    if (-not $InfExiste) { return @{ Estado = 'ausente'; Motivo = 'o arquivo .inf do pacote não existe mais no DriverStore' } }
    if (-not $CatExiste) { return @{ Estado = 'ausente'; Motivo = 'o catálogo (.cat) do pacote não existe' } }
    switch -Regex ($StatusAssinatura) {
        '^HashMismatch$' { return @{ Estado = 'adulterado'; Motivo = 'o catálogo não confere com o arquivo (pacote alterado ou danificado)' } }
        '^(Valid|NotTrusted|UnknownError|NotSigned|)$' { return @{ Estado = 'ok'; Motivo = '' } }
        default { return @{ Estado = 'indeterminado'; Motivo = "assinatura: $StatusAssinatura" } }
    }
}

function Get-CatalogosInf {
    # Pura: nomes de catálogo declarados no texto de um .inf (CatalogFile, CatalogFile.NTamd64...). Vazio = o INF não declara catálogo.
    param([string]$Texto)
    $r = New-Object System.Collections.Generic.List[string]
    foreach ($m in [regex]::Matches("$Texto", '(?im)^\s*CatalogFile(?:\.[A-Za-z0-9]+)?\s*=\s*([^\s;\r\n]+)')) {
        $n = $m.Groups[1].Value.Trim('"')
        if ($n -and -not $r.Contains($n)) { $r.Add($n) }
    }
    return $r.ToArray()
}

function Invoke-AnalisePacotesCorrompidos {
    if ($env:OS -ne 'Windows_NT') { return }
    $protegidas = 'DiskDrive', 'SCSIAdapter', 'HDC', 'System', 'Processor', 'Computer', 'Volume', 'Battery', 'Firmware'
    $pacotes = @(Get-PacotesDriverStore | Where-Object { "$($_.Driver)" -like 'oem*.inf' })
    $ruins = New-Object System.Collections.Generic.List[object]
    foreach ($pk in $pacotes) {
        $inf = "$($pk.OriginalFileName)"
        $infOk = [bool]($inf -and (Test-Path -LiteralPath $inf))
        # O catálogo é o que o próprio INF declara (o nome nem sempre é o do .inf); sem declaração, não há o que julgar.
        $catOk = $true; $cat = ''
        if ($infOk) {
            $nomes = @()
            try { $nomes = @(Get-CatalogosInf ([IO.File]::ReadAllText($inf))) } catch { $nomes = @() }
            if ($nomes.Count -gt 0) {
                $pastaInf = Split-Path -Parent $inf
                $achados = @($nomes | ForEach-Object { Join-Path $pastaInf $_ } | Where-Object { Test-Path -LiteralPath $_ })
                if ($achados.Count -eq 0) { $catOk = $false } else { $cat = $achados[0] }
            }
        }
        $st = ''
        if ($cat) { try { $st = "$((Get-AuthenticodeSignature -LiteralPath $cat -ErrorAction Stop).Status)" } catch { $st = '' } }
        $av = Get-AvaliacaoPacoteDriver -InfExiste $infOk -CatExiste $catOk -StatusAssinatura $st
        if ($av.Estado -in 'ausente', 'adulterado') { $ruins.Add([pscustomobject]@{ Pacote = "$($pk.Driver)"; Classe = "$($pk.ClassName)"; Provedor = "$($pk.ProviderName)"; Versao = "$($pk.Version)"; Motivo = $av.Motivo }) }
    }
    if ($ruins.Count -eq 0) { return }
    foreach ($r in $ruins) {
        $critica = ($r.Classe -in $protegidas)
        Add-Achado -Gravidade 'Atencao' -Categoria 'Drivers' -Titulo "Pacote de driver corrompido: $($r.Pacote) ($($r.Provedor), $($r.Classe))" `
            -Detalhe "Versão $($r.Versao): $($r.Motivo)." `
            -Solucao $(if ($critica) { 'É um driver de classe crítica: o Telomera não remove sozinho. Baixe o pacote do fabricante e reinstale.' } else { 'Use a correção sugerida: o Telomera guarda uma cópia, remove o pacote e o Windows volta ao driver nativo ou ao do Windows Update.' }) `
            -Explicacao ('Um pacote danificado no DriverStore pode impedir a instalação ou a atualização do driver desse dispositivo.' + "`r`n`r`n" + (Get-ExplicacaoDriverCaso -Situacao 'pacote' -Classe $r.Classe -Nome $r.Pacote -Provedor $r.Provedor -Versao $r.Versao)) -Veredito 'Corrigir'
        if (-not $critica) {
            Add-Acao -Descricao "Remover o pacote de driver corrompido $($r.Pacote) ($($r.Provedor)); uma cópia é guardada antes" -Protecao -MudaDriver -Arg $r.Pacote -Acao {
                param($nomePacote)
                Restore-DriverNativo -Ctx @{ Pacote = $nomePacote }
            }
        }
    }
}

function Get-ExplicacaoListaDrivers {
    # Pura: um parágrafo por driver (o que é, versão e idade), para o "Ver mais" da lista de drivers de som, rede e chipset.
    param([object[]]$Lista, [datetime]$Agora = (Get-Date), [int]$Maximo = 25)
    $p = New-Object System.Collections.Generic.List[string]
    foreach ($d in @($Lista | Select-Object -First $Maximo)) {
        $txt = @((Get-ExplicacaoClasseDriver -Classe "$($d.Classe)" -Nome "$($d.Nome)") -split "`r?`n")
        $oque = @($txt | Where-Object { $_ -like 'O que é:*' } | Select-Object -First 1)
        if ($oque.Count -eq 0) { $oque = @($txt | Where-Object { $_ -like 'Tipo:*' } | Select-Object -First 1) }
        $idade = ''
        if ($d.Data -is [datetime]) { $idade = ', de {0} ({1})' -f $d.Data.ToString('dd/MM/yyyy'), (Get-IdadeTexto $d.Data $Agora) }
        $p.Add(('• {0} [{1}, {2}], versão {3}{4}. {5}' -f $d.Nome, $d.Classe, $(if ($d.Fabricante) { $d.Fabricante } else { 'fabricante não informado' }), $d.Versao, $idade, ($oque -join ' ')).Trim())
    }
    if (@($Lista).Count -gt $Maximo) { $p.Add(('(e mais {0} driver(s); veja a lista completa em Ferramentas > Drivers.)' -f (@($Lista).Count - $Maximo))) }
    return ($p -join "`r`n`r`n")
}

function Invoke-AnaliseDriversGerais {
    if ($env:OS -ne 'Windows_NT') { return }
    $lista = @()
    try {
        $lista = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -in 'MEDIA', 'NET', 'SYSTEM' -and $_.DriverDate } | ForEach-Object {
            $d = $_.DriverDate; if ($d -isnot [datetime]) { try { $d = [Management.ManagementDateTimeConverter]::ToDateTime("$d") } catch { $d = $null } }
            @{ Classe = "$($_.DeviceClass)"; Nome = "$($_.DeviceName)"; Fabricante = "$($_.Manufacturer)"; Versao = "$($_.DriverVersion)"; Data = $d }
        })
    } catch { return }
    $av = Get-AvaliacaoDriversGerais $lista
    if ($av.Linhas.Count -eq 0) { return }
    Add-Achado -Gravidade $(if ($av.Atencao) { 'Atencao' } else { 'Info' }) -Categoria 'Drivers' -Titulo 'Drivers de som, rede, Wi-Fi e chipset (versões e idades)' `
        -Detalhe ($av.Linhas -join ' | ') `
        -Solucao 'Se algum estiver muito antigo, baixe a versão atual no site do fabricante da placa-mãe (botão "Abrir a página de suporte da placa-mãe" em Ferramentas de reparo). Não use programas atualizadores de driver.' `
        -Explicacao ('Driver antigo de chipset ou de rede pode causar travamentos e quedas de conexão. O Telomera só lista as versões; nada é instalado ou alterado. Preciso me preocupar? Só os de rede, Wi-Fi e chipset muito antigos, e só se houver sintoma (queda de conexão, travamento, lentidão). Os de som e dispositivos virtuais mudam pouco.' + "`r`n`r`nO que cada um é:`r`n`r`n" + (Get-ExplicacaoListaDrivers $lista)) `
        -Veredito 'Opcional'
}

function Get-LinkSuporteFabricante {
    # Página de suporte (BIOS e drivers) da placa-mãe e página de chipset do processador. Devolve @{ Fabricante; Produto; UrlBios; UrlChipset }.
    param([string]$Fabricante, [string]$Produto, [string]$Cpu = '')
    $f = "$Fabricante".Trim(); $p = "$Produto".Trim()
    $q = [Uri]::EscapeDataString($p)
    $url = ''
    switch -Regex ($f) {
        # Os buscadores internos dos fabricantes caem em manutenção ou mudam de endereço; a busca restrita ao domínio oficial sempre abre
        # e leva à página do modelo (aba Suporte > BIOS). O site aberto continua sendo o do fabricante.
        'GIGABYTE' { $url = 'https://www.google.com/search?q=' + [Uri]::EscapeDataString("site:gigabyte.com $p support BIOS") }
        'ASUS'     { $url = 'https://www.google.com/search?q=' + [Uri]::EscapeDataString("site:asus.com $p support BIOS") }
        'Micro-Star|MSI' { $url = 'https://www.google.com/search?q=' + [Uri]::EscapeDataString("site:msi.com $p support BIOS") }
        'ASRock'   { $url = 'https://www.google.com/search?q=' + [Uri]::EscapeDataString("site:asrock.com $p support BIOS") }
        'Dell'     { $url = 'https://www.dell.com/support/home/' }
        'HP|Hewlett' { $url = 'https://support.hp.com/' }
        'LENOVO'   { $url = 'https://support.lenovo.com/' }
        default    { $url = ("https://www.google.com/search?q=" + [Uri]::EscapeDataString("$f $p BIOS download suporte")) }
    }
    $chip = 'https://www.amd.com/en/support/downloads/drivers.html'
    if ($Cpu -match 'Intel') { $chip = 'https://www.intel.com/content/www/us/en/support/detect.html' }
    return @{ Fabricante = $f; Produto = $p; UrlBios = $url; UrlChipset = $chip }
}

function Get-InfoBiosAtual {
    # Texto com a BIOS instalada, para comparar com a da página do fabricante.
    if ($env:OS -ne 'Windows_NT') { return @{ Texto = ''; Fabricante = ''; Produto = ''; Cpu = '' } }
    $b = $null; $pb = $null; $cpu = ''
    try { $b = Get-CimInstance Win32_BIOS -ErrorAction Stop } catch { }
    try { $pb = Get-CimInstance Win32_BaseBoard -ErrorAction Stop } catch { }
    try { $cpu = "$((Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).Name)" } catch { }
    $data = ''; try { $data = ' de ' + ([Management.ManagementDateTimeConverter]::ToDateTime($b.ReleaseDate)).ToString('dd/MM/yyyy') } catch { }
    return @{ Texto = ("BIOS instalada: versão {0}{1}." -f $b.SMBIOSBIOSVersion, $data); Fabricante = "$($pb.Manufacturer)"; Produto = "$($pb.Product)"; Cpu = $cpu }
}


# ----------------------------------------------------------------------------
# Sensores: HWiNFO (configuração certa) e LibreHardwareMonitor (alternativa opcional)
# ----------------------------------------------------------------------------
function Invoke-ConfigurarHwinfo {
    # Corrige o INI do HWiNFO (com cópia de segurança) e o abre. Devolve as linhas de texto.
    $feito = New-Object System.Collections.Generic.List[string]
    $exe = Get-CaminhoHwinfo
    if (-not $exe) { $feito.Add('O HWiNFO não está instalado neste computador. Baixe em https://www.hwinfo.com/ (versão Installer ou Portable) e abra esta ferramenta de novo.'); return $feito.ToArray() }
    if (Get-Process -Name 'HWiNFO64', 'HWiNFO32' -ErrorAction SilentlyContinue) {
        $feito.Add('O HWiNFO está aberto. Feche-o (clique direito no ícone da bandeja > Sair) e rode esta ferramenta de novo: ele só lê o arquivo de configuração ao abrir.')
        return $feito.ToArray()
    }
    $ini = [IO.Path]::ChangeExtension($exe, 'INI')
    $texto = ''; try { if (Test-Path -LiteralPath $ini) { $texto = [IO.File]::ReadAllText($ini) } } catch { }
    $novo = Update-TextoIniHwinfo $texto
    if ($novo.Trim() -ne $texto.Trim()) {
        if (-not (Confirm-Acao "Ajustar a configuração do HWiNFO para o Telomera conseguir ler os sensores (memória compartilhada ligada, só sensores, atualização a cada 500 ms)? Uma cópia do arquivo atual será guardada ao lado.")) { $feito.Add('Nada foi alterado.'); return $feito.ToArray() }
        try {
            if (Test-Path -LiteralPath $ini) { Copy-Item -LiteralPath $ini -Destination ($ini + '.bak-telomera') -Force }
            [IO.File]::WriteAllText($ini, $novo, (New-Object System.Text.UTF8Encoding $false))
            Add-Alteracao -Acao 'Configuração do HWiNFO (HWiNFO64.INI)' -Resultado 'executado (cópia em HWiNFO64.INI.bak-telomera)'
            $feito.Add('Configuração ajustada. A cópia do arquivo antigo ficou como HWiNFO64.INI.bak-telomera na pasta do HWiNFO.')
        } catch {
            $feito.Add("Não consegui gravar o arquivo (pasta protegida?): $($_.Exception.Message)")
            $feito.Add('Faça à mão: no HWiNFO, Configurações > marque "Shared Memory Support" e deixe o intervalo de sensores em 500 ms.')
        }
    } else { $feito.Add('A configuração do HWiNFO já está correta.') }
    try { Start-Process -FilePath $exe; $feito.Add('HWiNFO aberto. Deixe-o aberto (pode minimizar) e ligue o monitor do Telomera.') } catch { $feito.Add("Não consegui abrir o HWiNFO: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-InstalarLhm {
    # Baixa a LibreHardwareMonitor oficial (GitHub) e confere o SHA-256 informado pelo GitHub. Só com confirmação.
    $feito = New-Object System.Collections.Generic.List[string]
    $dest = Get-PastaLhm
    if (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe')) { $feito.Add("A LibreHardwareMonitor já está em $dest."); return $feito.ToArray() }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $rel = $null
    try { $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/LibreHardwareMonitor/LibreHardwareMonitor/releases/latest' -Headers @{ 'User-Agent' = 'Telomera' } -TimeoutSec 30 -ErrorAction Stop } catch { }
    if (-not $rel) { $feito.Add('Não consegui consultar o GitHub (sem internet?). Baixe manualmente em https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases e extraia em: ' + $dest); return $feito.ToArray() }
    $ass = @($rel.assets | Where-Object { $_.name -match '^LibreHardwareMonitor.*\.zip$' -and $_.name -notmatch 'NET' }) | Select-Object -First 1
    if (-not $ass) { $ass = @($rel.assets | Where-Object { $_.name -match '\.zip$' }) | Select-Object -First 1 }
    if (-not $ass) { $feito.Add('Não achei o arquivo ZIP na versão mais recente. Baixe manualmente em https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases'); return $feito.ToArray() }
    $sha = ''; if ("$($ass.digest)" -match '^sha256:([0-9a-fA-F]{64})$') { $sha = $Matches[1].ToLower() }
    $aviso = "Baixar a LibreHardwareMonitor $($rel.tag_name) ($($ass.name), $([math]::Round($ass.size / 1MB, 1)) MB) de github.com/LibreHardwareMonitor e guardar em $dest? Ela é um programa de código aberto de terceiros. Para ler a temperatura do processador ela carrega um driver, e antivírus ou anticheat (como o Vanguard) podem reclamar; abra-a só se aceitar isso."
    if ($sha -eq '') { $aviso += " ATENÇÃO: o GitHub não informou o hash deste arquivo, então não dá para conferir a integridade."}
    if (-not (Confirm-Acao $aviso)) { $feito.Add('Nada foi baixado.'); return $feito.ToArray() }
    $zip = Join-Path ([IO.Path]::GetTempPath()) ('Telomera-lhm-' + [guid]::NewGuid().ToString('N') + '.zip')
    try {
        Invoke-WebRequest -Uri $ass.browser_download_url -OutFile $zip -UseBasicParsing -TimeoutSec 300 -ErrorAction Stop
        $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
        if ($sha -and $h -ne $sha) { $feito.Add('O arquivo baixado NÃO bate com o hash informado pelo GitHub. Descartado, nada foi instalado.'); return $feito.ToArray() }
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
        # Se o ZIP trouxe uma pasta dentro, sobe o conteúdo um nível
        if (-not (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe'))) {
            $sub = Get-ChildItem -LiteralPath $dest -Recurse -Filter 'LibreHardwareMonitor.exe' -File | Select-Object -First 1
            if ($sub) { Get-ChildItem -LiteralPath $sub.DirectoryName | Move-Item -Destination $dest -Force -ErrorAction SilentlyContinue }
        }
        if (-not (Test-Path -LiteralPath (Join-Path $dest 'LibreHardwareMonitor.exe'))) { $feito.Add('O ZIP não trouxe o LibreHardwareMonitor.exe como esperado.'); return $feito.ToArray() }
        Add-Alteracao -Acao "Baixar a LibreHardwareMonitor $($rel.tag_name)" -Resultado "executado (SHA-256 $h; apagar a pasta $dest para remover)"
        $feito.Add("LibreHardwareMonitor $($rel.tag_name) guardada em $dest (SHA-256 $h$(if ($sha) { ', conferido com o GitHub' } else { ', sem hash do GitHub' })).")
        $feito.Add('Para usar: Monitor e sensores > "Abrir a LibreHardwareMonitor". Para remover, apague essa pasta.')
    } catch { $feito.Add("Falhou: $($_.Exception.Message)") }
    finally { try { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue } catch { } }
    return $feito.ToArray()
}

function Invoke-AbrirLhm {
    $feito = New-Object System.Collections.Generic.List[string]
    $e = Get-EstadoSensores
    if (-not $e.LhmPasta) { $feito.Add('A LibreHardwareMonitor ainda não foi baixada. Use primeiro "Baixar a LibreHardwareMonitor".'); return $feito.ToArray() }
    if (-not (Confirm-Acao 'Abrir a LibreHardwareMonitor como administrador? Ela precisa disso para ler a temperatura do processador e vai carregar o driver dela. Se o anticheat ou o antivírus reclamar, feche-a.')) { $feito.Add('Nada foi aberto.'); return $feito.ToArray() }
    try { Start-Process -FilePath (Join-Path $e.LhmPasta 'LibreHardwareMonitor.exe') -Verb RunAs; $feito.Add('Aberta. Deixe-a aberta (pode minimizar): o monitor do Telomera passa a ler os sensores dela quando o HWiNFO não está aberto.') }
    catch { $feito.Add("Não consegui abrir: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-EstadoSensores {
    $e = Get-EstadoSensores
    $a = Get-AvaliacaoSensores $e
    $l = New-Object System.Collections.Generic.List[string]
    $l.Add($a.Resumo)
    $l.Add('HWiNFO: ' + $(if ($e.HwinfoCaminho) { $e.HwinfoCaminho + $(if ($e.HwinfoAberto) { ' (aberto)' } else { ' (fechado)' }) } else { 'não encontrado' }))
    if ($e.HwinfoConfig) { $l.Add(('  Memória compartilhada: {0} | só sensores: {1} | intervalo: {2} ms' -f $(if ($e.HwinfoConfig.SensoresMemoria) { 'ligada' } else { 'DESLIGADA' }), $(if ($e.HwinfoConfig.SoSensores) { 'sim' } else { 'não' }), $e.HwinfoConfig.Intervalo)) }
    $l.Add('LibreHardwareMonitor: ' + $(if ($e.LhmPasta) { $e.LhmPasta + $(if ($e.LhmAberto) { ' (aberta)' } else { ' (fechada)' }) } else { 'não baixada' }))
    foreach ($p in $a.Passos) { $l.Add('Próximo passo: ' + $p) }
    return $l.ToArray()
}


# ----------------------------------------------------------------------------
# Drivers: o que cada tipo faz, lista explicada e ferramentas que corrigem
# ----------------------------------------------------------------------------
$script:ClassesDriver = [ordered]@{
    'DISPLAY' = @{ Nome = 'Placa de vídeo'; Funcao = 'Desenha tudo o que aparece na tela e executa os jogos. É o driver mais importante para quem joga.'
        Falhar = 'Tela preta ou piscando, imagem congelada com o som continuando, jogo que fecha sozinho, resolução ou taxa de atualização erradas, e telas azuis (nvlddmkm, atikmdag).'
        Peso = 'Muito alto: é a causa mais comum de imagem congelada em jogos.'
        Verifica = 'Se há erro, se está usando o driver genérico da Microsoft, a versão e a data, se está assinado e se o Windows Update o sobrescreveu.' }
    'NET' = @{ Nome = 'Rede e Wi-Fi'; Funcao = 'Faz a placa de rede (cabo) e o Wi-Fi conversarem com o Windows.'
        Falhar = 'Internet que cai, Wi-Fi que não conecta, velocidade baixa, ping alto em jogos.'
        Peso = 'Médio: quase nunca trava o computador inteiro, mas derruba a conexão.'
        Verifica = 'Erros, driver genérico no lugar do do fabricante (Realtek, Intel, Qualcomm) e idade do driver.' }
    'MEDIA' = @{ Nome = 'Som'; Funcao = 'Controla placa de som, fones, caixas e o áudio do HDMI.'
        Falhar = 'Sem som, chiado, estalos, som que some depois de dormir o PC.'
        Peso = 'Baixo para travamentos, mas um driver de áudio ruim pode causar engasgos e travadas curtas.'
        Verifica = 'Erros, driver genérico e idade.' }
    'SYSTEM' = @{ Nome = 'Chipset e placa-mãe'; Funcao = 'Ensinam o Windows a usar as partes da placa-mãe: barramento PCIe, controle de energia, sensores, SMBus, GPIO e o processador de segurança (PSP).'
        Falhar = 'Gerenciamento de energia errado, desempenho abaixo do normal, USB e PCIe instáveis, travamentos ao dormir ou acordar.'
        Peso = 'Alto em PCs que travam sem motivo: um chipset desatualizado faz a placa de vídeo e o disco perderem estabilidade.'
        Verifica = 'Erros e a idade do driver de chipset (AMD ou Intel). O Windows traz um genérico que funciona, mas o do fabricante é melhor.' }
    'HDC' = @{ Nome = 'Controlador de disco (SATA/NVMe)'; Funcao = 'Faz a ligação entre o Windows e o HD ou SSD (AHCI para SATA, NVMe para SSD M.2).'
        Falhar = 'Lentidão, travamentos que congelam tudo por alguns segundos, erros de disco e telas azuis.'
        Peso = 'Alto: em PC com HD, o disco lento ou com erro de comunicação parece "travamento".'
        Verifica = 'Erros e se o driver é o do fabricante (AMD, Intel) ou o padrão do Windows.' }
    'SCSIADAPTER' = @{ Nome = 'Controlador de armazenamento'; Funcao = 'Igual ao controlador de disco: controla a comunicação com os discos.'
        Falhar = 'Disco que some, lentidão e telas azuis.'
        Peso = 'Alto quando acontece.'
        Verifica = 'Erros e versão.' }
    'USB' = @{ Nome = 'Portas USB'; Funcao = 'Controla as portas USB (teclado, mouse, pen drive, headset).'
        Falhar = 'Dispositivo que desconecta sozinho, teclado ou mouse que falham no meio do jogo.'
        Peso = 'Médio: a economia de energia do USB costuma desligar dispositivos.'
        Verifica = 'Erros nos controladores. A ferramenta "Desligar a economia de energia do USB" ajuda aqui.' }
    'BLUETOOTH' = @{ Nome = 'Bluetooth'; Funcao = 'Conecta fones, controles e outros aparelhos sem fio.'
        Falhar = 'Fone que não conecta, controle que desconecta.'
        Peso = 'Baixo.'
        Verifica = 'Erros e driver genérico.' }
    'CAMERA' = @{ Nome = 'Câmera'; Funcao = 'Faz a webcam funcionar.'; Falhar = 'Câmera não aparece ou não abre.'; Peso = 'Baixo.'; Verifica = 'Erros e idade.' }
    'IMAGE' = @{ Nome = 'Câmeras e scanners'; Funcao = 'Faz câmeras e scanners funcionarem.'; Falhar = 'Aparelho não é reconhecido.'; Peso = 'Baixo.'; Verifica = 'Erros e idade.' }
    'PROCESSOR' = @{ Nome = 'Processador'; Funcao = 'Gerencia a frequência e a economia de energia do processador.'
        Falhar = 'Desempenho abaixo do esperado, processador preso em frequência baixa, travadas ao trocar de repouso para carga.'
        Peso = 'Médio: em Ryzen, o driver de chipset da AMD é quem cuida disso.'
        Verifica = 'Erros.' }
    'DISKDRIVE' = @{ Nome = 'Discos'; Funcao = 'Representa cada HD ou SSD no Windows.'; Falhar = 'Disco não aparece ou aparece com erro.'; Peso = 'Alto quando o disco tem problema.'; Verifica = 'Erros e a saúde SMART.' }
    'MONITOR' = @{ Nome = 'Monitor'; Funcao = 'Informa ao Windows as resoluções e a taxa de atualização do monitor.'; Falhar = 'Taxa de atualização errada (por exemplo 60 Hz em monitor de 144 Hz).'; Peso = 'Baixo.'; Verifica = 'Erros.' }
}
$script:NomesDriver = @(
    @{ Padrao = 'NVIDIA'; Texto = 'Driver da placa de vídeo NVIDIA (GeForce). Roda jogos e vídeo. Versões novas às vezes trazem defeitos: se o problema começou depois de atualizar, volte a uma versão mais antiga e estável.' },
    @{ Padrao = 'Radeon|AMD Radeon|ATI '; Texto = 'Driver da placa de vídeo AMD Radeon. Roda jogos e vídeo.' },
    @{ Padrao = 'PSP'; Texto = 'Processador de segurança da AMD (PSP). Cuida de chaves e da inicialização segura. Não aparece para o usuário, mas precisa do driver de chipset da AMD em dia.' },
    @{ Padrao = 'SMBus'; Texto = 'Barramento que a placa-mãe usa para falar com sensores, memória e o controle de ventoinhas.' },
    @{ Padrao = 'GPIO'; Texto = 'Pinos de uso geral da placa-mãe (botões, LEDs, sensores). Faz parte do pacote de chipset.' },
    @{ Padrao = 'PCI Express|PCIe|Root Port'; Texto = 'Porta PCIe da placa-mãe: é por ela que a placa de vídeo e o SSD NVMe se comunicam. Defeito aqui causa travamentos graves.' },
    @{ Padrao = 'AHCI|SATA'; Texto = 'Controlador SATA: a ponte entre a placa-mãe e HDs/SSDs SATA. Se for o do Windows ("Standard SATA AHCI"), funciona; o do fabricante pode melhorar o desempenho.' },
    @{ Padrao = 'NVM|NVMe'; Texto = 'Controlador de SSD M.2 NVMe.' },
    @{ Padrao = 'Realtek.*(Audio|áudio)|High Definition Audio'; Texto = 'Placa de som integrada à placa-mãe (geralmente Realtek). Controla fones e caixas.' },
    @{ Padrao = 'HDMI|Display Audio|NVIDIA High Definition Audio'; Texto = 'Áudio que sai pelo cabo HDMI/DisplayPort da placa de vídeo, para monitores e TVs com alto-falante.' },
    @{ Padrao = 'Realtek PCIe|GbE|Gigabit|Ethernet'; Texto = 'Placa de rede com cabo (Ethernet).' },
    @{ Padrao = 'Wi-?Fi|Wireless|802\.11'; Texto = 'Placa de rede sem fio (Wi-Fi).' },
    @{ Padrao = 'xHCI|eXtensible|Host Controller'; Texto = 'Controlador das portas USB 3.0 e superiores.' },
    @{ Padrao = 'Basic Display|Basic Render|básico'; Texto = 'Driver genérico de vídeo da Microsoft: sem aceleração 3D. Se aparecer na sua placa de vídeo, falta o driver do fabricante.' }
)

function Get-ExplicacaoClasseDriver {
    # Texto (várias linhas) sobre o tipo de driver: o que faz, o que acontece se falhar, peso nos travamentos e o que o Telomera confere.
    param([string]$Classe, [string]$Nome = '')
    $c = "$Classe".ToUpper()
    $l = New-Object System.Collections.Generic.List[string]
    foreach ($n in $script:NomesDriver) { if ($Nome -and $Nome -match $n.Padrao) { $l.Add('O que é: ' + $n.Texto); break } }
    if ($script:ClassesDriver.Contains($c)) {
        $k = $script:ClassesDriver[$c]
        $l.Add(('Tipo: {0}. {1}' -f $k.Nome, $k.Funcao))
        $l.Add('Se der problema: ' + $k.Falhar)
        $l.Add('Importância para travamentos: ' + $k.Peso)
        $l.Add('O que o Telomera confere: ' + $k.Verifica)
    } elseif ($l.Count -eq 0) {
        $l.Add('Tipo de driver sem descrição pronta. Se o dispositivo funciona e o computador está estável, pode ignorar.')
    }
    return ($l -join "`r`n")
}

function Get-EstadoDriverItem {
    # Marcas de atenção de um driver (lista de textos curtos).
    param($D, [datetime]$Agora = (Get-Date))
    $t = New-Object System.Collections.Generic.List[string]
    if ([int]$D.Erro -ne 0) { $t.Add("COM ERRO (código $($D.Erro))") }
    if ($D.Assinado -eq $false) { $t.Add('SEM ASSINATURA') }
    if ($D.Classe -eq 'DISPLAY' -and "$($D.Nome)" -match 'Basic Display|Basic Render') { $t.Add('GENÉRICO (sem aceleração)') }
    if ($D.Data -and "$($D.Fabricante)" -ne 'Microsoft') {
        $limite = $(if ($D.Classe -eq 'DISPLAY') { 2 } else { 3 })
        if (($Agora - $D.Data).TotalDays / 365.25 -ge $limite) { $t.Add('ANTIGO') }
    }
    return $t.ToArray()
}

function Get-TextoDriversExplicados {
    # Relatório: por tipo, o que o driver faz, o que acontece se falhar e a lista dos que há no computador com a situação de cada um.
    param($Lista, [datetime]$Agora = (Get-Date))
    $l = New-Object System.Collections.Generic.List[string]
    $l.Add('DRIVERS DO SEU COMPUTADOR, EXPLICADOS')
    $l.Add('Driver é o programa que ensina o Windows a usar cada peça. Se ele é ruim, antigo ou falta, a peça trava ou fica lenta.')
    $l.Add('')
    $nAten = 0
    foreach ($c in $script:ClassesDriver.Keys) {
        $itens = @($Lista | Where-Object { "$($_.Classe)".ToUpper() -eq $c })
        if ($itens.Count -eq 0) { continue }
        $k = $script:ClassesDriver[$c]
        $l.Add(('=== {0} ===' -f $k.Nome))
        $l.Add('O que faz: ' + $k.Funcao)
        $l.Add('Se der problema: ' + $k.Falhar)
        $l.Add('Peso nos travamentos: ' + $k.Peso)
        foreach ($d in ($itens | Sort-Object Nome)) {
            $marcas = @(Get-EstadoDriverItem $d $Agora)
            $data = $(if ($d.Data) { $d.Data.ToString('MM/yyyy') } else { '?' })
            $linha = ('  - {0} | {1} | versão {2} | de {3}' -f $d.Nome, $(if ($d.Fabricante) { $d.Fabricante } else { '?' }), $d.Versao, $data)
            if ($marcas.Count -gt 0) { $linha += '   >>> ' + ($marcas -join ', '); $nAten++ }
            $l.Add($linha)
            foreach ($n in $script:NomesDriver) { if ("$($d.Nome)" -match $n.Padrao) { $l.Add('      ' + $n.Texto); break } }
        }
        $l.Add('')
    }
    if ($nAten -eq 0) { $l.Add('Resumo: nenhum driver com erro, sem assinatura ou antigo demais. Se o PC trava, o problema provavelmente não é um driver quebrado: veja fonte, memória e a investigação de travamento.') }
    else { $l.Add("Resumo: $nAten driver(s) marcado(s) com >>>. Use as ferramentas da área Drivers para corrigir: reparar dispositivos com erro, instalar pelo Windows Update, limpar versões antigas ou refazer o driver de vídeo.") }
    return ($l -join "`r`n")
}

function Get-DriversParaLista {
    # Lê os drivers que importam do Windows. Cada item: @{ Classe; Nome; Fabricante; Versao; Data; Inf; Assinado; Erro; Id }.
    if ($env:OS -ne 'Windows_NT') { return @() }
    $erros = @{}
    try { foreach ($p in @(Get-CimInstance Win32_PnPEntity -ErrorAction Stop)) { if ([int]$p.ConfigManagerErrorCode -ne 0) { $erros["$($p.PNPDeviceID)"] = [int]$p.ConfigManagerErrorCode } } } catch { }
    $r = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($d in @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop)) {
            $cl = "$($d.DeviceClass)".ToUpper()
            if (-not $script:ClassesDriver.Contains($cl) -or -not $d.DeviceName) { continue }
            $nome = "$($d.DeviceName)"; $prov = "$($d.DriverProviderName)"
            $erro = $(if ($erros.ContainsKey("$($d.DeviceID)")) { $erros["$($d.DeviceID)"] } else { 0 })
            if ($cl -eq 'SYSTEM' -and $erro -eq 0 -and ($prov -eq 'Microsoft' -or $nome -notmatch 'AMD|Intel|Chipset|SMBus|PSP|GPIO|PCI Express|Management Engine')) { continue }
            if ($cl -eq 'USB' -and $erro -eq 0 -and $nome -notmatch 'Host Controller|xHCI|eXtensible') { continue }
            if ($cl -in 'MONITOR', 'DISKDRIVE', 'PROCESSOR' -and $erro -eq 0) { continue }
            $data = $null
            try { if ($d.DriverDate) { $data = $(if ($d.DriverDate -is [datetime]) { $d.DriverDate } else { [Management.ManagementDateTimeConverter]::ToDateTime("$($d.DriverDate)") }) } } catch { }
            $r.Add(@{ Classe = $cl; Nome = $nome; Fabricante = $prov; Versao = "$($d.DriverVersion)"; Data = $data; Inf = "$($d.InfName)"; Assinado = $d.IsSigned; Erro = $erro; Id = "$($d.DeviceID)" })
        }
    } catch { }
    return $r.ToArray()
}

function Get-PacotesObsoletos {
    # Pacotes de driver de terceiros guardados no DriverStore que foram substituídos por um mais novo do mesmo fabricante/tipo/arquivo e não estão em uso.
    # $Pacotes: @{ Driver (oemN.inf); Original; Provedor; Classe; Versao; Data; Inbox }. $EmUso: nomes oemN.inf em uso.
    param($Pacotes, [string[]]$EmUso = @())
    $uso = @{}; foreach ($u in $EmUso) { if ($u) { $uso["$u".ToLower()] = $true } }
    $grupos = @{}
    foreach ($p in @($Pacotes)) {
        if ($p.Inbox -or "$($p.Driver)" -notmatch '^oem\d+\.inf$') { continue }
        $folha = ("$($p.Original)" -split '[\\/]')[-1].ToLower()
        $chave = ('{0}|{1}|{2}' -f $p.Provedor, $p.Classe, $folha)
        if (-not $grupos.ContainsKey($chave)) { $grupos[$chave] = New-Object System.Collections.Generic.List[object] }
        $grupos[$chave].Add($p)
    }
    $obs = New-Object System.Collections.Generic.List[object]
    foreach ($k in $grupos.Keys) {
        $g = @($grupos[$k] | Sort-Object { $_.Data }, { try { [version]$_.Versao } catch { [version]'0.0' } } -Descending)
        if ($g.Count -lt 2) { continue }
        foreach ($p in ($g | Select-Object -Skip 1)) { if (-not $uso.ContainsKey("$($p.Driver)".ToLower())) { $obs.Add($p) } }
    }
    return $obs.ToArray()
}

function Invoke-ListaDrivers {
    return @(Get-TextoDriversExplicados (Get-DriversParaLista))
}

function Invoke-ReparoDispositivosComErro {
    # Reativa o que está desativado e reinstala (remove + procura de novo) os dispositivos com erro. Só classes seguras.
    $feito = New-Object System.Collections.Generic.List[string]
    $protegidas = 'DiskDrive', 'SCSIAdapter', 'HDC', 'System', 'Processor', 'Computer', 'Volume', 'VolumeSnapshot', 'Battery', 'Firmware'
    $dev = @()
    try { $dev = @(Get-PnpDevice -ErrorAction Stop | Where-Object { $_.Status -eq 'Error' -or $_.Problem -in 'CM_PROB_DISABLED', 22 }) } catch { }
    if ($dev.Count -eq 0) { $feito.Add('Nenhum dispositivo com erro no Gerenciador de Dispositivos. Nada a reparar.'); return $feito.ToArray() }
    $lista = ($dev | ForEach-Object { "$($_.FriendlyName) [$($_.Class)]" }) -join '; '
    if (-not (Confirm-Acao "Reparar estes dispositivos com problema: $lista? Os desativados serão reativados; os com erro serão removidos e o Windows procura o driver de novo (tela e rede podem piscar). O que for de disco, processador e sistema é deixado de fora por segurança.")) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    foreach ($d in $dev) {
        $nome = "$($d.FriendlyName)"; if (-not $nome) { $nome = "$($d.InstanceId)" }
        try {
            if ($d.Problem -in 'CM_PROB_DISABLED', 22) { Enable-PnpDevice -InstanceId $d.InstanceId -Confirm:$false -ErrorAction Stop; $feito.Add("${nome}: reativado."); Add-Alteracao -Acao "Reativar dispositivo $nome" -Resultado 'executado'; continue }
            if ($d.Class -in $protegidas) { $feito.Add("${nome}: classe protegida ($($d.Class)), não mexi. Veja os links do relatório."); continue }
            $o = & pnputil.exe /remove-device "$($d.InstanceId)" 2>&1 | Out-String
            Add-Alteracao -Acao "Reinstalar o driver de $nome" -Resultado ("executado (pnputil /remove-device, código $LASTEXITCODE)")
            $feito.Add("${nome}: removido para ser reinstalado.")
        } catch { $feito.Add("${nome}: falhou ($($_.Exception.Message))") }
    }
    & pnputil.exe /scan-devices 2>&1 | Out-Null
    $feito.Add('O Windows procurou os dispositivos de novo. Se algum continuar com erro, instale o pacote do fabricante (links no relatório da verificação).')
    return $feito.ToArray()
}

function Invoke-ReiniciarDriverVideo {
    $feito = New-Object System.Collections.Generic.List[string]
    $v = @()
    try { $v = @(Get-PnpDevice -Class Display -Status OK -ErrorAction Stop) } catch { }
    if ($v.Count -eq 0) { $feito.Add('Não encontrei placa de vídeo funcionando para reiniciar.'); return $feito.ToArray() }
    if (-not (Confirm-Acao "Reiniciar o driver de vídeo ($(($v | ForEach-Object FriendlyName) -join ', '))? A tela vai ficar preta ou piscar por alguns segundos. Salve seus trabalhos e feche os jogos.")) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    foreach ($d in $v) {
        try { Disable-PnpDevice -InstanceId $d.InstanceId -Confirm:$false -ErrorAction Stop; Start-Sleep -Seconds 3; Enable-PnpDevice -InstanceId $d.InstanceId -Confirm:$false -ErrorAction Stop; $feito.Add("$($d.FriendlyName): driver reiniciado."); Add-Alteracao -Acao "Reiniciar o driver de vídeo $($d.FriendlyName)" -Resultado 'executado' }
        catch { $feito.Add("$($d.FriendlyName): falhou ($($_.Exception.Message)). Se a tela ficou preta, aperte Windows+Ctrl+Shift+B ou reinicie o PC."); try { Enable-PnpDevice -InstanceId $d.InstanceId -Confirm:$false -ErrorAction SilentlyContinue } catch { } }
    }
    return $feito.ToArray()
}

function Invoke-DriversWindowsUpdate {
    # Instala todos os drivers pendentes do Windows Update (sem pergunta interativa: mostra a lista e pede uma confirmação).
    $feito = New-Object System.Collections.Generic.List[string]
    $b = Get-AtualizacoesDriverWU
    if ($b.Erro) { $feito.Add("Não consegui consultar o Windows Update: $($b.Erro)"); return $feito.ToArray() }
    $itens = @($b.Itens)
    if ($itens.Count -eq 0) { $feito.Add('Nenhum driver pendente no Windows Update. Seus drivers estão em dia para o Windows.'); return $feito.ToArray() }
    $txt = ($itens | ForEach-Object { "- $($_.Titulo)" }) -join "`r`n"
    if (-not (Confirm-Acao ("Instalar estes drivers do Windows Update?`r`n$txt`r`nA tela ou a rede podem piscar. É criado um ponto de restauração antes se possível.") -MudaDriver)) { $feito.Add('Nada foi instalado.'); return $feito.ToArray() }
    try { Checkpoint-Computer -Description 'Telomera antes de instalar drivers' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop } catch { }
    try {
        $sessao = New-Object -ComObject Microsoft.Update.Session
        $res = $sessao.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
        $col = New-Object -ComObject Microsoft.Update.UpdateColl
        for ($i = 0; $i -lt $res.Updates.Count; $i++) { $u = $res.Updates.Item($i); if (-not $u.EulaAccepted) { $u.AcceptEula() }; [void]$col.Add($u) }
        $dl = $sessao.CreateUpdateDownloader(); $dl.Updates = $col
        if ($dl.Download().ResultCode -ne 2) { $feito.Add('O download falhou.'); return $feito.ToArray() }
        $ins = $sessao.CreateUpdateInstaller(); $ins.Updates = $col
        $ri = $ins.Install()
        $res2 = switch ([int]$ri.ResultCode) { 2 { 'concluída com sucesso' } 3 { 'concluída com erros' } 4 { 'falhou' } default { "código $($ri.ResultCode)" } }
        Add-Alteracao -Acao 'Instalar drivers do Windows Update' -Resultado ("$res2 ($($itens.Count) driver(s))")
        $feito.Add("Instalação $res2.")
        if ($ri.RebootRequired) { $feito.Add('Reinicie o computador para concluir.') }
    } catch { $feito.Add("Falhou: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-LimparDriversAntigos {
    # Remove do DriverStore os pacotes substituídos por versões mais novas. Guarda uma cópia de cada um antes (dá para desfazer).
    $feito = New-Object System.Collections.Generic.List[string]
    $pacotes = @(); $emUso = @()
    try { $pacotes = @(Get-WindowsDriver -Online -All -ErrorAction Stop | ForEach-Object { @{ Driver = "$($_.Driver)"; Original = "$($_.OriginalFileName)"; Provedor = "$($_.ProviderName)"; Classe = "$($_.ClassName)"; Versao = "$($_.Version)"; Data = $_.Date; Inbox = [bool]$_.Inbox } }) } catch { $feito.Add("Não consegui ler os pacotes de driver: $($_.Exception.Message)"); return $feito.ToArray() }
    try { $emUso = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | ForEach-Object { "$($_.InfName)" }) } catch { }
    $obs = @(Get-PacotesObsoletos -Pacotes $pacotes -EmUso $emUso)
    if ($obs.Count -eq 0) { $feito.Add('Não há versões antigas de driver sobrando. Nada a limpar.'); return $feito.ToArray() }
    $txt = ($obs | ForEach-Object { "- $($_.Driver): $($_.Provedor) $($_.Classe) versão $($_.Versao)" }) -join "`r`n"
    if (-not (Confirm-Acao ("Remover estas $($obs.Count) versão(ões) antiga(s) de driver que não estão em uso?`r`n$txt`r`nUma cópia de cada uma é guardada antes. Isso libera espaço e evita que o Windows volte para um driver velho.") -MudaDriver)) { $feito.Add('Nada foi removido.'); return $feito.ToArray() }
    $pasta = Join-Path (Split-Path -Parent (Get-ArquivoDados 'x')) ('drivers-removidos\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $ok = 0
    foreach ($p in $obs) {
        try {
            $dest = Join-Path $pasta ($p.Driver -replace '\.inf$', '')
            New-Item -ItemType Directory -Force -Path $dest | Out-Null
            & pnputil.exe /export-driver "$($p.Driver)" "$dest" 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { $feito.Add("$($p.Driver): não consegui guardar a cópia, não removi."); continue }
            & pnputil.exe /delete-driver "$($p.Driver)" 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { $ok++; $feito.Add("$($p.Driver): removido.") } else { $feito.Add("$($p.Driver): o Windows manteve (em uso).") }
        } catch { $feito.Add("$($p.Driver): falhou ($($_.Exception.Message))") }
    }
    Add-Alteracao -Acao 'Limpar versões antigas de driver (DriverStore)' -Resultado ("executado: $ok removido(s); cópias em $pasta; para voltar: pnputil /add-driver `"$pasta\*\*.inf`" /install")
    $feito.Add("Pronto: $ok removido(s). Cópias em: $pasta")
    return $feito.ToArray()
}

function Invoke-LimpezaDriverVideo {
    # Remove o driver de vídeo de terceiros (NVIDIA/AMD/Intel) para uma instalação limpa. Guarda cópia. Depois o usuário instala o driver escolhido.
    $feito = New-Object System.Collections.Generic.List[string]
    $pk = @()
    try { $pk = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -eq 'DISPLAY' -and "$($_.InfName)" -match '^oem\d+\.inf$' -and "$($_.DriverProviderName)" -ne 'Microsoft' }) } catch { }
    if ($pk.Count -eq 0) { $feito.Add('Não encontrei driver de vídeo de fabricante instalado (já está no genérico da Microsoft, ou é nativo do Windows).'); return $feito.ToArray() }
    $nomes = ($pk | ForEach-Object { "$($_.DeviceName) ($($_.DriverProviderName) $($_.DriverVersion), pacote $($_.InfName))" }) -join '; '
    if (-not (Confirm-Acao ("LIMPEZA DO DRIVER DE VÍDEO: remover $nomes? Depois disso a tela fica no driver genérico (resolução baixa) até você instalar o driver novo. TENHA O INSTALADOR DO DRIVER JÁ BAIXADO (nvidia.com/drivers ou amd.com/support) antes de continuar, de preferência uma versão mais antiga e estável. Uma cópia do driver atual é guardada.") -MudaDriver)) { $feito.Add('Nada foi feito.'); return $feito.ToArray() }
    try { Checkpoint-Computer -Description 'Telomera antes da limpeza do driver de vídeo' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop } catch { }
    $pasta = Join-Path (Split-Path -Parent (Get-ArquivoDados 'x')) ('drivers-removidos\video-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    foreach ($d in ($pk | Sort-Object InfName -Unique)) {
        $dest = Join-Path $pasta ($d.InfName -replace '\.inf$', '')
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        & pnputil.exe /export-driver "$($d.InfName)" "$dest" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { $feito.Add("$($d.InfName): não consegui guardar a cópia; por segurança parei aqui."); return $feito.ToArray() }
        & pnputil.exe /delete-driver "$($d.InfName)" /uninstall /force 2>&1 | Out-Null
        $feito.Add("$($d.InfName): removido (código $LASTEXITCODE).")
    }
    & pnputil.exe /scan-devices 2>&1 | Out-Null
    Add-Alteracao -Acao 'Limpeza do driver de vídeo' -Resultado ("executado; cópia em $pasta; para voltar: pnputil /add-driver `"$pasta\*\*.inf`" /install")
    $feito.Add('REINICIE o computador agora e instale o driver de vídeo que você baixou (escolha "Instalação personalizada > Executar instalação limpa" no instalador da NVIDIA).')
    $feito.Add("Para voltar ao driver que estava antes: pnputil /add-driver `"$pasta\*\*.inf`" /install")
    return $feito.ToArray()
}

# ----------------------------------------------------------------------------
# Instaladores de driver de fabricantes: só aceita arquivo com assinatura digital válida de um fabricante conhecido
# ----------------------------------------------------------------------------
$script:FabricantesDriver = @(
    @{ Nome = 'NVIDIA'; Assinante = 'NVIDIA Corporation'; Site = 'https://www.nvidia.com/Download/index.aspx'; Dominios = 'nvidia.com' },
    @{ Nome = 'AMD'; Assinante = 'Advanced Micro Devices'; Site = 'https://www.amd.com/en/support/downloads/drivers.html'; Dominios = 'amd.com' },
    @{ Nome = 'Intel'; Assinante = 'Intel Corporation'; Site = 'https://www.intel.com/content/www/us/en/download-center/home.html'; Dominios = 'intel.com' },
    @{ Nome = 'Realtek'; Assinante = 'Realtek Semiconductor'; Site = 'https://www.realtek.com/Download'; Dominios = 'realtek.com' },
    @{ Nome = 'Qualcomm'; Assinante = 'Qualcomm'; Site = 'https://www.qualcomm.com/support'; Dominios = 'qualcomm.com' },
    @{ Nome = 'Gigabyte'; Assinante = 'GIGA-BYTE'; Site = 'https://www.gigabyte.com/Support'; Dominios = 'gigabyte.com' },
    @{ Nome = 'ASUS'; Assinante = 'ASUSTeK'; Site = 'https://www.asus.com/support/'; Dominios = 'asus.com' },
    @{ Nome = 'MSI'; Assinante = 'Micro-Star'; Site = 'https://www.msi.com/support'; Dominios = 'msi.com' },
    @{ Nome = 'ASRock'; Assinante = 'ASRock'; Site = 'https://www.asrock.com/support/'; Dominios = 'asrock.com' }
)

function Test-AssinaturaInstalador {
    # Avalia a assinatura digital de um arquivo. $Info: @{ Status ('Valid'...); Assinante (texto do certificado); Hash }.
    # Devolve @{ Ok; Fabricante; Motivo }. Só é Ok se a assinatura é válida E o assinante é de um fabricante conhecido.
    param($Info)
    if ("$($Info.Status)" -ne 'Valid') { return @{ Ok = $false; Fabricante = ''; Motivo = "A assinatura digital do arquivo não é válida (situação: $($Info.Status)). Pode estar corrompido, adulterado ou sem assinatura." } }
    $a = "$($Info.Assinante)"
    foreach ($f in $script:FabricantesDriver) {
        if ($a -match [regex]::Escape($f.Assinante)) { return @{ Ok = $true; Fabricante = $f.Nome; Motivo = "Assinatura válida de $($f.Nome)." } }
    }
    return @{ Ok = $false; Fabricante = ''; Motivo = "A assinatura é válida, mas o assinante ($a) não é um fabricante de driver da lista confiável do Telomera." }
}

function Get-InfoAssinaturaArquivo {
    param([string]$Caminho)
    $sig = Get-AuthenticodeSignature -LiteralPath $Caminho
    $ass = ''
    if ($sig.SignerCertificate) { $ass = "$($sig.SignerCertificate.Subject)" }
    return @{ Status = "$($sig.Status)"; Assinante = $ass; Hash = (Get-FileHash -LiteralPath $Caminho -Algorithm SHA256).Hash.ToLower() }
}

function Invoke-VerificarInstaladorDriver {
    # Confere um instalador baixado do site do fabricante (assinatura e assinante) e, só com sua confirmação, executa.
    param([string]$Arquivo)
    $feito = New-Object System.Collections.Generic.List[string]
    if (-not $Arquivo -or -not (Test-Path -LiteralPath $Arquivo -PathType Leaf)) { $feito.Add('Nenhum arquivo foi escolhido.'); return $feito.ToArray() }
    if ($Arquivo -notmatch '\.(exe|msi)$') { $feito.Add('Só aceito instaladores .exe ou .msi.'); return $feito.ToArray() }
    $info = Get-InfoAssinaturaArquivo $Arquivo
    $av = Test-AssinaturaInstalador $info
    $feito.Add("Arquivo: $Arquivo")
    $feito.Add("SHA-256: $($info.Hash)")
    $feito.Add($av.Motivo)
    if (-not $av.Ok) { $feito.Add('NÃO vou executar este arquivo. Baixe de novo, direto do site oficial do fabricante.'); return $feito.ToArray() }
    $zona = ''
    try { $zona = [string](Get-Content -LiteralPath $Arquivo -Stream Zone.Identifier -ErrorAction Stop | Select-String 'HostUrl=' | Select-Object -First 1) } catch { }
    if ($zona) { $feito.Add("Origem do download: $($zona -replace '^.*HostUrl=', '')") }
    if (-not (Confirm-Acao ("O arquivo tem assinatura válida de $($av.Fabricante). Executar o instalador agora? O Telomera cria antes um ponto de restauração. A tela ou a rede podem piscar durante a instalação.") -MudaDriver)) { $feito.Add('Nada foi executado.'); return $feito.ToArray() }
    try { Checkpoint-Computer -Description 'Telomera antes de instalar driver' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop } catch { }
    try {
        Start-Process -FilePath $Arquivo
        Add-Alteracao -Acao "Executar instalador de driver verificado ($($av.Fabricante))" -Resultado "executado ($Arquivo, SHA-256 $($info.Hash))"
        $feito.Add('Instalador aberto. Siga as telas dele e reinicie o computador no final.')
    } catch { $feito.Add("Não consegui abrir o instalador: $($_.Exception.Message)") }
    return $feito.ToArray()
}

function Invoke-AbrirSitesDriver {
    # Abre a página oficial de download de cada fabricante dos seus componentes e mostra o driver instalado para comparar.
    $feito = New-Object System.Collections.Generic.List[string]
    $lista = @(Get-DriversParaLista | Where-Object { $_.Classe -in 'DISPLAY', 'NET', 'MEDIA', 'SYSTEM' })
    $abrir = New-Object System.Collections.Generic.List[string]
    foreach ($f in $script:FabricantesDriver) {
        $acha = @($lista | Where-Object { "$($_.Fabricante)" -match [regex]::Escape($f.Nome) -or "$($_.Nome)" -match [regex]::Escape($f.Nome) })
        if ($acha.Count -eq 0) { continue }
        $feito.Add("$($f.Nome): instalado agora -> " + (($acha | Select-Object -First 3 | ForEach-Object { "$($_.Nome) v$($_.Versao)" + $(if ($_.Data) { ' (' + $_.Data.ToString('MM/yyyy') + ')' } else { '' }) }) -join '; '))
        $feito.Add("  Página oficial: $($f.Site)")
        if ($f.Nome -in 'NVIDIA', 'AMD', 'Intel') { $abrir.Add($f.Site) }
    }
    if ($abrir.Count -eq 0) { $feito.Add('Não identifiquei fabricante de vídeo conhecido. Use "BIOS e drivers: abrir a página da placa-mãe".'); return $feito.ToArray() }
    $feito.Add('Como baixar com segurança: use SÓ estas páginas oficiais, escolha seu modelo e versão, baixe o instalador e depois use "Conferir um instalador baixado" aqui no Telomera, que só deixa executar se a assinatura digital for válida e de um fabricante conhecido.')
    foreach ($u in ($abrir | Select-Object -Unique)) { try { Start-Process $u } catch { } }
    return $feito.ToArray()
}

# ----------------------------------------------------------------------------
# Autoteste: confere se cada recurso do Telomera funciona neste Windows (para mandar o resultado ao desenvolvedor)
# ----------------------------------------------------------------------------
function Invoke-AutoTeste {
    $l = New-Object System.Collections.Generic.List[string]
    $ok = 0; $falha = 0; $pula = 0
    $v = 'desconhecida'; try { $v = $script:Versao } catch { }
    $l.Add("Telomera - autoteste (versão $v)")
    $l.Add("Windows: $([Environment]::OSVersion.VersionString) | PowerShell $($PSVersionTable.PSVersion) | Administrador: $([bool]$script:IsAdmin)")
    $l.Add('')
    $passo = {
        param([string]$Nome, [scriptblock]$Bloco)
        try {
            $r = & $Bloco
            if ($r -is [string] -and $r.StartsWith('PULADO')) { $script:_at.Pula++; $script:_at.L.Add(('  PULADO  {0}: {1}' -f $Nome, $r.Substring(7))) }
            else { $script:_at.Ok++; $script:_at.L.Add(('  OK      {0}{1}' -f $Nome, $(if ($r) { ': ' + $r } else { '' }))) }
        } catch { $script:_at.Falha++; $script:_at.L.Add(('  FALHOU  {0}: {1}' -f $Nome, $_.Exception.Message)) }
    }
    $script:_at = @{ Ok = 0; Falha = 0; Pula = 0; L = $l }
    if ($env:OS -ne 'Windows_NT') { $l.Add('O autoteste só roda no Windows.'); return ($l -join "`r`n") }
    & $passo 'Interface (Windows Forms)' { Add-Type -AssemblyName System.Windows.Forms, System.Drawing; 'carregada' }
    & $passo 'WPF e compilador de shader (d3dcompiler_47.dll)' { Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase; if (-not (Test-Path (Join-Path $env:SystemRoot 'System32\d3dcompiler_47.dll'))) { throw 'd3dcompiler_47.dll não encontrada (o estresse de jogo pesado não vai rodar)' }; 'ok' }
    & $passo 'Modo de vídeo (troca de resolução do teste de transição)' { if (-not ('WDModo' -as [type])) { Add-Type -TypeDefinition $script:CodigoModo }; $a = [WDModo]::Atual(); if (-not $a) { throw 'não conseguiu ler o modo atual' }; $alt = [WDModo]::Alternativo(); "atual $a; alternativo " + $(if ($alt) { $alt } else { 'nenhum' }) }
    & $passo 'Placa de vídeo (temperatura, consumo, clock)' { $g = Get-TempGpu; if (-not $g) { throw 'sem leitura (nvidia-smi ou driver AMD indisponível)' }; "{0} °C, {1} W, {2} MHz via {3}" -f $g.Temp, $g.Potencia, $g.Clock, $g.Fonte }
    & $passo 'NVIDIA: PCIe e motivos de redução de clock' { $e = Get-NvidiaExtra; if (-not $e) { return 'PULADO sem placa NVIDIA' }; "PCIe gen $($e.Gen)/$($e.GenMax) x$($e.Larg)/$($e.LargMax); motivos informados: $($e.Motivos)" }
    & $passo 'Lista de drivers explicada' { $d = @(Get-DriversParaLista); if ($d.Count -eq 0) { throw 'nenhum driver lido' }; "$($d.Count) driver(s) lidos" }
    & $passo 'Pacotes do DriverStore (limpeza de versões antigas)' { if (-not $script:IsAdmin) { return 'PULADO precisa de administrador' }; $p = @(Get-WindowsDriver -Online -All -ErrorAction Stop); "$($p.Count) pacote(s)" }
    & $passo 'Programas de sensores (HWiNFO / LibreHardwareMonitor)' { $e = Get-EstadoSensores; $a = Get-AvaliacaoSensores $e; $a.Resumo }
    & $passo 'Sensores (HWiNFO / MSI Afterburner)' { $r = Get-LeiturasMonitor; if (-not $r.Fontes) { return 'PULADO nenhum programa de sensores aberto' }; "$($r.Fontes) com $(@($r.Itens).Count) leituras" }
    & $passo 'Eventos do Windows' { $n = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; StartTime = (Get-Date).AddDays(-7) } -MaxEvents 5 -ErrorAction Stop).Count; "$n evento(s) lidos" }
    & $passo 'Configurações que influenciam travamentos' { $c = Get-ConfigTravamento; if ($c.Linhas.Count -eq 0) { throw 'nenhuma configuração lida' }; "$($c.Linhas.Count) linhas" }
    & $passo 'Discos (SMART pelo Windows)' { $d = @(Get-PhysicalDisk -ErrorAction Stop); "$($d.Count) disco(s)" }
    & $passo 'SMART detalhado (atributos, CRC)' { if (-not $script:IsAdmin) { return 'PULADO precisa de administrador' }; $s = @(Get-SmartAtributos); if ($s.Count -eq 0) { throw 'o disco ou o driver não expõe os atributos' }; "$($s.Count) disco(s), $(@($s[0].Atributos).Count) atributos no primeiro" }
    & $passo 'Memória instalada (pentes)' { $m = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop); "$($m.Count) pente(s)" }
    & $passo 'Drivers de som, rede e chipset' { $n = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -in 'MEDIA', 'NET', 'SYSTEM' }).Count; "$n driver(s)" }
    & $passo 'Teste de memória com padrões (10 s, 128 MB)' {
        if (-not (Get-Command Initialize-Testes -ErrorAction SilentlyContinue)) { return 'PULADO módulo de testes ausente' }
        Initialize-Testes; [WDTestes]::MemIniciar(128, 10, 2); while ([WDTestes]::MemRodando) { Start-Sleep -Milliseconds 300 }
        if ([WDTestes]::MemErros -gt 0) { throw "ENCONTROU $([WDTestes]::MemErros) erro(s) de memória" }; "$([WDTestes]::MemPassadas) passada(s), sem erros" }
    & $passo 'Estresse do disco (10 s, 64 MB)' {
        Initialize-Testes; $a = Join-Path ([IO.Path]::GetTempPath()) ('Telomera-auto-' + [guid]::NewGuid().ToString('N') + '.tmp')
        [WDTestes]::DiscoIniciar($a, 64, 10); while ([WDTestes]::DiscoRodando) { Start-Sleep -Milliseconds 300 }
        if ([WDTestes]::DiscoExcecao) { throw [WDTestes]::DiscoExcecao }; if ([WDTestes]::DiscoErros -gt 0) { throw "dados diferentes em $([WDTestes]::DiscoErros) bloco(s)" }
        'gravou e leu com verificação' }
    & $passo 'Pasta de dados do Telomera (escrita)' { $f = Get-ArquivoDados 'autoteste.tmp'; $d = Split-Path -Parent $f; if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }; [IO.File]::WriteAllText($f, 'x'); Remove-Item $f -Force; $d }
    & $passo 'Monitor em tempo real (gravação em disco)' { $dir = Get-PastaMonitor; if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }; $t = Join-Path $dir 'autoteste.tmp'; [IO.File]::WriteAllText($t, 'x'); Remove-Item $t -Force; $dir }
    $l.Add('')
    $l.Add(("Resultado: {0} OK, {1} falhou, {2} pulado(s)." -f $script:_at.Ok, $script:_at.Falha, $script:_at.Pula))
    if ($script:_at.Falha -gt 0) { $l.Add('Mande este texto ao desenvolvedor: cada linha FALHOU mostra o motivo.') }
    return ($l -join "`r`n")
}

# ----------------------------------------------------------------------------
# Ferramentas de reparo e restauração (manuais; cada uma pede confirmação)
# ----------------------------------------------------------------------------
function Reset-RedeWindows {
    foreach ($c in @('ipconfig /flushdns', 'netsh winsock reset', 'netsh int ip reset', 'netsh int ipv6 reset')) {
        Write-Host "    $c"
        $o = & cmd.exe /c "$c 2>&1"
        @($o) | Out-String -Stream | Where-Object { "$_".Trim() } | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
    }
    Write-Host '    Reinicie o computador para concluir a reinicialização da rede.' -ForegroundColor Cyan
}

function Reset-WindowsUpdate {
    $svcs = @('wuauserv', 'bits', 'cryptsvc', 'msiserver')
    foreach ($s in $svcs) { try { Stop-Service -Name $s -Force -ErrorAction Stop; Write-Host "    Parado: $s" -ForegroundColor DarkGray } catch { Write-Host "    Não consegui parar $s ($($_.Exception.Message))" -ForegroundColor Yellow } }
    $sufixo = '.bak_Telomera_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    foreach ($p in @((Join-Path $env:SystemRoot 'SoftwareDistribution'), (Join-Path $env:SystemRoot 'System32\catroot2'))) {
        if (Test-Path -LiteralPath $p) {
            try { Rename-Item -LiteralPath $p -NewName ((Split-Path -Leaf $p) + $sufixo) -ErrorAction Stop; Write-Host "    Pasta renomeada: $p" -ForegroundColor Green }
            catch { Write-Host "    Não consegui renomear $p ($($_.Exception.Message))" -ForegroundColor Yellow }
        }
    }
    foreach ($s in $svcs) { try { Start-Service -Name $s -ErrorAction Stop } catch { Write-Host "    Não consegui iniciar $s" -ForegroundColor Yellow } }
    Write-Host '    O Windows recria as pastas sozinho; as antigas ficaram guardadas com a terminação .bak_Telomera.' -ForegroundColor Cyan
}

function Clear-CacheIcones {
    # Reconstrói o cache de ícones/miniaturas: para o Explorer, apaga o cache e reabre o Explorer.
    # Não apaga nenhum arquivo do usuário -- o Windows recria os arquivos de cache na hora.
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    $pastas = @(
        (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer')
    )
    foreach ($p in $pastas) {
        if (Test-Path -LiteralPath $p) {
            Get-ChildItem -LiteralPath $p -Filter 'iconcache*.db' -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
            Get-ChildItem -LiteralPath $p -Filter 'thumbcache*.db' -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        }
    }
    $antigo = Join-Path $env:LOCALAPPDATA 'IconCache.db'
    if (Test-Path -LiteralPath $antigo) { Remove-Item -LiteralPath $antigo -Force -ErrorAction SilentlyContinue }
    Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe')
}

function Clear-CacheFontes {
    # Para o serviço de cache de fontes, apaga os arquivos de cache e reinicia o serviço.
    # O Windows reconstrói o cache na hora; nenhuma fonte instalada é removida.
    foreach ($s in @('FontCache', 'FontCache3.0.0.0')) { try { Stop-Service -Name $s -Force -ErrorAction Stop } catch { } }
    $pastaCache = Join-Path $env:SystemRoot 'ServiceProfiles\LocalService\AppData\Local\FontCache'
    if (Test-Path -LiteralPath $pastaCache) {
        Get-ChildItem -LiteralPath $pastaCache -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
    }
    $svcLocal = Join-Path $env:SystemRoot 'ServiceProfiles\LocalService\AppData\Local'
    if (Test-Path -LiteralPath $svcLocal) {
        Get-ChildItem -LiteralPath $svcLocal -Filter 'FontCache-*.dat' -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    }
    $antigo = Join-Path $env:SystemRoot 'System32\FNTCACHE.DAT'
    if (Test-Path -LiteralPath $antigo) { Remove-Item -LiteralPath $antigo -Force -ErrorAction SilentlyContinue }
    try { Start-Service -Name FontCache -ErrorAction Stop } catch { }
}

function Reset-CacheLoja {
    # wsreset.exe é a ferramenta própria do Windows para limpar o cache/dados locais da Microsoft Store.
    # Fecha e reabre a Store sozinha; não precisa de confirmação visual aqui, só rodar e aguardar.
    $wsreset = Join-Path $env:SystemRoot 'System32\wsreset.exe'
    if (-not (Test-Path -LiteralPath $wsreset)) { throw 'wsreset.exe não encontrado neste Windows.' }
    $p = Start-Process -FilePath $wsreset -PassThru -ErrorAction Stop
    $p | Wait-Process -Timeout 30 -ErrorAction SilentlyContinue
}

function Invoke-LimparWindowsOld {
    # Apaga a pasta Windows.old (instalação anterior do Windows), usando o mesmo mecanismo da
    # Limpeza de Disco do próprio Windows (perfil /sageset + /sagerun), e não um "del /s" manual --
    # a pasta tem permissões especiais e o Windows sabe limpá-la com segurança. Devolve
    # @{ Existia; Removida; EspacoLiberado; Mensagem }.
    $unidade = $env:SystemDrive
    if (-not $unidade) { $unidade = 'C:' }
    $pasta = Join-Path "$unidade\" 'Windows.old'
    if (-not (Test-Path -LiteralPath $pasta)) {
        return @{ Existia = $false; Removida = $false; EspacoLiberado = [int64]0; Mensagem = 'Não existe uma pasta Windows.old neste computador (ou o Windows já apagou sozinho -- ele some depois de cerca de 10 dias).' }
    }
    $chaveVol = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'
    $alvo = @(Get-ChildItem -Path $chaveVol -ErrorAction Stop | Where-Object { (Split-Path -Leaf $_.PSPath) -match '(?i)Previous\s*Installation' })
    if ($alvo.Count -eq 0) {
        return @{ Existia = $true; Removida = $false; EspacoLiberado = [int64]0; Mensagem = 'A pasta Windows.old existe, mas não encontrei a opção "Previous Installations" na Limpeza de Disco deste Windows -- por segurança, não apaguei nada automaticamente. Use o Liberador de Espaço em Disco do próprio Windows (procure "Limpeza de Disco" no menu Iniciar, clique em "Limpar arquivos do sistema" e marque "Instalações anteriores do Windows").' }
    }
    $n = 65039   # número de perfil dedicado do Telomera, para não interferir num /sageset que você já tenha configurado
    try {
        foreach ($sub in (Get-ChildItem -Path $chaveVol -ErrorAction Stop)) {
            try { New-ItemProperty -Path $sub.PSPath -Name "StateFlags$n" -Value 0 -PropertyType DWord -Force -ErrorAction Stop | Out-Null } catch { }
        }
        foreach ($a in $alvo) { New-ItemProperty -Path $a.PSPath -Name "StateFlags$n" -Value 2 -PropertyType DWord -Force -ErrorAction Stop | Out-Null }
    } catch { return @{ Existia = $true; Removida = $false; EspacoLiberado = [int64]0; Mensagem = "Não consegui configurar a Limpeza de Disco: $($_.Exception.Message)" } }
    $antes = [int64]0
    try { $antes = (Get-PSDrive -Name $unidade.TrimEnd(':') -ErrorAction Stop).Free } catch { }
    try {
        $p = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\cleanmgr.exe') -ArgumentList "/sagerun:$n" -PassThru -ErrorAction Stop
        $p | Wait-Process -Timeout 900 -ErrorAction SilentlyContinue
    } catch { return @{ Existia = $true; Removida = $false; EspacoLiberado = [int64]0; Mensagem = "Não consegui rodar a Limpeza de Disco: $($_.Exception.Message)" } }
    finally {
        # Desmarca de novo: não deixa o perfil "ligado" para uma próxima limpeza de disco acidental.
        try { foreach ($a in $alvo) { Set-ItemProperty -Path $a.PSPath -Name "StateFlags$n" -Value 0 -ErrorAction SilentlyContinue } } catch { }
    }
    $depois = $antes
    try { $depois = (Get-PSDrive -Name $unidade.TrimEnd(':') -ErrorAction Stop).Free } catch { }
    $liberado = [int64]([Math]::Max(0, $depois - $antes))
    $ainda = Test-Path -LiteralPath $pasta
    if ($ainda) {
        return @{ Existia = $true; Removida = $false; EspacoLiberado = $liberado; Mensagem = 'A Limpeza de Disco rodou, mas a pasta Windows.old ainda existe. Pode precisar reiniciar o computador para o Windows concluir a remoção, ou pode não ter tido permissão suficiente.' }
    }
    return @{ Existia = $true; Removida = $true; EspacoLiberado = $liberado; Mensagem = 'Windows.old removida.' }
}

function Repair-LojaWindows {
    $pacotes = @(Get-AppxPackage -AllUsers -Name 'Microsoft.WindowsStore' -ErrorAction SilentlyContinue)
    if ($pacotes.Count -eq 0) { Write-Host '    A Microsoft Store não está instalada neste Windows.' -ForegroundColor Yellow; return }
    foreach ($p in $pacotes) {
        $m = Join-Path $p.InstallLocation 'AppXManifest.xml'
        if (Test-Path -LiteralPath $m) {
            Add-AppxPackage -DisableDevelopmentMode -Register $m -ErrorAction Stop
            Write-Host '    Microsoft Store registrada novamente.' -ForegroundColor Green
        }
    }
}

function Get-ListaPontosRestauracao {
    $l = New-Object System.Collections.Generic.List[string]
    try {
        $pts = @(Get-ComputerRestorePoint -ErrorAction Stop)
        if ($pts.Count -eq 0) { $l.Add('Nenhum ponto de restauração encontrado (a Proteção do Sistema pode estar desativada).') }
        foreach ($p in ($pts | Sort-Object SequenceNumber -Descending)) {
            $quando = $p.CreationTime
            try { $quando = [Management.ManagementDateTimeConverter]::ToDateTime($p.CreationTime).ToString('dd/MM/yyyy HH:mm') } catch { }
            $l.Add("$quando  -  $($p.Description)")
        }
    } catch { $l.Add("Não consegui listar os pontos de restauração: $($_.Exception.Message)") }
    return ($l -join "`r`n")
}

function Invoke-Ferramenta {
    # Executa uma ferramenta e devolve @{ Ok; Titulo; Texto }.
    param([string]$Nome, [string]$Destino, [string]$Dia = 'Sunday', [string]$Hora = '10:00')
    if (-not $Dia) { $Dia = 'Sunday' }
    if (-not $Hora) { $Hora = '10:00' }
    $feito = New-Object System.Collections.Generic.List[string]
    $titulo = ''
    switch ($Nome) {
        'pontos-listar' {
            $titulo = 'Pontos de restauração do Windows'
            $feito.Add((Get-ListaPontosRestauracao))
            $feito.Add('')
            $feito.Add('Para voltar o Windows a um desses pontos, use a Restauração do Sistema (botão "Abrir a Restauração do Sistema").')
        }
        'pontos-criar' {
            $titulo = 'Criar ponto de restauração'
            if (Confirm-Acao 'Criar agora um ponto de restauração do sistema? (pode ativar a Proteção do Sistema na unidade do Windows)') {
                try {
                    Enable-ComputerRestore -Drive "$($env:SystemDrive)\" -ErrorAction Stop
                    Checkpoint-Computer -Description 'Telomera (manual)' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado 'executado'
                    $feito.Add('Ponto de restauração criado.')
                } catch {
                    Add-Alteracao -Acao 'Criar ponto de restauração' -Resultado "falhou: $($_.Exception.Message)"
                    $feito.Add("Não foi possível criar o ponto: $($_.Exception.Message)")
                    $feito.Add('(O Windows limita a um ponto a cada 24 horas por padrão.)')
                }
            } else { $feito.Add('Nada foi feito.') }
        }
        'rede' {
            $titulo = 'Reparar a rede'
            if (Confirm-Acao 'Reiniciar a configuração de rede (limpa o DNS e reinicia o Winsock e o IP)? Configurações de IP fixo podem ser perdidas.') {
                try { Reset-RedeWindows; Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado 'executado'; $feito.Add('Configuração de rede reiniciada. Reinicie o computador para concluir.') }
                catch { Add-Alteracao -Acao 'Reiniciar a configuração de rede' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'wu' {
            $titulo = 'Reparar o Windows Update'
            if (Confirm-Acao 'Reparar o Windows Update? Os serviços serão parados e as pastas temporárias do Windows Update renomeadas (o histórico de atualizações pode ser reiniciado).') {
                try { Reset-WindowsUpdate; Add-Alteracao -Acao 'Reparar o Windows Update (pastas SoftwareDistribution e catroot2)' -Resultado 'executado'; $feito.Add('Windows Update reparado. Reinicie e procure atualizações de novo.') }
                catch { Add-Alteracao -Acao 'Reparar o Windows Update' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'store' {
            $titulo = 'Reparar a Microsoft Store'
            if (Confirm-Acao 'Registrar novamente a Microsoft Store? (corrige loja que não abre ou não baixa)') {
                try { Repair-LojaWindows; Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado 'executado'; $feito.Add('Concluído. Abra a Microsoft Store para testar.') }
                catch { Add-Alteracao -Acao 'Reparar a Microsoft Store' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'chkdsk' {
            $titulo = 'Verificar o disco (CHKDSK)'
            $u = $env:SystemDrive
            if (-not $u) { $u = 'C:' }
            if (Confirm-Acao "Agendar a verificação completa do disco $u (CHKDSK /F /R)? Ela roda na próxima reinicialização e pode levar de minutos a horas." ) {
                try { Invoke-AgendarChkdsk -Unidade $u; Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado 'executado'; $feito.Add("Verificação do disco $u agendada. Reinicie o computador e aguarde: não desligue durante o processo.") }
                catch { Add-Alteracao -Acao "Agendar CHKDSK em $u" -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'temp' {
            $titulo = 'Limpar arquivos temporários'
            $tam = [int64]0
            foreach ($p in (Get-PastasTemporarios)) { $tam += (Get-TamanhoPasta -Pasta $p -DiasMinimos 2) }
            if (Confirm-Acao ("Apagar os arquivos temporários com mais de 2 dias? (cerca de {0})" -f (Format-Tamanho $tam))) {
                $l = Clear-Temporarios
                Add-Alteracao -Acao 'Apagar arquivos temporários antigos' -Resultado ("liberado {0}" -f (Format-Tamanho $l))
                $feito.Add(("Liberado: {0}" -f (Format-Tamanho $l)))
            } else { $feito.Add('Nada foi feito.') }
        }
        'limpar-windowsold' {
            $titulo = 'Apagar a instalação anterior do Windows (Windows.old)'
            if (Confirm-Acao 'Apagar de vez a pasta Windows.old (a cópia da instalação anterior do Windows)? ATENÇÃO: isto é DEFINITIVO -- depois de apagar, você não vai mais conseguir usar a opção "Voltar para a versão anterior do Windows" nas Configurações. Só continue se já faz tempo que atualizou e o computador está estável.') {
                try {
                    $r = Invoke-LimparWindowsOld
                    if ($r.Removida) { Add-Alteracao -Acao 'Apagar Windows.old' -Resultado ("executado (liberado {0})" -f (Format-Tamanho $r.EspacoLiberado)) } else { Add-Alteracao -Acao 'Apagar Windows.old' -Resultado "não concluído: $($r.Mensagem)" }
                    $feito.Add($r.Mensagem)
                    if ($r.Removida -and $r.EspacoLiberado -gt 0) { $feito.Add(("Espaço liberado: {0}" -f (Format-Tamanho $r.EspacoLiberado))) }
                } catch { Add-Alteracao -Acao 'Apagar Windows.old' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-ativar' {
            $titulo = 'Verificação semanal automática'
            $diasOk = @('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
            $diasPt = @{ Sunday = 'domingo'; Monday = 'segunda-feira'; Tuesday = 'terça-feira'; Wednesday = 'quarta-feira'; Thursday = 'quinta-feira'; Friday = 'sexta-feira'; Saturday = 'sábado' }
            if ($diasOk -notcontains $Dia -or $Hora -notmatch '^([01]\d|2[0-3]):[0-5]\d$') {
                $feito.Add('Dia ou horário inválido. Escolha de novo na página de Configurações.')
            } elseif (Confirm-Acao "Ativar a verificação semanal automática, toda $($diasPt[$Dia]) às $Hora (ou na próxima vez que o computador estiver ligado)? O Telomera faz uma verificação rápida só de leitura, sem alterar nada e sem usar a internet, e só avisa se a saúde do computador piorar. Dá para desativar quando quiser.") {
                try { Enable-VerificacaoAgendada -Dia $Dia -Hora $Hora; Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado 'executado'; $feito.Add((Get-TextoTarefaAgendada)) }
                catch { Add-Alteracao -Acao 'Ativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-desativar' {
            $titulo = 'Verificação semanal automática'
            if (-not (Get-TarefaAgendada)) { $feito.Add('A verificação semanal automática já estava desativada.') }
            elseif (Confirm-Acao 'Desativar a verificação semanal automática?') {
                try { Disable-VerificacaoAgendada; Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado 'executado'; $feito.Add('Verificação semanal automática desativada.') }
                catch { Add-Alteracao -Acao 'Desativar a verificação semanal automática' -Resultado "falhou: $($_.Exception.Message)"; $feito.Add("Falhou: $($_.Exception.Message)") }
            } else { $feito.Add('Nada foi feito.') }
        }
        'agendar-estado' {
            $titulo = 'Verificação semanal automática'
            $feito.Add((Get-TextoTarefaAgendada))
            $feito.Add('')
            $feito.Add('Como funciona: uma vez por semana o Telomera faz uma verificação rápida só de leitura (sem corrigir nada e sem usar a internet). Se a nota de saúde cair 5 pontos ou mais, ou aparecer um problema crítico novo, você recebe um aviso. As 4 verificações automáticas mais recentes ficam em %LOCALAPPDATA%\Telomera\Agendadas.')
        }
        'saude-historico' {
            $titulo = 'Nota de saúde ao longo do tempo'
            $feito.Add((Format-TextoHistoricoNotas))
        }
        'historico' {
            $titulo = 'O que o Telomera já mudou neste computador'
            $feito.Add((Format-TextoHistoricoAlteracoes))
        }
        'cfg-hags' { $titulo = 'Agendamento de GPU acelerado por hardware'; foreach ($x in (Invoke-ReparoCfg 'hags')) { $feito.Add($x) } }
        'cfg-pcie' { $titulo = 'Economia de energia do PCIe'; foreach ($x in (Invoke-ReparoCfg 'pcie')) { $feito.Add($x) } }
        'cfg-fast' { $titulo = 'Inicialização rápida do Windows'; foreach ($x in (Invoke-ReparoCfg 'fast')) { $feito.Add($x) } }
        'cfg-desfazer' { $titulo = 'Desfazer mudanças de configuração'; foreach ($x in (Invoke-DesfazerCfg)) { $feito.Add($x) } }
        'ini-desfazer' { $titulo = 'Reativar programas desativados pela otimização'; foreach ($x in (Invoke-DesfazerOtimizacaoInicializacao)) { $feito.Add($x) } }
        'drv-sites' { $titulo = 'Sites oficiais de driver'; foreach ($x in (Invoke-AbrirSitesDriver)) { $feito.Add($x) } }
        'drv-verificar' { $titulo = 'Conferir um instalador baixado'; foreach ($x in (Invoke-VerificarInstaladorDriver -Arquivo $Destino)) { $feito.Add($x) } }
        'reiniciar-pc' { $titulo = 'Reiniciar o computador'
            if (Confirm-Acao 'Reiniciar o computador em 30 segundos? Salve seus trabalhos. Para cancelar, abra o Prompt de Comando e digite: shutdown /a') {
                & shutdown.exe /r /t 30 /c 'Telomera: reinício solicitado' 2>&1 | Out-Null
                Add-Alteracao -Acao 'Reiniciar o computador' -Resultado 'agendado para 30 segundos'
                $feito.Add('O computador vai reiniciar em 30 segundos. Para cancelar: shutdown /a')
            } else { $feito.Add('Nada foi feito.') } }
        'drv-lista' { $titulo = 'Drivers explicados'; foreach ($x in (Invoke-ListaDrivers)) { $feito.Add($x) } }
        'drv-reparar' { $titulo = 'Reparar dispositivos com erro'; foreach ($x in (Invoke-ReparoDispositivosComErro)) { $feito.Add($x) } }
        'drv-video-reiniciar' { $titulo = 'Reiniciar o driver de vídeo'; foreach ($x in (Invoke-ReiniciarDriverVideo)) { $feito.Add($x) } }
        'drv-wu' { $titulo = 'Drivers do Windows Update'; foreach ($x in (Invoke-DriversWindowsUpdate)) { $feito.Add($x) } }
        'drv-limpar' { $titulo = 'Limpar versões antigas de driver'; foreach ($x in (Invoke-LimparDriversAntigos)) { $feito.Add($x) } }
        'drv-video-limpo' { $titulo = 'Limpeza do driver de vídeo'; foreach ($x in (Invoke-LimpezaDriverVideo)) { $feito.Add($x) } }
        'cfg-usb' { $titulo = 'Economia de energia do USB'; foreach ($x in (Invoke-ReparoCfg 'usb')) { $feito.Add($x) } }
        'sensores-estado' { $titulo = 'Estado dos sensores'; foreach ($x in (Invoke-EstadoSensores)) { $feito.Add($x) } }
        'hwinfo-config' { $titulo = 'Configurar o HWiNFO'; foreach ($x in (Invoke-ConfigurarHwinfo)) { $feito.Add($x) } }
        'lhm-baixar' { $titulo = 'Baixar a LibreHardwareMonitor'; foreach ($x in (Invoke-InstalarLhm)) { $feito.Add($x) } }
        'lhm-abrir' { $titulo = 'Abrir a LibreHardwareMonitor'; foreach ($x in (Invoke-AbrirLhm)) { $feito.Add($x) } }
        'bios-site' { $titulo = 'BIOS e drivers da placa-mãe'
            $b = Get-InfoBiosAtual; $lk = Get-LinkSuporteFabricante -Fabricante $b.Fabricante -Produto $b.Produto -Cpu $b.Cpu
            $feito.Add("Placa-mãe: $($b.Fabricante) $($b.Produto)"); $feito.Add($b.Texto)
            $feito.Add('O Telomera não consegue saber sozinho qual é a BIOS mais nova: abrimos a página de suporte do fabricante. Compare a versão e a data da lista com a instalada. Atualizar a BIOS tem risco: só faça se a nota da versão citar estabilidade, memória ou o seu processador, e nunca desligue o computador durante a atualização.')
            if ($lk.UrlBios -match '^https://') { try { Start-Process $lk.UrlBios; $feito.Add("Página aberta: $($lk.UrlBios)") } catch { $feito.Add("Endereço: $($lk.UrlBios)") } } }
        'chipset-site' { $titulo = 'Driver de chipset'
            $b = Get-InfoBiosAtual; $lk = Get-LinkSuporteFabricante -Fabricante $b.Fabricante -Produto $b.Produto -Cpu $b.Cpu
            $feito.Add("Processador: $($b.Cpu)")
            $feito.Add('Abrimos a página oficial do driver de chipset do fabricante do processador (AMD ou Intel). Baixe só dali ou do site da placa-mãe.')
            try { Start-Process $lk.UrlChipset; $feito.Add("Página aberta: $($lk.UrlChipset)") } catch { $feito.Add("Endereço: $($lk.UrlChipset)") } }
        'guia-driver-video' { $titulo = 'Guia: instalação limpa do driver de vídeo'; $feito.Add((Get-TextoGuia 'guia-driver-video')) }
        'guia-fonte' { $titulo = 'Guia: testar com outra fonte'; $feito.Add((Get-TextoGuia 'guia-fonte')) }
        'guia-energia' { $titulo = 'Guia: limitar a energia da placa de vídeo'; $feito.Add((Get-TextoGuia 'guia-energia')) }
        'autoteste' { $titulo = 'Autoteste do Telomera'; $feito.Add((Invoke-AutoTeste)) }
        'backup' {
            $titulo = 'Cópia dos arquivos pessoais'
            $feito.Add((Invoke-BackupPessoal -Destino $Destino))
        }
        default { return @{ Ok = $false; Erro = "Ferramenta desconhecida: $Nome" } }
    }
    return @{ Ok = $true; Titulo = $titulo; Texto = ($feito -join "`r`n") }
}

function Invoke-BackupPessoal {
    # Copia Documentos, Imagens e Área de Trabalho para uma pasta escolhida (não altera nem apaga nada na origem).
    param([string]$Destino)
    if (-not $Destino -or -not (Test-Path -LiteralPath $Destino)) { return 'Nenhuma pasta de destino foi escolhida.' }
    $origens = @()
    foreach ($n in @('MyDocuments', 'MyPictures', 'Desktop')) {
        $p = [Environment]::GetFolderPath($n)
        if ($p -and (Test-Path -LiteralPath $p)) { $origens += $p }
    }
    $tam = [int64]0
    foreach ($o in $origens) { $tam += (Get-TamanhoPasta -Pasta $o -LimiteSeg 60) }
    $livre = 0
    try { $livre = (New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Destino))).AvailableFreeSpace } catch { }
    if ($livre -gt 0 -and $tam -gt ($livre * 0.95)) {
        return ("Não há espaço suficiente no destino: precisa de cerca de {0} e há {1} livres." -f (Format-Tamanho $tam), (Format-Tamanho $livre))
    }
    if (-not (Confirm-Acao ("Copiar Documentos, Imagens e Área de Trabalho (cerca de {0}) para '{1}'? Nada é apagado nem alterado na origem." -f (Format-Tamanho $tam), $Destino))) { return 'Nada foi feito.' }
    $raiz = Join-Path $Destino ('Telomera_Backup_' + (Get-Date -Format 'yyyy-MM-dd_HH-mm'))
    New-Item -ItemType Directory -Force -Path $raiz | Out-Null
    $resumo = New-Object System.Collections.Generic.List[string]
    foreach ($o in $origens) {
        $alvo = Join-Path $raiz (Split-Path -Leaf $o)
        Write-Host "    Copiando $o ..."
        $argsRc = @("`"$o`"", "`"$alvo`"", '/E', '/XJ', '/R:1', '/W:1', '/MT:8', '/NFL', '/NDL', '/NP', '/XD', 'Telomera')
        $proc = $null
        try {
            $proc = Start-Process -FilePath 'robocopy.exe' -ArgumentList $argsRc -PassThru -WindowStyle Hidden
            while (-not $proc.HasExited) { Start-Sleep -Milliseconds 700 }
            $cod = $proc.ExitCode
        } finally { try { if ($proc -and -not $proc.HasExited) { $proc.Kill() } } catch { } }
        if ($cod -lt 8) { $resumo.Add("OK: $o") } else { $resumo.Add("Com falhas (código $cod): $o") }
    }
    Add-Alteracao -Acao "Cópia dos arquivos pessoais para $raiz" -Resultado 'executado'
    return ("Cópia concluída em:`r`n$raiz`r`n`r`n" + ($resumo -join "`r`n"))
}
