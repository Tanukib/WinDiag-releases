﻿<#
.SYNOPSIS
    Compila TelomeraLauncher.cs em Telomera.exe e assina com um certificado de teste (self-signed).
    Não precisa do .NET SDK: usa o csc.exe que já vem com o .NET Framework do Windows.

.DESCRIPTION
    Lógica central de compilação do launcher nativo, usada automaticamente pelo Instalar-Telomera.ps1
    (a cada instalação ou atualização) e pela ferramenta de teste em launcher\Compilar-Launcher.ps1.
    Não lança exceção: devolve um hashtable com o resultado, para o chamador decidir o que fazer se
    a compilação falhar (por exemplo, continuar a instalação sem o .exe nativo).

.PARAMETER Origem
    Pasta com TelomeraLauncher.cs, app.manifest e telomera.ico.

.PARAMETER Destino
    Pasta onde o Telomera.exe (e o certificado público exportado) devem ficar. Pode ser igual a -Origem.

.OUTPUTS
    Hashtable: @{ Ok = [bool]; Exe = [string]; Cer = [string]; Erro = [string] }
#>
param(
    [Parameter(Mandatory)][string]$Origem,
    [Parameter(Mandatory)][string]$Destino,
    [switch]$Silencioso
)
$ErrorActionPreference = 'Stop'
function Escrever([string]$t) { if (-not $Silencioso) { Write-Host $t } }

function Build-TelomeraExe {
    $resultado = @{ Ok = $false; Exe = $null; Cer = $null; Erro = $null }
    try {
        $fonte = Join-Path $Origem 'TelomeraLauncher.cs'
        $manifesto = Join-Path $Origem 'app.manifest'
        $icone = Join-Path $Origem 'telomera.ico'
        foreach ($necessario in @($fonte, $manifesto, $icone)) {
            if (-not (Test-Path -LiteralPath $necessario)) { throw "Arquivo necessário não encontrado: $necessario" }
        }

        # csc.exe (compilador C# do .NET Framework) já vem com o Windows desde o Vista; não precisa instalar nada.
        $csc = $null
        try {
            $dirRuntime = [System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()
            $candidato = Join-Path $dirRuntime 'csc.exe'
            if (Test-Path -LiteralPath $candidato) { $csc = $candidato }
        } catch { }
        if (-not $csc) {
            foreach ($p in @(
                "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
                "$env:windir\Microsoft.NET\Framework\v4.0.30319\csc.exe"
            )) { if (Test-Path -LiteralPath $p) { $csc = $p; break } }
        }
        if (-not $csc) { throw 'csc.exe (compilador C# do .NET Framework) não encontrado neste Windows.' }

        New-Item -ItemType Directory -Force -Path $Destino | Out-Null
        $exe = Join-Path $Destino 'Telomera.exe'
        if (Test-Path -LiteralPath $exe) { Remove-Item -LiteralPath $exe -Force -ErrorAction SilentlyContinue }

        $argsCsc = @(
            '/nologo', '/target:winexe', '/platform:anycpu',
            '/reference:System.dll', '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll',
            "/win32icon:`"$icone`"", "/win32manifest:`"$manifesto`"",
            "/out:`"$exe`"", "`"$fonte`""
        )
        Escrever 'Compilando Telomera.exe...'
        $saidaCsc = & $csc @argsCsc 2>&1 | Out-String
        if (-not (Test-Path -LiteralPath $exe)) { throw "A compilação não gerou o Telomera.exe.`r`n$($saidaCsc.Trim())" }
        Escrever "OK: $exe gerado ($([math]::Round((Get-Item $exe).Length / 1KB, 1)) KB)"

        # Certificado de assinatura de teste (self-signed): reaproveita um já existente neste computador.
        $assunto = 'CN=Heverton Martins Ferreira Nunes (TANUKI) - Telomera (certificado de teste)'
        $cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue |
            Where-Object { $_.Subject -eq $assunto } | Select-Object -First 1
        if (-not $cert) {
            Escrever 'Criando certificado de assinatura de teste (self-signed, só neste computador)...'
            $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject $assunto `
                -CertStoreLocation Cert:\CurrentUser\My -KeyUsage DigitalSignature `
                -FriendlyName 'Telomera - certificado de teste' -NotAfter (Get-Date).AddYears(5)
        }

        try {
            Set-AuthenticodeSignature -FilePath $exe -Certificate $cert `
                -TimestampServer 'http://timestamp.digicert.com' -HashAlgorithm SHA256 -ErrorAction Stop | Out-Null
        } catch {
            Escrever "Carimbo de tempo falhou ($($_.Exception.Message)); assinando sem carimbo de tempo..."
            Set-AuthenticodeSignature -FilePath $exe -Certificate $cert -HashAlgorithm SHA256 | Out-Null
        }

        $cer = Join-Path $Destino 'Telomera-certificado-teste.cer'
        try { Export-Certificate -Cert $cert -FilePath $cer -Type CERT | Out-Null } catch { $cer = $null }

        $resultado.Ok = $true
        $resultado.Exe = $exe
        $resultado.Cer = $cer
    } catch {
        $resultado.Erro = $_.Exception.Message
    }
    return $resultado
}

Build-TelomeraExe
