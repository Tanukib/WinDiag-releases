﻿<#
.SYNOPSIS
    Instala o Telomera para o usuário atual (sem precisar de administrador).

.DESCRIPTION
    Copia o programa para %LOCALAPPDATA%\Programs\Telomera, cria os atalhos (Área de Trabalho e Menu Iniciar)
    e registra o Telomera em "Aplicativos e recursos" do Windows, para poder desinstalar por lá.
    Use o arquivo Instalar-Telomera.bat (duplo clique).
#>
param([switch]$SemPerguntas, [switch]$ComoAdministrador, [string]$Destino)

$ErrorActionPreference = 'Stop'
$origem = $PSScriptRoot
if (-not $Destino) { $Destino = Join-Path $env:LOCALAPPDATA 'Programs\Telomera' }

if (-not (Test-Path -LiteralPath (Join-Path $origem 'Telomera-GUI.ps1'))) {
    Write-Host 'Não encontrei o Telomera-GUI.ps1 ao lado deste instalador. Extraia o ZIP inteiro antes.' -ForegroundColor Red
    exit 1
}
function Get-ArgsOculto {
    # No Windows 11 com o Terminal do Windows como padrão, "-WindowStyle Hidden" não esconde o console: ele fica aberto e aparece no Alt+Tab.
    # "conhost.exe --headless" executa o PowerShell sem nenhuma janela de console.
    param([string]$Resto)
    if ($env:OS -ne 'Windows_NT' -or -not $env:SystemRoot) { return @{ Exe = 'powershell.exe'; Args = $Resto; Oculto = $false } }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $ch = Join-Path $env:SystemRoot 'System32\conhost.exe'
    $build = 0
    try { $build = [Environment]::OSVersion.Version.Build } catch { }
    if ($build -ge 22000 -and (Test-Path -LiteralPath $ch)) { return @{ Exe = $ch; Args = ('--headless "{0}" {1}' -f $ps, $Resto); Oculto = $true } }
    return @{ Exe = $ps; Args = $Resto; Oculto = $false }
}

$versao = '?'
$m = [regex]::Match([IO.File]::ReadAllText((Join-Path $origem 'Telomera.ps1')), "Versao\s*=\s*'([^']+)'")
if ($m.Success) { $versao = $m.Groups[1].Value }

# ----------------------------------------------------------------------------
# Migração de uma instalação antiga (quando o programa ainda se chamava WinDiag por dentro, até a 2.28.x):
# fecha o programa antigo se estiver aberto, move os dados (logs, histórico) para o nome novo, remove o
# registro e a tarefa agendada antigos, e deixa a pasta antiga para trás (apagada em instantes, depois que
# a instalação nova já estiver pronta — assim quem acabou de clicar em "Procurar atualização" não fica sem
# o programa por um instante).
function Invoke-MigracaoNomeAntigo {
    param([string]$DestinoNovo)
    $pastaAntiga = Join-Path $env:LOCALAPPDATA 'Programs\WinDiag'
    if (-not (Test-Path -LiteralPath $pastaAntiga) -or ($pastaAntiga -eq $DestinoNovo)) { return }
    Write-Host "  Encontrei uma instalação antiga (quando o programa se chamava WinDiag por dentro): $pastaAntiga" -ForegroundColor Cyan
    Write-Host '  Migrando para o nome Telomera...' -ForegroundColor Cyan

    # Fecha o programa antigo, se estiver aberto, para não travar a cópia dos dados.
    try {
        $abertos = @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction Stop |
            Where-Object { $_.CommandLine -match 'WinDiag-GUI\.ps1' -or $_.CommandLine -match 'WinDiag-Monitor\.ps1' })
        foreach ($p in $abertos) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch { }

    # Dados (logs, histórico de alterações, ícone em cache): move para a pasta com o nome novo.
    try {
        $dadosAntigos = Join-Path $env:LOCALAPPDATA 'WinDiag'
        $dadosNovos = Join-Path $env:LOCALAPPDATA 'Telomera'
        if ((Test-Path -LiteralPath $dadosAntigos) -and -not (Test-Path -LiteralPath $dadosNovos)) {
            Move-Item -LiteralPath $dadosAntigos -Destination $dadosNovos -Force
            Write-Host '  Dados (histórico, logs) migrados.' -ForegroundColor Cyan
        }
    } catch { Write-Host "  Não consegui migrar os dados antigos: $($_.Exception.Message)" -ForegroundColor Yellow }

    # Registro em "Aplicativos e recursos": remove a entrada antiga (a nova é criada mais adiante).
    try { Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\WinDiag' -Recurse -Force -ErrorAction SilentlyContinue } catch { }

    # Verificação semanal automática: se existia com o nome antigo, remove (o usuário pode reativar pelas
    # Configurações do Telomera, agora com o nome novo).
    try {
        if (Get-ScheduledTask -TaskName 'WinDiag - verificação semanal' -ErrorAction SilentlyContinue) {
            Unregister-ScheduledTask -TaskName 'WinDiag - verificação semanal' -Confirm:$false -ErrorAction SilentlyContinue
            Write-Host '  A verificação semanal automática estava ativada com o nome antigo; foi desligada. Reative pelas Configurações, se quiser.' -ForegroundColor Yellow
        }
    } catch { }

    # A pasta do programa antigo só é apagada depois que a instalação nova estiver pronta (mesma técnica do
    # desinstalador): assim, se algo ainda depender do caminho antigo por um instante, não quebra na hora.
    try {
        # Espera bem mais que o resto da instalação (compilar o Telomera.exe, criar atalhos, registrar) costuma
        # levar, porque o Atualizar-WinDiag.ps1 antigo (já em memória, de quem está atualizando agora) ainda
        # vai olhar o caminho antigo por um instante para reabrir o programa sozinho.
        $cmd = 'ping 127.0.0.1 -n 20 >nul & rd /s /q "{0}"' -f $pastaAntiga
        Start-Process -FilePath 'cmd.exe' -ArgumentList "/c $cmd" -WindowStyle Hidden
    } catch { }
}
Invoke-MigracaoNomeAntigo -DestinoNovo $Destino

Write-Host "Instalando o Telomera $versao em: $Destino" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$arquivos = @('Telomera.ps1', 'Telomera-GUI.ps1', 'Telomera-Worker.ps1', 'Telomera-Bench.ps1', 'Telomera-Extras.ps1', 'Telomera-Monitor.ps1',
              'Criar-Atalho.ps1', 'Criar-Atalho.bat', 'Abrir-Telomera.bat', 'Executar-Telomera.bat',
              'Desinstalar-Telomera.ps1', 'Desinstalar-Telomera.bat', 'Atualizar-Telomera.ps1', 'README.md', 'LICENSE', 'telomera.ico', 'telomera-logo.png',
              'TelomeraLauncher.cs', 'app.manifest', 'Compilar-Telomera.ps1')
$copiados = 0
foreach ($a in $arquivos) {
    $src = Join-Path $origem $a
    if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $Destino $a) -Force; $copiados++ }
}
Write-Host "  $copiados arquivo(s) copiado(s)."
try { Get-ChildItem -LiteralPath $Destino -Recurse -File | Unblock-File -ErrorAction SilentlyContinue } catch { }

# Launcher nativo (Telomera.exe): compila com o csc.exe do .NET Framework (já vem com o Windows) e assina
# com um certificado de teste. Se não der certo por algum motivo, a instalação continua normalmente: os
# atalhos passam a apontar para o PowerShell, como antes.
$telomeraExe = $null
try {
    $compilador = Join-Path $Destino 'Compilar-Telomera.ps1'
    if (Test-Path -LiteralPath $compilador) {
        $rc = & $compilador -Origem $Destino -Destino $Destino -Silencioso
        if ($rc.Ok) { $telomeraExe = $rc.Exe; Write-Host '  Telomera.exe compilado e assinado (certificado de teste).' -ForegroundColor Cyan }
        else { Write-Host "  Não consegui compilar o Telomera.exe ($($rc.Erro)); vai abrir pelo PowerShell normalmente." -ForegroundColor Yellow }
    }
} catch { Write-Host "  Não consegui compilar o Telomera.exe ($($_.Exception.Message)); vai abrir pelo PowerShell normalmente." -ForegroundColor Yellow }

# Atalhos (usa o Criar-Atalho da pasta de destino, para que apontem para a cópia instalada)
if (-not $SemPerguntas -and -not $PSBoundParameters.ContainsKey('ComoAdministrador')) {
    $r = Read-Host 'Abrir sempre como administrador? Necessário para corrigir problemas (o Windows vai pedir permissão a cada abertura) [S/n]'
    $ComoAdministrador = ($r -notmatch '^\s*[nN]')
}
$criar = Join-Path $Destino 'Criar-Atalho.ps1'
if ($ComoAdministrador) { & $criar -SemPerguntas -ComoAdministrador -Silencioso | Out-Null }
else { & $criar -SemPerguntas -Silencioso | Out-Null }

# Registro em "Aplicativos e recursos"
try {
    $chave = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Telomera'
    New-Item -Path $chave -Force | Out-Null
    $ico = Join-Path $env:LOCALAPPDATA 'Telomera\telomera-app.ico'
    $hd = Get-ArgsOculto ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f (Join-Path $Destino 'Desinstalar-Telomera.ps1'))
    $desinst = ('"{0}" {1}' -f $hd.Exe, $hd.Args)
    $props = @{
        DisplayName     = 'Telomera'
        DisplayVersion  = $versao
        Publisher       = 'TANUKI'
        InstallLocation = $Destino
        UninstallString = $desinst
        NoModify        = 1
        NoRepair        = 1
    }
    if ($telomeraExe -and (Test-Path -LiteralPath $telomeraExe)) { $props.DisplayIcon = $telomeraExe }
    elseif (Test-Path -LiteralPath $ico) { $props.DisplayIcon = $ico }
    foreach ($k in $props.Keys) { New-ItemProperty -Path $chave -Name $k -Value $props[$k] -Force | Out-Null }
} catch { Write-Host "  Não consegui registrar em Aplicativos e recursos: $($_.Exception.Message)" -ForegroundColor Yellow }

Write-Host ''
Write-Host 'Pronto! O Telomera foi instalado. Abra-o pelo atalho "Telomera" na Área de Trabalho ou no Menu Iniciar.' -ForegroundColor Green
Write-Host 'Para desinstalar: Configurações > Aplicativos > Telomera, ou o arquivo Desinstalar-Telomera.bat.'
