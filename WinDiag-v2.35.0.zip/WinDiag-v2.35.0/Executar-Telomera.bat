@echo off
title Telomera
rem Lancador do Telomera: de duplo clique neste arquivo.
rem Argumentos opcionais sao repassados, por exemplo:  Executar-Telomera.bat -SomenteLeitura
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Telomera.ps1" %*
if errorlevel 1 pause
