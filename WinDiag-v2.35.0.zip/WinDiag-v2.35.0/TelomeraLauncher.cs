// TelomeraLauncher: um .exe nativo que só existe para dar ao Telomera uma "porta de entrada" normal de
// aplicativo do Windows (ícone, versão, atalho que abre direto) e então chamar os scripts de sempre
// (Telomera-GUI.ps1 — o arquivo continua com esse nome; só a marca visível mudou).
// Não reescreve o Telomera em C#; só substitui o "duplo-clique no .bat" por um .exe assinado.
//
// O manifesto (app.manifest) pede "asInvoker" (não força administrador): quem decide pedir UAC é este
// próprio .exe, logo abaixo, para o pedido aparecer como "Telomera" (não como "Windows PowerShell").
// Se o usuário recusar, segue sem admin, só para verificação — igual o Telomera sempre permitiu.
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Principal;
using System.Windows.Forms;

// Nome e descrição que aparecem nas Propriedades do arquivo e no diálogo do UAC ("Program name"),
// em vez de só o nome do arquivo.
[assembly: AssemblyTitle("Telomera")]
[assembly: AssemblyDescription("Telomera")]
[assembly: AssemblyProduct("Telomera")]
[assembly: AssemblyCompany("TANUKI")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

internal static class TelomeraLauncher
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            bool administrador = EstaAdministrador();
            if (!administrador)
            {
                // Pede elevação pelo próprio Telomera.exe (assinado), para o UAC mostrar o nome e o ícone
                // certos em vez de "Windows PowerShell". Se aceitar, essa segunda cópia (já admin) é que
                // chama o script; a atual termina aqui.
                try
                {
                    var psiElevado = new ProcessStartInfo
                    {
                        FileName = Application.ExecutablePath,
                        Arguments = JuntarArgumentos(args),
                        UseShellExecute = true,
                        Verb = "runas"
                    };
                    Process.Start(psiElevado);
                    return 0;
                }
                catch (Win32Exception exUac)
                {
                    // 1223 = ERROR_CANCELLED: o usuário clicou "Não" no UAC. Segue sem admin (modo somente
                    // leitura). Qualquer outro erro (ex.: UAC desativado pelo administrador do PC) é real.
                    if (exUac.NativeErrorCode != 1223) throw;
                }
            }

            string pastaExe = Path.GetDirectoryName(Application.ExecutablePath) ?? Environment.CurrentDirectory;
            string script = Path.Combine(pastaExe, "Telomera-GUI.ps1");
            if (!File.Exists(script))
            {
                MessageBox.Show(
                    "Não encontrei o Telomera-GUI.ps1 ao lado do Telomera.exe." + Environment.NewLine +
                    "Pasta esperada: " + pastaExe,
                    "Telomera", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            string argumentos = "-NoProfile -ExecutionPolicy Bypass -File \"" + script + "\"" + JuntarArgumentos(args);

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = argumentos,
                UseShellExecute = false,
                WorkingDirectory = pastaExe,
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true
            };
            if (!administrador)
            {
                // Já perguntamos pelo UAC (pelo .exe) e foi recusado: avisa o script para não perguntar de
                // novo (ele teria sua própria lógica de auto-elevação, e isso pediria o UAC uma segunda vez).
                psi.EnvironmentVariables["TELOMERA_UAC_JA_PERGUNTADO"] = "1";
            }
            Process.Start(psi);
            return 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não consegui iniciar o Telomera:" + Environment.NewLine + Environment.NewLine + ex.Message,
                "Telomera", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    private static bool EstaAdministrador()
    {
        using (var identidade = WindowsIdentity.GetCurrent())
        {
            var principal = new WindowsPrincipal(identidade);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }

    private static string JuntarArgumentos(string[] args)
    {
        string r = "";
        foreach (string a in args)
        {
            // Repassa qualquer argumento recebido (ex.: -Agendada) direto para o script, entre aspas.
            r += " \"" + a.Replace("\"", "\\\"") + "\"";
        }
        return r;
    }
}
