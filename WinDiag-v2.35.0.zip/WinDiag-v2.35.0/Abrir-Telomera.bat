@echo off
title Telomera
rem Abre a interface grafica do Telomera (sem janela preta). O Windows pedira permissao de administrador.
rem Se o Telomera.exe nativo existir ao lado deste arquivo, usa ele; senao cai de volta no PowerShell.
if exist "%~dp0Telomera.exe" (
    start "" "%~dp0Telomera.exe"
    goto :fim
)
rem No Windows 11 o Terminal do Windows ignora a janela oculta; "conhost --headless" abre sem nenhuma janela.
setlocal
set "BUILD=0"
for /f "tokens=3 delims=." %%a in ('ver') do set "BUILD=%%a"
set "PRE="
if %BUILD% GEQ 22000 if exist "%SystemRoot%\System32\conhost.exe" set "PRE=conhost.exe --headless "
start "" %PRE%powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0Telomera-GUI.ps1"
:fim
