@echo off
setlocal
title Telomera - criar atalho
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Criar-Atalho.ps1"
echo.
pause
